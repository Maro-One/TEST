package middleware.security;

import middleware.entities.User;
import middleware.exception.MaxAttemptsException;
import middleware.services.UserService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private UserService userService;

    public UserDetailsServiceImpl(UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserDetails loadUserByUsername(String userName) {
        User user = userService.findByUsername(userName);
        if (user != null && user.getActive() != null && user.getActive().equals(Boolean.TRUE)) {
            if (!userService.isBlocked(user)) {
                return user;
            } else {
                throw new MaxAttemptsException(user.getLogin());
            }
        } else {
            throw new UsernameNotFoundException(userName);
        }
    }
}
