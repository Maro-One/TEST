package middleware.security;

import middleware.entities.User;
import middleware.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class AuthenticationSuccessEventListener
        implements ApplicationListener<AuthenticationSuccessEvent> {

    @Autowired
    private UserService userService;

    public void onApplicationEvent(AuthenticationSuccessEvent e) {
        User user = (User) e.getAuthentication().getPrincipal();
        userService.update(User.builder()
                .login(user.getLogin())
                .attempts(0)
                .lastAttempt(userService.toTimeZoneGMT1(new Date()))
                .build());
    }
}