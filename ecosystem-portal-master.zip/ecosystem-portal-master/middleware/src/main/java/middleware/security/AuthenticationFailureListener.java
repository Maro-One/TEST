package middleware.security;

import middleware.entities.User;
import middleware.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class AuthenticationFailureListener
        implements ApplicationListener<AuthenticationFailureBadCredentialsEvent> {

    @Autowired
    private UserService userService;

    public void onApplicationEvent(AuthenticationFailureBadCredentialsEvent e) {
        if (e.getException() instanceof BadCredentialsException) {
            User user = userService.findByUsername(e.getAuthentication().getPrincipal().toString());
            if (user != null) {
                int attempts = user.getAttempts();
                if (userService.isLockExpired(user)) {
                    attempts = 0;
                }
                userService.update(User.builder().login(user.getLogin())
                        .attempts(attempts + 1)
                        .lastAttempt(userService.toTimeZoneGMT1(new Date()))
                        .build());
            }
        }
    }
}
