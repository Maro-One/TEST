package middleware.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import middleware.entities.Credentials;
import middleware.entities.User;
import middleware.services.TokenService;
import org.json.simple.JSONObject;
import org.slf4j.MDC;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private final ObjectMapper objectMapper = new ObjectMapper();

    private TokenService tokenService;

    public JWTAuthenticationFilter(TokenService tokenService) {
        super();
        this.tokenService = tokenService;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request,
                                                HttpServletResponse response) {
        try {
            Credentials credentials = objectMapper.readValue(request.getInputStream(), Credentials.class);

            return getAuthenticationManager().authenticate(
                    new UsernamePasswordAuthenticationToken(credentials.getLogin(), credentials.getPassword())
            );
        } catch (IOException e) {
            throw new BadCredentialsException("Cannot process login request", e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest req,
                                            HttpServletResponse res,
                                            FilterChain chain,
                                            Authentication authResult) throws IOException {

        Map<String, Object> data = new HashMap<>();
        if (authResult.getPrincipal() instanceof User) {
            User loginUser = (User) authResult.getPrincipal();

            SecurityContextHolder.getContext().setAuthentication(authResult);

            Map<String,String> userData = Maps.newHashMap();
            userData.put("login", loginUser.getLogin());
            data.put("user", userData);
            String token = tokenService.getToken(data);
            res.addHeader("Authorization", token);

            try {
                Writer writer = res.getWriter();
                Map<String, String> userDataMFA = new HashMap<>();
                userDataMFA.put("login", loginUser.getLogin());
                writer.write((new JSONObject(userDataMFA)).toJSONString());
                writer.close();
                MDC.put("user", ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getLogin());
            } catch (Exception e) {
                log.error("supplier profile not found");
            }
        }
    }
}
