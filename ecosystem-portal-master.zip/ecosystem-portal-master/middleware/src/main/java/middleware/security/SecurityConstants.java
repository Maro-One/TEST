package middleware.security;

public class SecurityConstants {

    private SecurityConstants() {

    }
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STRING = "Authorization";
}
