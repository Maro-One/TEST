package middleware.security;

import middleware.entities.User;
import middleware.services.TokenService;
import middleware.services.UserService;
import org.slf4j.MDC;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


public class JWTAuthorizationFilter extends BasicAuthenticationFilter {

    private TokenService tokenService;
    private UserService userService;


    public JWTAuthorizationFilter(AuthenticationManager authManager, TokenService tokenService, UserService userService) {
        super(authManager);
        this.tokenService = tokenService;
        this.userService = userService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws IOException, ServletException {
        String header = req.getHeader("Authorization");

        if (header == null || !header.startsWith("Bearer")) {
            chain.doFilter(req, res);
            return;
        }

        UsernamePasswordAuthenticationToken authentication = getAuthentication(req);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(req, res);
    }

    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
        String token = request.getHeader("Authorization");
        if (token != null) {
            // parse the token.
            try {
                User loginUser = userService.findByUsername(tokenService.getUsername(token));
                if (loginUser != null) {
                    MDC.put("user", loginUser.getLogin());
                    return new UsernamePasswordAuthenticationToken(loginUser.getLogin(),
                            null, loginUser.getAuthorities());
                }

            } catch (Exception e) {
                return null;
            }
            return null;
        }
        return null;
    }
}
