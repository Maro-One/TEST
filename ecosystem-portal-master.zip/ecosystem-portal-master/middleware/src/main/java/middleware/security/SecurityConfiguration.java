package middleware.security;

import middleware.services.TokenService;
import middleware.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    @Autowired
    TokenService tokenService;
    @Autowired
    UserService userService;
    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Value("${security.jwt.token.secret}")
    private String secret;

    @Value("${security.jwt.token.expiration}")
    private long expiration;

    @Value("${swagger.enabled: false}")
    private boolean isSwaggerEnabled;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        List<String> authWhiteList = new ArrayList<>(Arrays.asList(
                "/login",
                "/captcha",
                "/reset-password",
                "/change-password",
                "/h2-console/**",
                "/health",
                "/prometheus",
                "/info",
                "/checktoken",
                "/features-toggle/",
                "/features-toggle/enabled/**"
        ));
        if (isSwaggerEnabled) {
            authWhiteList.addAll(Arrays.asList(
                    "/v2/api-docs",
                    "/swagger-resources/**",
                    "/swagger-ui.html**",
                    "/webjars/**"
                    )
            );
        }
        String[] antMatchers = authWhiteList.toArray(new String[0]);
        http.csrf().disable()
                .headers().frameOptions().sameOrigin().and()
                .authorizeRequests()
//                .antMatchers("/registration/create-user").hasRole("INTEGRATION")
                .antMatchers(antMatchers)
                .permitAll()
                .anyRequest().authenticated()
                .and()
                .addFilterBefore(createAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .addFilter(new JWTAuthorizationFilter(authenticationManager(), tokenService, userService))
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(userDetailsService);
        daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
        auth.authenticationProvider(daoAuthenticationProvider);
    }


    private JWTAuthenticationFilter createAuthenticationFilter() throws Exception {
        JWTAuthenticationFilter jwtAuthenticationFilter = new JWTAuthenticationFilter(tokenService);
        jwtAuthenticationFilter.setAuthenticationManager(authenticationManager());

        return jwtAuthenticationFilter;
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
