package middleware.resources;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import middleware.services.JobService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@RestController
@RequestMapping("/batch")
@RequiredArgsConstructor
public class JobRunnerResource {

    private final JobService jobService;
    private final ExecutorService executorService = Executors.newCachedThreadPool();
    @PostMapping("/oracle-history")
    public ResponseEntity<HttpStatus> runJob(){
        executorService.submit(jobService);
        return new ResponseEntity(HttpStatus.OK);
    }
}
