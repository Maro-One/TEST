package middleware.resources;


import middleware.dto.AttachmentFromOraclePageableResponse;
import middleware.dto.sap.AttachmentSAPDto.AttachmentRequestDto;
import middleware.services.AttachmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController

@RequestMapping("/attachments")

public class AttachmentResource {

    @Autowired
    private AttachmentService attachmentService;

    @PreAuthorize(value ="hasRole('ROLE_AGENCY')")
    @GetMapping("/approved-attachments/{orderId}")
    public  ResponseEntity<AttachmentFromOraclePageableResponse>  getAttachmentsfromSap(@PathVariable String orderId) {
        AttachmentFromOraclePageableResponse result = attachmentService.getAttachmentsfromSAPbyOrderId(orderId);
        return ResponseEntity.ok().body(result);

    }

    @PreAuthorize(value ="hasRole('ROLE_AGENCY')")
    @PostMapping("/approved-attachments/{orderId}/{requestSource}")
    public ResponseEntity<AttachmentFromOraclePageableResponse> getAttachmentsfromSapByRefCmdAppelList(
            @PathVariable String orderId,
            @PathVariable String requestSource,
            @RequestBody AttachmentRequestDto requestDto) {

        AttachmentFromOraclePageableResponse result = attachmentService.getAttachmentsfromSAPbyRefCmdAppelList(orderId, requestDto.getRefCmdAppelList(), requestSource);
        return ResponseEntity.ok().body(result);
    }




}
