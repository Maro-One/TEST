package middleware.resources;

import middleware.dto.ImportUsersResponse;
import middleware.entities.Credentials;
import middleware.entities.RegisterCredentials;
import middleware.entities.User;
import middleware.exception.ParseUsersCSVFileException;
import middleware.services.*;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;

@RestController
@RequestMapping("")
public class UserResource {

    private static final Logger log = LoggerFactory.getLogger(UserResource.class);

    @Autowired
    private UserService userService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private CaptchaService captchaService;

    @Autowired
    private UserExcelExporterService userExcelExporterService;

    @Value("${resetpassword.host}")
    private String linkResetPasswordHost;
    @Value("${resetpassword.path}")
    private String linkResetPasswordPath;

    @GetMapping("/test")
    public @ResponseBody
    ResponseEntity<String> test(User loginUser) {
        return ResponseEntity.ok("test");
    }

    @GetMapping("/log-out")
    public @ResponseBody
    ResponseEntity<Boolean> logOut(User loginUser) {
        log.info("logout of : {}", loginUser.getLogin());
        return ResponseEntity.ok(true);
    }

    @PostMapping("/reset-password")
    public @ResponseBody
    ResponseEntity resetPassword(@RequestBody Credentials credentials) {
        if (captchaService.isValidCaptcha(credentials.getEntryCode(), credentials.getCaptchaValue())) {
            log.info("Start resetting password");

            try {
                User user = userService.findByUsername(credentials.getLogin());
                if (user == null) {
                    log.error("Resetting password failed: user is null or inactive");
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Utilisateur non trouvé");
                }
                User userToken = new User();
                userToken.setLogin(user.getLogin());
                Map<String, Object> data = new HashMap<>();
                data.put("user", userToken);
                String url = linkResetPasswordHost.concat(linkResetPasswordPath);
                Map<String, Object> forMail = new HashMap<>();
                forMail.put("login", user.getLogin());
                forMail.put("allLink", url.concat(tokenService.getResetPasswordToken(data)));
                forMail.put("shortLink", url);
                log.info("The allLink of {} is {}" , user.getLogin(), url.concat(tokenService.getResetPasswordToken(data)));
                emailService.sendEmail(
                        user.getEmail(),
                        "Demande de récupération de mot de passe",
                        "reset_password",
                        forMail,
                        null,
                        null
                );
                log.info("Resetting password succeeded");
                return new ResponseEntity<>(HttpStatus.OK);
            } catch (Exception e) {
                log.error("Resetting password failed: internal error");
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else {
            log.error("captcha text is not valid .");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Captcha n'est pas valide, réessayer!");
        }

    }


    @PostMapping("/checktoken")
    public @ResponseBody
    ResponseEntity<Boolean> checkToken(@RequestBody RegisterCredentials credentials) {

        if (credentials.getToken() == null) {
            log.error("CheckToken, Token is null");
            return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
        } else {
            try {
                String userUsername = tokenService.getUsername(credentials.getToken());
                log.info("CheckToken, get Username {} from Token", userUsername);
                User user = userService.findByUsername(userUsername);
                if (user == null) {
                    log.error("CheckToken, no user for this Username {}", userUsername);
                    return new ResponseEntity<>(false, HttpStatus.NOT_FOUND);
                } else {
                    if (!user.isEnabled()) {
                        return new ResponseEntity<>(true, HttpStatus.OK);
                    } else {
                        return new ResponseEntity<>(false, HttpStatus.OK);
                    }
                }
            } catch (Exception e) {
                log.error("CheckToken failed");
                return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
            }
        }
    }

    @PostMapping("/change-password")
    public @ResponseBody
    ResponseEntity changePassword(@RequestBody RegisterCredentials credentials) {
        log.info("Start changing password");
        if (credentials.getFirstPassword() == null || credentials.getFirstPassword().isEmpty()
                || !credentials.getFirstPassword().equals(credentials.getSecondPassword()) || credentials.getToken() == null
                || !credentials.getFirstPassword().matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")
        ) {
            log.error("Changing password failed: the passwords don't match or are not valide (first:   {}, second : {})", credentials.getFirstPassword(), credentials.getSecondPassword());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        User user;
        try {
            String username = tokenService.getUsername(credentials.getToken());
            user = userService.findByUsername(username);
        } catch (Exception e) {
            log.error("Error while trying to get username from token or find user by username", e);
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        if (user == null) {
            log.error("Changing password failed: user not authorized");
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        try {
            userService.updateUserPassword(user, credentials.getFirstPassword());
        } catch (Exception e) {
            log.error("Error while trying to update user {}", user.getUsername(), e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.info("Changing password succeeded");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/userinfos")
    public ResponseEntity<User> userInfos(User user) {
        return ResponseEntity.ok(User.builder()
                .agencyName(user.getAgencyName())
                .lastName(user.getLastName())
                .firstName(user.getFirstName())
                .roleLabel(user.getRoleLabel())
                .build());
    }

    @PostMapping("/import-users")
    @PreAuthorize(value = "hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<ImportUsersResponse>> importUsers(@RequestParam("file") MultipartFile file) {
        ImportUsersResponse.ImportUsersResponseBuilder importUsersResponseBuilder = ImportUsersResponse.builder().saved(false);
        String filename = file.getOriginalFilename();
        if (file.isEmpty() || filename == null || filename.isEmpty() || !filename.substring(filename.lastIndexOf('.') + 1).equals("csv")) {
            importUsersResponseBuilder.message("Please select a valid CSV file");
            return new ResponseEntity(Collections.singletonList(importUsersResponseBuilder.build()), HttpStatus.OK);
        }
        try {
            List<ImportUsersResponse> importUsersResponses = userService.importUsers(file);
            return new ResponseEntity(importUsersResponses, HttpStatus.OK);
        } catch (ParseUsersCSVFileException e) {
            importUsersResponseBuilder.message(e.getMessage());
            return new ResponseEntity(Collections.singletonList(importUsersResponseBuilder.build()), HttpStatus.OK);
        } catch (Exception e) {
            importUsersResponseBuilder.message("Invalid csv file - [" + e.getMessage() + "]");
            return new ResponseEntity(Collections.singletonList(importUsersResponseBuilder.build()), HttpStatus.OK);
        }
    }

    @GetMapping("/export-users")
    @PreAuthorize(value = "hasRole('ROLE_ADMIN')")
    public void exportUsers (HttpServletResponse response) throws IOException {
        List<User> users= userService.exportUsers();

        ByteArrayInputStream byteArrayInputStream = userExcelExporterService.export(users);

        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=contacts.xlsx");
        IOUtils.copy(byteArrayInputStream, response.getOutputStream());
    }
}

