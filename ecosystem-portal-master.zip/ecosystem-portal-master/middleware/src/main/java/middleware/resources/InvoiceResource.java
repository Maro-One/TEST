package middleware.resources;

import lombok.extern.slf4j.Slf4j;
import middleware.dto.EventDto;
import middleware.dto.InvoicePageableResponse;
import middleware.dto.sap.invoice.InvoiceEventDto;
import middleware.dto.sap.invoice.SapInvoicePageableResponse;
import middleware.entities.User;
import middleware.services.InvoiceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/invoices")
public class InvoiceResource {

    private InvoiceService invoiceService;

    public InvoiceResource(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    @PreAuthorize(value ="hasRole('ROLE_AGENCY')")
    @GetMapping("/all/{orderId}/{requestSource}")
    public ResponseEntity<SapInvoicePageableResponse> getInvoiceList(User user, @PathVariable String orderId,
                                                                     @PathVariable String requestSource,
                                                                     @RequestParam int page,
                                                                     @RequestParam String sortBy,
                                                                     @RequestParam String order,
                                                                     @RequestParam(required = false) String status
    ) {
        log.info("Get all invoices API by orderID : {} ",orderId);
        return ResponseEntity.ok().body(invoiceService.getAllInvoices(user.getAgencyId(), orderId, page, sortBy, order, status, requestSource));
    }

    @PreAuthorize("hasRole('ROLE_AGENCY')")
    @GetMapping("/invoice-timeline")
    public ResponseEntity<List<InvoiceEventDto>> getInvoiceEvents(
            User user,
            @RequestParam(required = false) String sapInvoiceId,
            @RequestParam(required = false) String einvoiceId,
            @RequestParam String orderId,
            @RequestParam String creationDate,
            @RequestParam String invoiceStatus,
            @RequestParam String requestSource) {
        log.info("Get all events API by orderID : {} ",orderId);
        return invoiceService.getInvoiceEventsByNumberAndYear(user.getAgencyId(), sapInvoiceId, einvoiceId, orderId, creationDate, invoiceStatus, requestSource);
    }

}

