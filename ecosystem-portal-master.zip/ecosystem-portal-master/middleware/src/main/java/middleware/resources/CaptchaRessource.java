package middleware.resources;

import middleware.entities.Captcha;
import middleware.services.CaptchaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/captcha")
public class CaptchaRessource {

    private static final Logger log = LoggerFactory.getLogger(CaptchaRessource.class);

    @Autowired
    private CaptchaService captchaService;
    @GetMapping
    public ResponseEntity<Captcha> getCaptcha(){
        log.info("Getting captcha");
        Captcha captcha = captchaService.generateCaptcha();
        log.info("Getted captcha {}", captcha.getEntryCode());
        return ResponseEntity.ok(captcha);
    }
}
