package middleware.resources;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import middleware.dto.*;
import middleware.dto.sap.ImportPurchaseOrdersResponseSAP;
import middleware.dto.sap.OrdersRequest;
import middleware.dto.sap.SapOrderRequest;
import middleware.entities.User;
import middleware.services.EmailService;
import middleware.services.FundingRequestService;
import middleware.services.SapService;
import middleware.services.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/funding-request")
public class FundingRequestResource {

    @Autowired
    private FundingRequestService fundingRequestService;
    @Autowired
    private SupplierService supplierService;
    @Autowired
    private EmailService emailService;

    @Autowired
    private SapService sapService ;

    @PreAuthorize("hasRole('ROLE_AGENCY')")
    @GetMapping("/approved-funding-applicants")
    public ResponseEntity<ApplicantPageableResponse> getApprovedFundingApplicantsListByAgency(User user,
                                                                                              @RequestParam int page) {
        return ResponseEntity.ok()
                .body(fundingRequestService.getPaginatedFundingRequestsApplicants(user.getRoleLabel(), page, user.getAgencyId()));
    }

    @PreAuthorize("hasRole('ROLE_BUYER')")
    @GetMapping("/all-applicants")
    public ResponseEntity<ApplicantPageableResponse> getAllFundingApplicantsList(User user,
                                                                                 @RequestParam int page) {
        return ResponseEntity.ok()
                .body(fundingRequestService.getPaginatedFundingRequestsApplicants(user.getRoleLabel(), page, null));
    }

    @PreAuthorize("hasRole('ROLE_AGENCY')")
    @GetMapping("/approved-list/{bravoId}")
    public ResponseEntity<RequestPageableResponse> getApprovedFundingRequestsBySupplier(User user,
                                                                                        @PathVariable Long bravoId,
                                                                                        @RequestParam int page) throws IOException{

        return ResponseEntity.ok
                (fundingRequestService.getFundingRequestsForSupplierByStatusUsingSap(user.getRoleLabel(), user.getAgencyId(), bravoId, page, null));
    }

    @GetMapping("/supplier-list-all")
    @PreAuthorize("hasRole('ROLE_BUYER')")
    public ResponseEntity<RequestPageableResponse> getAllFundingRequestsBySupplier(User user,
                                                                                   @RequestParam int page, @RequestParam(required=false) String filter) {

        return ResponseEntity.ok
                (fundingRequestService.getFundingRequestsForSupplierByStatusWithOutPercentage(user.getRoleLabel(), null, null, page, filter));
    }

    @PreAuthorize("hasRole('ROLE_AGENCY')")
    @GetMapping("/approved-funding-request-detail/{orderId}/{requestId}/{requestSource}")
    public ResponseEntity<FundingRequestDto> getApprovedFundingRequestDetail(User user,
                                                                             @PathVariable String orderId,
                                                                             @PathVariable Integer requestId,
                                                                             @PathVariable String requestSource) {
        FundingRequestDto approvedFundingRequestDetail =
                fundingRequestService.getFundingRequestDetailUsingSap(user.getAgencyId(), orderId, requestId, requestSource);
        if (approvedFundingRequestDetail == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok().body(approvedFundingRequestDetail);
    }

    @GetMapping("/funding-request-by-supplier/{supplierId}")
    public ResponseEntity<RequestPageableResponse> getSupplierFundingRequestDetail(@PathVariable Long supplierId,
                                                                                   @RequestParam int page,
                                                                                   @RequestParam(required = false) String status) {
        RequestPageableResponse supplierFundingRequests = fundingRequestService.getSupplierFundingRequestsByStatus(supplierId, status, page);
        if (supplierFundingRequests == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok().body(supplierFundingRequests);
    }
    @PreAuthorize(value = "hasRole('ROLE_ADMIN')")
    @PostMapping("/import")
    public ResponseEntity<List<ImportPurchaseOrdersResponse>> importPurchaseOrders(@RequestParam("file") MultipartFile file) {
        String filename = file.getOriginalFilename();
        if (file.isEmpty() || filename == null || filename.isEmpty() || !filename.substring(filename.lastIndexOf('.') + 1).contains("xls")) {
            return new ResponseEntity("Please select a valid excel file", HttpStatus.OK);
        }
        try {
            List<ImportPurchaseOrdersResponse> importPurchaseOrdersResponses = fundingRequestService.importPurchaseOrders(file);
            return new ResponseEntity<>(importPurchaseOrdersResponses, HttpStatus.OK);
        } catch (IOException e) {
            log.error("Error while importing purchase orders", e);
            return new ResponseEntity("Couldn't read file.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PreAuthorize(value = "hasRole('ROLE_BUYER')")
    @PutMapping("/{id}")
    public void updateFundingRequest(User user, @PathVariable Integer id, @RequestParam String fundingAgencyEmail) throws MessagingException {
        FundingRequestDto fundingRequestDto = fundingRequestService.updateFundingRequest(id, user.getAgencyId());
        if (fundingRequestDto != null) {
            FundingRequestApplicantDto supplierInfo = supplierService.getSupplierInfo(fundingRequestDto.getBravoId());
            Map<String, Object> forMail = new HashMap<>();
            forMail.put("supplierName", supplierInfo != null ? supplierInfo.getCompanyName() : "");
            forMail.put("purchaseOrderDescription", fundingRequestDto.getPurchaseOrderDescription());

            emailService.sendEmail(
                    fundingAgencyEmail,
                    "Demande de financement",
                    "funding_agency_request",
                    forMail,
                    null,
                    null
            );
        }

    }

    @PreAuthorize(value = "hasRole('ROLE_BUYER')")
    @PutMapping("/refuse/{requestId}/{supplierBravoId}")
    public ResponseEntity refuseFundingRequest(User user, @PathVariable(name = "requestId") Integer requestId, @PathVariable(name = "supplierBravoId") Long supplierBravoId,
                                               @RequestParam(name = "comment") String comment) {
        FundingRequestApplicantDto suplierInfo = supplierService.getSupplierInfo(supplierBravoId);
        log.info("Refusing funding request {} for {}", requestId, suplierInfo.getProfessionalEmail());
        FundingRequestDto fundingRequestDto = fundingRequestService.refuseFundingRequest(requestId, comment, suplierInfo.getProfessionalEmail(), user.getAgencyId());
        if (fundingRequestDto == null) {
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity(fundingRequestDto, HttpStatus.OK);
    }

    // Using SAP
    @PreAuthorize(value = "hasRole('ROLE_ADMIN')")
    @PostMapping("/import-Requests-SAP")
    public ResponseEntity<List<ImportPurchaseOrdersResponseSAP>> importPurchaseOrdersSAP(@RequestParam("file") MultipartFile file) {
        String filename = file.getOriginalFilename();
        if (file.isEmpty() || filename == null || filename.isEmpty() || !filename.substring(filename.lastIndexOf('.') + 1).contains("xls")) {
            return new ResponseEntity("Please select a valid excel file", HttpStatus.OK);
        }
        try {
            List<ImportPurchaseOrdersResponseSAP> ImportPurchaseOrdersResponsesSAP = fundingRequestService.importPurchaseOrdersSAP(file);
            return new ResponseEntity<>(ImportPurchaseOrdersResponsesSAP, HttpStatus.OK);
        } catch (IOException e) {
            log.error("Error while importing purchase orders", e);
            return new ResponseEntity("Couldn't read file.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/supplier-list-all-SAP")
    @PreAuthorize("hasRole('ROLE_BUYER')")
    public ResponseEntity<RequestPageableResponse> getAllFundingRequestsBySupplierSap(User user,
                                                                                   @RequestParam int page, @RequestParam(required=false) String filter) throws IOException{

        return ResponseEntity.ok
                (fundingRequestService.getFundingRequestsForSupplierByStatusUsingSap(user.getRoleLabel(), null, null, page, filter));
    }
}

