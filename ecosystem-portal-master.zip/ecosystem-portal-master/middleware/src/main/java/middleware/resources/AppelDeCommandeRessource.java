package middleware.resources;


import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import middleware.dto.AppelDeCommandeFromOraclePageableResponse;
import middleware.services.AppelDeCommandeService;
import middleware.services.FundingRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController

@Slf4j
@RequestMapping("/appel-de-commandes")

public class AppelDeCommandeRessource {

    //Appel de commande
    @Autowired
    private AppelDeCommandeService appelDeCommandeServic;

    @PreAuthorize(value ="hasRole('ROLE_AGENCY')")
    @GetMapping("/approved-appel-de-commandes/{orderId}/{requestSource}")
    public ResponseEntity<AppelDeCommandeFromOraclePageableResponse> getAppelDeCommandesfromSap(@PathVariable String orderId,
                                                                                                @PathVariable String requestSource) throws JsonProcessingException, IOException {
        log.info("Start calling AppelDeCommandes API by orderId : {} ",orderId);
        AppelDeCommandeFromOraclePageableResponse result = appelDeCommandeServic.getAppelDeCommandesfromSapByOrderIdUsingSap(orderId, requestSource);
        return ResponseEntity.ok().body(result);

    }
}
