package middleware.resources;

import middleware.dto.ExportSupplierDto;
import middleware.dto.FundingRequestApplicantDto;
import middleware.dto.ScoringDto;
import middleware.dto.SupplierDto;
import middleware.entities.User;
import middleware.services.FundingRequestService;
import middleware.services.SupplierExcelExporterService;
import middleware.services.SupplierService;
import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/supplier")
public class SupplierResource {

    @Autowired
    private SupplierService supplierService;
    @Autowired
    private SupplierExcelExporterService supplierExcelExporterService;

    @PreAuthorize("hasAnyRole('ROLE_AGENCY','ROLE_BUYER')")
    @GetMapping("/supplier-info/{supplierId}")
    public ResponseEntity<FundingRequestApplicantDto> getApplicantsInfo(User user,
                                                                        @PathVariable Long supplierId) {
        FundingRequestApplicantDto supplierInfo;
        if (user.getRoleLabel().equals("ROLE_AGENCY")) {
            supplierInfo = supplierService.getSupplierInfoWithCheck(user.getAgencyId(), supplierId);
        } else {
            supplierInfo = supplierService.getSupplierInfo(supplierId);
        }
        if (supplierInfo != null) {
            return ResponseEntity.ok().body(supplierInfo);
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @PreAuthorize("hasAnyRole('ROLE_AGENCY','ROLE_BUYER')")
    @GetMapping("/supplier-scoring/{bravoId}")
    public ResponseEntity<ScoringDto> getApplicantsScorings(User user,
                                                            @PathVariable Long bravoId) {
        ScoringDto supplierScorings;
            supplierScorings = supplierService.getSupplierScoring(bravoId);
        return ResponseEntity.ok().body(supplierScorings);
    }

   // @PreAuthorize(value = "hasRole('ROLE_ADMIN')")
    @GetMapping("/export-suppliers")
    public void exportToExcel(HttpServletResponse response) throws IOException {
//        response.setContentType("application/octet-stream");
//        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
//        String currentDateTime = dateFormatter.format(new Date());
//
//        String headerKey = "Content-Disposition";
//        String headerValue = "attachment; filename=suppliers_" + currentDateTime + ".xlsx";
//        response.setHeader(headerKey, headerValue);
//
//        List<ExportSupplierDto> exportSupplierDto = supplierService.exportSuppliersFile();
//
//        SupplierExcelExporterService excelExporter =new SupplierExcelExporterService(exportSupplierDto);
//
//        excelExporter.export(response);
        List<ExportSupplierDto> exportSupplierDto = supplierService.exportSuppliersFile();

        ByteArrayInputStream byteArrayInputStream = supplierExcelExporterService.export(exportSupplierDto);

        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=contacts.xlsx");
        IOUtils.copy(byteArrayInputStream, response.getOutputStream());

    }
//    public ResponseEntity<List<ExportSupplierDto>> exportSuppliers() {
//        List<ExportSupplierDto> exportSupplierDto = supplierService.exportSuppliersFile();
//        return ResponseEntity.ok().body(exportSupplierDto);
//
//    }

    @PreAuthorize("hasRole('ROLE_AGENCY')")
    @GetMapping("/search-approved-funding-applicants")
    public ResponseEntity<List<FundingRequestApplicantDto>> searchApprovedFundingApplicantsList(User user,
                                                                                                @RequestParam String input) {
        return ResponseEntity.ok().body(supplierService.searchApprovedFundingRequestsApplicants(user.getAgencyId(), input));
    }

    @PreAuthorize("hasRole('ROLE_BUYER')")
    @GetMapping("/search-all-funding-applicants")
    public ResponseEntity<List<FundingRequestApplicantDto>> searchAllFundingApplicantsList(@RequestParam String input) {
        return ResponseEntity.ok().body(supplierService.searchAllFundingRequestsApplicants(input));
    }

    @GetMapping("/search-deactivated-suppliers")
    public void searchDeactivatedSuppliers() {
        supplierService.getAllSuppliersBackup();
    }
}

