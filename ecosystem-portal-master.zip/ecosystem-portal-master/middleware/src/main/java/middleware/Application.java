package middleware;

import middleware.conf.auth.BackendAuthenticationInterceptor;
import middleware.conf.stats.RestTemplateStatisticsLoggingFilter;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class,
        DataSourceTransactionManagerAutoConfiguration.class,
        HibernateJpaAutoConfiguration.class})
@EnableScheduling
@EnableAsync
@EnableBatchProcessing
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public RestTemplate restTemplate(
            RestTemplateBuilder builder,
            RestTemplateStatisticsLoggingFilter restTemplateStatisticsLoggingFilter,
            BackendAuthenticationInterceptor authenticationInterceptorInterceptor
    ) {
        return builder
                .setConnectTimeout(Duration.ofSeconds(15)).setReadTimeout(Duration.ofSeconds(500))
                .additionalInterceptors(restTemplateStatisticsLoggingFilter)
                .additionalInterceptors(authenticationInterceptorInterceptor)
                .build();
    }

    @Bean(name = "sapRestTemplate")
    public RestTemplate sapRestTemplate(
            RestTemplateBuilder builder,
            RestTemplateStatisticsLoggingFilter restTemplateStatisticsLoggingFilter
    ) {
        return builder
                .setConnectTimeout(Duration.ofSeconds(15)).setReadTimeout(Duration.ofSeconds(500))
                .additionalInterceptors(restTemplateStatisticsLoggingFilter)
                .build();
    }
}
