package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScoringCategoryDto {
    private String codeCategory;
    private List<String> positionning;
    private int positionningChangeRating;
    private List<Double> capabilitiesRating;
    private double capabilitiesChangeRating;
}
