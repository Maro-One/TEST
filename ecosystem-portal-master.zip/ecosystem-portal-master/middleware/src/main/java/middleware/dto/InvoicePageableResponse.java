package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvoicePageableResponse {
    private List<InvoiceDto> content;
    private Long count;
    private Set<String> statusList;
}
