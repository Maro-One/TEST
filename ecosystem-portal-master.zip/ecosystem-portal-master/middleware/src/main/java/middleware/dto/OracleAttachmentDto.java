package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OracleAttachmentDto {
    private Integer id;
    private String refAttachment;
    private String refCmdAppel;
    private String status;
    private LocalDate dateValidation;
    private Double montantAttachement;
    private String purchaseOrderId;
    private Long poHeaderIp;
}
