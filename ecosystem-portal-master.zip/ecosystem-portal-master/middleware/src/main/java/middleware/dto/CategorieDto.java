package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategorieDto {
    private String categoryCode;
    private String codeFamille;
    private String famille;
    private String codeSousFamille;
    private String sousFamille;
}
