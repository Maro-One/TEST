package middleware.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Buyer {
    private String fullName;
    private String employeeNumber;
    private String source;
    private String emailAddress;
}