package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SupplierBackupDto {
    private Long supplierId;
    private String companyName;
    private Long supplierBravoId;
    private String supplierOracleCode;
    private String supplierStatus;
    private String supplierSecondaryStatus;
}