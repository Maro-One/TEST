package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ExportSupplierDto {
    private Long supplierBravoId;
    private String companyName;
    private String supplierStatus;
    private String mainActivity;
    private String purchaseOrderRef;
    private String purchaseOrderId;
    private String status;
    private Date purchaseOrderApprovalDate;
    private String purchaseOrderDescription;
    private Long purchaseOrderAmount;
    private Long approvalAttachmentAmount;
    private Long billedAmount;
    private Long paidAmount;
    private Double achievementPercentage = 0.0D;
    private String secondaryStatus;
}
