package middleware.dto.mapper;
import middleware.dto.FundingRequestDto;
import middleware.dto.PurchaseOrderSearch;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class FundingRequestDtoMapper {
    public FundingRequestDtoMapper(){

    }
    public  static FundingRequestDto toDto(PurchaseOrderSearch purchaseOrderSearch, String bravo_id){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        FundingRequestDto out = null;
        if(purchaseOrderSearch != null) {
            out = new FundingRequestDto();
            out.setBravoId(Long.valueOf(bravo_id));
            out.setPurchaseOrderRef(purchaseOrderSearch.getPurchaseOrderReference());
            out.setPurchaseOrderId(purchaseOrderSearch.getPurchaseOrderReference());
            out.setStatus(purchaseOrderSearch.getApprovalStatus());
            out.setPurchaseOrderStatus(purchaseOrderSearch.getApprovalStatus().equals("approved") ? "Approuvée" : purchaseOrderSearch.getApprovalStatus());
            out.setPurchaseOrderApprovalDate(LocalDate.parse(purchaseOrderSearch.getApprovalDate(),formatter));
            out.setPurchaseOrderAmount(purchaseOrderSearch.getAmount());
            out.setPurchaseOrderDescription(purchaseOrderSearch.getDescription());
            out.setBilledAmount(purchaseOrderSearch.getBilledAmount());
            out.setPaidAmount(Double.valueOf(purchaseOrderSearch.getPaidAmount()));
            out.setPurchaseOrderPaymentTermsName(purchaseOrderSearch.getPurchaseOrderPaymentTermsName());
            out.setPurchaseOrderPaymentTermsDescription(purchaseOrderSearch.getPurchaseOrderPaymentTermsDescription());
            out.setSource("SAP");
            out.setPurchaseOrderCategory(purchaseOrderSearch.getCategoryDescription());
            out.setPurchaseOrderDescription(purchaseOrderSearch.getDescription());
        }
        return out;
    }
}
