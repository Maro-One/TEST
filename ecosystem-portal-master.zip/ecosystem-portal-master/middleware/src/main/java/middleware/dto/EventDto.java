package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.Map;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EventDto {
    private String eventCode;
    private Date eventDate;
    private String eventStatus;
    private Map<String, String> metadata;
}
