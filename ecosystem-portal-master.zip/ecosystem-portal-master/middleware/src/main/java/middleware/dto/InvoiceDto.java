package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoiceDto {
    private Long oracleInvoiceId;
    private Long einvoiceId;
    private String invoiceNumber;
    private String purchaseOrderId;
    private String purchaseOrderCode;
    private LocalDate creationDate;
    private LocalDate baseEcheance;
    private LocalDate dueDate;
    private Double amountHT;
    private String paymentStatus;
    private String approvalStatus;
    private String status;

}
