package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OracleFundingRequestDto {
    private Integer id;
    private String supplierOracleCode;
    private String purchaseOrderId;
    private String purchaseOrderRef;
    private String status;
    private LocalDate purchaseOrderApprovalDate;
    private Double purchaseOrderAmount;
    private Double achievementPercentage = 0.0D;
    private Double billedAmount;
    private Double paidAmount;
    private Double approvalAttachmentAmount;
    private String purchaseOrderPaymentTermsName;
    private String purchaseOrderCategory;
    private Double purchaseOrderAmountCallOf;
    private Double achievementPercentageCallOf = 0.0D;
    private String purchaseOrderDescription;
    private String  purchaseOrderStatus;
    private Long bravoId;
}
