package middleware.dto.sap.invoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import middleware.utils.InvoiceDateSerializer;
import middleware.utils.InvoiceDateDeserializer;
import java.time.LocalDate;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoiceEventDto {
    @JsonDeserialize(using = InvoiceDateDeserializer.class)
    @JsonSerialize(using = InvoiceDateSerializer.class)
    @JsonAlias({"eventdate", "eventDate"})
    private LocalDate eventDate;

    @JsonAlias({"eventstatus", "eventStatus"})
    private String eventStatus;

    /*@JsonAlias({"metadata", "sapMetadata"})
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private InvoiceEventMetadataDto invoiceEventMetadata;*/
    @JsonAlias({"metadata", "metadata"})
    private Map<String, String> metadata;
    @JsonAlias({"eventcode", "eventCode"})
    private String eventCode;
}
