package middleware.dto.sap;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ImportPurchaseOrdersResponseSAP {
    String CommandeID;
    String ContractID;
    Integer agencyIDString;
    boolean saved;
    String message;
}
