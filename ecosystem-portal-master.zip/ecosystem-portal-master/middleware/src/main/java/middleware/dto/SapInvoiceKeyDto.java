package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SapInvoiceKeyDto {
    String supplierSapId;
    String source;
    String errorMessage;
}
