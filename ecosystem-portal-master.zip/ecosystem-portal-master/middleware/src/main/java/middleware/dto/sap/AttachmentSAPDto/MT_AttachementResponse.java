package middleware.dto.sap.AttachmentSAPDto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import middleware.utils.MT_AttachementResponseDeserializer;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonDeserialize(using = MT_AttachementResponseDeserializer.class)
public class MT_AttachementResponse {
    @JsonProperty("content")
    private List<Content> content;
        @JsonProperty("messages")
    private List<Messages> messages;
}
