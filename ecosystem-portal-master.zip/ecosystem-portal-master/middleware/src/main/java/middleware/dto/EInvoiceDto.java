package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EInvoiceDto {
    private Long einvoiceId;
    private Long oracleInvoiceId;
    private String supplierId;
    private String supplierName;
    private String status;
    private String statusLabel;
    private String paymentStatus;
    private String invoiceNumber;
    private String orderNumber;
    private Long orderId;
    private Date factureDate;
    private String site;
    private Double amountHT;
    private String currency;
    private Date scanDate;
    private Date baseEcheance;
}
