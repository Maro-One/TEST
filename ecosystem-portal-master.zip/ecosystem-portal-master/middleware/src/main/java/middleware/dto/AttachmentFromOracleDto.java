
package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttachmentFromOracleDto {
    private String REF_ATTACHMENT;
    private String REF_CMD_APPEL;
    private  String STATUS;
    private String DATE_VALIDATION;
    private  String MONTANT_ATTACHEMENT;
    private  String DEVISE_ATTACHEMENT;
    private Date TYPE_LOOKUP_CODE;
    private  Double PO_HEADER_ID;
}