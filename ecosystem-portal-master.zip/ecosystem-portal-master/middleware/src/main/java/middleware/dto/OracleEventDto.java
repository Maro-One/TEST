package middleware.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OracleEventDto {
    private String oracleInvoiceId;
    private String eventCode;
    private LocalDate eventDate;
    private String invoicesNumber;
    private Double amount;
    private Double amountTtc;
    private Double amountReg;
    private String refReg;
    private LocalDate deadlineDate;
    private LocalDate rejectDate;
    private String eventStatus;
    private String eInvoiceId;

}
