package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor

public class AppelDeCommandeFromOracleDto {

    private String PO_NUM;
    private Long RELEASE_NUM;
    private String REF_CMD_APPEL;
    private Long PO_HEADER_ID;
    private String RELEASE_STATUS;
    private Date RELEASE_APPROVAL_DATE;
    private Long RELEASE_TOT_AMOUNT;
    private Long RELEASE_EXECUTION_PRCNT;

}
