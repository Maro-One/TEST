package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BravoDto {
    private boolean Exist;
    private String Message;
    private String Bravo_id;
}
