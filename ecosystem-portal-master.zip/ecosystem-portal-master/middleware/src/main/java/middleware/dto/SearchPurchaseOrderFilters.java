package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchPurchaseOrderFilters {
    private String status;
    private String cps;
    private String isApproved="true";
    private Integer minPrice;
    private Integer maxPrice;
    private String minApprovalDate;
    private String maxApprovalDate;
    private String purchaseOrderReference;
    private String employeeNumber;
    private String purchaseOrderDescription;
    private String supplierId;
    private String progressStatus;
    private String purchaseOrderId;
    private String operationUnit;
    private String supplierCode;
    private String rfqCode;
    private String onlyNewPurchaseOrders;
    private String posWithPendingReceipts;
    private String posWithPendingPayments;
    private Integer page;
    private  Integer size=20;
    private List<SortBy> sortBy;
    private String minDate;
    private String maxDate;
    private String emailAddress;

}
