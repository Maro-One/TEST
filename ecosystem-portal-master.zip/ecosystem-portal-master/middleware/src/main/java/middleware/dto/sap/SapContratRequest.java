package middleware.dto.sap;


import lombok.Data;

@Data
public class SapContratRequest {
    ContractsRequest Contracts;
}
