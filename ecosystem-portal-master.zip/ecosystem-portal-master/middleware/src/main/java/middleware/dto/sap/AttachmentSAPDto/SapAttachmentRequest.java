package middleware.dto.sap.AttachmentSAPDto;

import lombok.Data;

@Data
public class SapAttachmentRequest {
    String Ponumber;

}
