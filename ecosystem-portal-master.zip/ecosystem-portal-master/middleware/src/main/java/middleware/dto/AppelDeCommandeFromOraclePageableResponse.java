package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class AppelDeCommandeFromOraclePageableResponse {

    private List<AppelDeCommandeDto> content;
}
