package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ImportPurchaseOrdersResponse {
    String orderReference;
    Integer agencyIDString;
    String operationUnit;
    boolean saved;
    String message;
}
