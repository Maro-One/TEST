package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentDto {
    private String refAttachment;
    private String refCmdAppel;
    private String status;
    private LocalDate dateValidation;
    private Double montantAttachement;
    private String deviseAttachement;
    private String typeLookupCode;
    private Long poHeaderIp;
}
