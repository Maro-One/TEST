package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FundingAgencyAccountDto {
    private Integer id;
    private String email;
    private Integer fundingAgencyId;
}
