package middleware.dto.sap.AttachmentSAPDto;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Messages {
    @JsonProperty("type")
    private String type;
    @JsonProperty("message")
    private String message;
}
