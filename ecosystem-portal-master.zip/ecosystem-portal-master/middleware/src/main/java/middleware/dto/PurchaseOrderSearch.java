package middleware.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PurchaseOrderSearch {
    private PageInfo page;
    private String approvalDate;
    private Double amount;
    private String approvalStatus ;
    private String approved;
    private String billedAmountHT;
    private String businessUnitName;
    private Buyer buyer;
    private String categoryCode;
    private String categoryDescription ;
    private String city;
    private String closed;
    private String codeSiteLivraison;
    private String currency;
    private String deliveredAmountHT;
    private String description ;
    private String expectedDeliveryDateStatus;
    private String firstApprovalDate;
    private Double billedAmount ;
    private String deliveredAmount;
    private Double receivedAmount;
    private String operationUnit;
    private String orderType;
    private String purchaseOrderId;
    private PurchaseRequest purchaseRequest;
    private String referenceCode;
    private String supplierCommonCode;
    private String supplierCountry;
    private String supplierName;
    private String rfqReferenceCode;
    private String paidAmount;
    private String paidAmountHT;
    private String purchaseOrderPaymentTermsDescription;
    private String purchaseOrderPaymentTermsName;
    private String purchaseOrderReference;
    private String flag;
    private String isReceived;
    private String isDelivered;
    private String isBilled;
    private String LegacyPONumber;
    private String LegacyPONumberRef;
    private boolean isMigrated;
}
