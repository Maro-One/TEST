package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScoringCapabilities {
    private Double score;
    private Double changeRate;
    private String supplierPositioning;
    private int positionChangeRate;
    private String category;
}
