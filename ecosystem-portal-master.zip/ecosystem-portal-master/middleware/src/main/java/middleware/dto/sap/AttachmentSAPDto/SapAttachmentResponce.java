package middleware.dto.sap.AttachmentSAPDto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SapAttachmentResponce {
    @JsonProperty("MT_AttachementResponse")
    MT_AttachementResponse MT_AttachementResponse;
}
