package middleware.dto.sap.AttachmentSAPDto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Content {
    @JsonProperty("dateValidation")
    private String dateValidation;
    @JsonProperty("deviseAttachement")
    private String deviseAttachement;
    @JsonProperty("montantAttachement")
    private String montantAttachement;
    @JsonProperty("poHeaderIp")
    private String poHeaderIp;
    @JsonProperty("refAttachment")
    private String refAttachment;
    @JsonProperty("refCmdAppel")
    private String refCmdAppel;
    @JsonProperty("status")
    private String status;
}
