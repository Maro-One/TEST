package middleware.dto.sap;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Document {
    @JsonProperty("approvalAttachmentAmount")
    private String approvalAttachmentAmount;
    @JsonProperty("purchaseOrderPaymentTermsDescription")
    private String purchaseOrderPaymentTermsDescription;
    @JsonProperty("achievementPercentage_K")
    private Long achievementPercentage_K;
    @JsonProperty("purchaseOrderStatus")
    private String purchaseOrderStatus;
    @JsonProperty("purchaseOrderCategory")
    private String purchaseOrderCategory;
    @JsonProperty("purchaseOrderApprovalDate_K")
    private String purchaseOrderApprovalDate_K;
    @JsonProperty("achievementPercentage")
    private Double achievementPercentage = 0.0;
    @JsonProperty("billedAmount")
    private Double billedAmount;
    @JsonProperty("bravoId")
    private Long bravoId;
    @JsonProperty("businessUnitName")
    private String businessUnitName;
    @JsonProperty("paidAmount")
    private Double paidAmount;
    @JsonProperty("purchaseOrderAmount")
    private Double purchaseOrderAmount;
    @JsonProperty("purchaseOrderApprovalDate")
    private String purchaseOrderApprovalDate;
    @JsonProperty("purchaseOrderDescription")
    private String purchaseOrderDescription;
    @JsonProperty("purchaseOrderId")
    private String purchaseOrderId;
    @JsonProperty("purchaseOrderPaymentTermsName")
    private String purchaseOrderPaymentTermsName;
    @JsonProperty("ContractID")
    private Long ContractID;
    @JsonProperty("purchaseOrderStatus_K")
    private String purchaseOrderStatus_K;
    @JsonProperty("purchaseOrderDescription_K")
    private String purchaseOrderDescription_K;
}
