package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FundingRequestDto {
    private Integer id;
    private Long bravoId;
    private String supplierOracleCode;
    private String purchaseOrderId;
    private String purchaseOrderRef;
    private String businessUnitName;
    private String status;
    private String purchaseOrderStatus;
    private LocalDate purchaseOrderApprovalDate;
    private Double purchaseOrderAmount;
    private Double purchaseOrderAmountCallOf;
    private Double achievementPercentage = 0.0D;
    private Double achievementPercentageCallOf = 0.0D;
    private String purchaseOrderDescription;
    private Integer fundingAgencyId;
    private String fundingAgencyName;
    private Double approvalAttachmentAmount;
    private Double billedAmount;
    private Double paidAmount;
    private String purchaseOrderCategory;
    private String fundingAgencyEmail;
    private String purchaseOrderPaymentTermsName;
    private String purchaseOrderPaymentTermsDescription;
    private String companyName;
    private String source = null;

}
