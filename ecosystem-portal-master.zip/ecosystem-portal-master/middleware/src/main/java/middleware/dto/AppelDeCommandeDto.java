package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Date;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppelDeCommandeDto {
    private String purchaseOrderCode;
    private Long releaseNum;
    private String refCmdAppel;
    private String purchaseOrderId;
    private String status;
    private LocalDate approvalDate;
    private Double montantAppelDeCommande;
    private Double appelDeCommandePRCNT;
}
