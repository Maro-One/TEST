package middleware.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Assessment {
    private Long supplierBravoId;
    private String supplierPositioning;
    private String assessmentDate;
    private String assessmentType;
    private Double financialRating;
    private Double capabilitiesRating;
    private List<CategorieDto> categories;
}
