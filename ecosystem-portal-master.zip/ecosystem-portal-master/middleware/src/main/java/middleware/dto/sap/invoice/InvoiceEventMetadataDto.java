package middleware.dto.sap.invoice;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoiceEventMetadataDto {

    private Double amount;
    @JsonProperty("invoicenumber")
    private String invoiceNumber;
    private String ref;
    @JsonProperty("amountreg")
    private Double amountReg;
    @JsonProperty("amounttc")
    private Double amountTc;
    @JsonProperty("refreg")
    private String refReg;
}