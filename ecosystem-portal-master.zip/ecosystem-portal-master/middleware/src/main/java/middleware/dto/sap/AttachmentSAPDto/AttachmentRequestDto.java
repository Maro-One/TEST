package middleware.dto.sap.AttachmentSAPDto;

import lombok.Data;

import java.util.List;

@Data
public class AttachmentRequestDto {
    private List<String> refCmdAppelList;
    private int page;
    private String sortBy;
    private String order;

}
