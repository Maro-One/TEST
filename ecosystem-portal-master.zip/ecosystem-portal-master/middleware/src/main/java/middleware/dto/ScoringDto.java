package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScoringDto {
    private Long supplierBravoId;
    private String supplierStatus;
    private ScoringFinancial scoringFinancial;
    private List<ScoringCapabilities> scoringCapabilities;
    private String mainActivity;
}
