package middleware.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PageInfo {
    private Integer page;
    private Integer totalPages;
    private Integer totalElements;
    private List<Contents> contents;
}