package middleware.dto.sap.invoice;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import middleware.utils.InvoiceDateSerializer;
import middleware.utils.InvoiceDateDeserializer;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvoicePurchaseOrderResponseDto {
    @JsonAlias({"InvoiceNumber", "invoiceNumber"})
    private String invoiceNumber;
    @JsonAlias({"PurchaseOrderCode", "purchaseOrderCode"})
    private Long purchaseOrderCode;
    @JsonAlias({"CreationDate", "creationDate"})
    //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    @JsonSerialize(using = InvoiceDateSerializer.class)
    @JsonDeserialize(using = InvoiceDateDeserializer.class)
    private LocalDate creationDate;
    //@JsonAlias({"BaseEcheance", "baseEcheance"})
    //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    @JsonDeserialize(using = InvoiceDateDeserializer.class)
    @JsonSerialize(using = InvoiceDateSerializer.class)
    private LocalDate baseEcheance;
    @JsonAlias({"AmountHT", "amountHT"})
    private Double amountHT;
    @JsonAlias({"PaymentStatus", "paymentStatus"})
    private String paymentStatus;
    @JsonAlias({"ApprovalStatus", "approvalStatus"})
    private String approvalStatus;
    private String status;
    @JsonAlias({"SAPInvoiceId", "sapInvoiceId"})
    private Long sapInvoiceId;
    @JsonAlias({"DueDate", "dueDate"})
    @JsonSerialize(using = InvoiceDateSerializer.class)
    @JsonDeserialize(using = InvoiceDateDeserializer.class)
    private LocalDate dueDate;
    private Long einvoiceId;
}
