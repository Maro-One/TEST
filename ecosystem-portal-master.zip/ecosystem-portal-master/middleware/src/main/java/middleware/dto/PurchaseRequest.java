package middleware.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PurchaseRequest {
    private String purchaseRequestId;
    private String referenceCode;
}
