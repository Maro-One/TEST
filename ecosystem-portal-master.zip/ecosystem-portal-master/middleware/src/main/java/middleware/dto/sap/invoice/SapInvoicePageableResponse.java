package middleware.dto.sap.invoice;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import middleware.dto.sap.invoice.InvoicePurchaseOrderResponseDto;

import java.util.List;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SapInvoicePageableResponse {
    private List<InvoicePurchaseOrderResponseDto> content;
    private Long count;
    private Set<String> statusList;
}
