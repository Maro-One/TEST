package middleware.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundingRequestApplicantDto {
    private Long supplierBravoId;
    private String supplierOracleCode;
    private String companyName;
    private String dunsOrICECode;
    private String professionalEmail;
    private Long fundingRequestsCount;

    public FundingRequestApplicantDto(Long supplierBravoId){
        this.supplierBravoId= supplierBravoId;
    }
}
