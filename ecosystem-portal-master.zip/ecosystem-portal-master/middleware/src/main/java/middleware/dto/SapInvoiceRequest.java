package middleware.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class SapInvoiceRequest {
    private String supplierId;
    private String approvalStatus;
    private String paymentStatus;
    private String searchQuery;
    private String minPrice;
    private String maxPrice;
    private String minCreationDate;
    private String maxCreationDate;
    private String invoiceId;
    private String purchaseOrderId;
    private String page;
    private SortBy sortBy;
    private String supplierOracleId;
    private String  status; // for oracle status
}