package middleware.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SupplierDto {
    private String address;
    private List<CategorieDto> categories;
    private String city;
    private String classification;
    private String companyCode;
    private String companyEmail;
    private String companyName;
    private String country;
    private String lastModificationDate;
    private String mainContactEmail;
    private String mainContactFirstName;
    private String mainContactLastName;
    private String phoneNumber;
    private String site;
    private Long supplierId;
    private String supplierOracleCode;
    private String supplierStatus;
    private String zipCode;
    private String mainActivity;
    private String supplierSecondaryStatus;
    private Long supplierBravoId;
}
