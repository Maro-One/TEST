package middleware.dto.sap;

import lombok.Data;

import java.util.List;

@Data
public class SapRequest {
    ContractsRequest Contracts;
    OrdersRequest Orders;
}
