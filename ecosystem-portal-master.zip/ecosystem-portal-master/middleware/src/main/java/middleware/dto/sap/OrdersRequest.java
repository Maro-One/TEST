package middleware.dto.sap;

import lombok.Data;

import java.util.List;

@Data
public class OrdersRequest {
    List<String> OrderNumber;
}
