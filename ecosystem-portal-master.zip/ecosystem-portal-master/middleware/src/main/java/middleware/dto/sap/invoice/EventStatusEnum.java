package middleware.dto.sap.invoice;

import org.apache.commons.lang3.StringUtils;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum EventStatusEnum {

    INVOICE_PAID,
    IN_REJECTED,
    OTHER;
    private static final Set<String> rejectedListStatus = Stream.of("6", "8", "10", "Z6", "Z7")
            .collect(Collectors.toCollection(HashSet::new));
    private static final Set<String> payedListStatus = Stream.of("Invoice_Paid")
            .collect(Collectors.toCollection(HashSet::new));

    public static EventStatusEnum getEventCode(String sapCode) {
        if(rejectedListStatus.stream().anyMatch(status -> status.equals(sapCode)))
            return IN_REJECTED;
        else if (payedListStatus.stream().anyMatch(status -> StringUtils.equalsIgnoreCase(sapCode, status)))
            return INVOICE_PAID;
        else
            return OTHER;
    }

}