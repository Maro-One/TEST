package middleware.batch;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.*;
import middleware.utils.Helper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Slf4j
@RequiredArgsConstructor
public class JobHelper {

    private final RestTemplate restTemplate;
    private final BackendConfig backendConfig;
    private static final String FUNDING_REQUEST = "/funding-request/";
    private final LotusServiceConfig lotusServiceConfig;
    public void mergeData(FundingRequestApplicantDto fundingRequestApplicant) {
        log.info("Start merge data history for bravo Id : {} ", fundingRequestApplicant.getSupplierBravoId());
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl()
                        .concat(FUNDING_REQUEST.concat("supplier-funding-requests-all-by-bravo-id/").concat(String.valueOf(fundingRequestApplicant.getSupplierBravoId()))));

        ResponseEntity<FundingRequestDto[]> requestListResponse = restTemplate.getForEntity(fundingRequestsUrl.build().toUriString(), FundingRequestDto[].class);
        log.info("Found {} Funding Requests selected", requestListResponse.getBody() != null ? requestListResponse.getBody().length : 0);
        if(ObjectUtils.isNotEmpty(requestListResponse)) {
            if(requestListResponse.getBody() != null) {
                List<FundingRequestDto> requestList =  Arrays.asList(requestListResponse.getBody());

                if(CollectionUtils.isNotEmpty(requestList)) {
                    List<OracleFundingRequestDto> oracleFundingRequestList = new ArrayList<>();
                    requestList.forEach(fundingRequest -> {
                        if(StringUtils.isNotBlank(fundingRequest.getSupplierOracleCode())) {
                            OracleFundingRequestDto dto = buildAndSaveFundingRequestDetail(fundingRequestApplicant.getSupplierBravoId(), fundingRequest.getPurchaseOrderId(), fundingRequest.getId());
                            if(ObjectUtils.isNotEmpty(dto)) {
                                oracleFundingRequestList.add(dto);
                                log.info("persist oracleFundingRequest obj : {}",dto);
                            }

                        }
                    });

                    if(CollectionUtils.isNotEmpty(oracleFundingRequestList)) {

                        HttpEntity<List<OracleFundingRequestDto>> requestEntity = new HttpEntity<>(oracleFundingRequestList);
                        String purchaseOrderDetailUrl = lotusServiceConfig.getEcosystemUrl().concat("/oracle-history/funding-request");
                        restTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST,
                                requestEntity, OracleFundingRequestDto[].class);

                        oracleFundingRequestList.forEach(
                                oracleFundingRequestDto -> {

                                    List<AppelDeCommandeDto> appelDeCommandeList = getAppelDeCommandesfromOraclebyOrderId(oracleFundingRequestDto.getPurchaseOrderId());
                                    if(CollectionUtils.isNotEmpty(appelDeCommandeList)) {
                                        HttpEntity<List<AppelDeCommandeDto>> appelCmdRequestEntity = new HttpEntity<>(appelDeCommandeList);
                                        String appelCmdRequestUrl = lotusServiceConfig.getEcosystemUrl().concat("/oracle-history/appel-de-commandes");
                                        restTemplate.exchange(appelCmdRequestUrl, HttpMethod.POST,
                                                appelCmdRequestEntity, AppelDeCommandeDto[].class);
                                    }

                                    List<OracleAttachmentDto> attachments = getAttachmentsfromOracleByOrderId(oracleFundingRequestDto.getPurchaseOrderId());
                                    if(CollectionUtils.isNotEmpty(attachments)){
                                        HttpEntity<List<OracleAttachmentDto>> attachmentRequestEntity = new HttpEntity<>(attachments);
                                        String attachmentRequestUrl = lotusServiceConfig.getEcosystemUrl().concat("/oracle-history/attachments");
                                        restTemplate.exchange(attachmentRequestUrl, HttpMethod.POST,
                                                attachmentRequestEntity, OracleAttachmentDto[].class);
                                    }

                                    List<InvoiceDto> invoices = getPurchaseOrderInvoices(oracleFundingRequestDto.getPurchaseOrderId());
                                    if(CollectionUtils.isNotEmpty(invoices)) {
                                        HttpEntity<List<InvoiceDto>> invoicesRequestEntity = new HttpEntity<>(invoices);
                                        String invoicesRequestUrl = lotusServiceConfig.getEcosystemUrl().concat("/oracle-history/invoices");
                                        restTemplate.exchange(invoicesRequestUrl, HttpMethod.POST,
                                                invoicesRequestEntity, InvoiceDto[].class);

                                        invoices.forEach(
                                                invoice -> {
                                                    List<OracleEventDto> invoicesEvents = getInvoiceEvents(invoice.getOracleInvoiceId(), invoice.getEinvoiceId(), invoice.getPurchaseOrderId());

                                                    if(CollectionUtils.isNotEmpty(invoicesEvents)) {
                                                        //log.info("{}",invoicesEvents);
                                                        HttpEntity<List<OracleEventDto>> invoicesEventsRequestEntity = new HttpEntity<>(invoicesEvents);
                                                        String invoicesEventsRequestUrl = lotusServiceConfig.getEcosystemUrl().concat("/oracle-history/invoices-events");
                                                        restTemplate.exchange(invoicesEventsRequestUrl, HttpMethod.POST,
                                                                invoicesEventsRequestEntity, OracleEventDto[].class);
                                                    }
                                                }
                                        );
                                    }

                                });
                    }
                }
            }
        }
    }

    private OracleFundingRequestDto buildAndSaveFundingRequestDetail(Long bravoId, String orderId, Integer requestId) {
        log.info("Get funding request detail for orderId {} and request id {}",orderId, requestId);
        String fundingRequestUrl = "/funding-request/funding-request-detail/" + requestId;
        OracleFundingRequestDto dto = new OracleFundingRequestDto();
        try {
            FundingRequestDto fundingRequestDetailDto = restTemplate.getForObject(lotusServiceConfig.getEcosystemUrl() + fundingRequestUrl, FundingRequestDto.class);
            if (fundingRequestDetailDto != null && !fundingRequestDetailDto.getStatus().equals("PENDING")) {

                log.info("Got funding request detail {} for request id {}", fundingRequestDetailDto.getId(), requestId);

                FundingRequestDto poOracleDetails = getOracleOrderDetailsById(orderId);

                if(ObjectUtils.isNotEmpty(poOracleDetails)) {
                    dto.setBilledAmount(poOracleDetails.getBilledAmount());
                    dto.setPaidAmount(poOracleDetails.getPaidAmount());
                    dto.setPurchaseOrderCategory(poOracleDetails.getPurchaseOrderCategory());
                    dto.setPurchaseOrderPaymentTermsName(poOracleDetails.getPurchaseOrderPaymentTermsName());
                    dto.setPurchaseOrderStatus(poOracleDetails.getPurchaseOrderStatus());
                }

                Double approvalAttachmentAmount = getApprovedAttachments(orderId);
                dto.setBravoId(bravoId);
                dto.setApprovalAttachmentAmount(approvalAttachmentAmount);
                dto.setPurchaseOrderStatus(fundingRequestDetailDto.getPurchaseOrderStatus());
                dto.setPurchaseOrderApprovalDate(fundingRequestDetailDto.getPurchaseOrderApprovalDate());
                dto.setStatus(fundingRequestDetailDto.getStatus());
                dto.setAchievementPercentageCallOf(fundingRequestDetailDto.getAchievementPercentageCallOf());
                dto.setPurchaseOrderDescription(fundingRequestDetailDto.getPurchaseOrderDescription());
                dto.setSupplierOracleCode(fundingRequestDetailDto.getSupplierOracleCode());
                dto.setPurchaseOrderId(fundingRequestDetailDto.getPurchaseOrderId());
                dto.setPurchaseOrderRef(fundingRequestDetailDto.getPurchaseOrderRef());
                dto.setPurchaseOrderAmount(fundingRequestDetailDto.getPurchaseOrderAmount());
                dto.setPurchaseOrderAmountCallOf(fundingRequestDetailDto.getPurchaseOrderAmountCallOf());
                dto.setAchievementPercentage(0D);
                if (dto.getBilledAmount() != null && dto.getPurchaseOrderAmount() != null)
                    if(dto.getBilledAmount()> 0.0)
                        dto.setAchievementPercentage(dto.getBilledAmount() / dto.getPurchaseOrderAmount());
                if(dto.getAchievementPercentage().isInfinite())
                    dto.setAchievementPercentage(0D);
                return dto;
            }
        } catch (Exception e) {
            log.error("Error occured with cause {}", e.getMessage());
        }
        return null;
    }

    private FundingRequestDto getOracleOrderDetailsById(String orderId) {
        HttpEntity<List<String>> requestEntity = new HttpEntity<>(Collections.singletonList(orderId));
        log.info("Get additional information for purchase order {} from Oracle", orderId);
        String purchaseOrderDetailUrl = backendConfig.getBackEndGateWayUrl().concat("/purchase-orders/purchase-details");
        ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = restTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST,
                requestEntity, FundingRequestDto[].class);
        if(oracleDetailsResponse.getBody() != null) {
            List<FundingRequestDto> requestDtoList = Arrays.asList(oracleDetailsResponse.getBody());
            if (!requestDtoList.isEmpty()) {
                FundingRequestDto poOracleDetails = requestDtoList.get(0);
                log.info("Got additional information {} for purchaseOrder {} from oracle", poOracleDetails, orderId);
                return poOracleDetails;
            }
        }

        return null;
    }

    private Double getApprovedAttachments(String orderId) {
        log.info("Get approved attachments total amount for purchase order {}", orderId);
        HttpEntity<Long> requestEntity = new HttpEntity<>(Long.parseLong(orderId.replaceAll("[^0-9]","")));
        try {
            ResponseEntity<Double> attachmentResponse = restTemplate.
                    exchange(backendConfig.getOracleEbsURL()+"/attachments/approved-amount",
                            HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<Double>() {});
            return attachmentResponse.getBody() == null ? 0D : attachmentResponse.getBody();
        } catch (Exception ex) {
            log.error("Error occured with cause {}", ex.getMessage());
        }
        return 0D;
    }

    private List<OracleAttachmentDto> getAttachmentsfromOracleByOrderId(String orderId) {
        log.info("get Attachments by orderId {}", orderId);
        List<OracleAttachmentDto> oracleAttachmentList = new ArrayList<>();
        String OracleEbsUrl=backendConfig.getOracleEbsURL()+"/attachments/approved-attachments";
        UriComponentsBuilder attachmentsUrl = UriComponentsBuilder.fromHttpUrl(OracleEbsUrl);
        attachmentsUrl.queryParam("orderId", orderId.substring(1));

        try {
            AttachmentFromOraclePageableResponse result = restTemplate.getForObject(attachmentsUrl.build().toUriString(), AttachmentFromOraclePageableResponse.class);
            if(ObjectUtils.isNotEmpty(result)) {
                if(CollectionUtils.isNotEmpty(result.getContent())) {
                    result.getContent().forEach(
                            attachmentDto -> {
                                OracleAttachmentDto dto = OracleAttachmentDto.builder()
                                        .refAttachment(attachmentDto.getRefAttachment())
                                        .montantAttachement(attachmentDto.getMontantAttachement())
                                        .status(attachmentDto.getStatus())
                                        .refCmdAppel(attachmentDto.getRefCmdAppel())
                                        .dateValidation(attachmentDto.getDateValidation())
                                        .purchaseOrderId(orderId)
                                        .poHeaderIp(attachmentDto.getPoHeaderIp()).build();
                                oracleAttachmentList.add(dto);
                            }

                    );
                }
            }

        } catch (Exception ex) {
            log.error("Error occured with cause {}", ex.getMessage());
        }
        log.info("Found {} Attachments selected", oracleAttachmentList.size());
        return oracleAttachmentList;
    }

    private List<InvoiceDto> getPurchaseOrderInvoices(String orderId) {
        List<InvoiceDto> invoicesList = new ArrayList<>();
        log.info("get Invoices by orderId {}", orderId);
        try {
            HttpEntity<List<String>> requestBody = new HttpEntity<>(Collections.emptyList());
            String invoicesUrl = backendConfig.getBackEndGateWayUrl().concat("/purchase-orders/").concat(orderId).concat("/invoices");
            invoicesList = Helper.emptyIfNull(restTemplate.exchange(invoicesUrl, HttpMethod.POST, requestBody, InvoiceDto[].class).getBody());
            Helper.emptyIfNull(invoicesList)
                    .forEach(invoice -> {
                        invoice.setStatus(Helper.getReverseStatus(invoice.getStatus()));
                        invoice.setPurchaseOrderId(orderId);
                    });

        } catch (Exception ex) {
            log.error("Error occured with cause {}", ex.getMessage());
        }
        log.info("Found {} Invoices selected", invoicesList.size());
        return invoicesList;
    }

    private List<OracleEventDto> getInvoiceEvents(Long invoiceOracleId, Long einvoiceId, String orderId) {
        log.info("get invoice events, invoiceOracleId: {}, einvoiceId: {}, orderId: {}", invoiceOracleId, einvoiceId, orderId);
        String INVOICE_ORACLE_ID = "invoiceOracleId";
        DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss zzz yyyy").withLocale(Locale.ENGLISH);
        List<EventDto> oracleEvents = new ArrayList<>();
        List<EventDto> eInvoiceEvents = new ArrayList<>();
        List<OracleEventDto> oracleEventsList = new ArrayList<>();

            if (invoiceOracleId != null) {
                log.info("get invoice events from oracle with invoiceOracleId: {}", invoiceOracleId);
                UriComponentsBuilder oracleUriBuilder = UriComponentsBuilder.fromUriString(backendConfig.getOracleEbsURL().concat("/supplier/invoice-timeline"));
                oracleUriBuilder.queryParam(INVOICE_ORACLE_ID, invoiceOracleId);
                try {
                    EventDto[] events = restTemplate.getForObject(oracleUriBuilder.build().toUriString(), EventDto[].class);
                    if(events != null)
                        log.info("got {} events from oracle", events.length);
                    oracleEvents = Helper.emptyIfNull(events);
                } catch (Exception ex) {
                    log.error("Error occured with cause {}", ex.getMessage());
                }

            } else {
                log.info("invoiceOracleId is not provided");
            }
            if (einvoiceId != null) {
                log.info("get invoice events from e-invoice with einvoiceId: {} and invoiceOracleId: {}", einvoiceId, invoiceOracleId);
                MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
                params.add("einvoiceId", String.valueOf(einvoiceId));
                if(invoiceOracleId != null)
                    params.add(INVOICE_ORACLE_ID, String.valueOf(invoiceOracleId));

                UriComponentsBuilder eInvoiceUriBuilder = UriComponentsBuilder.fromUriString(backendConfig.getEInvoiceURL().concat("/supplier/timeline"));
                eInvoiceUriBuilder.queryParams(params);

                try {
                    EventDto[] events = restTemplate.getForObject(eInvoiceUriBuilder.build().toUriString(), EventDto[].class);
                    if(events != null) {
                        log.info("got {} events from e-invoice", events.length);
                        eInvoiceEvents = eInvoiceEventMapping(events);
                    }

                    log.info("e-invoice mapped events size: {}", eInvoiceEvents.size());
                } catch (Exception ex) {
                    log.error("Error occured with cause {}", ex.getMessage());
                }

                // GET INVOICE FROM E-INVOICE
                try {
                    eInvoiceUriBuilder = UriComponentsBuilder.fromUriString(backendConfig.getEInvoiceURL().concat("/supplier/invoices"));
                    eInvoiceUriBuilder.queryParams(params);
                    EInvoiceDto eInvoiceDto = restTemplate.getForObject(eInvoiceUriBuilder.build().toUriString(), EInvoiceDto.class);
                    // POPULATE METADATA
                    if (eInvoiceDto != null) {
                        log.info("got eInvoiceDto, invoice number: {}", eInvoiceDto.getInvoiceNumber());
                        log.info("populating metadata for events with code IN_PROCESS_OF_ACCOUNTING, IN_REJECTED_AFTER_SCAN & IN_REJECTED");
                        eInvoiceEvents.forEach(eventDto -> {
                            Map<String, String> metadata = new HashMap<>();
                            metadata.put("eInvoiceId", einvoiceId.toString());
                            metadata.put("invoiceNum", eInvoiceDto.getInvoiceNumber());
                            switch (eventDto.getEventCode()) {
                                case "IN_PROCESS_OF_ACCOUNTING":
                                    metadata.put("invoiceNum", eInvoiceDto.getInvoiceNumber());
                                    metadata.put("amount", eInvoiceDto.getAmountHT().toString());
                                    metadata.put("deadlineDate", eInvoiceDto.getBaseEcheance() != null?eInvoiceDto.getBaseEcheance().toString():"");
                                    break;
                                case "IN_REJECTED_AFTER_SCAN":
                                case "IN_REJECTED":
                                    metadata.put("invoiceNum", eInvoiceDto.getInvoiceNumber());
                                    metadata.put("amount", eInvoiceDto.getAmountHT().toString());
                                    metadata.put("rejectDate", eventDto.getEventDate().toString());
                                    break;
                                default:
                                    break;
                            }
                            eventDto.setMetadata(metadata);
                        });
                    }
                } catch (Exception ex) {
                    log.error("Error occured with cause {}", ex.getMessage());
                }
                log.info("get invoice from e-invoice");

            } else {
                log.info("einvoiceId is not provided");
            }

            List<EventDto> concatenatedEvents =
                    Stream
                            .concat(eInvoiceEvents.stream(), oracleEvents.stream())
                            .collect(Collectors.toList());

            if(CollectionUtils.isNotEmpty(concatenatedEvents)) {
                concatenatedEvents.forEach(
                        eventDto -> {
                            OracleEventDto oracleEvent = OracleEventDto.builder()
                                    .eventCode(eventDto.getEventCode())
                                    .eventDate(eventDto.getEventDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())
                                    .eventStatus(eventDto.getEventStatus()).build();
                            if(invoiceOracleId != null)
                                oracleEvent.setOracleInvoiceId(String.valueOf(invoiceOracleId));
                            if(MapUtils.isNotEmpty(eventDto.getMetadata())) {
                                if(eventDto.getMetadata().containsKey("eInvoiceId"))
                                    oracleEvent.setEInvoiceId(eventDto.getMetadata().get("eInvoiceId"));

                                if(eventDto.getMetadata().containsKey("invoiceNum"))
                                    oracleEvent.setInvoicesNumber(eventDto.getMetadata().get("invoiceNum"));

                                if(eventDto.getMetadata().containsKey("invoicesNumber"))
                                    oracleEvent.setInvoicesNumber(eventDto.getMetadata().get("invoicesNumber"));

                                if(eventDto.getMetadata().containsKey("refReg"))
                                    oracleEvent.setRefReg(eventDto.getMetadata().get("refReg"));

                                if(eventDto.getMetadata().containsKey("amount")) {
                                    if(StringUtils.isNotBlank(eventDto.getMetadata().get("amount")))
                                        oracleEvent.setAmount(Double.parseDouble(eventDto.getMetadata().get("amount")));
                                }
                                if(eventDto.getMetadata().containsKey("amountTTC")) {
                                    if(StringUtils.isNotBlank(eventDto.getMetadata().get("amountTTC")))
                                        oracleEvent.setAmountTtc(Double.parseDouble(eventDto.getMetadata().get("amountTTC")));
                                }
                                if(eventDto.getMetadata().containsKey("amountReg")) {
                                    if(StringUtils.isNotBlank(eventDto.getMetadata().get("amountReg")))
                                        oracleEvent.setAmountReg(Double.parseDouble(eventDto.getMetadata().get("amountReg")));
                                }
                                if(eventDto.getMetadata().containsKey("deadlineDate")) {
                                    if(StringUtils.isNotBlank(eventDto.getMetadata().get("deadlineDate")))
                                        oracleEvent.setDeadlineDate(LocalDate.parse(eventDto.getMetadata().get("deadlineDate"), DATE_TIME_FORMATTER));
                                }
                                if(eventDto.getMetadata().containsKey("rejectDate")) {
                                    if(StringUtils.isNotBlank(eventDto.getMetadata().get("rejectDate")))
                                        oracleEvent.setRejectDate(LocalDate.parse(eventDto.getMetadata().get("rejectDate"), DATE_TIME_FORMATTER));
                                }
                            }
                            oracleEventsList.add(oracleEvent);
                        }
                );
            }

            log.info("concatenated events size: {}", concatenatedEvents.size());
            return oracleEventsList;
    }

    private List<EventDto> eInvoiceEventMapping(EventDto[] doneEInvoicesEvents) {
        if (doneEInvoicesEvents.length > 0) {
            Stack<EventDto> result = new Stack<>();
            for (EventDto event : doneEInvoicesEvents) {
                event.setEventCode(Helper.getReverseStatus(event.getEventCode()));
                if (result.empty()) {
                    result.push(event);
                } else if (event.getEventCode() != null && !event.getEventCode().equals(result.peek().getEventCode())) {
                    result.push(event);
                } else {
                    result.pop();
                    result.push(event);
                }
            }
            return result;
        }
        return Collections.emptyList();
    }

    private List<AppelDeCommandeDto> getAppelDeCommandesfromOraclebyOrderId(String orderId) {
        log.info("get Appel de commandes by orderId {}", orderId);
        List<AppelDeCommandeDto> appelDeCommandeList = new ArrayList<>();
        String OracleEbsUrl=backendConfig.getOracleEbsURL().concat("/appel-de-commandes/approved-appel-de-commandes");
        UriComponentsBuilder appelDeCommandesUrl = UriComponentsBuilder.fromHttpUrl(OracleEbsUrl);
        appelDeCommandesUrl.queryParam("PoHeaderId", orderId.substring(1));
        try {
            AppelDeCommandeFromOraclePageableResponse result = restTemplate.getForObject(appelDeCommandesUrl.build().toUriString(), AppelDeCommandeFromOraclePageableResponse.class);
            if(ObjectUtils.isNotEmpty(result))
                appelDeCommandeList = result.getContent();
        } catch (Exception ex) {
            log.error("Error occured with cause {}", ex.getMessage());
        }
        log.info("Found {} Appel de commandes selected", appelDeCommandeList.size());
        return appelDeCommandeList;
    }

}
