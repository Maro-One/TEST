package middleware.batch;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.FundingRequestApplicantDto;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.item.ItemReader;
import org.springframework.context.annotation.Configuration;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class OracleDataHistoryJob {

    private final JobLauncher jobLauncher;
    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;
    private final RestTemplate restTemplate;
    private final LotusServiceConfig lotusServiceConfig;
    private final BackendConfig backendConfig;
    private final OracleDataHistoryJobWriter oracleDataHistoryJobWriter;

    @Bean
    public ItemReader<FundingRequestApplicantDto> bravoRestReader(RestTemplate restTemplate, LotusServiceConfig lotusServiceConfig, BackendConfig backendConfig) {
        return new RestReader(restTemplate, lotusServiceConfig, backendConfig);
    }

    @Bean
    public Step mergeDataStep() {
        return stepBuilderFactory.get("mergeOracleDataStep")
                .<FundingRequestApplicantDto, FundingRequestApplicantDto>chunk(200)
                .reader(bravoRestReader(restTemplate, lotusServiceConfig, backendConfig))
                .writer(this.oracleDataHistoryJobWriter)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(10)
                .listener(new OracleDataHistorySkipListener())
                .build();
    }


    @Bean(name = "oracleDataHistoriesJob")
    public Job job() {
        return jobBuilderFactory.get("OracleDataHistoryJob")
                .incrementer(new RunIdIncrementer())
                .flow(mergeDataStep())
                .end()
                .build();
    }

    public void run() throws Exception {
        JobExecution execution = jobLauncher.run(
                job(),
                new JobParametersBuilder().addLong("JobID", System.nanoTime())
                        .toJobParameters()
        );
        log.info("Exit status: {}", execution.getStatus());
    }
}
