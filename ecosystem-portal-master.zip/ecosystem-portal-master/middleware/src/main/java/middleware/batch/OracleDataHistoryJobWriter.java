package middleware.batch;

import lombok.extern.slf4j.Slf4j;
import middleware.dto.FundingRequestApplicantDto;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class OracleDataHistoryJobWriter implements ItemWriter<FundingRequestApplicantDto> {

    private final JobHelper jobHelper;

    @Autowired
    public OracleDataHistoryJobWriter(JobHelper jobHelper) {
        this.jobHelper = jobHelper;
    }

    @Override
    public void write(List bravoIds) {
        if(CollectionUtils.isNotEmpty(bravoIds))
            CollectionUtils.emptyIfNull((List<FundingRequestApplicantDto>) bravoIds).forEach(jobHelper::mergeData);
        else
            log.warn("Empty bravo Id");
    }
}
