package middleware.batch;

import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.FundingRequestApplicantDto;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.batch.item.ItemReader;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Slf4j
public class RestReader implements ItemReader<FundingRequestApplicantDto> {

    private final LotusServiceConfig lotusServiceConfig;
    private final RestTemplate restTemplate;
    private final BackendConfig backendConfig;

    private int nextBravoIndex;
    private List<FundingRequestApplicantDto> bravoIdData;

    RestReader(RestTemplate restTemplate, LotusServiceConfig lotusServiceConfig, BackendConfig backendConfig) {
        this.restTemplate = restTemplate;
       this.backendConfig = backendConfig;
        this.lotusServiceConfig = lotusServiceConfig;
        nextBravoIndex = 0;
    }

    @Override
    public FundingRequestApplicantDto read() throws Exception {
        log.info("Reading the information of the next bravo id");

        if (bravoIdDataIsNotInitialized()) {
            bravoIdData = fetchbravoIdDataFromAPI();
        }

        FundingRequestApplicantDto nextBravoId = null;

        if (nextBravoIndex < bravoIdData.size()) {
            nextBravoId = bravoIdData.get(nextBravoIndex);
            nextBravoIndex++;
        }

        if(Objects.nonNull(nextBravoId))
            log.info("Found bravo id: {}", nextBravoId);
        else {
            nextBravoIndex = 0;
            bravoIdData = null;
        }

        return nextBravoId;
    }

    private boolean bravoIdDataIsNotInitialized() {
        return this.bravoIdData == null;
    }

    private List<FundingRequestApplicantDto> fetchbravoIdDataFromAPI() {
        log.info("Fetching bravo ids data from an external API by using the url");

        ResponseEntity<Long[]> response = restTemplate.getForEntity(lotusServiceConfig.getEcosystemUrl().concat("/funding-request/all-funding-requests-bravo-ids"), Long[].class);
        Long[] bravoIdData = response.getBody();
        log.info("Found {} bravo ids", bravoIdData != null ? bravoIdData.length : 0);

        if (bravoIdData != null) {
            HttpEntity<Object> requestEntity = new HttpEntity<>(new HashSet<>(Arrays.asList(bravoIdData)));
            Map<String, Integer> params = new HashMap<>();
            List<FundingRequestApplicantDto> fundingRequestApplicantList = new ArrayList<>();
            List<FundingRequestApplicantDto> fundingRequestApplicantListTmp = new ArrayList<>();
            int page = 0;

            while((CollectionUtils.isEmpty(fundingRequestApplicantListTmp) && page==0) || (CollectionUtils.isNotEmpty(fundingRequestApplicantListTmp) && page>=1)) {
                fundingRequestApplicantListTmp = new ArrayList<>();
                params.put("page", page);
                ResponseEntity<List<FundingRequestApplicantDto>> profileResponse = restTemplate.
                        exchange(backendConfig.getBravoURL() + "/supplier/profilesBySupplierIds?page=".concat(String.valueOf(page)), HttpMethod.POST, requestEntity,
                                new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                                }, params);
                if( profileResponse.getBody() != null)
                    if(profileResponse.getBody().size()>0) {
                        fundingRequestApplicantList.addAll(profileResponse.getBody());
                        fundingRequestApplicantListTmp.addAll(profileResponse.getBody());
                    }

                page++;

                log.info("Found {} funding request applicants selected", profileResponse.getBody() != null ? profileResponse.getBody().size() : 0);
            }

            return fundingRequestApplicantList;
        }

        return new ArrayList<>();
    }
}
