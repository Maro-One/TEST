package middleware.batch;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.SkipListener;

@Slf4j
public class OracleDataHistorySkipListener implements SkipListener {

    @Override
    public void onSkipInRead(Throwable t) {
        log.error("Enregistrement écarté lors de la lecture", t);
    }

    @Override
    public void onSkipInWrite(Object item, Throwable t) {
        log.error("Enregistrement écarté lors de l'écriture", t);
    }

    @Override
    public void onSkipInProcess(Object item, Throwable t) {
        log.error("Enregistrement écarté lors du traitement", t);
    }
}
