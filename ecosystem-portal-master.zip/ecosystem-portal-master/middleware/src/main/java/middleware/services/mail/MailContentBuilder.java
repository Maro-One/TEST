package middleware.services.mail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.Map;

@Service
public class MailContentBuilder {
    private TemplateEngine templateEngine;

    @Autowired
    public MailContentBuilder(TemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
    }

    public String build(Map<String, Object> data, String template) {
        Context context = new Context();
        if (data != null) {
            for (Map.Entry<String, Object> entry : data.entrySet())
                context.setVariable(entry.getKey(), entry.getValue());
        }
        return templateEngine.process(template, context);
    }
}
