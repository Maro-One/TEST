package middleware.services;

import middleware.conf.LotusServiceConfig;
import middleware.dto.CategorieDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CategorieService {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private LotusServiceConfig lotusServiceConfig;

    public CategorieDto getCategorieByCode(String code) {
        return restTemplate.getForObject(lotusServiceConfig.getInscriptionURL() + "/categories/category?code=" + code, CategorieDto.class);
    }

}
