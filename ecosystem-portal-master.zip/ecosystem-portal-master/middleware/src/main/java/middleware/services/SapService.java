package middleware.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.sap.BasicAuthorizationSap;
import middleware.dto.AttachmentDto;
import middleware.dto.FundingRequestDto;
import middleware.dto.sap.*;
import middleware.dto.sap.AttachmentSAPDto.SapAttachmentResponce;
import middleware.dto.sap.AttachmentSAPDto.Content;
import middleware.utils.SapResponseWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
@Slf4j
public class SapService {

    @Autowired
    BasicAuthorizationSap basicAuthorizationSap;
    @Autowired
    BackendConfig backendConfig;
    @Autowired
    RestTemplate sapRestTemplate;

    ObjectMapper objectMapper = new ObjectMapper();

    public List<FundingRequestDto> getFromSap(String jsonRequest, String type) throws IOException {

        HttpEntity<String> requestEntityCommandeID = new HttpEntity<>(jsonRequest,basicAuthorizationSap.Authorization());
        String purchaseOrderDetailUrl = backendConfig.getSapPoURL()+"/PurDocGetDetail";

        try {
        ResponseEntity<SapResponse> sapResponse =
                sapRestTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST, requestEntityCommandeID, SapResponse.class);
        if(type.equals("commande")){
            return MtToDtoCommande(sapResponse.getBody());
        }
        else{
            return MtToDtoContract(sapResponse.getBody());
        }
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            // Log the error with status code
            log.error("Error while calling SAP service sapRestTemplate.exchange in method getFromSap : {} - {}", e.getStatusCode(), e.getMessage());

            // Return an empty list to continue processing
            return new ArrayList<FundingRequestDto>();
        } catch (Exception e) {
            // Log any other exceptions
            log.error("Unexpected error while calling SAP service sapRestTemplate.exchange in method getFromSap: {}", e.getMessage());

            // Return an empty list to continue processing
            return new ArrayList<FundingRequestDto>();
        }



    }

    public SapResponseWrapper getFromSapWithErrorMessages(String jsonRequest, String type) throws IOException {
        HttpEntity<String> requestEntityCommandeID = new HttpEntity<>(jsonRequest, basicAuthorizationSap.Authorization());
        String purchaseOrderDetailUrl = backendConfig.getSapPoURL() + "/PurDocGetDetail";

        ResponseEntity<SapResponse> sapResponse =
                sapRestTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST, requestEntityCommandeID, SapResponse.class);

        SapResponse body = sapResponse.getBody();
        // Initialize the list for error messages
        List<String> errorMessages = new ArrayList<>();
        List<FundingRequestDto> fundingRequestDtos = new ArrayList<>();

        // Extract error messages from the SAP response
        if (body != null && body.getMT_PurDocGetDetailResponse() != null) {
            List<Message> sapMessages = body.getMT_PurDocGetDetailResponse().getMessages();

            if (sapMessages != null) {
                for (Message message : sapMessages) {

                    errorMessages.add(message.getMessage());
                    log.error("SAP Response Message: Type - {}, Content - {}", message.getType(), message.getMessage());
                }
            }

            List<Document> contracts = body.getMT_PurDocGetDetailResponse().getDocument();
            if (contracts == null) {
                // No documents found, returning an empty list
                log.warn("No documents found for the given request.");
                return new SapResponseWrapper(Collections.emptyList(), errorMessages);
            }


            // Map the response based on type
            if (type.equals("commande")) {
                fundingRequestDtos = MtToDtoCommande(body);
            } else {
                fundingRequestDtos = MtToDtoContract(body);
            }

            // Return both the FundingRequestDto list and the error messages
            return new SapResponseWrapper(fundingRequestDtos, errorMessages);

        }
        else {
            log.error("Invalid response received from SAP or the response body is null.");
            throw new IOException("Invalid response received from SAP.");
        }
    }


    public List<AttachmentDto> getFromSapAttachment(String ponumber) {
        // Build the URL with the query parameter for Ponumber
        String purchaseOrderDetailUrl = backendConfig.getSapPoURL() + "/PoDoc/Attachement";

        // Add Ponumber as a query parameter to the URL
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(purchaseOrderDetailUrl)
                .queryParam("Ponumber", ponumber);

        // Perform the GET request
        HttpEntity<Void> requestEntity = new HttpEntity<>(basicAuthorizationSap.Authorization());

        try {
            ResponseEntity<SapAttachmentResponce> sapAttachmentResponse =
                    sapRestTemplate.exchange(uriBuilder.toUriString(), HttpMethod.GET, requestEntity, SapAttachmentResponce.class);

            // Check if the response is empty or null
            SapAttachmentResponce responseBody = sapAttachmentResponse.getBody();
            if (responseBody == null || responseBody.getMT_AttachementResponse() == null
                    || responseBody.getMT_AttachementResponse().getContent() == null
                    || responseBody.getMT_AttachementResponse().getContent().isEmpty()) {
                // Return an empty list if no data is available
                return Collections.emptyList();
            }

            // Otherwise, convert the response to a list of attachments
            return MtAttachmentToAttachmentDto(responseBody);
        } catch (Exception e) {
            log.error("Error while calling SAP service for attachments: {}", e.getMessage());
            return Collections.emptyList();
        }

    }

    public List<FundingRequestDto> MtToDtoCommande(SapResponse mt){
        ArrayList<FundingRequestDto> fundingRequestDtoList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        List<Document> contacts = mt.getMT_PurDocGetDetailResponse().getDocument();

        for (Document i : contacts){
            FundingRequestDto fundingRequestDto = new FundingRequestDto();
            if(i.getApprovalAttachmentAmount()!=null){fundingRequestDto.setApprovalAttachmentAmount(Double.valueOf(i.getApprovalAttachmentAmount()));}
            if(i.getBilledAmount()!=null){fundingRequestDto.setBilledAmount(i.getBilledAmount());}
            if(i.getBravoId()!=null){fundingRequestDto.setBravoId(i.getBravoId());}
            if(i.getPurchaseOrderStatus()!=null){fundingRequestDto.setStatus(i.getPurchaseOrderStatus().equals("Released") ? "Approuvée" : i.getPurchaseOrderStatus());}
            if(i.getBusinessUnitName()!=null){fundingRequestDto.setBusinessUnitName(i.getBusinessUnitName());}
            if(i.getPaidAmount()!=null){fundingRequestDto.setPaidAmount(i.getPaidAmount());}
            if(i.getPurchaseOrderAmount()!=null){fundingRequestDto.setPurchaseOrderAmount(i.getPurchaseOrderAmount());}
            if(i.getPurchaseOrderApprovalDate()!=null){fundingRequestDto.setPurchaseOrderApprovalDate(LocalDate.parse(i.getPurchaseOrderApprovalDate(),formatter));}
            if(i.getPurchaseOrderCategory()!=null){fundingRequestDto.setPurchaseOrderCategory(i.getPurchaseOrderCategory());}
            if(i.getPurchaseOrderDescription()!=null){fundingRequestDto.setPurchaseOrderDescription(i.getPurchaseOrderDescription());}
            if(i.getPurchaseOrderPaymentTermsName()!=null){fundingRequestDto.setPurchaseOrderPaymentTermsName(i.getPurchaseOrderPaymentTermsName());}
            //referenceID and PurchaseOrderID are the same for commandes
            if(i.getPurchaseOrderId()!=null){fundingRequestDto.setPurchaseOrderId(i.getPurchaseOrderId());}
            if(i.getPurchaseOrderId()!=null){fundingRequestDto.setPurchaseOrderRef(i.getPurchaseOrderId());}
            if(i.getPurchaseOrderPaymentTermsDescription()!=null){fundingRequestDto.setPurchaseOrderPaymentTermsDescription(i.getPurchaseOrderPaymentTermsDescription());}
            if(i.getAchievementPercentage()!=null){fundingRequestDto.setAchievementPercentage(i.getAchievementPercentage());}
            if(i.getPurchaseOrderStatus()!=null){fundingRequestDto.setPurchaseOrderStatus(i.getPurchaseOrderStatus());}
            fundingRequestDto.setSource("commande");
            fundingRequestDtoList.add(fundingRequestDto);
        }
        return fundingRequestDtoList;
    }
    public List<FundingRequestDto> MtToDtoContract(SapResponse mt){
        ArrayList<FundingRequestDto> fundingRequestDtoList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        List<Document> contracts = mt.getMT_PurDocGetDetailResponse().getDocument();

        for (Document i : contracts){
            FundingRequestDto fundingRequestDto = new FundingRequestDto();
            if(i.getApprovalAttachmentAmount()!=null){fundingRequestDto.setApprovalAttachmentAmount(Double.valueOf(i.getApprovalAttachmentAmount()));}
            if(i.getBilledAmount()!=null){fundingRequestDto.setBilledAmount(i.getBilledAmount());}
            if(i.getBravoId()!=null){fundingRequestDto.setBravoId(i.getBravoId());}
            if(i.getPurchaseOrderStatus_K()!=null && !i.getPurchaseOrderStatus_K().isEmpty()){
                fundingRequestDto.setPurchaseOrderStatus(i.getPurchaseOrderStatus_K());
            }
            if(i.getBusinessUnitName()!=null){fundingRequestDto.setBusinessUnitName(i.getBusinessUnitName());}
            if(i.getPaidAmount()!=null){fundingRequestDto.setPaidAmount(i.getPaidAmount());}
            if(i.getPurchaseOrderAmount()!=null){fundingRequestDto.setPurchaseOrderAmount(0.0);}
            if(i.getPurchaseOrderAmount()!=null){fundingRequestDto.setPurchaseOrderAmountCallOf(i.getPurchaseOrderAmount());}
            if(i.getPurchaseOrderCategory()!=null){fundingRequestDto.setPurchaseOrderCategory(i.getPurchaseOrderCategory());}
            if(i.getPurchaseOrderApprovalDate_K()!=null && !i.getPurchaseOrderApprovalDate_K().isEmpty() ){fundingRequestDto.setPurchaseOrderApprovalDate(LocalDate.parse(i.getPurchaseOrderApprovalDate_K(),formatter));}
            if(i.getPurchaseOrderDescription_K()!=null){fundingRequestDto.setPurchaseOrderDescription(i.getPurchaseOrderDescription_K());}
            if(i.getPurchaseOrderPaymentTermsName()!=null){fundingRequestDto.setPurchaseOrderPaymentTermsName(i.getPurchaseOrderPaymentTermsName());}
            //referenceID and PurchaseOrderID are different for contract
            if(i.getPurchaseOrderId()!=null){fundingRequestDto.setPurchaseOrderId(i.getPurchaseOrderId());}
            if(i.getPurchaseOrderPaymentTermsDescription()!=null){fundingRequestDto.setPurchaseOrderPaymentTermsDescription(i.getPurchaseOrderPaymentTermsDescription());}
            if(i.getContractID()!=null){fundingRequestDto.setPurchaseOrderRef(String.valueOf(i.getContractID()));}
            if(i.getAchievementPercentage_K()!=null){fundingRequestDto.setAchievementPercentageCallOf(Double.valueOf(i.getAchievementPercentage_K()));}
            if(i.getAchievementPercentage()!=null){fundingRequestDto.setAchievementPercentage(Double.valueOf(i.getAchievementPercentage()));}
            if(i.getPurchaseOrderStatus()!=null && !i.getPurchaseOrderStatus().isEmpty()){fundingRequestDto.setStatus(i.getPurchaseOrderStatus());}
            fundingRequestDto.setSource("contract");
            fundingRequestDtoList.add(fundingRequestDto);
        }
        return fundingRequestDtoList;
    }
    public List<AttachmentDto> MtAttachmentToAttachmentDto(SapAttachmentResponce mt){
        ArrayList<AttachmentDto> attachmentDtoList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        List<Content> contents = mt.getMT_AttachementResponse().getContent();
        for (Content i : contents) {
            AttachmentDto attachmentDto = new AttachmentDto();
            if(i.getDateValidation()!=null){attachmentDto.setDateValidation(LocalDate.parse(i.getDateValidation(),formatter));}
            if(i.getDeviseAttachement()!=null){attachmentDto.setDeviseAttachement(i.getDeviseAttachement());}
            if(i.getMontantAttachement()!=null){attachmentDto.setMontantAttachement(Double.valueOf(i.getMontantAttachement()));}
            if(i.getPoHeaderIp()!=null){attachmentDto.setPoHeaderIp(Long.valueOf(i.getPoHeaderIp()));}
            if(i.getRefAttachment()!=null){attachmentDto.setRefAttachment(i.getRefAttachment());}
            if(i.getStatus()!=null){attachmentDto.setStatus(i.getStatus());}
            attachmentDtoList.add(attachmentDto);
        }
        return  attachmentDtoList;
    }
    public  String capitalizeKeys(String jsonString) throws Exception {
        // Create ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();

        // Parse JSON string into a JsonNode
        JsonNode jsonNode = objectMapper.readTree(jsonString);

        // Recursively capitalize keys
        JsonNode modifiedJsonNode = capitalizeKeysRecursive(jsonNode, objectMapper);

        // Convert the modified JsonNode back to a string
        return objectMapper.writeValueAsString(modifiedJsonNode);
    }

    // Recursively capitalize keys in a JsonNode
    private JsonNode capitalizeKeysRecursive(JsonNode jsonNode, ObjectMapper objectMapper) {
        if (jsonNode.isObject()) {
            ObjectNode objectNode = (ObjectNode) jsonNode;
            ObjectNode modifiedObjectNode = objectMapper.createObjectNode();
            objectNode.fields().forEachRemaining(entry -> {
                String key = entry.getKey();
                String capitalizedKey = key.substring(0, 1).toUpperCase() + key.substring(1);
                modifiedObjectNode.set(capitalizedKey, capitalizeKeysRecursive(entry.getValue(), objectMapper));
            });
            return modifiedObjectNode;
        } else if (jsonNode.isArray()) {
            ArrayNode arrayNode = (ArrayNode) jsonNode;
            ArrayNode modifiedArrayNode = objectMapper.createArrayNode();
            arrayNode.elements().forEachRemaining(element -> modifiedArrayNode.add(capitalizeKeysRecursive(element, objectMapper)));
            return modifiedArrayNode;
        } else {
            return jsonNode;
        }
    }
    public String bodyToJsonOrder(SapOrderRequest sapOrderRequest){
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = null;
        try {
            String jsonRequestToUpperCase = objectMapper.writeValueAsString(sapOrderRequest);
            jsonRequest = capitalizeKeys(jsonRequestToUpperCase);
        } catch (JsonProcessingException e) {
            log.error("Error serializing SapRequest: {}", e.getMessage());
            // Handle the error gracefully, perhaps return an error response
            return null;
        }catch (Exception e){
            log.error("File not have been change toUpperCase for the first indexes", e.getMessage());
        }
        return jsonRequest;
    }
    public String bodyToJsonContract(SapContratRequest sapContratRequest){
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = null;
        try {
            String jsonRequestToUpperCase = objectMapper.writeValueAsString(sapContratRequest);
            jsonRequest = capitalizeKeys(jsonRequestToUpperCase);
        } catch (JsonProcessingException e) {
            log.error("Error serializing SapRequest: {}", e.getMessage());
            // Handle the error gracefully, perhaps return an error response
            return null;
        }catch (Exception e){
            log.error("File not have been change toUpperCase for the first indexes", e.getMessage());
        }
        return jsonRequest;
    }
}

