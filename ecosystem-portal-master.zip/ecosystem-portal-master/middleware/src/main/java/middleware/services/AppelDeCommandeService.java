package middleware.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.conf.sap.BasicAuthorizationSap;
import middleware.dto.*;

import middleware.dto.sap.ContractsRequest;
import middleware.dto.sap.SapContratRequest;
import middleware.dto.sap.SapResponse;
import middleware.utils.SapResponseWrapper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


@Service

@Slf4j
public class AppelDeCommandeService {

    RestTemplate restTemplate;

    BackendConfig backendConfig;

    LotusServiceConfig lotusServiceConfig;
    @Autowired
    FundingRequestService fundingRequestService;
    private static final String FUNDING_REQUEST_SOURCE = "s";

    public AppelDeCommandeService(RestTemplate restTemplate, BackendConfig backendConfig, LotusServiceConfig lotusServiceConfig) {

        this.restTemplate = restTemplate;

        this.backendConfig = backendConfig;

        this.lotusServiceConfig = lotusServiceConfig;

    }

    public AppelDeCommandeFromOraclePageableResponse getAppelDeCommandesfromOraclebyOrderId(String orderId) {

        String OracleEbsUrl=backendConfig.getOracleEbsURL()+"/appel-de-commandes/approved-appel-de-commandes";
        UriComponentsBuilder appelDeCommandesUrl = UriComponentsBuilder.fromHttpUrl(OracleEbsUrl);
        appelDeCommandesUrl.queryParam("PoHeaderId", orderId.substring(1));
        AppelDeCommandeFromOraclePageableResponse result = restTemplate.getForObject(appelDeCommandesUrl.build().toUriString(), AppelDeCommandeFromOraclePageableResponse.class);

        return result;
    }
    public AppelDeCommandeFromOraclePageableResponse getAppelDeCommandesfromSapByOrderIdUsingSap(String orderId, String requestSource) throws JsonProcessingException, IOException {
        List<AppelDeCommandeDto> appelDeCommandeDtos = new ArrayList<>();
        if(StringUtils.equalsIgnoreCase(requestSource, FUNDING_REQUEST_SOURCE)) {
            String ecosystemUrl = lotusServiceConfig.getEcosystemUrl() + "/funding-request/haveContractId";
            UriComponentsBuilder appelDeCommandeUrl = UriComponentsBuilder.fromHttpUrl(ecosystemUrl);
            appelDeCommandeUrl.queryParam("PurchaseOrderId", orderId);
            log.info("Start calling Lotus service API funding-request by orderId : {} ",orderId);
            String contractId = restTemplate.getForObject(appelDeCommandeUrl.build().toUriString(),String.class);

            if(!contractId.isEmpty() && !contractId.equals(orderId)){
                log.info("Start calling SAP API Command details by contractId : {} ",contractId);
                SapResponseWrapper responseContract = fundingRequestService.getSAPDetailsByCommandeIDOrContractID(contractId,"contract",false);
                List<FundingRequestDto> fundingRequestDtos=responseContract.getFundingRequestDtos();
                log.info("End of calling SAP API Command details by contractId {}",contractId);
                fundingRequestDtos.forEach(e -> {
                    AppelDeCommandeDto appelDeCommande = new AppelDeCommandeDto();
                    appelDeCommande.setRefCmdAppel(e.getPurchaseOrderId());
                    appelDeCommande.setStatus(e.getStatus()!=null? e.getStatus() : e.getPurchaseOrderStatus());
                    appelDeCommande.setApprovalDate(e.getPurchaseOrderApprovalDate());
                    appelDeCommande.setMontantAppelDeCommande(e.getPurchaseOrderAmountCallOf());
                    appelDeCommande.setAppelDeCommandePRCNT(e.getAchievementPercentage());

                    appelDeCommandeDtos.add(appelDeCommande);
                });
            }
        } else {
            String oracleUrlHistory = "/oracle-history/approved-appel-de-commandes/".concat(orderId);
            String oracleUrlHistoryRequestUrl = UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + oracleUrlHistory)
                    .encode()
                    .toUriString();
            List<AppelDeCommandeDto> appelDeCommandeList = restTemplate.exchange(oracleUrlHistoryRequestUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<AppelDeCommandeDto>>() {}).getBody();
            if(CollectionUtils.isNotEmpty(appelDeCommandeList)) {
                appelDeCommandeList.forEach(
                        oracleAppelDeCommande -> {
                            AppelDeCommandeDto appelDeCommande = new AppelDeCommandeDto();
                            appelDeCommande.setRefCmdAppel(oracleAppelDeCommande.getPurchaseOrderId());
                            appelDeCommande.setStatus(oracleAppelDeCommande.getStatus());
                            appelDeCommande.setApprovalDate(oracleAppelDeCommande.getApprovalDate());
                            appelDeCommande.setMontantAppelDeCommande(oracleAppelDeCommande.getMontantAppelDeCommande());
                            appelDeCommande.setAppelDeCommandePRCNT(appelDeCommande.getAppelDeCommandePRCNT());
                            appelDeCommandeDtos.add(appelDeCommande);
                        }
                );
            }

        }

        log.info("End of calling Lotus service API funding-request by orderId : {} ",orderId);
        return new AppelDeCommandeFromOraclePageableResponse(appelDeCommandeDtos);
    }
}
