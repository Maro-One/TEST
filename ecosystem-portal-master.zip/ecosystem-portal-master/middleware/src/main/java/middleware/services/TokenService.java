package middleware.services;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class TokenService {
    public static final String BEARER_STRING = "Bearer ";
    @Value("${spring.token.secret}")
    private String secret;

    @Value("${spring.token.expiration}")
    private long expiration;

    @Value("${spring.resetPasswordToken.expiration}")
    private long resetPasswordTokenExpiration;

    public String getResetPasswordToken(Map<String, Object> user) {
        return getTokenWithExp(user, new Date(System.currentTimeMillis() + resetPasswordTokenExpiration * 1000));
    }

    public String getToken(Map<String, Object> user) {
        return getTokenWithExp(user, new Date(System.currentTimeMillis() + expiration * 1000));
    }

    private String getTokenWithExp(Map<String, Object> user, Date expiration) {
        return Jwts.builder()
                .setClaims(user)
                .setIssuedAt(new Date())
                .setExpiration(expiration)
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
    }

    public String getBravoSupplierId(String token) {
        Jws<Claims> claims = Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token.replace(BEARER_STRING, ""));
        Map obj = (Map) claims.getBody().get("user");
        return (String) obj.get("supplierBravoId");
    }


    public String getBody(String token) {
        Jws<Claims> claims = parseClaims(token);
        Map obj = (Map) claims.getBody().get("user");
        JSONObject jsonObject = new JSONObject();
        jsonObject.putAll(obj);

        return jsonObject.toJSONString();
    }

    public Instant getExpirationInstant(String token) {
        String[] tokenParts = token.split("[.]");
        Base64.Decoder decoder = Base64.getUrlDecoder();
        String decodedToken = new String(decoder.decode(tokenParts[1]));
        try {
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(decodedToken);
            long expirationTimestamp = Long.parseLong(json.get("exp").toString());
            return Instant.ofEpochSecond(expirationTimestamp);
        } catch (ParseException e) {
            throw new IllegalStateException("Error to parse backend token");
        }
    }

    /**
     * This will only work on Registration tokens!
     *
     * @param token The token
     * @return The email
     */

    public String getUsername(String token) {
        Jws<Claims> claims = Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token.replace(BEARER_STRING, ""));
        return ((LinkedHashMap<String, String>) claims.getBody().get("user")).get("login");
    }

    public Jws<Claims> parseClaims(String token) {
        return Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token.replace(BEARER_STRING, ""));
    }

}
