package middleware.services;



import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import middleware.conf.BackendConfig;

import middleware.conf.LotusServiceConfig;
import middleware.dto.*;

import middleware.dto.sap.AttachmentSAPDto.SapAttachmentRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import org.springframework.web.client.RestTemplate;

import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;


@Service

@Slf4j

public class AttachmentService {

    private static final String FUNDING_REQUEST_SOURCE = "s";
    RestTemplate restTemplate;

    BackendConfig backendConfig;

    LotusServiceConfig lotusServiceConfig;

    SapService sapService;


    @Autowired

    public AttachmentService(RestTemplate restTemplate, BackendConfig backendConfig, LotusServiceConfig lotusServiceConfig, SapService sapService) {

        this.restTemplate = restTemplate;

        this.backendConfig = backendConfig;

        this.lotusServiceConfig = lotusServiceConfig;

        this.sapService = sapService;

    }

//fix pipeline
    public AttachmentPageableResponse getSupplierApprovedAttachmentsByPurchaseOrder(Integer agencyId, String orderId, int page,

                                                                                    String sortBy, String order) {

        log.info("Get approved attachments for purchase order {} at page {}", orderId, page);

        if(!Arrays.asList("updatedDate", "totalAmount").contains(sortBy) || !Arrays.asList("asc","desc").contains(order)) {

            log.info("Les input du tri ne sont pas correct");

            throw new IllegalArgumentException("Les input du tri ne sont pas correct");

        }else {

            String url =

                    lotusServiceConfig.getEcosystemUrl() + "/funding-request/agency-has-supplier-request-by-orderId/"

                            + agencyId + "/" + orderId;

            Boolean checkExistence = restTemplate.getForObject(url, Boolean.class);

            if (checkExistence.equals(true)) {

                UriComponentsBuilder attachmentsUrl =

                        UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getAttachmentURL() + "/attachments/approved-by-order/"

                                + orderId);

                attachmentsUrl.queryParam("page", page);

                attachmentsUrl.queryParam("sortBy", sortBy);

                attachmentsUrl.queryParam("order", order.toUpperCase());


                AttachmentPageableResponse result = restTemplate.getForObject(attachmentsUrl.build().toUriString(), AttachmentPageableResponse.class);

                log.info("Got {} total approved attachments for purchase order {}", result.getCount(), orderId);

                return result;

            }

            return null;

        }

    }


    public AttachmentFromOraclePageableResponse getAttachmentsfromOraclebyOrderId(String orderId) {

        String OracleEbsUrl=backendConfig.getOracleEbsURL()+"/attachments/approved-attachments";
        UriComponentsBuilder attachmentsUrl = UriComponentsBuilder.fromHttpUrl(OracleEbsUrl);
        attachmentsUrl.queryParam("orderId", orderId.substring(1));
        AttachmentFromOraclePageableResponse result = restTemplate.getForObject(attachmentsUrl.build().toUriString(), AttachmentFromOraclePageableResponse.class);

        return result;
    }
    public AttachmentFromOraclePageableResponse getAttachmentsfromSAPbyOrderId(String orderId) {

        log.info("the OrderId is : ", orderId);
        List<AttachmentDto> attachmentDtos = sapService.getFromSapAttachment(orderId);
        return new AttachmentFromOraclePageableResponse(attachmentDtos);
    }

    public AttachmentFromOraclePageableResponse getAttachmentsfromSAPbyRefCmdAppelList(String orderId, List<String> refCmdAppelList, String requestSource) {
        log.info("Processing purchaseOrderId: {} with refCmdAppelList: {}", orderId, refCmdAppelList);

        Set<AttachmentDto> attachmentDtosSet = new HashSet<>();

        log.info("the OrderId is : {} ", orderId);
        List<AttachmentDto> attachmentDtos = new ArrayList<>();
        if(StringUtils.equalsIgnoreCase(requestSource, FUNDING_REQUEST_SOURCE)) {
            if (refCmdAppelList.size() == 0 ) {
                // Single element case, proceed as usual
            /*SapAttachmentRequest sapAttachmentRequest = new SapAttachmentRequest();
            sapAttachmentRequest.setPonumber(orderId);
            String jsonRequest = StringToJsonAndCapitalized(sapAttachmentRequest);*/
                attachmentDtosSet.addAll(sapService.getFromSapAttachment(orderId));

            } else {
                // Multiple elements case
                for (String refCmdAppel : refCmdAppelList) {
                /*SapAttachmentRequest sapAttachmentRequest = new SapAttachmentRequest();
                sapAttachmentRequest.setPonumber(refCmdAppel);
                String jsonRequest = StringToJsonAndCapitalized(sapAttachmentRequest);*/
                    attachmentDtosSet.addAll(sapService.getFromSapAttachment(refCmdAppel));

                }
            }
        } else {
            String oracleUrlHistory = "/oracle-history/attachments/approved-attachments/".concat(orderId);
            String oracleUrlHistoryRequestUrl = UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + oracleUrlHistory)
                    .encode()
                    .toUriString();
            List<OracleAttachmentDto> attachments = restTemplate.exchange(oracleUrlHistoryRequestUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<OracleAttachmentDto>>() {}).getBody();
            if(CollectionUtils.isNotEmpty(attachments)) {
                attachments.forEach(
                        oracleAttachmentDto -> {
                            AttachmentDto attachmentDto = new AttachmentDto();
                            attachmentDto.setMontantAttachement(oracleAttachmentDto.getMontantAttachement());
                            attachmentDto.setRefAttachment(oracleAttachmentDto.getRefAttachment());
                            attachmentDto.setStatus(oracleAttachmentDto.getStatus());
                            attachmentDto.setDateValidation(oracleAttachmentDto.getDateValidation());
                            attachmentDto.setRefCmdAppel(oracleAttachmentDto.getRefCmdAppel());
                            attachmentDto.setPoHeaderIp(oracleAttachmentDto.getPoHeaderIp());
                            attachmentDtosSet.add(attachmentDto);
                        }
                );
            }
        }




        // Convert the set back to a list to return
        List<AttachmentDto> uniqueAttachmentDtos = new ArrayList<>(attachmentDtosSet);

        return new AttachmentFromOraclePageableResponse(uniqueAttachmentDtos);

    }


    public String StringToJsonAndCapitalized(SapAttachmentRequest sapAttachmentRequest){
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = null;
        try {
            String jsonRequestToUpperCase = objectMapper.writeValueAsString(sapAttachmentRequest);
            jsonRequest = jsonRequestToUpperCase.substring(0,2).toLowerCase() + jsonRequestToUpperCase.substring(2,3).toUpperCase() + jsonRequestToUpperCase.substring(3);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonRequest;
    }

}
