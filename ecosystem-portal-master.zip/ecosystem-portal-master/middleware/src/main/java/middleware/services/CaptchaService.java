package middleware.services;

import middleware.conf.LotusServiceConfig;
import middleware.entities.Captcha;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CaptchaService {

    @Autowired
    LotusServiceConfig lotusServiceConfig;
    @Autowired
    private RestTemplate restTemplate;

    private static final Logger log = LoggerFactory.getLogger(CaptchaService.class);
    public Captcha generateCaptcha () {
        log.info("Get Captcha");
        Captcha  captcha = restTemplate.getForObject(lotusServiceConfig.getCaptchaURL() + "/captcha", Captcha.class);
        log.info("Captcha is generated");
        return captcha;
    }

    public boolean isValidCaptcha(String entryCode, String captchaValue) {
        Captcha captcha = new Captcha();
        captcha.setCaptchaValue(captchaValue);
        captcha.setEntryCode(entryCode);
        return restTemplate.postForObject(lotusServiceConfig.getCaptchaURL() + "/captcha",captcha, Boolean.class);
    }
}
