package middleware.services;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class JobService implements Runnable {

    private final Job oracleDataHistoriesJob;
    private final JobLauncher jobLauncher;

    public JobService(
            JobLauncher jobLauncher,
            @Qualifier("oracleDataHistoriesJob") Job oracleDataHistoriesJob) {
        this.jobLauncher = jobLauncher;
        this.oracleDataHistoriesJob = oracleDataHistoriesJob;
    }
    private void launchOracleDataHistoryJobJobProcess() {

        JobParametersBuilder dynamicJParameters = new JobParametersBuilder();

        JobParameters jobParameters = dynamicJParameters.addLong("JobID", System.nanoTime())
                .toJobParameters();
        try {
            JobExecution jobExecution = jobLauncher.run(oracleDataHistoriesJob, jobParameters);

            log.info("Job execution status [ {} ]", jobExecution.getStatus());
        } catch (JobExecutionAlreadyRunningException
                 | JobInstanceAlreadyCompleteException
                 | JobRestartException
                 | JobParametersInvalidException e) {
            log.error(e.getMessage(), e);
            if (log.isDebugEnabled())
                log.debug(e.getMessage(), e);
        }
    }

    @Override
    public void run() {
        launchOracleDataHistoryJobJobProcess();
    }
}
