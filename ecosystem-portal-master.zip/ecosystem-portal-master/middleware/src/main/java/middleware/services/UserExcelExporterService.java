package middleware.services;

import middleware.entities.User;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class UserExcelExporterService {

    private XSSFWorkbook workbook;
    private XSSFSheet sheet;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public ByteArrayInputStream export(List<User> users) {
        try(Workbook workbook = new XSSFWorkbook()){
            Sheet sheet = workbook.createSheet("Users");

            Row row = sheet.createRow(0);

            // Define header cell style
            CellStyle headerCellStyle = workbook.createCellStyle();
            headerCellStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Creating header cells
            Cell cell = row.createCell(0);
            cell.setCellValue("Nom");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(1);
            cell.setCellValue("Prenom");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(2);
            cell.setCellValue("Role");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(3);
            cell.setCellValue("Email");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(4);
            cell.setCellValue("Date derniere connexion");
            cell.setCellStyle(headerCellStyle);

            for(int i = 0; i < users.size(); i++) {
                Row dataRow = sheet.createRow(i + 1);
                dataRow.createCell(0).setCellValue(users.get(i).getLastName());
                dataRow.createCell(1).setCellValue(users.get(i).getFirstName());
                dataRow.createCell(2).setCellValue(users.get(i).getRoleLabel().equals("ROLE_ADMIN") ? "Administrator" : users.get(i).getRoleLabel().equals("ROLE_AGENCY") ? "Agency" : users.get(i).getRoleLabel().equals("ROLE_BUYER") ? "Buyer" : "");
                dataRow.createCell(3).setCellValue(users.get(i).getEmail());
                dataRow.createCell(4).setCellValue(users.get(i).getLastAttempt() != null ? DateFormatUtils.format(users.get(i).getLastAttempt(),"dd-MM-yyyy HH:mm:ss") : "");
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (IOException ex) {
            logger.error("Error during export Excel file", ex);
            return null;
        }
    }
}
