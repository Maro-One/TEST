package middleware.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.conf.sap.BasicAuthorizationSap;
import middleware.dto.*;
import middleware.dto.mapper.FundingRequestDtoMapper;
import middleware.dto.sap.*;
import middleware.utils.SapResponseWrapper;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class FundingRequestService {


    public static final String FUNDING_REQUEST = "/funding-request/";
    public static final String FUNDING_REQUEST_REFUSE = "/funding-request/refuse/";
    private static final String FUNDING_REQUEST_SOURCE = "s";

    RestTemplate restTemplate;

    RestTemplate sapRestTemplate;
    BackendConfig backendConfig;
    LotusServiceConfig lotusServiceConfig;

    @Autowired
    BasicAuthorizationSap basicAuthorizationSap;

    @Autowired
    SapService sapService;
    private EmailService emailService;
    @Autowired
    public FundingRequestService(RestTemplate restTemplate,RestTemplate sapRestTemplate ,BackendConfig backendConfig, LotusServiceConfig lotusServiceConfig, EmailService emailService) {
        this.restTemplate = restTemplate;
        this.sapRestTemplate = sapRestTemplate;
        this.backendConfig = backendConfig;
        this.lotusServiceConfig = lotusServiceConfig;
        this.emailService = emailService;
    }

    public ApplicantPageableResponse getPaginatedFundingRequestsApplicants(String role, int page, Integer pathVariable) {
        String url = FUNDING_REQUEST;
        if (role.equals("ROLE_AGENCY")) {
            url += "approved-funding-applicants-count-pageable/" + pathVariable;
        } else {
            url += "all-applicants-count-pageable";
        }
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() +
                        url);
        fundingRequestsUrl.queryParam("page", page);
        MapPageableResponse countResult =
                restTemplate.getForObject(fundingRequestsUrl.build().toUriString(),
                        MapPageableResponse.class);
        Map<Long, Long> content = countResult.getContent();
        if (!content.isEmpty()) {
            HttpEntity<Object> requestEntity = new HttpEntity<>(content.keySet());
            Map<String, Integer> params = new HashMap<>();
            params.put("page", page);

            ResponseEntity<List<FundingRequestApplicantDto>> response = restTemplate.
                    exchange(backendConfig.getBravoURL() + "/supplier/profilesBySupplierIds?page=0", HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                            }, params);

            response.getBody().forEach(applicant ->
                    applicant.setFundingRequestsCount(content.get(applicant.getSupplierBravoId())));

            List<FundingRequestApplicantDto> fundingRequestApplicantDtos = response.getBody();
            //check sap suppliers not existing in bravo system
            List<Long> responseIds = response.getBody().stream().map(a->a.getSupplierBravoId()).collect(Collectors.toList());
            List<Long>  idSapSupplier=content.keySet().stream()
                    .filter(id -> !responseIds.contains(id)).collect(Collectors.toList());
           if(!idSapSupplier.isEmpty()){
               idSapSupplier.forEach(id -> fundingRequestApplicantDtos.add(new FundingRequestApplicantDto(id)));
            }
            return new ApplicantPageableResponse(fundingRequestApplicantDtos, countResult.getCount());
        }
        return new ApplicantPageableResponse(Collections.emptyList(), 0L);
    }
    public RequestPageableResponse getFundingRequestsForSupplierByStatus(String role, Integer agencyId, Long bravoId, int page, String filter) {
        String url = FUNDING_REQUEST;
        if (role.equals("ROLE_AGENCY")) {
            url += "approved-applicant-funding-requests/" + agencyId + "/" + bravoId;
        } else {
            url += "supplier-funding-requests-all";
        }
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + url);
        fundingRequestsUrl.queryParam("page", page);
        if (filter != null) {
            fundingRequestsUrl.queryParam("filter", filter);
        }
        RequestPageableResponse requestsResponse = restTemplate.getForObject(fundingRequestsUrl.build().toUriString(),
                RequestPageableResponse.class);
        List<FundingRequestDto> requestList = requestsResponse.getContent();
        RequestPageableResponse pageableResponse = new RequestPageableResponse();
        pageableResponse.setCount(requestsResponse.getCount());
        //toDo split detail by source
        if (!requestList.isEmpty()) {
            requestList.stream().forEach(i -> {
                if (i.getSource() == null) i.setSource("null");
            });
            List<String> oracleordersList = requestList.parallelStream()
                    .filter(order -> !order.getSource().equals("SAP"))
                    .map(FundingRequestDto::getPurchaseOrderId)
                    .distinct().collect(Collectors.toList());

            List<Long> bravoIds = requestList.parallelStream().map(FundingRequestDto::getBravoId)
                    .distinct().collect(Collectors.toList());
            Map<Long, String> companyNamesByBravoId = Collections.emptyMap();
            if (role.equals("ROLE_BUYER")) {
                companyNamesByBravoId = getCompanyNamesByBravoId(bravoIds);
            }
            Map<Long, String> finalCompanyNamesByBravoId = companyNamesByBravoId;
            List<FundingRequestDto> requestDtoList = new ArrayList<>();
            if(!oracleordersList.isEmpty()){
                HttpEntity<List<String>> requestEntity = new HttpEntity<>(oracleordersList);
                log.info("Get additional information for purchase order list {} from Oracle", oracleordersList);
                String purchaseOrderDetailUrl = backendConfig.getBackEndGateWayUrl() + "/purchase-orders/purchase-details";
                ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = restTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST,
                        requestEntity, FundingRequestDto[].class);
                requestDtoList.addAll(Arrays.asList(oracleDetailsResponse.getBody()));
            }
            List<FundingRequestDto> sapordersList = requestList.parallelStream()
                    .filter(order -> order.getSource() != null)
                    .filter(order ->order.getSource().equals("SAP"))
                    .distinct().collect(Collectors.toList());
            if(!sapordersList.isEmpty()){
                log.info("Get additional information for purchase order list from SAP");
                sapordersList.parallelStream().forEach(saporderid ->{
                    if (getPurchaseDetailSap(saporderid.getPurchaseOrderRef()) != null && !getPurchaseDetailSap(saporderid.getPurchaseOrderRef()).getBody().getContent().isEmpty())
                    requestDtoList.add(FundingRequestDtoMapper.
                            toDto(getPurchaseDetailSap(saporderid.getPurchaseOrderRef()).getBody().getContent().get(0), String.valueOf(saporderid.getBravoId())));
                });
            }
            requestList.forEach(request -> {
                if (role.equals("ROLE_BUYER")) {
                    request.setCompanyName(finalCompanyNamesByBravoId.getOrDefault(request.getBravoId(), ""));
                }

                Optional<FundingRequestDto> purchaseOrderAdditionalInfo =
                        requestDtoList.parallelStream().filter(po -> po.getPurchaseOrderId().equals(request.getPurchaseOrderId())).findAny();
                double billedAmount = 0;
                if (purchaseOrderAdditionalInfo.isPresent()) {
                    billedAmount = purchaseOrderAdditionalInfo.get().getBilledAmount();
                    request.setPurchaseOrderStatus(purchaseOrderAdditionalInfo.get().getPurchaseOrderStatus());
                    request.setPurchaseOrderApprovalDate(purchaseOrderAdditionalInfo.get().getPurchaseOrderApprovalDate());
                }

                if (request.getPurchaseOrderAmount() != null) {
                    request.setAchievementPercentage(billedAmount / request.getPurchaseOrderAmount());
                }
            });
        }
        pageableResponse.setContent(requestList);
        return pageableResponse;
    }
    public RequestPageableResponse getFundingRequestsForSupplierByStatusWithOutPercentage(String role, Integer agencyId, Long bravoId, int page, String filter) {
        String url = FUNDING_REQUEST;
        if (role.equals("ROLE_AGENCY")) {
            url += "approved-applicant-funding-requests/" + agencyId + "/" + bravoId;
        } else {
            url += "supplier-funding-requests-all";
        }
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + url);
        fundingRequestsUrl.queryParam("page", page);
        if (filter != null) {
            fundingRequestsUrl.queryParam("filter", filter);
        }
        RequestPageableResponse requestsResponse = restTemplate.getForObject(fundingRequestsUrl.build().toUriString(),
                RequestPageableResponse.class);
        List<FundingRequestDto> requestList = requestsResponse.getContent();
        RequestPageableResponse pageableResponse = new RequestPageableResponse();
        pageableResponse.setCount(requestsResponse.getCount());
        if (!requestList.isEmpty()) {
            requestList.stream().forEach(i -> {
                if (i.getSource() == null) i.setSource("null");
            });
            List<String> oracleordersList = requestList.parallelStream()
                    .filter(order -> !order.getSource().equals("SAP"))
                    .map(FundingRequestDto::getPurchaseOrderId)
                    .distinct().collect(Collectors.toList());

            List<Long> bravoIds = requestList.parallelStream().map(FundingRequestDto::getBravoId)
                    .distinct().collect(Collectors.toList());
            Map<Long, String> companyNamesByBravoId = Collections.emptyMap();
            if (role.equals("ROLE_BUYER")) {
                companyNamesByBravoId = getCompanyNamesByBravoId(bravoIds);
            }
            Map<Long, String> finalCompanyNamesByBravoId = companyNamesByBravoId;
            List<FundingRequestDto> requestDtoList = new ArrayList<>();
            if(!oracleordersList.isEmpty()){
                HttpEntity<List<String>> requestEntity = new HttpEntity<>(oracleordersList);
                log.info("Get additional information for purchase order list {} from Oracle", oracleordersList);
                String purchaseOrderDetailUrl = backendConfig.getBackEndGateWayUrl() + "/purchase-orders/purchase-detailsWithOutPercentage";
                ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = restTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST,
                        requestEntity, FundingRequestDto[].class);
                requestDtoList.addAll(Arrays.asList(oracleDetailsResponse.getBody()));
            }
            List<FundingRequestDto> sapordersList = requestList.parallelStream()
                    .filter(order -> order.getSource() != null)
                    .filter(order ->order.getSource().equals("SAP"))
                    .distinct().collect(Collectors.toList());
            if(!sapordersList.isEmpty()){
                log.info("Get additional information for purchase order list from SAP");
                sapordersList.parallelStream().forEach(saporderid ->{
                    if (getPurchaseDetailSap(saporderid.getPurchaseOrderRef()) != null && !getPurchaseDetailSap(saporderid.getPurchaseOrderRef()).getBody().getContent().isEmpty())
                    requestDtoList.add(FundingRequestDtoMapper.
                            toDto(getPurchaseDetailSap(saporderid.getPurchaseOrderRef()).getBody().getContent().get(0), String.valueOf(saporderid.getBravoId())));
                });
            }
            requestList.forEach(request -> {
                if (role.equals("ROLE_BUYER")) {
                    request.setCompanyName(finalCompanyNamesByBravoId.getOrDefault(request.getBravoId(), ""));
                }

                Optional<FundingRequestDto> purchaseOrderAdditionalInfo =
                        requestDtoList.parallelStream().filter(po -> po.getPurchaseOrderId().equals(request.getPurchaseOrderId())).findAny();
                //double billedAmount = 0;
                if (purchaseOrderAdditionalInfo.isPresent()) {
                    //billedAmount = purchaseOrderAdditionalInfo.get().getBilledAmount();
                    request.setPurchaseOrderStatus(purchaseOrderAdditionalInfo.get().getPurchaseOrderStatus());
                    request.setPurchaseOrderApprovalDate(purchaseOrderAdditionalInfo.get().getPurchaseOrderApprovalDate());
                }
//                if (request.getPurchaseOrderAmount() != null) {
//                    request.setAchievementPercentage(billedAmount / request.getPurchaseOrderAmount());
//                }
            });
        }
        pageableResponse.setContent(requestList);
        return pageableResponse;
    }

    private Map<Long, String> getCompanyNamesByBravoId(List<Long> bravoIds) {
        if (bravoIds == null || bravoIds.isEmpty()) {
            return Collections.emptyMap();
        }
        try {
            ResponseEntity<List<FundingRequestApplicantDto>> res = restTemplate.
                    exchange(backendConfig.getBravoURL() + "/supplier/profilesBySupplierIdsAndInputFilter",
                            HttpMethod.POST,
                            new HttpEntity<>(SupplierFilter.builder().supplierIdList(bravoIds).build()),
                            new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                            });
            if (res.getBody() == null) {
                log.warn("Got null body while trying to get supplier details from bravo using bravo IDs");
                return Collections.emptyMap();
            }
            return res.getBody().stream().collect(Collectors.toMap(FundingRequestApplicantDto::getSupplierBravoId, FundingRequestApplicantDto::getCompanyName));
        } catch (Exception e) {
            log.error("Error while trying to get supplier details from bravo using bravo IDs", e);
            return Collections.emptyMap();
        }
    }

    public FundingRequestDto getFundingRequestDetail(Integer agencyId, String orderId, Integer requestId) {
        log.info("Get funding request detail for agency id {} and request id {}", agencyId, requestId);
        String fundingRequestUrl = "/funding-request/funding-request-detail/" + requestId;
        try {
            FundingRequestDto fundingRequestDetailDto = restTemplate.getForObject(lotusServiceConfig.getEcosystemUrl() + fundingRequestUrl, FundingRequestDto.class);
            if (fundingRequestDetailDto != null && !fundingRequestDetailDto.getStatus().equals("PENDING") &&
                    fundingRequestDetailDto.getFundingAgencyId().equals(agencyId)) {
                log.info("Got funding request detail {} for agency id {} and request id {}", fundingRequestDetailDto.getId(), agencyId, requestId);
                FundingRequestDto poDetails = null;
                if(!fundingRequestDetailDto.getSource().equals("SAP")){
                    poDetails = getOracleOrderDetailsById(orderId);
                }
                if(fundingRequestDetailDto.getSource().equals("SAP")){
                    if (getPurchaseDetailSap(fundingRequestDetailDto.getPurchaseOrderRef()) != null && !getPurchaseDetailSap(fundingRequestDetailDto.getPurchaseOrderRef()).getBody().getContent().isEmpty())
                    poDetails=FundingRequestDtoMapper.toDto(getPurchaseDetailSap(fundingRequestDetailDto.getPurchaseOrderRef()).getBody().getContent().get(0),
                            String.valueOf(fundingRequestDetailDto.getBravoId()));
                }
                if (poDetails != null) {
                    fundingRequestDetailDto.setBilledAmount(poDetails.getBilledAmount());
                    fundingRequestDetailDto.setPaidAmount(poDetails.getPaidAmount());
                    fundingRequestDetailDto.setPurchaseOrderCategory(poDetails.getPurchaseOrderCategory());
                    fundingRequestDetailDto.setPurchaseOrderPaymentTermsName(poDetails.getPurchaseOrderPaymentTermsName());
                    fundingRequestDetailDto.setPurchaseOrderPaymentTermsDescription(poDetails.getPurchaseOrderPaymentTermsDescription());
                    fundingRequestDetailDto.setPurchaseOrderStatus(poDetails.getPurchaseOrderStatus());
                    fundingRequestDetailDto.setStatus(poDetails.getPurchaseOrderStatus());
                    fundingRequestDetailDto.setPurchaseOrderApprovalDate(poDetails.getPurchaseOrderApprovalDate());

                }
                log.info("Get approved attachments total amount for purchase order {}", orderId);
                HttpEntity<Long> requestEntity = new HttpEntity<>(Long.parseLong(orderId.replaceAll("[^0-9]","")));
                ResponseEntity<Double> attachmentResponse = restTemplate.
                        exchange(backendConfig.getOracleEbsURL()+"/attachments/approved-amount",
                                HttpMethod.POST, requestEntity,
                                new ParameterizedTypeReference<Double>() {});
                Double approvalAttachmentAmount = attachmentResponse.getBody() == null ? 0D : attachmentResponse.getBody();
                log.info("Got approved attachments total amount {} for purchase order {}", approvalAttachmentAmount, orderId);
                fundingRequestDetailDto.setApprovalAttachmentAmount(approvalAttachmentAmount);
                if (fundingRequestDetailDto.getBilledAmount() != null)
                fundingRequestDetailDto.setAchievementPercentage(fundingRequestDetailDto.getBilledAmount() / fundingRequestDetailDto.getPurchaseOrderAmount());
                return fundingRequestDetailDto;
            }
            log.info("Funding request is not found or not approved");
            return null;
        } catch (Exception e) {
            log.info("Error occured with cause {}", e.getMessage());
        }
        return null;
    }

    public RequestPageableResponse getSupplierFundingRequestsByStatus(Long supplierId, String status, int page) {
        log.info("Get funding request list for supplier id {} and status {} at page {}", supplierId, status, page);
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() +
                        "/funding-request/funding-requests-by-supplier/" + supplierId);
        fundingRequestsUrl.queryParam("page", page);
        if (status != null) {
            fundingRequestsUrl.queryParam("status", status);
        }
        RequestPageableResponse fundingRequestDetailDto =
                restTemplate.getForObject(fundingRequestsUrl.build().toUriString(), RequestPageableResponse.class);
        log.info("Got {} total funding requests for supplier id {} and status {}", supplierId, status);
        return fundingRequestDetailDto;
    }

    public FundingRequestDto updateFundingRequest(Integer id, Integer agencyId) {
        log.info("update funding request status with id={}", id);

        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() +
                        FUNDING_REQUEST + id);
        fundingRequestsUrl.queryParam("agencyId", agencyId);
        try {
            ResponseEntity<FundingRequestDto> result =
                    restTemplate.exchange(fundingRequestsUrl.build().toUriString(), HttpMethod.PUT, null,
                            FundingRequestDto.class);
            return result.getBody();
        } catch (Exception e) {
            log.info("Error occured while updating funding request with id {} for cause {}",
                    id, e.getMessage());
            return null;
        }

    }
    public FundingRequestDto refuseFundingRequest(Integer requestId, String comment, String supplierEmail, Integer agencyId) {
        log.info("refuse funding request status with id={}", requestId);

        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() +
                        FUNDING_REQUEST_REFUSE + requestId);
        fundingRequestsUrl.queryParam("comment", comment);
        fundingRequestsUrl.queryParam("agencyId", agencyId);
        try {
            ResponseEntity<FundingRequestDto> result =
                    restTemplate.exchange(fundingRequestsUrl.build().toUriString(), HttpMethod.PUT, null,
                            FundingRequestDto.class);
            FundingRequestDto fundingRequestDto = result.getBody();
            if (fundingRequestDto == null) {
                return null;
            }
            Map<String, Object> forMail = new HashMap<>();
            forMail.put("comment", comment);
            forMail.put("purchaseOrderDescription", fundingRequestDto.getPurchaseOrderDescription());

            emailService.sendEmail(
                    supplierEmail,
                    "Refus de la demande de financement",
                    "funding_request_rejection",
                    forMail,
                    null,
                    null
            );
            return fundingRequestDto;
        } catch (Exception e) {
            log.error("Error occured while updating (refusing) funding request with id {}",
                    requestId, e);
            return null;
        }
    }

    public FundingRequestDto getOracleOrderDetailsById(String orderId) {
        HttpEntity<List<String>> requestEntity = new HttpEntity<>(Collections.singletonList(orderId));
        log.info("Get additional information for purchase order {} from Oracle", orderId);
        String purchaseOrderDetailUrl = backendConfig.getBackEndGateWayUrl() + "/purchase-orders/purchase-details";
        ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = restTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST,
                requestEntity, FundingRequestDto[].class);
        List<FundingRequestDto> requestDtoList = Arrays.asList(oracleDetailsResponse.getBody());
        if (!requestDtoList.isEmpty()) {
            FundingRequestDto poOracleDetails = requestDtoList.get(0);
            log.info("Got additional information {} for purchaseOrder {} from oracle", poOracleDetails, orderId);
            return poOracleDetails;
        }
        return null;
    }

    public FundingRequestDto getOracleOrderDetailsByReferenceAndOperationUnit(String reference, String operationUnit) {
        log.info("Get additional information for purchase order by reference {} and operation unit {} from Oracle",
                reference, operationUnit);
        String purchaseOrderDetailUrl = backendConfig.getBackEndGateWayUrl() + "/purchase-orders/purchase-details-by-reference/"
                + reference + "/" + operationUnit;
        FundingRequestDto purchaseOrderDetails = restTemplate.getForObject(purchaseOrderDetailUrl, FundingRequestDto.class);
        log.info("Got additional information {} for purchaseOrder by reference {} and operation unit {} from oracle",
                purchaseOrderDetails, reference, operationUnit);
        return purchaseOrderDetails;
    }

    public List<ImportPurchaseOrdersResponse> importPurchaseOrders(MultipartFile file) throws IOException {
        List<FundingRequestDto> fundingRequestDtos = new ArrayList<>();
        List<ImportPurchaseOrdersResponse> importPurchaseOrdersResponses = new ArrayList<>();
        List<PurchaseOrderFundingRequest> purchaseOrders = readPurchaseOrdersFundingRequests(file);
        for (PurchaseOrderFundingRequest purchaseOrderFundingRequest : purchaseOrders) {
            ImportPurchaseOrdersResponse.ImportPurchaseOrdersResponseBuilder importPurchaseOrdersResponse = ImportPurchaseOrdersResponse.builder()
                    .agencyIDString(purchaseOrderFundingRequest.agencyID)
                    .orderReference(purchaseOrderFundingRequest.orderReference)
                    .operationUnit(purchaseOrderFundingRequest.operationUnit)
                    .message("Saved")
                    .saved(true);
            // la source SAP
            if (purchaseOrderFundingRequest.getOrderSource().equals("SAP")) {
                ResponseEntity<DataResponse<PurchaseOrderSearch>> response;
                try{
                    response=getPurchaseDetailSap(purchaseOrderFundingRequest.orderReference);
                }
                catch (Exception e){
                    log.error("Error while getting SAP Order Details By Reference {} ", purchaseOrderFundingRequest.orderReference, e);
                    importPurchaseOrdersResponse.message("Error while getting SAP Order Details By Reference " + purchaseOrderFundingRequest.orderReference );
                    importPurchaseOrdersResponse.saved(false);
                    importPurchaseOrdersResponses.add(importPurchaseOrdersResponse.build());
                    continue;
                }
                if(!response.getBody().getContent().isEmpty()) {
                    PurchaseOrderSearch posap = response.getBody().getContent().get(0);
                    //search the bravo id
                    BravoDto bravoDto = getBravoIdBySapId(posap.getSupplierCommonCode());
                    String bravo_Id = null;
                    FundingRequestDto poSapDetails = new FundingRequestDto();
                    if (bravoDto.isExist()) {
                        bravo_Id = bravoDto.getBravo_id();
                        poSapDetails = FundingRequestDtoMapper.toDto(posap, bravo_Id);
                    }

                    if (poSapDetails != null && bravo_Id != null) {
                        poSapDetails.setStatus("PENDING");
                        poSapDetails.setFundingAgencyId(purchaseOrderFundingRequest.agencyID);
                        fundingRequestDtos.add(poSapDetails);

                    } else if (bravo_Id == null) {
                        importPurchaseOrdersResponse.message("Bravo_id indisponible pour supplierSapId : " + posap.getSupplierCommonCode());
                        importPurchaseOrdersResponse.saved(false);
                    }
                }
                else {
                    importPurchaseOrdersResponse.message("No data found while trying to get poDetails for orderReference " + purchaseOrderFundingRequest.orderReference);
                    importPurchaseOrdersResponse.saved(false);
                }
            }



            if(!purchaseOrderFundingRequest.getOrderSource().equals("SAP")){
                FundingRequestDto poOracleDetails;
                try {
                    poOracleDetails = getOracleOrderDetailsByReferenceAndOperationUnit(purchaseOrderFundingRequest.orderReference, purchaseOrderFundingRequest.operationUnit);
                } catch (Exception e) {
                    log.error("Error while getting Oracle Order Details By Reference {} And OperationUnit {}", purchaseOrderFundingRequest.orderReference, purchaseOrderFundingRequest.operationUnit, e);
                    importPurchaseOrdersResponse.message("Error while getting Oracle Order Details By Reference " + purchaseOrderFundingRequest.orderReference + " And OperationUnit " + purchaseOrderFundingRequest.operationUnit);
                    importPurchaseOrdersResponse.saved(false);
                    importPurchaseOrdersResponses.add(importPurchaseOrdersResponse.build());
                    continue;
                }

                if (poOracleDetails != null) {
                    String supplierInfoUrl = backendConfig.getBravoURL() + "/supplier/profileByCommonCode/" + poOracleDetails.getSupplierOracleCode();
                    try {
                        FundingRequestApplicantDto supplierInfo = restTemplate.getForObject(supplierInfoUrl, FundingRequestApplicantDto.class);
                        if (supplierInfo != null) {
                            poOracleDetails.setStatus("PENDING");
                            poOracleDetails.setBravoId(supplierInfo.getSupplierBravoId());
                            poOracleDetails.setFundingAgencyId(purchaseOrderFundingRequest.agencyID);
                            fundingRequestDtos.add(poOracleDetails);
                        } else {
                            importPurchaseOrdersResponse.message("The supplier info is not found in bravo for Oracle code " + poOracleDetails.getSupplierOracleCode());
                            importPurchaseOrdersResponse.saved(false);
                        }
                    } catch (Exception e) {
                        log.error("Error while trying to get supplier info from bravo for Oracle code {}", poOracleDetails.getSupplierOracleCode(), e);
                        importPurchaseOrdersResponse.message("Error while trying to get supplier info from bravo for Oracle code " + poOracleDetails.getSupplierOracleCode());
                        importPurchaseOrdersResponse.saved(false);
                    }
                } else {
                    importPurchaseOrdersResponse.message("No data found while trying to get poOracleDetails for orderReference " + purchaseOrderFundingRequest.orderReference + " and operationUnit " + purchaseOrderFundingRequest.operationUnit);
                    importPurchaseOrdersResponse.saved(false);
                }
            }
            importPurchaseOrdersResponses.add(importPurchaseOrdersResponse.build());
        }
        restTemplate.postForEntity(lotusServiceConfig.getEcosystemUrl() + "/funding-request/import-all", fundingRequestDtos, ResponseEntity.class);
        return importPurchaseOrdersResponses;
    }

    private List<PurchaseOrderFundingRequest> readPurchaseOrdersFundingRequests(MultipartFile file) throws IOException {
        List<PurchaseOrderFundingRequest> purchaseOrderFundingRequests = new ArrayList<>();
        XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
        XSSFSheet sheet = workbook.getSheetAt(0);
        DataFormatter dataFormatter = new DataFormatter();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row currentRow = sheet.getRow(i);
            String orderReference = dataFormatter.formatCellValue(currentRow.getCell(0));
            String operationUnit = dataFormatter.formatCellValue(currentRow.getCell(1));
            String agencyIDString = dataFormatter.formatCellValue(currentRow.getCell(2));
            String orderSource = dataFormatter.formatCellValue(currentRow.getCell(3));
            Integer agencyID = (agencyIDString != null && !agencyIDString.isEmpty()) ? Integer.parseInt(agencyIDString) : 1;
            purchaseOrderFundingRequests.add(PurchaseOrderFundingRequest.builder()
                    .agencyID(agencyID)
                    .operationUnit(operationUnit)
                    .orderReference(orderReference)
                    .orderSource(orderSource)
                    .build()
            );
        }
        return purchaseOrderFundingRequests;
    }

    @Data
    @Builder
    protected static class PurchaseOrderFundingRequest {
        String orderReference;
        String operationUnit;
        Integer agencyID;

        String orderSource;
    }

    public BravoDto getBravoIdBySapId(String supplierSapId){
        String inscriptionUrl = lotusServiceConfig.getInscriptionURL()+"/supplier/bravoIdBySapId/"+supplierSapId;
        BravoDto bravoDto = new BravoDto();
        try{
            ResponseEntity<BravoDto> responseBravo = restTemplate.getForEntity(inscriptionUrl , BravoDto.class);
            bravoDto = responseBravo.getBody();
        }
        catch (Exception e){
            log.error("Error while getting bravo_id by sap_id "+e.getMessage());
        }
            return bravoDto;
    }

    public ResponseEntity<DataResponse<PurchaseOrderSearch>> getPurchaseDetailSap(String OrderReference){
        String S4URL = lotusServiceConfig.getCoordinatorURL() + "/search-purchase-orders/all";
        SearchPurchaseOrderFilters searchPurchaseOrderFilters = SearchPurchaseOrderFilters.builder()
                .purchaseOrderReference(OrderReference)
                .isApproved("true")
                .build();
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = "null";
        try {
            jsonRequest = objectMapper.writeValueAsString(searchPurchaseOrderFilters);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, requestHeaders);
        ResponseEntity<DataResponse<PurchaseOrderSearch>> response = new ResponseEntity<>(HttpStatus.OK);
        try { return
                restTemplate.exchange(S4URL, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<DataResponse<PurchaseOrderSearch>>() {}); }
        catch (Exception e){
            log.error("Error while getting SAP Order Details By Reference {} ", OrderReference, e);
        }
        return response;
    }

    public ApplicantPageableResponse getAllPaginatedFundingRequestsApplicantsForAgencyRole(Integer pathVariable) {
        String url = FUNDING_REQUEST;
        url += "all-approved-funding-applicants-count-pageable/" + pathVariable;
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() +
                        url);
        MapPageableResponse countResult =
                restTemplate.getForObject(fundingRequestsUrl.build().toUriString(),
                        MapPageableResponse.class);
        Map<Long, Long> content = countResult.getContent();
        if (!content.isEmpty()) {
            HttpEntity<Object> requestEntity = new HttpEntity<>(content.keySet());
            Map<String, Integer> params = new HashMap<>();

            ResponseEntity<List<FundingRequestApplicantDto>> response = restTemplate.
                    exchange(backendConfig.getBravoURL() + "/supplier/profilesBySupplierIds?page=0", HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                            }, params);

            response.getBody().forEach(applicant ->
                    applicant.setFundingRequestsCount(content.get(applicant.getSupplierBravoId())));

            List<FundingRequestApplicantDto> fundingRequestApplicantDtos = response.getBody();
            //check sap suppliers not existing in bravo system
            List<Long> responseIds = response.getBody().stream().map(a->a.getSupplierBravoId()).collect(Collectors.toList());
            List<Long>  idSapSupplier=content.keySet().stream()
                    .filter(id -> !responseIds.contains(id)).collect(Collectors.toList());
            if(!idSapSupplier.isEmpty()){
                idSapSupplier.forEach(id -> fundingRequestApplicantDtos.add(new FundingRequestApplicantDto(id)));
            }
            return new ApplicantPageableResponse(fundingRequestApplicantDtos, countResult.getCount());
        }
        return new ApplicantPageableResponse(Collections.emptyList(), 0L);
    }

    public RequestPageableResponse getAllFundingRequestsForSupplierByStatusForAgencyRole(Integer agencyId, Long bravoId, String filter) {
        String url = FUNDING_REQUEST;
        String role = "ROLE_AGENCY";
        url += "all-approved-applicant-funding-requests/" + agencyId + "/" + bravoId;
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + url);
        if (filter != null) {
            fundingRequestsUrl.queryParam("filter", filter);
        }
        RequestPageableResponse requestsResponse = restTemplate.getForObject(fundingRequestsUrl.build().toUriString(),
                RequestPageableResponse.class);
        List<FundingRequestDto> requestList = requestsResponse.getContent();
        RequestPageableResponse pageableResponse = new RequestPageableResponse();
        pageableResponse.setCount(requestsResponse.getCount());
        //toDo split detail by source
        if (!requestList.isEmpty()) {
            requestList.stream().forEach(f -> {
                if(f.getSource() == null) f.setSource("null");
            });

            Map<Long, String> companyNamesByBravoId = Collections.emptyMap();
            Map<Long, String> finalCompanyNamesByBravoId = companyNamesByBravoId;
            requestList.forEach(request -> {
                if (role.equals("ROLE_BUYER")) {
                    request.setCompanyName(finalCompanyNamesByBravoId.getOrDefault(request.getBravoId(), ""));
                }

                double billedAmount = 0;

                if (request.getPurchaseOrderAmount() != null) {
                    request.setAchievementPercentage(billedAmount / request.getPurchaseOrderAmount());
                }
            });
        }
        pageableResponse.setContent(requestList);
        return pageableResponse;
    }

    //Using SAP
    @Data
    @Builder
    protected static class PurchaseOrderFundingRequestSAP {
        String CommandeID;
        String ContractID;
        Integer agencyID;
    }
    public List<ImportPurchaseOrdersResponseSAP> importPurchaseOrdersSAP(MultipartFile file) throws IOException {
        List<FundingRequestDto> fundingRequestDtos = new ArrayList<>();
        List<ImportPurchaseOrdersResponseSAP> importPurchaseOrdersResponsesSAP = new ArrayList<>();
        List<PurchaseOrderFundingRequestSAP> purchaseOrders = readPurchaseOrdersFundingRequestsSAP(file);
        for (PurchaseOrderFundingRequestSAP purchaseOrderFundingRequest : purchaseOrders) {
            ImportPurchaseOrdersResponseSAP.ImportPurchaseOrdersResponseSAPBuilder importPurchaseOrdersResponse = ImportPurchaseOrdersResponseSAP.builder()
                    .agencyIDString(purchaseOrderFundingRequest.agencyID)
                    .CommandeID(purchaseOrderFundingRequest.CommandeID)
                    .ContractID(purchaseOrderFundingRequest.ContractID)
                    .message("Saved")
                    .saved(true);
            List<FundingRequestDto> poSAPDetails = new ArrayList<>();
            //List<FundingRequestDto> poSAPDetailsContract;
            //List<FundingRequestDto> poSAPDetailsCommande;
            // Traiter commandeID s'il est rempli
            if (purchaseOrderFundingRequest.CommandeID != null && !purchaseOrderFundingRequest.CommandeID.isEmpty()) {
                try {
                    SapResponseWrapper responseCommande =   getSAPDetailsByCommandeIDOrContractID(purchaseOrderFundingRequest.CommandeID, "commande", true);
                    poSAPDetails.addAll(responseCommande.getFundingRequestDtos());
                    if(responseCommande.getFundingRequestDtos()!=null && responseCommande.getFundingRequestDtos().size()>0){
                        importPurchaseOrdersResponse.saved(true);
                    }

                    if (!responseCommande.getErrorMessages().isEmpty() ) {
                        importPurchaseOrdersResponse.message("Errors while getting SAP Details By CommandID:\n" + String.join("\n", responseCommande.getErrorMessages()));
                        if(responseCommande.getFundingRequestDtos().isEmpty()){
                        importPurchaseOrdersResponse.saved(false);
                        importPurchaseOrdersResponsesSAP.add(importPurchaseOrdersResponse.build());
                        continue;
                        }
                    }
                } catch (Exception e) {
                    log.error("Error while getting SAP Order Details By CommandeID {}", purchaseOrderFundingRequest.CommandeID, e);
                    importPurchaseOrdersResponse.message("Error while getting SAP Details By CommandID (" + purchaseOrderFundingRequest.CommandeID + ") cause : "+e.getMessage());
                    importPurchaseOrdersResponse.saved(false);
                    importPurchaseOrdersResponsesSAP.add(importPurchaseOrdersResponse.build());
                    continue;
                }
            }

            // Traiter contractID s'il est rempli
            if (purchaseOrderFundingRequest.ContractID != null && !purchaseOrderFundingRequest.ContractID.isEmpty()) {
                try {
                    SapResponseWrapper responseContract = getSAPDetailsByCommandeIDOrContractID(purchaseOrderFundingRequest.ContractID, "contract", true);
                    poSAPDetails.addAll(responseContract.getFundingRequestDtos());

                    if (!responseContract.getErrorMessages().isEmpty() ) {
                        importPurchaseOrdersResponse.message("Errors while getting SAP Details By ContractID:\n" + String.join("\n", responseContract.getErrorMessages()));
                        if(responseContract.getFundingRequestDtos().isEmpty()){
                            importPurchaseOrdersResponse.saved(false);
                            importPurchaseOrdersResponsesSAP.add(importPurchaseOrdersResponse.build());
                            continue;
                        }
                    }
                } catch (Exception e) {
                    log.error("Error while getting SAP Order Details By ContractID {}", purchaseOrderFundingRequest.ContractID, e);
                    importPurchaseOrdersResponse.message("Error while getting SAP Details By ContractID (" + purchaseOrderFundingRequest.ContractID + ") cause : "+e.getMessage());
                    importPurchaseOrdersResponse.saved(false);
                    importPurchaseOrdersResponsesSAP.add(importPurchaseOrdersResponse.build());
                    continue;
                }
            }

            for(FundingRequestDto fundingRequestDto : poSAPDetails){
                if (fundingRequestDto != null) {
                    String supplierInfoUrl = backendConfig.getBravoURL() + "/supplier/profileBySupplierId/" + fundingRequestDto.getBravoId();
                    try {
                        FundingRequestApplicantDto supplierInfo = restTemplate.getForObject(supplierInfoUrl, FundingRequestApplicantDto.class);
                        if (supplierInfo != null || fundingRequestDto.getBravoId() != null) {
                            fundingRequestDto.setStatus("PENDING");
                            fundingRequestDto.setFundingAgencyId(purchaseOrderFundingRequest.agencyID);
                            fundingRequestDtos.add(fundingRequestDto);
                        } else {
                            importPurchaseOrdersResponse.message("The supplier info is not found for the bravoID " + fundingRequestDto.getBravoId() +" in SAP/S4Hana or the bravoId isn't sent from the call SAP");
                            importPurchaseOrdersResponse.saved(false);
                        }
                    } catch (Exception e) {
                        log.error("Error while trying to get info for bravoID {} because it's null", fundingRequestDto.getBravoId(), e);
                        importPurchaseOrdersResponse.message("Error while trying to get info for bravoID ( " + fundingRequestDto.getBravoId() + " ) because it's null or the list of supplierInfo is empty");
                        importPurchaseOrdersResponse.saved(false);
                    }
                }else {
                    importPurchaseOrdersResponse.message("No data found while trying to get SapDetails for CommandID " + purchaseOrderFundingRequest.CommandeID + " and ContractID " + purchaseOrderFundingRequest.ContractID);
                    importPurchaseOrdersResponse.saved(false);
                }
            }
            importPurchaseOrdersResponsesSAP.add(importPurchaseOrdersResponse.build());
        }
        restTemplate.postForEntity(lotusServiceConfig.getEcosystemUrl() + "/funding-request/import-all", fundingRequestDtos, ResponseEntity.class);
        return importPurchaseOrdersResponsesSAP;
    }
    private List<PurchaseOrderFundingRequestSAP> readPurchaseOrdersFundingRequestsSAP(MultipartFile file) throws IOException {
        List<PurchaseOrderFundingRequestSAP> purchaseOrderFundingRequests = new ArrayList<>();
        XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
        XSSFSheet sheet = workbook.getSheetAt(0);
        DataFormatter dataFormatter = new DataFormatter();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row currentRow = sheet.getRow(i);
            String CommandeID = dataFormatter.formatCellValue(currentRow.getCell(0));
            String ContractID = dataFormatter.formatCellValue(currentRow.getCell(1));
            String agencyIDString = dataFormatter.formatCellValue(currentRow.getCell(2));
            Integer agencyID = (agencyIDString != null && !agencyIDString.isEmpty()) ? Integer.parseInt(agencyIDString) : 1;
            purchaseOrderFundingRequests.add(PurchaseOrderFundingRequestSAP.builder()
                    .agencyID(agencyID)
                    .CommandeID(CommandeID)
                    .ContractID(ContractID)
                    .build()
            );
        }
        return purchaseOrderFundingRequests;
    }
    public SapResponseWrapper  getSAPDetailsByCommandeIDOrContractID(String id, String type, Boolean uniqueLine) throws JsonProcessingException, IOException {
        // Logging additional information
        log.info("Get additional information for purchase order by CommandeID {} from SAP/S4Hana", id);
        SapResponseWrapper responseWrapper = new SapResponseWrapper();
        List<FundingRequestDto> result = new ArrayList<>();
        List<String> errorMessages = new ArrayList<>();

        if (type == "contract" && !id.isEmpty()) {
            log.info("ContractID est {}", id);
            ContractsRequest contractsRequest = new ContractsRequest();
            ArrayList<String> commandeNumbers = new ArrayList<>();
            commandeNumbers.add(id);
            contractsRequest.setContractNumber(commandeNumbers);
            SapContratRequest sapContratRequest = new SapContratRequest();
            sapContratRequest.setContracts(contractsRequest);
            String jsonRequest = bodyToJsonContract(sapContratRequest);
            //List<FundingRequestDto> resultContract = sapService.retrieveFundingRequestDetailsFromSap(jsonRequest,type);
            SapResponseWrapper sapResponse = sapService.getFromSapWithErrorMessages(jsonRequest, type);
            errorMessages.addAll(sapResponse.getErrorMessages());

            log.info("The final result using using contractId {} ",sapResponse.getFundingRequestDtos());
            if(sapResponse.getFundingRequestDtos()!=null && sapResponse.getFundingRequestDtos().size()>0){
                if(uniqueLine ){
                    result.add(sapResponse.getFundingRequestDtos().get(0));
                }else
                    result.addAll(sapResponse.getFundingRequestDtos());
            }
        }
        if (type == "commande" && !id.isEmpty()) {
            log.info("CommandeID est {}", id);
            OrdersRequest ordersRequest = new OrdersRequest();
            ArrayList<String> orderNumbers = new ArrayList<>();
            orderNumbers.add(id);
            ordersRequest.setOrderNumber(orderNumbers);
            SapOrderRequest sapOrderRequest = new SapOrderRequest();
            sapOrderRequest.setOrders(ordersRequest);
            String jsonRequest = bodyToJsonOrder(sapOrderRequest);
            //List<FundingRequestDto> resultCommande= sapService.retrieveFundingRequestDetailsFromSap(jsonRequest,type);
            SapResponseWrapper sapResponse = sapService.getFromSapWithErrorMessages(jsonRequest, type);
            errorMessages.addAll(sapResponse.getErrorMessages());
            log.info("The final result using commandeId {} ",sapResponse.getFundingRequestDtos());
            //log.info("the commandeID {} le {} ",CommandeID,resultCommande.get);
            result.addAll(sapResponse.getFundingRequestDtos());
        }
        responseWrapper.setFundingRequestDtos(result);
        responseWrapper.setErrorMessages(errorMessages);
        return responseWrapper;

    }


    //The first index of json will be in UpperCase "Contracts": {"ContractNumber": [""]}
    public static String capitalizeKeys(String jsonString) throws Exception {
        // Create ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();

        // Parse JSON string into a JsonNode
        JsonNode jsonNode = objectMapper.readTree(jsonString);

        // Recursively capitalize keys
        JsonNode modifiedJsonNode = capitalizeKeysRecursive(jsonNode, objectMapper);

        // Convert the modified JsonNode back to a string
        return objectMapper.writeValueAsString(modifiedJsonNode);
    }

    // Recursively capitalize keys in a JsonNode
    private static JsonNode capitalizeKeysRecursive(JsonNode jsonNode, ObjectMapper objectMapper) {
        if (jsonNode.isObject()) {
            ObjectNode objectNode = (ObjectNode) jsonNode;
            ObjectNode modifiedObjectNode = objectMapper.createObjectNode();
            objectNode.fields().forEachRemaining(entry -> {
                String key = entry.getKey();
                String capitalizedKey = key.substring(0, 1).toUpperCase() + key.substring(1);
                modifiedObjectNode.set(capitalizedKey, capitalizeKeysRecursive(entry.getValue(), objectMapper));
            });
            return modifiedObjectNode;
        } else if (jsonNode.isArray()) {
            ArrayNode arrayNode = (ArrayNode) jsonNode;
            ArrayNode modifiedArrayNode = objectMapper.createArrayNode();
            arrayNode.elements().forEachRemaining(element -> modifiedArrayNode.add(capitalizeKeysRecursive(element, objectMapper)));
            return modifiedArrayNode;
        } else {
            return jsonNode;
        }
    }

    public RequestPageableResponse getFundingRequestsForSupplierByStatusUsingSap(String role, Integer agencyId, Long bravoId, int page, String filter) throws  IOException{
        String url = FUNDING_REQUEST;
        String oracleUrlHistory = "/oracle-history/approved-applicant-funding-requests/" + agencyId + "/" + bravoId;
        if (role.equals("ROLE_AGENCY")) {
            url += "approved-applicant-funding-requests/" + agencyId + "/" + bravoId;
        } else {
            url += "supplier-funding-requests-all";
        }
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + url);
        fundingRequestsUrl.queryParam("page", page);
        if (filter != null) {
            log.info("filter1",filter);
            System.out.println("filter "+filter);
            fundingRequestsUrl.queryParam("filter", filter);
        }

        log.info("starting the call to lotus services");
        RequestPageableResponse requestsResponse = restTemplate.getForObject(fundingRequestsUrl.build().toUriString(),
                RequestPageableResponse.class);
        log.info("end of the call to lotus services");
        List<FundingRequestDto> requestList = requestsResponse.getContent();
        RequestPageableResponse pageableResponse = new RequestPageableResponse();
        pageableResponse.setCount(requestsResponse.getCount());
        if (!requestList.isEmpty()) {
            //ORDERS
            OrdersRequest ordersRequest = new OrdersRequest();
            ArrayList<String> orderNumbers = new ArrayList<>();
            SapOrderRequest sapOrderRequest = new SapOrderRequest();
            //CONTRACT
            ContractsRequest contractsRequest = new ContractsRequest();
            ArrayList<String> contractNumbers = new ArrayList<>();
            SapContratRequest sapContratRequest = new SapContratRequest();

            requestList.forEach(e ->  {
                if(e.getSource().equals("commande")){
                    orderNumbers.add(e.getPurchaseOrderId());
                }
                if(e.getSource().equals("contract")){
                    contractNumbers.add(e.getPurchaseOrderRef());
                }
            });
            if(!orderNumbers.isEmpty()){
                ordersRequest.setOrderNumber(orderNumbers);
                sapOrderRequest.setOrders(ordersRequest);
                String ordersList = bodyToJsonOrder(sapOrderRequest);
                List<Long> bravoIds = requestList.parallelStream().map(FundingRequestDto::getBravoId)
                        .distinct().collect(Collectors.toList());
                Map<Long, String> companyNamesByBravoId = Collections.emptyMap();
                if (role.equals("ROLE_BUYER")) {
                    log.info("starting the call to bravo commande");
                    companyNamesByBravoId = getCompanyNamesByBravoId(bravoIds);
                    log.info("end of the call to bravo commande");
                }
                Map<Long, String> finalCompanyNamesByBravoId = companyNamesByBravoId;
                log.info("Get additional information for purchase order(commandeId) list {} from SAP", ordersList);
                //send ordersList is here commandeId taken from Mysql DataBase
                String type = "commande";
                log.info("starting the call to sap commande");
                List<FundingRequestDto> requestDtoList =  sapService.getFromSap(ordersList,type);
                log.info("end of the call to sap commande");
                requestList.forEach(request -> {
                    if (role.equals("ROLE_BUYER")) {
                        request.setCompanyName(finalCompanyNamesByBravoId.getOrDefault(request.getBravoId(), ""));
                    }
                    Optional<FundingRequestDto> purchaseOrderAdditionalInfo =
                            requestDtoList.parallelStream().filter(po -> po.getPurchaseOrderId().equals(request.getPurchaseOrderId())).findAny();
                    if (purchaseOrderAdditionalInfo.isPresent()) {
                        request.setPurchaseOrderStatus(purchaseOrderAdditionalInfo.get().getPurchaseOrderStatus());
                        request.setPurchaseOrderApprovalDate(purchaseOrderAdditionalInfo.get().getPurchaseOrderApprovalDate());
                        request.setAchievementPercentage((double)Math.round(purchaseOrderAdditionalInfo.get().getAchievementPercentage())/100);
                    }
                });
            }
            if(!contractNumbers.isEmpty()){
                contractsRequest.setContractNumber(contractNumbers);
                sapContratRequest.setContracts(contractsRequest);
                String contractList = bodyToJsonContract(sapContratRequest);
                List<Long> bravoIds = requestList.parallelStream().map(FundingRequestDto::getBravoId)
                        .distinct().collect(Collectors.toList());
                Map<Long, String> companyNamesByBravoId = Collections.emptyMap();
                if (role.equals("ROLE_BUYER")) {
                    log.info("first call to bravo contract");
                    companyNamesByBravoId = getCompanyNamesByBravoId(bravoIds);
                    log.info("second call to bravo contract");
                }
                Map<Long, String> finalCompanyNamesByBravoId = companyNamesByBravoId;
                log.info("Get additional information for purchase order(contractId) list {} from SAP", contractList);
                //send ordersList is here contractId taken from Mysql DataBase
                String type = "contract";
                log.info("starting the call to sap contract");
                List<FundingRequestDto> requestDtoList = sapService.getFromSap(contractList,type);
                log.info("end of the call to sap contract");

                // Filter requestDtoList to remove already processed purchaseOrderIds
                List<FundingRequestDto> requestDtoListFiltredFromOrderNumber = requestDtoList.stream()
                        .filter(dto -> !orderNumbers.contains(dto.getPurchaseOrderId()))
                        .collect(Collectors.toList());

                requestList.forEach(request -> {
                    if (role.equals("ROLE_BUYER")) {
                        request.setCompanyName(finalCompanyNamesByBravoId.getOrDefault(request.getBravoId(), ""));
                    }
                    Optional<FundingRequestDto> purchaseOrderAdditionalInfo =
                            requestDtoListFiltredFromOrderNumber.parallelStream().filter(po -> po.getPurchaseOrderId().equals(request.getPurchaseOrderId())).findAny();
                    if (purchaseOrderAdditionalInfo.isPresent()) {
                        request.setPurchaseOrderStatus(purchaseOrderAdditionalInfo.get().getPurchaseOrderStatus());
                        request.setPurchaseOrderApprovalDate(purchaseOrderAdditionalInfo.get().getPurchaseOrderApprovalDate());
                        request.setAchievementPercentage((double)Math.round(purchaseOrderAdditionalInfo.get().getAchievementPercentage())/100);
                    }
                });
            }

            if (role.equals("ROLE_AGENCY")) {
                UriComponentsBuilder fundingRequestsHistoryUrl =
                        UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + oracleUrlHistory);
                ResponseEntity<OracleFundingRequestDto[]> oracleHistoryList = restTemplate.getForEntity(fundingRequestsHistoryUrl.build().toUriString(),
                        OracleFundingRequestDto[].class);
                if(ObjectUtils.isNotEmpty(oracleHistoryList)) {
                    if(oracleHistoryList.getBody() != null) {
                        List<OracleFundingRequestDto> oracleRequestList =  Arrays.asList(oracleHistoryList.getBody());
                        oracleRequestList.forEach(
                                oracleFundingRequestDto -> {
                                    requestList.forEach(request -> {
                                        if(StringUtils.isNotBlank(request.getStatus()) && StringUtils.isNotBlank(request.getSupplierOracleCode())) {
                                            if(request.getStatus().equalsIgnoreCase("APPROVED")) {
                                                request.setPurchaseOrderStatus("Validé");
                                                request.setPurchaseOrderApprovalDate(oracleFundingRequestDto.getPurchaseOrderApprovalDate());
                                                request.setAchievementPercentage((double)Math.round(oracleFundingRequestDto.getAchievementPercentage())/100);
                                            }
                                        }
                                    });
                                }
                        );
                    }
                }
            }


        }
        pageableResponse.setContent(requestList);
        return pageableResponse;
    }

    public FundingRequestDto getFundingRequestDetailUsingSap(Integer agencyId, String orderId, Integer requestId, String requestSource) {
        log.info("Get funding request detail for agency id {} and request id {}", agencyId, requestId);
            String fundingRequestUrl = "/funding-request/funding-request-detail/" + requestId;
            try {
                FundingRequestDto fundingRequestDetailDto = restTemplate.getForObject(lotusServiceConfig.getEcosystemUrl() + fundingRequestUrl, FundingRequestDto.class);
                if (fundingRequestDetailDto != null && !fundingRequestDetailDto.getStatus().equals("PENDING") &&
                        fundingRequestDetailDto.getFundingAgencyId().equals(agencyId)) {
                    log.info("Got funding request detail {} for agency id {} and request id {}", fundingRequestDetailDto.getId(), agencyId, requestId);
                    if(StringUtils.equalsIgnoreCase(requestSource, FUNDING_REQUEST_SOURCE)) {
                        if(fundingRequestDetailDto.getSource().equals("contract")){
                            ContractsRequest contractsRequest = new ContractsRequest();
                            ArrayList<String> commandeNumbers = new ArrayList<>();
                            orderId = fundingRequestDetailDto.getPurchaseOrderRef();
                            commandeNumbers.add(orderId);
                            contractsRequest.setContractNumber(commandeNumbers);
                            SapContratRequest sapContratRequest = new SapContratRequest();
                            sapContratRequest.setContracts(contractsRequest);
                            String jsonRequest = bodyToJsonContract(sapContratRequest);
                            SapResponseWrapper poSapDetails =sapService.getFromSapWithErrorMessages(jsonRequest,"contract");
                            if (poSapDetails.getFundingRequestDtos()!=null && poSapDetails.getFundingRequestDtos().size()>0) {
                                for(FundingRequestDto i : poSapDetails.getFundingRequestDtos()){
                                    fundingRequestDetailDto.setBilledAmount(i.getBilledAmount());
                                    fundingRequestDetailDto.setPaidAmount(i.getPaidAmount());
                                    fundingRequestDetailDto.setPurchaseOrderCategory(i.getPurchaseOrderCategory());
                                    fundingRequestDetailDto.setPurchaseOrderPaymentTermsName(i.getPurchaseOrderPaymentTermsName());
                                    fundingRequestDetailDto.setPurchaseOrderPaymentTermsDescription(i.getPurchaseOrderPaymentTermsDescription());
                                    fundingRequestDetailDto.setPurchaseOrderStatus(i.getPurchaseOrderStatus());
                                    fundingRequestDetailDto.setStatus(i.getStatus());
                                    fundingRequestDetailDto.setApprovalAttachmentAmount(i.getApprovalAttachmentAmount());
                                    fundingRequestDetailDto.setAchievementPercentage((double)Math.round(i.getAchievementPercentage())/100);
                                }
                            }
                            return fundingRequestDetailDto;
                        }
                        if(fundingRequestDetailDto.getSource().equals("commande")){
                            OrdersRequest ordersRequest = new OrdersRequest();
                            ArrayList<String> orderNumbers = new ArrayList<>();
                            orderNumbers.add(orderId);
                            ordersRequest.setOrderNumber(orderNumbers);
                            SapOrderRequest sapOrderRequest = new SapOrderRequest();
                            sapOrderRequest.setOrders(ordersRequest);
                            String jsonRequest = bodyToJsonOrder(sapOrderRequest);
                            SapResponseWrapper poSapDetails =sapService.getFromSapWithErrorMessages(jsonRequest,"commande");
                            if (poSapDetails.getFundingRequestDtos()!=null && poSapDetails.getFundingRequestDtos().size()>0) {
                                for(FundingRequestDto i : poSapDetails.getFundingRequestDtos()){
                                    fundingRequestDetailDto.setBilledAmount(i.getBilledAmount());
                                    fundingRequestDetailDto.setPurchaseOrderAmount(i.getPurchaseOrderAmount());
                                    fundingRequestDetailDto.setPaidAmount(i.getPaidAmount());
                                    fundingRequestDetailDto.setPurchaseOrderCategory(i.getPurchaseOrderCategory());
                                    fundingRequestDetailDto.setPurchaseOrderPaymentTermsName(i.getPurchaseOrderPaymentTermsName());
                                    fundingRequestDetailDto.setPurchaseOrderPaymentTermsDescription(i.getPurchaseOrderPaymentTermsDescription());
                                    fundingRequestDetailDto.setPurchaseOrderStatus(i.getPurchaseOrderStatus());
                                    fundingRequestDetailDto.setApprovalAttachmentAmount(i.getApprovalAttachmentAmount());
                                    fundingRequestDetailDto.setAchievementPercentage((double)Math.round(i.getAchievementPercentage())/100);
                                }
                            }
                            return fundingRequestDetailDto;
                        }
                    } else {
                        log.info("Got funding request detail {} for agency id {} and request id {} from oracle History data", fundingRequestDetailDto.getId(), agencyId, requestId);
                        String oracleUrlHistory = "/oracle-history/funding-request/funding-request-detail/".concat(orderId);
                        UriComponentsBuilder fundingRequestsHistoryUrl =
                                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + oracleUrlHistory);
                        OracleFundingRequestDto oracleFundingRequest = restTemplate.getForObject(fundingRequestsHistoryUrl.build().toUriString(), OracleFundingRequestDto.class);
                        if(ObjectUtils.isNotEmpty(oracleFundingRequest)) {
                            fundingRequestDetailDto.setBilledAmount(oracleFundingRequest.getBilledAmount());
                            fundingRequestDetailDto.setPurchaseOrderAmount(oracleFundingRequest.getPurchaseOrderAmount());
                            fundingRequestDetailDto.setPaidAmount(oracleFundingRequest.getPaidAmount());
                            fundingRequestDetailDto.setPurchaseOrderCategory(oracleFundingRequest.getPurchaseOrderCategory());
                            fundingRequestDetailDto.setPurchaseOrderPaymentTermsName(oracleFundingRequest.getPurchaseOrderPaymentTermsName());
                            fundingRequestDetailDto.setPurchaseOrderPaymentTermsDescription(oracleFundingRequest.getPurchaseOrderPaymentTermsName());
                            fundingRequestDetailDto.setPurchaseOrderStatus(oracleFundingRequest.getPurchaseOrderStatus());
                            fundingRequestDetailDto.setApprovalAttachmentAmount(oracleFundingRequest.getApprovalAttachmentAmount());
                            fundingRequestDetailDto.setAchievementPercentage((double)Math.round(oracleFundingRequest.getAchievementPercentage())/100);
                            if(oracleFundingRequest.getStatus().equalsIgnoreCase("APPROVED"))
                                fundingRequestDetailDto.setPurchaseOrderStatus("Validé");
                        }
                        return fundingRequestDetailDto;
                    }

                }
                log.info("Funding request is not found or not approved");
                return null;
            } catch (Exception e) {
                log.info("Error occured with cause {}", e.getMessage());
            }
            return null;
    }


    private String bodyToJsonOrder(SapOrderRequest sapOrderRequest){
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = null;
        try {
            String jsonRequestToUpperCase = objectMapper.writeValueAsString(sapOrderRequest);
            jsonRequest = capitalizeKeys(jsonRequestToUpperCase);
        } catch (JsonProcessingException e) {
            log.error("Error serializing SapRequest: {}", e.getMessage());
            // Handle the error gracefully, perhaps return an error response
            return null;
        }catch (Exception e){
            log.error("File not have been change toUpperCase for the first indexes", e.getMessage());
        }
        return jsonRequest;
    }
    private String bodyToJsonContract(SapContratRequest sapContratRequest){
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = null;
        try {
            String jsonRequestToUpperCase = objectMapper.writeValueAsString(sapContratRequest);
            jsonRequest = capitalizeKeys(jsonRequestToUpperCase);
        } catch (JsonProcessingException e) {
            log.error("Error serializing SapRequest: {}", e.getMessage());
            // Handle the error gracefully, perhaps return an error response
            return null;
        }catch (Exception e){
            log.error("File not have been change toUpperCase for the first indexes", e.getMessage());
        }
        return jsonRequest;
    }
}
