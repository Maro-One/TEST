package middleware.services;

import lombok.extern.slf4j.Slf4j;
import middleware.services.mail.MailContentBuilder;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import java.io.*;
import java.util.Map;

@Service
@Slf4j
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.from}")
    private String from;

    @Autowired
    MailContentBuilder mailContentBuilder;
    @Async
    public void sendEmail(String to, String subject, String tempalte, Map<String, Object> data, ByteArrayOutputStream attachement, String inlineImagePath) throws javax.mail.MessagingException {
        String content = mailContentBuilder.build(data, tempalte);
        sendEmail(to, subject, content, attachement, inlineImagePath);
    }
    @Async
    public void sendEmail(String to, String subject, String content, ByteArrayOutputStream attachement, String inlineImagePath) throws javax.mail.MessagingException {
        log.info("Start sending email to {}", to);
        MimeMessage message = javaMailSender.createMimeMessage();
        try {
            message.setFrom(from);
            message.setHeader("Content-Type", "multipart/mixed");
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject("Tamwil Plateforme");

            MimeBodyPart messageBodyPart = new MimeBodyPart();
            message.setSubject(subject, "UTF-8");
            messageBodyPart.setContent(content, "text/html; charset=UTF-8");
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            if (attachement != null) {
                log.info("Start setting the attachment in the mail of {}",to);
                messageBodyPart = new MimeBodyPart();
                DataSource source = new ByteArrayDataSource(attachement.toByteArray(), "application/pdf");
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName("Ecosystem.pdf");
                multipart.addBodyPart(messageBodyPart);
                log.info("End setting the attachment in the mail of {}",to);
            }

            if (inlineImagePath != null) {
                log.info("Start setting the image in the mail of {}",to);
                multipart = new MimeMultipart("related");
                messageBodyPart = new MimeBodyPart();
                messageBodyPart.setContent(content, "text/html");
                multipart.addBodyPart(messageBodyPart);

                //create file
                File tempFile = new File(System.getProperty("user.home") + File.separator + inlineImagePath.split("/")[3]);
                if(!tempFile.exists()) {
                    try (OutputStream output = new FileOutputStream(tempFile);) {
                        IOUtils.copy(new ClassPathResource(inlineImagePath).getInputStream(), output);
                    }
                }
                DataSource fds = new FileDataSource(tempFile);

                messageBodyPart = new MimeBodyPart();
                messageBodyPart.setDataHandler(new DataHandler(fds));
                messageBodyPart.setHeader("Content-ID", "<image>");
                messageBodyPart.setFileName(fds.getName());
                multipart.addBodyPart(messageBodyPart);
                log.info("End of setting the image in the mail to {}", to);
            }

            message.setContent(multipart);
            javaMailSender.send(message);
            log.info("Email sent to {}", to);
        } catch (javax.mail.MessagingException e) {
            log.error("Ecosystem: Failed to send email to " + to + ", content was: " + content, e);
            throw(e);
        } catch (IOException e) {
            log.error("Error sending email", e);
        }
    }

}
