package middleware.services;

import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.*;
import middleware.utils.Helper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.mail.MessagingException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@EnableAsync
@Service
@Slf4j
public class SupplierService {

    RestTemplate restTemplate;
    BackendConfig backendConfig;
    LotusServiceConfig lotusServiceConfig;
    CategorieService categorieService;
    private final EmailService emailService;
    FundingRequestService fundingRequestService;
    @Value("${spring.mail.to}")
    private String to;

    @Autowired
    public SupplierService(RestTemplate restTemplate, BackendConfig backendConfig, LotusServiceConfig lotusServiceConfig, CategorieService categorieService, EmailService emailService, FundingRequestService fundingRequestService) {
        this.restTemplate = restTemplate;
        this.backendConfig = backendConfig;
        this.lotusServiceConfig = lotusServiceConfig;
        this.categorieService = categorieService;
        this.emailService = emailService;
        this.fundingRequestService = fundingRequestService;
    }

    public FundingRequestApplicantDto getSupplierInfoWithCheck(Integer agencyId, Long supplierId) {
        String url =
                lotusServiceConfig.getEcosystemUrl() + "/funding-request/agency-has-supplier-request-by-id/"
                        + agencyId + "/" + supplierId;
        Boolean checkExistence = restTemplate.getForObject(url, Boolean.class);
        if (checkExistence.equals(true)) {
            return getSupplierInfo(supplierId);
        }
        return null;
    }

    public FundingRequestApplicantDto getSupplierInfo(Long supplierId) {
        HttpEntity<List<Long>> requestEntity = new HttpEntity<>(Collections.singletonList(supplierId));
        Map<String, Integer> params = new HashMap<>();
        params.put("page", 0);
        ResponseEntity<List<FundingRequestApplicantDto>> response = restTemplate.
                exchange(backendConfig.getBravoURL() + "/supplier/profilesBySupplierIds?page={page}",
                        HttpMethod.POST, requestEntity,
                        new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                        }, params);

        List<FundingRequestApplicantDto> result = response.getBody();
        return result.isEmpty() ? new FundingRequestApplicantDto() : result.get(0);
    }

    public List<FundingRequestApplicantDto> searchApprovedFundingRequestsApplicants(Integer agencyId, String input) {
        log.info("Get approved funding requests applicants by agency id {} and input {}", agencyId, input);
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + "/funding-request/approved-funding-applicants-count/"
                        + agencyId);
        ResponseEntity<Map<Long, Long>> exchangeResult = restTemplate.exchange(fundingRequestsUrl.build().toUriString(), HttpMethod.GET, null,
                new ParameterizedTypeReference<Map<Long, Long>>() {
                });
        Map<Long, Long> content = exchangeResult.getBody();
        log.info("Got {} total approved funding requests applicants by agency id {} and input {}", agencyId, input, content.size());
        if (!content.isEmpty()) {
            HttpEntity<SupplierFilterDto> requestEntity =
                    new HttpEntity<>(new SupplierFilterDto(new ArrayList<>(content.keySet()), input));

            ResponseEntity<List<FundingRequestApplicantDto>> response = restTemplate.
                    exchange(backendConfig.getBravoURL() + "/supplier/profilesBySupplierIdsAndInputFilter", HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                            });

            List<FundingRequestApplicantDto> supplierInfos = response.getBody();
            supplierInfos.forEach(applicant ->
                    applicant.setFundingRequestsCount(content.get(applicant.getSupplierBravoId())));

            return supplierInfos;
        }
        return Collections.emptyList();
    }

    public List<FundingRequestApplicantDto> searchAllFundingRequestsApplicants(String input) {
        log.info("Get all funding requests applicants with and input {}", input);
        UriComponentsBuilder fundingRequestsUrl =
                UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + "/funding-request/all-funding-applicants-count");
        ResponseEntity<Map<Long, Long>> exchangeResult = restTemplate.exchange(fundingRequestsUrl.build().toUriString(), HttpMethod.GET, null,
                new ParameterizedTypeReference<Map<Long, Long>>() {
                });
        Map<Long, Long> content = exchangeResult.getBody();
        log.info("Got {} total funding requests applicants by input {}", input, content.size());
        if (!content.isEmpty()) {
            HttpEntity<SupplierFilterDto> requestEntity =
                    new HttpEntity<>(new SupplierFilterDto(new ArrayList<>(content.keySet()), input));

            ResponseEntity<List<FundingRequestApplicantDto>> response = restTemplate.
                    exchange(backendConfig.getBravoURL() + "/supplier/profilesBySupplierIdsAndInputFilter", HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                            });

            List<FundingRequestApplicantDto> supplierInfos = response.getBody();
            supplierInfos.forEach(applicant ->
                    applicant.setFundingRequestsCount(content.get(applicant.getSupplierBravoId())));

            return supplierInfos;
        }
        return Collections.emptyList();
    }

    public ScoringDto getSupplierScoringsForAgency(Integer agencyId, Long bravoId) {
        String url = lotusServiceConfig.getEcosystemUrl() + "/funding-request/agency-has-supplier-request-by-id/" + agencyId + "/" + bravoId;
        Boolean checkExistence = restTemplate.getForObject(url, Boolean.class);
        if (checkExistence != null && checkExistence.equals(true)) {
            return getSupplierScoring(bravoId);
        }
        return null;
    }

    public ScoringDto getSupplierScoring(Long bravoId) {
        String status = "Activé";

        SupplierDto supplierDto =
                restTemplate.getForObject(backendConfig.getBravoURL() + "/supplier/" + bravoId, SupplierDto.class);
        if ( supplierDto == null ||
                supplierDto.getSupplierStatus() == null ||
                !status.equals(supplierDto.getSupplierStatus()) ) {
            return null;
        }


        String assessmentUrl =
                backendConfig.getBravoURL() + "/supplier/" + bravoId + "/category-assessment/all";
        List<Assessment> assessments = Helper.emptyIfNull(restTemplate.getForObject(assessmentUrl, Assessment[].class));

        if (assessments.isEmpty()) {
            return ScoringDto
                    .builder()
                    .supplierBravoId(bravoId)
                    .supplierStatus(getSupplierSecondaryStatut(bravoId))
                    .scoringCapabilities(new ArrayList<>())
                    .mainActivity(supplierDto.getMainActivity())
                    .build();
        }
        List<Assessment> orderedAssessmentsByDateDesc =
                assessments
                        .stream()
                        .filter(assessment -> assessment.getAssessmentType().equals("CATEGORY"))
                        .sorted(Collections.reverseOrder(Comparator.comparing(Assessment::getAssessmentDate)))
                        .collect(Collectors.toList());

        ScoringFinancial scoringFinancial = getFinancialScoring(orderedAssessmentsByDateDesc);

        List<ScoringCapabilities> scoringCapabilities = getScoringCapabilities(orderedAssessmentsByDateDesc);

        return ScoringDto
                .builder()
                .supplierBravoId(bravoId)
                .supplierStatus(getSupplierSecondaryStatut(bravoId))
                .scoringFinancial(scoringFinancial)
                .scoringCapabilities(scoringCapabilities)
                .mainActivity(supplierDto.getMainActivity())
                .build();
    }

    public String getSupplierSecondaryStatut(Long bravoId){

        String BsUrl = backendConfig.getBravoURL()+"/supplier/supplierSeconderyStatut/"+bravoId;
        String responce = restTemplate.getForObject(BsUrl,String.class);
        return responce;
    }

    public List<ExportSupplierDto> exportSuppliersFile(){
        String ecosystemUrl = lotusServiceConfig.getEcosystemUrl() + "/funding-request/export-supplierPurchaseOrderIds";
        String bravoUrl = backendConfig.getBravoURL()+"/supplier/exportSupplier/info";
        String OracleUrl = backendConfig.getOracleEbsURL()+"/purchase-orders/exportSupplierRequest/info";
        UriComponentsBuilder oracleURI = UriComponentsBuilder.fromHttpUrl(OracleUrl);
        UriComponentsBuilder bravoURI = UriComponentsBuilder.fromHttpUrl(bravoUrl);
        //Getting Bravo_Ids and Purchase_Order_ids
        ResponseEntity<List<ExportedDto>> responce = restTemplate.exchange(ecosystemUrl,HttpMethod.GET,null,new ParameterizedTypeReference<List<ExportedDto>>(){});
        log.info("responce from ecosystem BravoIds and PurchaseOrderIds : {}",responce);
        //Getting just the Bravo_Ids
        List<Long> distinctBravoIds = responce.getBody().stream()
                .map(ExportedDto :: getSupplierBravoId)
                .distinct()
                .collect(Collectors.toList());
        log.info("les bravos ids que nous récupéront depuis lotus-services ecosystem distinctBravoIds : {}",distinctBravoIds);
        //Getting just the Purchase_Ids
        List<String> distinctPurchaseOrderIds = responce.getBody().stream()
                .map(ExportedDto :: getPurchaseOrderId)
                .distinct()
                .collect(Collectors.toList());
        log.info("les PurchaseOrderIds que nous récupéront depuis lotus-services ecosystem distinctPurchaseOrderIds : {}",distinctPurchaseOrderIds);
        HttpEntity<List<String>>  requestEntity1 = new HttpEntity<>(distinctPurchaseOrderIds);
//        ResponseEntity<List<ExportSupplierDto>> oracleResponse = restTemplate.exchange(oracleURI.toUriString(),HttpMethod.POST,requestEntity1, new ParameterizedTypeReference<List<ExportSupplierDto>>() {}
//        );
        ResponseEntity<List<ExportSupplierOraclePageableResponse>> oracleResponse = restTemplate.exchange(oracleURI.toUriString(),HttpMethod.POST,requestEntity1,new ParameterizedTypeReference<List<ExportSupplierOraclePageableResponse>>() {});
        List<ExportSupplierDto> supplierDto = oracleResponse.getBody().get(0).getContent();
        log.info("le contenu récupé depuis bravo Oracle : {}",supplierDto);

        HttpEntity<List<Long>> requestEntity = new HttpEntity<>(distinctBravoIds);
        ResponseEntity<List<ExportSupplierDto>> bravoResponse = restTemplate.exchange(bravoURI.toUriString(),HttpMethod.POST,requestEntity, new ParameterizedTypeReference<List<ExportSupplierDto>>() {}
        );
        List<ExportSupplierDto> bravoSupplierDto = bravoResponse.getBody();
        log.info("le contenu récupé depuis bravo bravoSupplierDto : {}",bravoSupplierDto);
        List<ExportSupplierDto> finalResult = new ArrayList<>();
        for(ExportSupplierDto e : supplierDto){
            //Long bravo_Id = responce.getBody().stream().filter( d -> d.getPurchaseOrderId().equals(e.getPurchaseOrderId())).collect(Collectors.toList()).get(0).getSupplierBravoId();
            responce.getBody().stream().forEach(d ->{
                        String pod = d.getPurchaseOrderId().replace("s","");
                        log.info("pod est : {} ",pod);
                        if (pod.equals(e.getPurchaseOrderId())){
                            Long bravo_Id = d.getSupplierBravoId();
                            log.info("bravo_Id est : {} ",bravo_Id);
                            ExportSupplierDto exportSupplierDto = getBravoInfo(bravo_Id, bravoSupplierDto);
                            log.info("getBravoInfo(bravo_Id, bravoSupplierDto) : {} ",exportSupplierDto);
                            ExportSupplierDto exportSupplierDto1 = new ExportSupplierDto();
                            exportSupplierDto1.setBilledAmount(e.getBilledAmount());
                            exportSupplierDto1.setPaidAmount(e.getPaidAmount());
                            exportSupplierDto1.setPurchaseOrderId(e.getPurchaseOrderId());
                            exportSupplierDto1.setPurchaseOrderRef(e.getPurchaseOrderRef());
                            exportSupplierDto1.setPurchaseOrderDescription(e.getPurchaseOrderDescription());
                            exportSupplierDto1.setPurchaseOrderAmount(e.getPurchaseOrderAmount());
                            exportSupplierDto1.setStatus(e.getStatus());
                            exportSupplierDto1.setPurchaseOrderApprovalDate(e.getPurchaseOrderApprovalDate());
                            exportSupplierDto1.setApprovalAttachmentAmount(e.getApprovalAttachmentAmount());
                            if(exportSupplierDto != null){
                                exportSupplierDto1.setSupplierBravoId(exportSupplierDto.getSupplierBravoId());
                                exportSupplierDto1.setCompanyName(exportSupplierDto.getCompanyName());
                                exportSupplierDto1.setSupplierStatus(exportSupplierDto.getSupplierStatus());
                                exportSupplierDto1.setMainActivity(exportSupplierDto.getMainActivity());
                                exportSupplierDto1.setSecondaryStatus(exportSupplierDto.getSecondaryStatus());
                            }
                            finalResult.add(exportSupplierDto1);
                        }
                    }
            );

        }
        log.info("finalResult : {} ",finalResult);
        return finalResult;

    }

//    for(ExportSupplierDto e : supplierDto){
//        Long bravo_Id = responce.getBody().stream().filter( d -> d.getPurchaseOrderId().equals(e.getPurchaseOrderId())).collect(Collectors.toList()).get(0).getSupplierBravoId();
//        ExportSupplierDto exportSupplierDto = getBravoInfo(bravo_Id, supplierDto);
//        ExportSupplierDto exportSupplierDto1 = new ExportSupplierDto();
//        exportSupplierDto1.setBilledAmount(e.getBilledAmount());
//        exportSupplierDto1.setPaidAmount(e.getPaidAmount());
//        exportSupplierDto1.setPurchaseOrderId(e.getPurchaseOrderId());
//        exportSupplierDto1.setPurchaseOrderAmount(e.getPurchaseOrderAmount());
//        if(exportSupplierDto != null){
//            exportSupplierDto1.setSupplierBravoId(exportSupplierDto.getSupplierBravoId());
//            exportSupplierDto1.setCompanyName(exportSupplierDto.getCompanyName());
//            exportSupplierDto1.setSupplierStatus(exportSupplierDto.getSupplierStatus());
//            exportSupplierDto1.setMainActivity(exportSupplierDto.getMainActivity());
//            exportSupplierDto1.setSecondaryStatus(exportSupplierDto.getSecondaryStatus());
//        }
//        finalResult.add(exportSupplierDto1);
//    }

    private ExportSupplierDto getBravoInfo(Long BravoId, List<ExportSupplierDto> lists){
        for(ExportSupplierDto exportDto : lists){
            log.info("exportDto.getSupplierBravoId().equals(BravoId) : {} ",exportDto.getSupplierBravoId().equals(BravoId));
            if(exportDto.getSupplierBravoId().equals(BravoId)){
                log.info("exportDto : {} ",exportDto);
                return  exportDto;
            }
        }
        return null;
    }

    private ScoringFinancial getFinancialScoring(List<Assessment> assessments) {
        double changeRate = 0.;
        Assessment lastAssessment = assessments.get(0);

        if (assessments.size() > 1 && lastAssessment.getFinancialRating() > 0 && assessments.get(1).getFinancialRating() > 0) {
            changeRate = ((lastAssessment.getFinancialRating() - assessments.get(1).getFinancialRating())/assessments.get(1).getFinancialRating())*100;
        }

        return ScoringFinancial.builder()
                .score(assessments.get(0).getFinancialRating())
                .changeRate((double)Math.round(changeRate*100)/100)
                .build();
    }

    private String getCategoryNameByCode(CategorieDto categorieDto) {
        CategorieDto category = categorieService.getCategorieByCode(categorieDto.getCategoryCode());
        return category.getSousFamille();
    }

    private Set<CategorieDto> getCategoriesFromAssessments(List<Assessment> assessments) {
        Set<CategorieDto> categories = new HashSet<>();
        for (Assessment assessment : assessments) {
            categories.addAll(assessment.getCategories());
        }
        return categories;
    }

    private Rating<Double, Double> getCapabilitiesRating(List<Double> capabilitiesRatingPerCategory) {
        Rating<Double, Double> rating = new Rating<>(0.,0.);


        if (!capabilitiesRatingPerCategory.isEmpty() ) {
            rating.setScore(capabilitiesRatingPerCategory.get(0));
            double changeRate = 0.;

            if (capabilitiesRatingPerCategory.size() > 1 && capabilitiesRatingPerCategory.get(0) > 0 && capabilitiesRatingPerCategory.get(1) > 0 ) {
                changeRate = ((capabilitiesRatingPerCategory.get(0) - capabilitiesRatingPerCategory.get(1))/capabilitiesRatingPerCategory.get(1))*100;
            }
            rating.setChangeRate((double)Math.round(changeRate*100)/100);
        }

        return rating;
    }

    private Rating<String, Integer> getPositionRating(List<String> positioning) {
        Rating<String, Integer> rating = new Rating<>("",0);

        if (!positioning.isEmpty()) {
            rating.setScore(positioning.get(0));
            int positionChangeRate = 0;
            if (positioning.size() > 1 && !positioning.get(0).equals(positioning.get(1))) {
                Map<String, Integer> supplierPositioning = Helper.supplierPositioning;
                positionChangeRate =
                        supplierPositioning.get(positioning.get(0)) - supplierPositioning.get(positioning.get(1));
            }
            rating.setChangeRate(positionChangeRate);
        }

        return rating;
    }

    private List<ScoringCapabilities> getScoringCapabilities(List<Assessment> assessments) {
        Set<CategorieDto> categories = getCategoriesFromAssessments(assessments);

        List<ScoringCapabilities> scoringCapabilities = new ArrayList<>();

        for (CategorieDto category : categories) {
            ScoringCapabilities scoringCapability = ScoringCapabilities.builder().build();
            scoringCapability.setCategory(getCategoryNameByCode(category));

            List<Double> capabilitiesRatingPerCategory = new ArrayList<>();
            List<String> positioning = new ArrayList<>();
            for (Assessment assessment: assessments) {
                long count =
                    assessment.getCategories()
                        .stream()
                        .filter(categoryDto -> categoryDto.getCategoryCode().equals(category.getCategoryCode()))
                        .count();
                if (count == 1) {
                    if (assessment.getSupplierPositioning() != null) {
                        positioning.add(mapSupplierPositioning(assessment.getSupplierPositioning()));
                    }
                    if (assessment.getCapabilitiesRating() != null) {
                        capabilitiesRatingPerCategory.add(assessment.getCapabilitiesRating());
                    }
                }
            }

            Rating<Double, Double> capabilitiesRating = getCapabilitiesRating(capabilitiesRatingPerCategory);
            scoringCapability.setScore(capabilitiesRating.getScore());
            scoringCapability.setChangeRate(capabilitiesRating.getChangeRate());

            Rating<String, Integer> positionRating = getPositionRating(positioning);
            scoringCapability.setSupplierPositioning(positionRating.getScore());
            scoringCapability.setPositionChangeRate(positionRating.getChangeRate());

            scoringCapabilities.add(scoringCapability);
        }

        return scoringCapabilities;
    }

    private String mapSupplierPositioning(String position) {
        switch (position) {
            case "Developped":
                return "Developed";
            case "Champions":
                return "Champion";
            default:
                return position;
        }
    }

    @Async
    @Scheduled(cron = "${schedule.disabled-supplier}")
    public void getAllSuppliersBackup() {
        log.info("Disabled supplier service starting");
        String BsUrl = backendConfig.getBravoURL() + "/supplier/getAllNoFlag"; //get all suppliers from bravo
        String fundingRequestBravoIdsEsUrl = lotusServiceConfig.getEcosystemUrl() + "/funding-request/all-funding-requests-bravo-ids"; // get all tamwil suppliers bravo ids
        String supplierSeconderyStatusBsUrl = backendConfig.getBravoURL() + "/supplier/supplierSeconderyStatut/"; // get secondery status one by one
        String suppliersBackupEsUrl = lotusServiceConfig.getEcosystemUrl() + "/supplier/all-suppliers-backup"; // get all backed suppliers
        String saveSupplierEsUrl = lotusServiceConfig.getEcosystemUrl() + "/supplier/save-supplier-backup"; // save suppliers
        String AgencyListUrl = lotusServiceConfig.getEcosystemUrl() + "/funding-agency-account/get-all-agencies-data"; // get agencies account id and emails
        ResponseEntity<Long[]> bravoLotusIdsArray = restTemplate.getForEntity(fundingRequestBravoIdsEsUrl, Long[].class);
        List<Long> bravoLotusIdsList = Arrays.asList(bravoLotusIdsArray.getBody());
        ResponseEntity<SupplierDto[]> bravoSuppliersArray = restTemplate.getForEntity(BsUrl, SupplierDto[].class);
        List<SupplierDto> bravoSuppliersList = Arrays.asList(bravoSuppliersArray.getBody());
        Map<Long, SupplierDto> bravoSuppliersMap = bravoSuppliersList.stream().collect(Collectors.toMap(SupplierDto::getSupplierId, v -> v));
        ResponseEntity<SupplierBackupDto[]> suppliersBackupArray = restTemplate.getForEntity(suppliersBackupEsUrl, SupplierBackupDto[].class);
        List<SupplierBackupDto> suppliersBackupList = Arrays.asList(suppliersBackupArray.getBody());
        Map<Long, SupplierBackupDto> suppliersBackupMap = suppliersBackupList.stream().collect(Collectors.toMap(SupplierBackupDto::getSupplierId, v -> v));
        ResponseEntity<FundingAgencyAccountDto[]> AgencyArray = restTemplate.getForEntity(AgencyListUrl, FundingAgencyAccountDto[].class);
        List<FundingAgencyAccountDto> AgencyList = Arrays.asList(AgencyArray.getBody());
        Map<String, Object> forMail = new HashMap<>();
        Set<String> emailList = new HashSet<String>();
        Set<Integer> fundingAgencyIds = new HashSet<Integer>();
        bravoLotusIdsList.forEach(id -> {
            String status = restTemplate.getForEntity(supplierSeconderyStatusBsUrl + id.toString(), String.class).getBody();
            if (suppliersBackupMap.get(id) != null) {
                String bravoSupplierBackupStatus = suppliersBackupMap.get(id).getSupplierSecondaryStatus();
                if (status != null) {
                    if (!status.equals(bravoSupplierBackupStatus)) {
                        suppliersBackupMap.get(id).setSupplierSecondaryStatus(status);
                        restTemplate.postForEntity(saveSupplierEsUrl, suppliersBackupMap.get(id), SupplierDto.class);
                        log.info("Update supplier's backup status: {}", bravoSuppliersMap.get(id).getCompanyName());
                        if (status.equals("Désactivé")) {
                            //logique
                            try {
                                AgencyList.stream().forEach(e -> {
                                    fundingRequestService.getAllFundingRequestsForSupplierByStatusForAgencyRole(e.getFundingAgencyId(), id, null).getContent().stream().forEach(y -> {
                                        fundingAgencyIds.add(y.getFundingAgencyId());
                                    });
                                });
                                fundingAgencyIds.stream().forEach(x -> fundingRequestService.getAllPaginatedFundingRequestsApplicantsForAgencyRole(x).getContent().stream().forEach(y -> {
                                    AgencyList.stream().forEach(e -> {
                                        fundingRequestService.getAllFundingRequestsForSupplierByStatusForAgencyRole(e.getFundingAgencyId(), y.getSupplierBravoId(), null).getContent().stream().forEach(z -> {
                                            if (z.getFundingAgencyId() == x) {
                                                emailList.add(e.getEmail().toLowerCase());
                                                log.info("user {} added successfully to the email list ", e.getId());
                                            }
                                        });

                                    });
                                }));

                            } catch (Exception ex) {
                                log.error("Error getting email list to be sent");
                            }
                            emailList.stream().forEach(e -> to += "," + e);

                            log.info("email list : {}", to);
                            forMail.put("supplierName", bravoSuppliersMap.get(id).getCompanyName());
                            LocalDate localDate = LocalDate.now();
                            forMail.put("supplierLastMod", localDate.toString());
                            //send notification
                            try {
                                emailService.sendEmail(to, "Tamwil : Statut désactivé du fournisseur " + bravoSuppliersMap.get(id).getCompanyName(),

                                        "disabled-supplier", forMail, null, null);
                                log.info("Mail sent about supplier: {}", bravoSuppliersMap.get(id).getCompanyName());
                            } catch (MessagingException e) {
                                throw new RuntimeException(e);
                            }
                        } else {
                            log.info("No mail sent, Supplier {} status changed to : {}", bravoSuppliersMap.get(id).getCompanyName(), status);
                        }
                    }
                } else {
                    log.info("Supplier {} status is null", bravoSuppliersMap.get(id).getCompanyName());
                }
            } else {
                try {
                    bravoSuppliersMap.get(id).setSupplierBravoId(id);
                    log.info("Comparing supplier ids : {} vs {}", bravoSuppliersMap.get(id).getSupplierId(), id);
                    restTemplate.postForEntity(saveSupplierEsUrl, bravoSuppliersMap.get(id), SupplierDto.class);
                    log.info("Supplier {} saved successfully !", bravoSuppliersMap.get(id).getCompanyName());
                } catch (Exception ex) {
                    log.info("Error while saving supplier with id {} ", id);
                    log.info("Error message : {} ", ex.getMessage());
                }
            }
        });
        log.info("Disabled supplier service ends");
    }

}
