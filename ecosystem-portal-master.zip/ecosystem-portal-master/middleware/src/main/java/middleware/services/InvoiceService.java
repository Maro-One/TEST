package middleware.services;

import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.conf.sap.BasicAuthorizationSap;
import middleware.dto.*;
import middleware.dto.sap.invoice.*;
import middleware.utils.Helper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Slf4j
public class InvoiceService {

    public static final String INVOICE_ORACLE_ID = "invoiceOracleId";
    public static final String E_INVOICE_ID = "einvoiceId";
    public static final String AMOUNT_HT = "amountHT";
    private static final String SAP_API_PURCHASE_ORDER_INVOICE = "/PurchaseOrder/Invoice";
    private static final String SAP_API_INVOICE_TIMELINE = "/PurchaseOrder/TimelineInvoice";
    private static final String FUNDING_REQUEST_SOURCE = "s";

    RestTemplate restTemplate;
    BackendConfig backendConfig;
    LotusServiceConfig lotusServiceConfig;

    @Value("${pagination.page-size:10}")
    int pageSize;

    private final BasicAuthorizationSap basicAuthorizationSap;

    @Autowired
    public InvoiceService(RestTemplate restTemplate, BackendConfig backendConfig, LotusServiceConfig lotusServiceConfig,
                          BasicAuthorizationSap basicAuthorizationSap) {
        this.restTemplate = restTemplate;
        this.backendConfig = backendConfig;
        this.lotusServiceConfig = lotusServiceConfig;
        this.basicAuthorizationSap = basicAuthorizationSap;
    }

    private boolean agencyHasOrderByOrderId(Integer agencyId, String orderId) {
        String url =
                lotusServiceConfig.getEcosystemUrl() + "/funding-request/agency-has-supplier-request-by-orderId/"
                        + agencyId + "/" + orderId;
        return restTemplate.getForObject(url, Boolean.class);
    }

    public InvoicePageableResponse getPurchaseOrderInvoices(Integer agencyId, String orderId, int page, String sortBy, String order, String status) {
        //checker la source
        String inscriptionUrl = lotusServiceConfig.getInscriptionURL()+"/supplier/supplierSapId/"+orderId;
        SapInvoiceKeyDto sapInvoiceKeyDto = new SapInvoiceKeyDto("","NA","");
        try{
            sapInvoiceKeyDto=restTemplate.getForObject(inscriptionUrl, SapInvoiceKeyDto.class);
        }
        catch (Exception e){
            log.error("Erro while getting source order & suppliersapid");
        }
        if (sapInvoiceKeyDto.getSource()!=null && sapInvoiceKeyDto.getSource().equals("SAP")){
            UriComponentsBuilder uriComponentsBuilder =UriComponentsBuilder.fromUriString (lotusServiceConfig.getCoordinatorURL()+"/invoices/all/"+orderId);
            uriComponentsBuilder.queryParam("supplierSapId",sapInvoiceKeyDto.getSupplierSapId());
            uriComponentsBuilder.queryParam("page",page);
            List<InvoiceDto> sapInvoices = restTemplate.exchange(uriComponentsBuilder.build().toUriString(), HttpMethod.GET, null, new ParameterizedTypeReference<List<InvoiceDto>>() {}).getBody();
            String[] status1 = {"IN_PROCESS_OF_ACCOUNTING", "IN_REJECTED", "INVOICE_PAID"};

            return new InvoicePageableResponse(sapInvoices, (long) sapInvoices.size(), Arrays.stream(status1).collect(Collectors.toSet()));
        }

        else
            log.info("Get invoices for purchase order {} at page {}", orderId, page);
        int startIndex = page == 0 ? 0 : pageSize * page;
        int endIndex = page == 0 ? pageSize : pageSize * (page + 1);
        if (agencyHasOrderByOrderId(agencyId, orderId)) {
            HttpEntity<List<String>> requestBody = new HttpEntity<>(Helper.getReverseMappingStatus(status));
            String invoicesUrl = backendConfig.getBackEndGateWayUrl() + "/purchase-orders/" + orderId + "/invoices";
            List<InvoiceDto> invoicesList = Helper.emptyIfNull(restTemplate.exchange(invoicesUrl, HttpMethod.POST, requestBody, InvoiceDto[].class).getBody());
            Helper.emptyIfNull(invoicesList)
                    .forEach(invoice -> invoice.setStatus(Helper.getReverseStatus(invoice.getStatus())));

            // REMOVE DUPLICATED INVOICES AND KEEP THE LAST CREATED ONE
            Collection<InvoiceDto> collection = invoicesList.stream()
                    .collect(Collectors.toMap(InvoiceDto::getInvoiceNumber, Function.identity(),
                            BinaryOperator.maxBy(Comparator.comparing(InvoiceDto::getCreationDate, Comparator.nullsFirst(Comparator.naturalOrder()))))).values();
            invoicesList = new ArrayList<>(collection);

            Map<String, Function<InvoiceDto, LocalDate>> sortExtractor = new HashMap<>();
            sortExtractor.put("baseEcheance", InvoiceDto::getBaseEcheance);
            sortExtractor.put("dueDate", InvoiceDto::getDueDate);
            Function<InvoiceDto, LocalDate> keyExtractor = sortExtractor.get(sortBy);
            List<InvoiceDto> sortedList;
            if (order.equals("asc")) {
                sortedList = invoicesList.stream()
                        .sorted(sortBy.equals(AMOUNT_HT)
                                ? Comparator.comparing(InvoiceDto::getAmountHT)
                                : Comparator.comparing(keyExtractor, Comparator.nullsLast(Comparator.naturalOrder())))
                        .collect(Collectors.toList());
            } else {
                sortedList = invoicesList.stream()
                        .sorted(sortBy.equals(AMOUNT_HT)
                                ? Comparator.comparing(InvoiceDto::getAmountHT).reversed()
                                : Comparator.comparing(keyExtractor, Comparator.nullsLast(Comparator.naturalOrder())).reversed())
                        .collect(Collectors.toList());
            }

            Set<String> statusList = new HashSet<>();
            if (status == null) {
                statusList = invoicesList.stream().map(InvoiceDto::getStatus).collect(Collectors.toSet());
            }
            List<InvoiceDto> finalList = sortedList;
            Collection<List<InvoiceDto>> partitionList = sortedList.stream()
                    .collect(Collectors.partitioningBy(s -> finalList.indexOf(s) >= startIndex &&
                            finalList.indexOf(s) < endIndex)).values();
            List<List<InvoiceDto>> subSets = new ArrayList<>(partitionList);
            return new InvoicePageableResponse(subSets.get(1), (long) invoicesList.size(), statusList);
        }
        return null;
    }

    private List<EventDto> eInvoiceEventMapping(EventDto[] doneEInvoicesEvents) {
        if (doneEInvoicesEvents.length > 0) {
            Stack<EventDto> result = new Stack<>();
            for (EventDto event : doneEInvoicesEvents) {
                event.setEventCode(Helper.getReverseStatus(event.getEventCode()));
                if (result.empty()) {
                    result.push(event);
                } else if (event.getEventCode() != null && !event.getEventCode().equals(result.peek().getEventCode())) {
                    result.push(event);
                } else {
                    result.pop();
                    result.push(event);
                }
            }
            return result;
        }
        return Collections.emptyList();
    }

    public ResponseEntity<List<EventDto>> getInvoiceEvents(Integer agencyId, String invoiceOracleId, String einvoiceId, String orderId) {
        log.info("get invoice events, agencyId: {}, invoiceOracleId: {}, einvoiceId: {}, orderId: {}", agencyId, invoiceOracleId, einvoiceId, orderId);
        List<EventDto> oracleEvents = new ArrayList<>();
        List<EventDto> eInvoiceEvents = new ArrayList<>();
        if (agencyHasOrderByOrderId(agencyId, orderId)) {
            if (invoiceOracleId != null) {
                log.info("get invoice events from oracle with invoiceOracleId: {}", invoiceOracleId);
                UriComponentsBuilder oracleUriBuilder = UriComponentsBuilder.fromUriString(backendConfig.getOracleEbsURL() + "/supplier/invoice-timeline");
                oracleUriBuilder.queryParam(INVOICE_ORACLE_ID, invoiceOracleId);
                EventDto[] events = restTemplate.getForObject(oracleUriBuilder.build().toUriString(), EventDto[].class);
                log.info("got {} events from oracle", events.length);
                oracleEvents = Helper.emptyIfNull(events);
            } else {
                log.info("invoiceOracleId is not provided");
            }
            if (einvoiceId != null) {
                log.info("get invoice events from e-invoice with einvoiceId: {} and invoiceOracleId: {}", einvoiceId, invoiceOracleId);
                MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
                params.add(E_INVOICE_ID, einvoiceId);
                params.add(INVOICE_ORACLE_ID, invoiceOracleId);

                UriComponentsBuilder eInvoiceUriBuilder = UriComponentsBuilder.fromUriString(backendConfig.getEInvoiceURL() + "/supplier/timeline");
                eInvoiceUriBuilder.queryParams(params);
                EventDto[] events = restTemplate.getForObject(eInvoiceUriBuilder.build().toUriString(), EventDto[].class);
                log.info("got {} events from e-invoice", events.length);

                eInvoiceEvents = eInvoiceEventMapping(events);
                log.info("e-invoice mapped events size: {}", eInvoiceEvents.size());

                // GET INVOICE FROM E-INVOICE
                log.info("get invoice from e-invoice");
                eInvoiceUriBuilder = UriComponentsBuilder.fromUriString(backendConfig.getEInvoiceURL() + "/supplier/invoices");
                eInvoiceUriBuilder.queryParams(params);
                EInvoiceDto eInvoiceDto = restTemplate.getForObject(eInvoiceUriBuilder.build().toUriString(), EInvoiceDto.class);
                // POPULATE METADATA
                if (eInvoiceDto != null) {
                    log.info("got eInvoiceDto, invoice number: {}", eInvoiceDto.getInvoiceNumber());
                    log.info("populating metadata for events with code IN_PROCESS_OF_ACCOUNTING, IN_REJECTED_AFTER_SCAN & IN_REJECTED");
                    eInvoiceEvents.forEach(eventDto -> {
                        Map<String, String> metadata = new HashMap<>();
                        switch (eventDto.getEventCode()) {
                            case "IN_PROCESS_OF_ACCOUNTING":
                                metadata.put("invoiceNum", eInvoiceDto.getInvoiceNumber());
                                metadata.put("amount", eInvoiceDto.getAmountHT().toString());
                                metadata.put("currency", eInvoiceDto.getCurrency());
                                metadata.put("deadlineDate", eInvoiceDto.getBaseEcheance() != null?eInvoiceDto.getBaseEcheance().toString():"");
                                eventDto.setMetadata(metadata);
                                break;
                            case "IN_REJECTED_AFTER_SCAN":
                            case "IN_REJECTED":
                                metadata.put("invoiceNum", eInvoiceDto.getInvoiceNumber());
                                metadata.put("amount", eInvoiceDto.getAmountHT().toString());
                                metadata.put("currency", eInvoiceDto.getCurrency());
                                metadata.put("rejectDate", eventDto.getEventDate().toString());
                                eventDto.setMetadata(metadata);
                                break;
                            default:
                                break;
                        }
                    });
                }
            } else {
                log.info("einvoiceId is not provided");
            }

            List<EventDto> concatenatedEvents =
                    Stream
                            .concat(eInvoiceEvents.stream(), oracleEvents.stream())
                            .collect(Collectors.toList());

            log.info("concatenated events size: {}", concatenatedEvents.size());
            return ResponseEntity
                    .status(HttpStatus.OK)
                    .body(concatenatedEvents);

        }
        log.info("user unauthorized to get invoice events");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    public SapInvoicePageableResponse getAllInvoices(Integer agencyId, String orderId, int page, String sortBy, String order, String status, String requestSource) {
        Map<String, Function<InvoicePurchaseOrderResponseDto, LocalDate>> sortExtractor = new HashMap<>();
        sortExtractor.put("baseEcheance", InvoicePurchaseOrderResponseDto::getBaseEcheance);
        sortExtractor.put("dueDate", InvoicePurchaseOrderResponseDto::getDueDate);
        Function<InvoicePurchaseOrderResponseDto, LocalDate> keyExtractor = sortExtractor.get(sortBy);

        if(StringUtils.equalsIgnoreCase(requestSource, FUNDING_REQUEST_SOURCE)) {
            String sapInvoiceRequestUrl = UriComponentsBuilder.fromHttpUrl(backendConfig.getSapPoURL().concat(SAP_API_PURCHASE_ORDER_INVOICE))
                    .queryParam("po_number", "{po_number}")
                    .encode()
                    .toUriString();

            Map<String, Object> sapInvoiceRequestParams = new HashMap<>();
            sapInvoiceRequestParams.put("po_number", orderId);

            HttpEntity<String> sapPurchaseOrderRequest = new HttpEntity<>(basicAuthorizationSap.Authorization());
            SapInvoiceResponseDto sapPurchaseOrderResponse =
                    restTemplate.exchange(
                            sapInvoiceRequestUrl,
                            HttpMethod.GET,
                            sapPurchaseOrderRequest,
                            SapInvoiceResponseDto.class,
                            sapInvoiceRequestParams
                    ).getBody();
            if(ObjectUtils.isNotEmpty(sapPurchaseOrderResponse)) {
                log.info("invoices list response {} ", sapPurchaseOrderResponse);
                if (CollectionUtils.isNotEmpty(sapPurchaseOrderResponse.getInvoicePurchaseOrder())) {
                    log.info("invoices list size {} ", sapPurchaseOrderResponse.getInvoicePurchaseOrder().size());
                    sapPurchaseOrderResponse.getInvoicePurchaseOrder().forEach(
                            invoice -> {
                                if(StringUtils.isBlank(invoice.getPaymentStatus()))
                                    invoice.setStatus(invoice.getApprovalStatus());
                                else
                                    invoice.setStatus(invoice.getPaymentStatus());
                            }
                    );


                    List<InvoicePurchaseOrderResponseDto> sortedList;
                    if (order.equals("asc")) {
                        sortedList = sapPurchaseOrderResponse.getInvoicePurchaseOrder().stream()
                                .sorted(sortBy.equals(AMOUNT_HT)
                                        ? Comparator.comparing(InvoicePurchaseOrderResponseDto::getAmountHT)
                                        : Comparator.comparing(keyExtractor, Comparator.nullsLast(Comparator.naturalOrder())))
                                .collect(Collectors.toList());
                    } else {
                        sortedList = sapPurchaseOrderResponse.getInvoicePurchaseOrder().stream()
                                .sorted(sortBy.equals(AMOUNT_HT)
                                        ? Comparator.comparing(InvoicePurchaseOrderResponseDto::getAmountHT).reversed()
                                        : Comparator.comparing(keyExtractor, Comparator.nullsLast(Comparator.naturalOrder())).reversed())
                                .collect(Collectors.toList());
                    }

                    Set<String> statusList = new HashSet<>();
                    if (status == null) {
                        statusList =  sapPurchaseOrderResponse.getInvoicePurchaseOrder().stream().map(InvoicePurchaseOrderResponseDto::getStatus).collect(Collectors.toSet());
                    }

                    return new SapInvoicePageableResponse(paginateInvoice(sortedList, page, pageSize), (long)  sapPurchaseOrderResponse.getInvoicePurchaseOrder().size(), statusList);
                }
                else
                    log.info("empty invoices list {} ",orderId);
            }

        } else {
            List<InvoicePurchaseOrderResponseDto> oracleInvoicesList = new ArrayList<>();
            String oracleUrlHistory = "/oracle-history/invoices/".concat(orderId);
            String oracleUrlHistoryRequestUrl = UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + oracleUrlHistory)
                    .encode()
                    .toUriString();
            List<InvoiceDto> oracleInvoices = restTemplate.exchange(oracleUrlHistoryRequestUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<InvoiceDto>>() {}).getBody();
            if(org.apache.commons.collections4.CollectionUtils.isNotEmpty(oracleInvoices)) {
                oracleInvoices.forEach(
                        invoiceDto -> {
                            InvoicePurchaseOrderResponseDto invoicePurchaseOrder = new InvoicePurchaseOrderResponseDto();
                            invoicePurchaseOrder.setSapInvoiceId(invoiceDto.getOracleInvoiceId());
                            invoicePurchaseOrder.setInvoiceNumber(invoiceDto.getInvoiceNumber());
                            invoicePurchaseOrder.setCreationDate(invoiceDto.getCreationDate());
                            invoicePurchaseOrder.setStatus(invoiceDto.getStatus());
                            invoicePurchaseOrder.setAmountHT(invoiceDto.getAmountHT());
                            invoicePurchaseOrder.setEinvoiceId(invoiceDto.getEinvoiceId());
                            invoicePurchaseOrder.setApprovalStatus(invoiceDto.getApprovalStatus());
                            invoicePurchaseOrder.setBaseEcheance(invoiceDto.getBaseEcheance());
                            invoicePurchaseOrder.setDueDate(invoiceDto.getDueDate());
                            oracleInvoicesList.add(invoicePurchaseOrder);
                        }
                );
                Set<String> statusList = new HashSet<>();
                if (status == null) {
                    statusList =  oracleInvoicesList.stream().map(InvoicePurchaseOrderResponseDto::getStatus).collect(Collectors.toSet());
                }
                return new SapInvoicePageableResponse(paginateInvoice(oracleInvoicesList, page, pageSize), (long)  oracleInvoicesList.size(), statusList);
            }
        }
        return new SapInvoicePageableResponse(new ArrayList<>(), (long)  0, new HashSet<>());
    }

    private List<InvoicePurchaseOrderResponseDto> paginateInvoice(List<InvoicePurchaseOrderResponseDto> invoices, int offset, int limit) {
        if(offset>0)
            offset = (offset)*limit;
        return invoices.stream().skip(offset).limit(limit).collect(Collectors.toList());
    }

    public ResponseEntity<List<InvoiceEventDto>> getInvoiceEventsByNumberAndYear(Integer agencyId, String sapInvoiceId, String einvoiceId, String orderId, String creationDate, String invoiceStatus, String requestSource) {
        if(StringUtils.isBlank(creationDate) || (StringUtils.equalsIgnoreCase(creationDate, "undefined")))
            return null;

        if(StringUtils.equalsIgnoreCase(requestSource, FUNDING_REQUEST_SOURCE)) {

            DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd MMM yyyy").withLocale(Locale.ENGLISH);

            if(StringUtils.isBlank(sapInvoiceId)) {
                InvoiceEventDto invoiceEvent = InvoiceEventDto.builder().eventStatus(invoiceStatus).
                        eventDate(LocalDate.parse(creationDate, DATE_FORMATTER)).eventCode(invoiceStatus).build();
                SapInvoiceTimeLineResponseDto sapInvoiceTimeLineResponse = SapInvoiceTimeLineResponseDto.builder().
                        invoiceEvents(Collections.singletonList(invoiceEvent)).build();
                return ResponseEntity
                        .status(HttpStatus.OK)
                        .body(sapInvoiceTimeLineResponse.getInvoiceEvents());
            }

            String sapInvoiceRequestUrl = UriComponentsBuilder.fromHttpUrl(backendConfig.getSapPoURL().concat(SAP_API_INVOICE_TIMELINE))
                    .queryParam("invoice_number", "{invoice_number}")
                    .queryParam("year", "{year}")
                    .encode()
                    .toUriString();

            Map<String, Object> sapInvoiceRequestParams = new HashMap<>();
            sapInvoiceRequestParams.put("invoice_number", sapInvoiceId);
            sapInvoiceRequestParams.put("year", LocalDate.parse(creationDate, DATE_FORMATTER).getYear());

            HttpEntity<String> sapPurchaseOrderRequest = new HttpEntity<>(basicAuthorizationSap.Authorization());
            SapInvoiceTimeLineResponseDto sapInvoiceTimeLineResponse =
                    restTemplate.exchange(
                            sapInvoiceRequestUrl,
                            HttpMethod.GET,
                            sapPurchaseOrderRequest,
                            SapInvoiceTimeLineResponseDto.class,
                            sapInvoiceRequestParams
                    ).getBody();
            if(ObjectUtils.isNotEmpty(sapInvoiceTimeLineResponse)) {
                if(CollectionUtils.isNotEmpty(sapInvoiceTimeLineResponse.getInvoiceEvents())) {
                    sapInvoiceTimeLineResponse.getInvoiceEvents().forEach(
                            event -> {
                                Map<String, String> metadata = new HashMap<>();
                                if(EventStatusEnum.getEventCode(event.getEventCode()).equals(EventStatusEnum.INVOICE_PAID)) {
                                    metadata.put("amountReg", event.getMetadata().get("amountreg"));
                                    metadata.put("refReg", event.getMetadata().get("refreg"));
                                    metadata.put("invoiceNumber", event.getMetadata().get("invoicenumber"));
                                    event.setEventCode(EventStatusEnum.INVOICE_PAID.name());
                                    event.setMetadata(metadata);
                                } else if (EventStatusEnum.getEventCode(event.getEventCode()).equals(EventStatusEnum.IN_REJECTED)) {
                                    metadata.put("rejetDate",  event.getEventDate().toString());
                                    metadata.put("rejetInfo", "");
                                    event.setEventCode(EventStatusEnum.IN_REJECTED.name());
                                    event.setMetadata(metadata);
                                } else {
                                    event.setEventCode(event.getEventStatus());
                                }

                            }
                    );
                    return ResponseEntity
                            .status(HttpStatus.OK)
                            .body(sapInvoiceTimeLineResponse.getInvoiceEvents());
                }

            }
        } else {
            List<InvoiceEventDto> oracleInvoiceEventsList = new ArrayList<>();
            String oracleUrlHistory = "/oracle-history/invoice-timeline/";

            String oracleUrlHistoryRequestUrl = UriComponentsBuilder.fromHttpUrl(lotusServiceConfig.getEcosystemUrl() + oracleUrlHistory)
                    .queryParam("oracleInvoiceId", "{oracleInvoiceId}")
                    .queryParam("eInvoiceId", "{eInvoiceId}")
                    .encode()
                    .toUriString();

            Map<String, Object> oracleEventsRequestParams = new HashMap<>();
            oracleEventsRequestParams.put("oracleInvoiceId", sapInvoiceId != null ? sapInvoiceId : 0);
            oracleEventsRequestParams.put("eInvoiceId", einvoiceId != null ? einvoiceId : 0);

            List<OracleEventDto> oracleInvoiceEvents = restTemplate.exchange(oracleUrlHistoryRequestUrl, HttpMethod.GET, null,
                    new ParameterizedTypeReference<List<OracleEventDto>>() {},
                    oracleEventsRequestParams).getBody();
            if(org.apache.commons.collections4.CollectionUtils.isNotEmpty(oracleInvoiceEvents)) {
                oracleInvoiceEvents.forEach(
                        oracleEventDto -> {
                            InvoiceEventDto invoiceEventDto = new InvoiceEventDto();
                            invoiceEventDto.setEventCode(oracleEventDto.getEventCode());
                            invoiceEventDto.setEventDate(oracleEventDto.getEventDate());
                            invoiceEventDto.setEventStatus(oracleEventDto.getEventStatus());
                            Map<String, String> metadata = new HashMap<>();
                            if(EventStatusEnum.getEventCode(oracleEventDto.getEventCode()).equals(EventStatusEnum.INVOICE_PAID)) {
                                metadata.put("amountReg", oracleEventDto.getAmountReg() != null ? oracleEventDto.getAmountReg().toString() : "");
                                metadata.put("refReg", oracleEventDto.getRefReg());
                                metadata.put("invoiceNumber", oracleEventDto.getInvoicesNumber());
                                invoiceEventDto.setMetadata(metadata);
                            } else if (EventStatusEnum.getEventCode(oracleEventDto.getEventCode()).equals(EventStatusEnum.IN_REJECTED)) {
                                metadata.put("rejetDate",  oracleEventDto.getEventDate() != null ? oracleEventDto.getEventDate().toString() : "");
                                metadata.put("rejetInfo", "");
                                invoiceEventDto.setMetadata(metadata);
                            }
                            oracleInvoiceEventsList.add(invoiceEventDto);
                        }
                );
                return ResponseEntity
                        .status(HttpStatus.OK)
                        .body(oracleInvoiceEventsList);
            }

        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }


}
