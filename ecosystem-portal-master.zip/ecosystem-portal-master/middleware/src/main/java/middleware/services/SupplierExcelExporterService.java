package middleware.services;

import middleware.dto.ExportSupplierDto;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.util.List;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class SupplierExcelExporterService {

    private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    private List<ExportSupplierDto> listSuppliers;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public ByteArrayInputStream export(List<ExportSupplierDto> listSuppliers) {
        try(Workbook workbook = new XSSFWorkbook()){
            Sheet sheet = workbook.createSheet("Suppliers");

            Row row = sheet.createRow(0);

            // Define header cell style
            CellStyle headerCellStyle = workbook.createCellStyle();
            headerCellStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Creating header cells
            Cell cell = row.createCell(0);
            cell.setCellValue("Bravo Id");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(1);
            cell.setCellValue("Supplier Name");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(2);
            cell.setCellValue("Supplier Main Status");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(3);
            cell.setCellValue("Supplier Secondary Status");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(4);
            cell.setCellValue("Main Activity");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(5);
            cell.setCellValue("PurchaseOrderRef");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(6);
            cell.setCellValue("PurchaseOrderId");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(7);
            cell.setCellValue("status");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(8);
            cell.setCellValue("PurchaseOrderApprovalDate");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(9);
            cell.setCellValue("Description");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(10);
            cell.setCellValue("PurchaseOrderAmount");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(11);
            cell.setCellValue("Montant Facturable");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(12);
            cell.setCellValue("Montant Facturé");
            cell.setCellStyle(headerCellStyle);

            cell = row.createCell(13);
            cell.setCellValue("Montant Payé");
            cell.setCellStyle(headerCellStyle);

            // Creating data rows for each contact
            for(int i = 0; i < listSuppliers.size(); i++) {
                Row dataRow = sheet.createRow(i + 1);
                dataRow.createCell(0).setCellValue(listSuppliers.get(i).getSupplierBravoId());
                dataRow.createCell(1).setCellValue(listSuppliers.get(i).getCompanyName());
                dataRow.createCell(2).setCellValue(listSuppliers.get(i).getSupplierStatus());
                dataRow.createCell(3).setCellValue(listSuppliers.get(i).getSecondaryStatus());
                dataRow.createCell(4).setCellValue(listSuppliers.get(i).getMainActivity());
                dataRow.createCell(5).setCellValue(listSuppliers.get(i).getPurchaseOrderRef());
                dataRow.createCell(6).setCellValue(listSuppliers.get(i).getPurchaseOrderId());
                dataRow.createCell(7).setCellValue(listSuppliers.get(i).getStatus());
                dataRow.createCell(8).setCellValue(DateFormatUtils.format(listSuppliers.get(i).getPurchaseOrderApprovalDate(),"dd/MM/yyyy"));
                dataRow.createCell(9).setCellValue(listSuppliers.get(i).getPurchaseOrderDescription());
                dataRow.createCell(10).setCellValue(listSuppliers.get(i).getPurchaseOrderAmount());
                dataRow.createCell(11).setCellValue(listSuppliers.get(i).getApprovalAttachmentAmount());
                dataRow.createCell(12).setCellValue(listSuppliers.get(i).getBilledAmount());
                dataRow.createCell(13).setCellValue(listSuppliers.get(i).getPaidAmount());
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return new ByteArrayInputStream(outputStream.toByteArray());
        } catch (IOException ex) {
            logger.error("Error during export Excel file", ex);
            return null;
        }
    }



}
