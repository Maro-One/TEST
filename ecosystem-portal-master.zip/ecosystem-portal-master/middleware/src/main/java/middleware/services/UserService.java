package middleware.services;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import middleware.conf.LotusServiceConfig;
import middleware.dto.ImportUsersResponse;
import middleware.entities.User;
import middleware.exception.ParseUsersCSVFileException;
import org.apache.commons.compress.utils.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);
    private RestTemplate restTemplate;
    private LotusServiceConfig lotusServiceConfig;
    private EmailService emailService;
    private TokenService tokenService;
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Value("${login.attempts.lock.duration:10}")
    private int lockDuration;
    @Value("${login.attempts.count:3}")
    private int maxAttemps;
    @Value("${resetpassword.host}")
    private String linkResetPasswordHost;
    @Value("${resetpassword.path}")
    private String linkResetPasswordPath;
    private static final String MAIL_REGEX = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$";
    private static final String LOGIN_REGEX = "^[a-zA-Z0-9]+[a-zA-Z0-9_.-]+[a-zA-Z0-9]+$";

    @Autowired
    public UserService(TokenService tokenService, RestTemplate restTemplate,
                       LotusServiceConfig lotusServiceConfig, EmailService emailService,
                       @Lazy BCryptPasswordEncoder bCryptPasswordEncoder
    ) {
        this.restTemplate = restTemplate;
        this.lotusServiceConfig = lotusServiceConfig;
        this.emailService = emailService;
        this.tokenService = tokenService;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    public User findByUsername(String login) {
        Map<String, String> query = new HashMap<>();
        query.put("login", login);
        try {
            return restTemplate.getForObject(lotusServiceConfig.getEcosystemUrl()
                            + "/funding-agency-account/active-account?login={login}",
                    User.class, query);
        } catch (HttpClientErrorException ex) {
            log.error("error while calling ecosystem for login: {}", login, ex);
            return null;
        }
    }

    public void updateUserPassword(User user, String password) {
        //is first time
        if (!user.isEnabled()) {
            user.setActive(true);
        } else {
            user.setActive(null);
            user.setCreationDate(null);
        }
        user.setPassword(bCryptPasswordEncoder.encode(password));
        user.setAttempts(0);
        update(user);
    }

    public User update(User user) {
        return restTemplate.postForObject(lotusServiceConfig.getEcosystemUrl()
                        + "/funding-agency-account/update-account",
                user,
                User.class);
    }

    public boolean isLockExpired(User user) {
        if (user.getLastAttempt() != null) {
            long diffInMillis = new Date().getTime() - user.getLastAttempt().getTime();
            long diffInMinutes = TimeUnit.MINUTES.convert(diffInMillis, TimeUnit.MILLISECONDS);
            return diffInMinutes >= lockDuration;
        }
        return false;
    }

    public boolean isBlocked(User user) {
        if (user != null) {
            if (user.getAttempts() < maxAttemps || user.getLastAttempt() == null) {
                return false;
            }
            return !isLockExpired(user);
        }
        return true;
    }

    public List<User> parseUsersFile(MultipartFile file) throws ParseUsersCSVFileException, IOException, CsvValidationException {
        log.info("Start to read csv file");
        List<User> users = new ArrayList<>();
        CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream(), StandardCharsets.ISO_8859_1));
        String[] line;
        while ((line = reader.readNext()) != null) {
            if (reader.getLinesRead() == 1) continue;
            if (line.length != 6) {
                log.warn("The line {} does not have 6 values", line[0]);
                throw new ParseUsersCSVFileException("[Line:" + (users.size() + 1) + "]");
            } else {
                trimLineTokens(line);
                List<String> errors = checkTypeOfLine(line);
                if (!CollectionUtils.isEmpty(errors)) {
                    throw new ParseUsersCSVFileException(String.join(", ", errors));
                }
                users.add(User.builder()
                        .login(line[0])
                        .email(line[1])
                        .firstName(line[2])
                        .lastName(line[3])
                        .agencyId(!line[4].isEmpty() ? Integer.valueOf(line[4]) : null)
                        .roleId(Integer.valueOf(line[5]))
                        .build());
            }
        }
        log.info("End read csv file, {} user in this file", users.size());
        return users;
    }

    private void trimLineTokens(String[] line) {
        for (int i = 0; i < line.length; i++) {
            if (line[i] != null && !line[i].isEmpty()) {
                line[i] = line[i].trim();
            }
        }
    }

    private List<String> checkTypeOfLine(String[] line) {
        List<String> errors = Lists.newArrayList();
        if (!line[0].isEmpty() && !line[0].matches(LOGIN_REGEX) && !line[0].matches(MAIL_REGEX)) {
            errors.add(String.format("Invalid format for Login value '%s'", line[0]));
        }
        if (!line[1].isEmpty() && !line[1].matches(MAIL_REGEX)) {
            errors.add(String.format("Invalid mail format value '%s'", line[1]));
        }
        if (!line[4].isEmpty() && !line[4].matches("\\d*")) {
            errors.add(String.format("Agency ID value '%s' should be a number", line[4]));
        }
        return errors;
    }

    public User createUser(User user) {
        try {
            user.setCreationDate(new Date());
            return restTemplate.postForObject(lotusServiceConfig.getEcosystemUrl()
                            + "/funding-agency-account/create-account",
                    user,
                    User.class) ;
        } catch (RuntimeException ex) {
            log.error("error while calling ecosystem for login: {}", user, ex);
            return null;
        }
    }

    @Async
    public void notifyUser(String email, String login) throws javax.mail.MessagingException {
        User userToken = new User();
        userToken.setLogin(login);
        Map<String, Object> data = new HashMap<>();
        data.put("user", userToken);
        String url = linkResetPasswordHost.concat(linkResetPasswordPath);
        Map<String, Object> forMail = new HashMap<>();
        forMail.put("login", login);
        forMail.put("allLink", url.concat(tokenService.getToken(data)));
        forMail.put("shortLink", url);
        emailService.sendEmail(
                email,
                "Compléter votre inscription",
                "reset_password_first",
                forMail,
                null,
                null
        );
    }

    public List<ImportUsersResponse> importUsers(MultipartFile file) throws CsvValidationException, IOException, ParseUsersCSVFileException {
        List<ImportUsersResponse> importUsersResponses = new ArrayList<>();
        List<User> usersList = parseUsersFile(file);
        for (User user : usersList) {
            ImportUsersResponse importUsersResponse = ImportUsersResponse.builder()
                    .login(user.getLogin())
                    .saved(true)
                    .message("User created")
                    .build();
            User newUser = createUser(user);
            if (newUser == null) {
                importUsersResponse.setSaved(false);
                importUsersResponse.setMessage("User already exist (or unable to create new user)");
            } else {
                try {
                    notifyUser(user.getEmail(), user.getLogin());
                    log.info("User {} created, an email was sent", user.getEmail());
                } catch (Exception e) {
                    log.error("Could not send an email to {} for {}", user.getEmail(), user.getLogin());
                    importUsersResponse.setMessage("User created but not notified by email with resest password link");
                }
            }
            importUsersResponses.add(importUsersResponse);
        }
        return importUsersResponses;
    }

    public List<User> exportUsers() {
        try {
            ResponseEntity<User[]> responseEntity = restTemplate.getForEntity(
                    UriComponentsBuilder.fromUriString(lotusServiceConfig.getEcosystemUrl())
                            .path("/funding-agency-account/export-accounts")
                            .toUriString(),
                    User[].class
            );
            if (responseEntity.getStatusCode().is2xxSuccessful()) {
                return Arrays.asList(responseEntity.getBody());
            }
        } catch (RuntimeException ex) {
            log.error("error while calling ecosystem", ex);
            return null;
        }
        return null;
    }

    public Date toTimeZoneGMT1(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY, 1);
        calendar.setTimeZone(TimeZone.getTimeZone("GMT+1"));
        return calendar.getTime();
    }
}
