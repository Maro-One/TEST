package middleware.entities;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RegisterCredentials {
    private String firstPassword;
    private  String secondPassword;
    private String token;
}
