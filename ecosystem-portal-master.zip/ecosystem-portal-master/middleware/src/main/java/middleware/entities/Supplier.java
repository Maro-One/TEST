package middleware.entities;

public class Supplier {
}
