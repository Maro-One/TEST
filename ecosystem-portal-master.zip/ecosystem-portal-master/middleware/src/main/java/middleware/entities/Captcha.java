package middleware.entities;

import lombok.Data;

@Data
public class Captcha {

    private String image;
    private String entryCode;
    private String captchaValue;
}
