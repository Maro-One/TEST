package middleware.entities;

import lombok.Data;

@Data
public class Credentials {

    private String login;
    private String password;
    private String entryCode;
    private String captchaValue;

}
