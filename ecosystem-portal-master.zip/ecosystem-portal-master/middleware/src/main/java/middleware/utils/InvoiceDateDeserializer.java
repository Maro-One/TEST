package middleware.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class InvoiceDateDeserializer extends StdDeserializer<LocalDate> {

    public static final DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public InvoiceDateDeserializer() {
        this(null);
    }

    public InvoiceDateDeserializer(Class<?> vc) {
        super(vc);
    }

    @Override
    public LocalDate deserialize(JsonParser jsonparser, DeserializationContext context)
            throws IOException, JsonProcessingException {
        final String date = jsonparser.getText();
        return LocalDate.parse(date, CUSTOM_FORMATTER);
    }
}

