package middleware.utils;

import middleware.dto.FundingRequestDto;

import java.util.List;

public class SapResponseWrapper {
    private List<FundingRequestDto> fundingRequestDtos;
    private List<String> errorMessages;

    // Constructeurs, getters, setters
    public SapResponseWrapper(List<FundingRequestDto> fundingRequestDtos, List<String> errorMessages) {
        this.fundingRequestDtos = fundingRequestDtos;
        this.errorMessages = errorMessages;
    }

    public SapResponseWrapper() {
    }

    public List<FundingRequestDto> getFundingRequestDtos() {
        return fundingRequestDtos;
    }

    public void setFundingRequestDtos(List<FundingRequestDto> fundingRequestDtos) {
        this.fundingRequestDtos = fundingRequestDtos;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

}
