package middleware.utils;

import java.util.*;

public class Helper {

    private Helper (){

    }

    private static Map<String,List<String>> initilizeInvoiceStatusMapping() {
        Map<String,List<String>> map = new HashMap<>();
        map.put("IN_DEPOSIT", Collections.singletonList("IN.FMFI"));
        map.put("IN_REJECTED_AFTER_SCAN", Collections.emptyList());
        map.put("IN_PROCESS_OF_ACCOUNTING",Arrays.asList("IN.RECONC","IN.RECONC_MAN","IN.RECYCLE","IN.WAITRECEIPT",
                "IN.APPGAP","IN.APPGAP_MAIL","IN.APPGAP_MAIL_BA",
                "IN.ACC","IN.DISCRP","IN.WD_ASK",
                "IN.APPREJ","IN.APPREJ1","IN.ACCWOPO",
                "IN.APPREJ2","IN.APPREJ3","IN.APPREJ4","IN.EXPORT_BAP","IN.EXPBAP_KO","IN.ACCFINALWOPO","IN.APPQTYWOPO1",
                "IN.APPQTYWOPO2","IN.DISC","IN.ORAUPD","IN.RECONC_LINE","IN.REJQTYWOPO","IN.WAITRECEIPT_NO",
                "IN.CDTRECONC","IN.RECONC_NO","IN.ACCREJ","IN.ROUTE",
                "IN.WD_MANAGE","IN.WD_ROUTE","IN.ACC_EXPORT","IN.WAIT_ERP","IN.ORAINTREJECT","IN.ACC_ERR"));
        map.put("IN_PAID", Collections.singletonList("IN.PAID"));
        map.put("IN_PROCESS_OF_APPROVAL",Arrays.asList("IN.APP1","IN.APP2","IN.APP3","IN.APP4","IN.ACCASK","IN.APPASK","UNAPPROVED","FULL","UNPAID","NEEDS_REAPPROVAL","NEVER_APPROVED"));
        map.put("IN_REJECTED",Arrays.asList("IN.APPCANCELED","IN.APPCANCEL","IN.REJ","CANCELLED"));
        map.put("APPROVED",Arrays.asList("APPROVED","AVAILABLE","IN.ARCH"));
        map.put("INVOICE_PARTIALLY_PAID",Arrays.asList("INVOICE_PARTIALLY_PAID"));
        map.put("IN_LITIGATION", Arrays.asList("IN.APPWAIT1","IN.APPWAIT2"));
        return map;
    }

    public static final Map<String,List<String>> statusMapping = Collections.unmodifiableMap(initilizeInvoiceStatusMapping());

    private static Map<String, Integer> initiliazeSuplierPosition() {
        Map<String, Integer> positioningMap = new HashMap<>();
        positioningMap.put("Aspiring", 1);
        positioningMap.put("Emerging", 2);
        positioningMap.put("Developed", 3);
        positioningMap.put("Champion", 4);
        return  positioningMap;
    }

    public static final Map<String, Integer> supplierPositioning = Collections.unmodifiableMap(initiliazeSuplierPosition());

    public static String getReverseStatus (String status) {
        Iterator<Map.Entry<String, List<String>>> iterator = Helper.statusMapping.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, List<String>> entry = iterator.next();
            if (entry.getValue().contains(status)) {
                return entry.getKey();
            }
        }
        return status;
    }

    public static List<String> getReverseMappingStatus (String status) {
        if(status != null){
            Optional<Map.Entry<String, List<String>>> statusMap =
                Helper.statusMapping.entrySet().stream().filter(map -> map.getKey().equals(status)).findAny();
            if(statusMap.isPresent()){
                return statusMap.get().getValue();
            }
            return Collections.singletonList(status);
        }
        return Collections.emptyList();
    }


    public static <T> List<T> emptyIfNull(List<T> list) {
        if (list == null) {
            return Collections.emptyList();
        }
        return list;
    }

    public static <T> List<T> emptyIfNull(T[] array) {
        if (array == null) {
            return Collections.emptyList();
        }
        return Arrays.asList(array);
    }
}
