package middleware.utils;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import middleware.dto.sap.AttachmentSAPDto.Content;
import middleware.dto.sap.AttachmentSAPDto.MT_AttachementResponse;
import middleware.dto.sap.AttachmentSAPDto.Messages;

import java.io.IOException;
import java.util.List;

public class MT_AttachementResponseDeserializer extends JsonDeserializer<MT_AttachementResponse> {

    @Override
    public MT_AttachementResponse deserialize(JsonParser jsonParser, DeserializationContext ctxt)
            throws IOException {
        JsonNode node = jsonParser.getCodec().readTree(jsonParser);

        if (node.isTextual() && node.asText().isEmpty()) {
            return null;  // Return null if the response is an empty string
        }

        MT_AttachementResponse response = new MT_AttachementResponse();
        // Assuming the JSON structure, manually set the fields
        if (node.has("content")) {
            response.setContent(new ObjectMapper().convertValue(node.get("content"),
                    new TypeReference<List<Content>>() {}));
        }
        if (node.has("messages")) {
            response.setMessages(new ObjectMapper().convertValue(node.get("messages"),
                    new TypeReference<List<Messages>>() {}));
        }

        return response;
    }
}


