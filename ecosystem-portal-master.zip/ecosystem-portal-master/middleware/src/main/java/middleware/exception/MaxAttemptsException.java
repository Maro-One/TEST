package middleware.exception;

import org.springframework.security.core.AuthenticationException;

public class MaxAttemptsException extends AuthenticationException {

    public MaxAttemptsException(String msg, Throwable t) {
        super(msg, t);
    }

    public MaxAttemptsException(String msg) {
        super(msg);
    }
}
