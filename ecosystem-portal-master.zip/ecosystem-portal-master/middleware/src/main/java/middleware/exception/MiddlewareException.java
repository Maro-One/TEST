package middleware.exception;

public class MiddlewareException extends RuntimeException {

    public MiddlewareException() {
    }

    public MiddlewareException(String message) {
        super(message);
    }

    public MiddlewareException(String message, Throwable cause) {
        super(message, cause);
    }

    public MiddlewareException(Throwable cause) {
        super(cause);
    }

    public MiddlewareException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
