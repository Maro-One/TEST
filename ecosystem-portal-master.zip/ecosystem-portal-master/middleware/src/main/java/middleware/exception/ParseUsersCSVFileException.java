package middleware.exception;

public class ParseUsersCSVFileException extends Exception {
    public ParseUsersCSVFileException(String error) {
        super("Error while parsing csv file :" + error);
    }
}
