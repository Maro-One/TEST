package middleware.conf.prometheus;

import io.prometheus.client.Histogram;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;

@Component
public class RequestResponseTimeInterceptor extends HandlerInterceptorAdapter {

    private static final String ATTRIBUTE_TIMING_NANO = "timing_nano";

    private static final Histogram LATENCY = Histogram
            .build()
            .name("http_request_latency_secs")
            .labelNames("method", "handler")
            .help("Histogram of response time in milliseconds.")
            .register();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String handlerLabel = getLabel(handler);
        Histogram.Timer timer = LATENCY.labels(request.getMethod(), handlerLabel).startTimer();
        request.setAttribute(ATTRIBUTE_TIMING_NANO, timer);

        return super.preHandle(request, response, handler);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {

        Histogram.Timer timer = (Histogram.Timer) request.getAttribute(ATTRIBUTE_TIMING_NANO);
        timer.observeDuration();
    }

    private String getLabel(Object handler) {

        if (handler == null) {
            return "HandlerIsNull";
        } else if (handler instanceof HandlerMethod) {
            Method method = ((HandlerMethod) handler).getMethod();
            return method.getDeclaringClass().getSimpleName() + "." + method.getName();
        }
        return handler.toString();
    }
}
