package middleware.conf.sap;




import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.Base64;


@Configuration
public class BasicAuthorizationSap {

    @Value("${sap-po.auth.username}")
    public String username;
    @Value("${sap-po.auth.password}")
    private String password;
    private static final String AUTHORIZATION = "Authorization";
    private static final String BASIC = "Basic ";

    @Bean
    public HttpHeaders Authorization(){
        String notEncoded = username+ ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(notEncoded.getBytes());
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(AUTHORIZATION, BASIC + encodedAuth);
        return headers;
    }

}
