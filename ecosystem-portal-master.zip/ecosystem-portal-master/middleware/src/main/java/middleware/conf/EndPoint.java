package middleware.conf;

import lombok.Data;

@Data
public class EndPoint {

    private String host;
    private String port;
    private String basePath;

    public String getURL() {
        if(this.basePath==null){
            return "http://" + this.host + ":" + port;
        }
        return "http://" + this.host + ":" + port + this.basePath;
    }

}
