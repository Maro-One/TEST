package middleware.conf;


import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("lotus-services.api")
@Data
public class LotusServiceConfig {

    private static final Logger log = LoggerFactory.getLogger(LotusServiceConfig.class);

    private EndPoint ecosystem;
    private EndPoint attachment;
    private EndPoint captcha;
    private EndPoint inscription;
    private CredentialsEndPoint auth;

    private EndPoint coordinator;


    public String getEcosystemUrl() {
        return ecosystem.getURL();
    }

    public String getAttachmentURL() {
        return attachment.getURL();
    }

    public String getBackEndLogin() {
        return auth.getLogin();
    }

    public String getBackEndPwd() {
        return auth.getPassword();
    }

    public String getCaptchaURL() {
        return captcha.getURL();
    }

    public String getInscriptionURL() {
        return inscription.getURL();
    }

    public String getCoordinatorURL() {
        return coordinator.getURL();
    }

}

