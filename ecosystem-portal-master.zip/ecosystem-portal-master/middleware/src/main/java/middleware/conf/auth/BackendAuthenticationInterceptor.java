package middleware.conf.auth;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.services.TokenService;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class BackendAuthenticationInterceptor implements ClientHttpRequestInterceptor {

    public static final String JWT_HEADER = "Authorization";
    public static final String JWT_HEADER_PREFIX = "Bearer ";
    private RestTemplate restTemplate;


    @Data
    class ServiceTokenManager {
        private String serviceName;
        private String token;
        private Instant expires;
        private String url;

        public ServiceTokenManager(String serviceName, String url) {
            this.serviceName = serviceName;
            this.url = url;
        }
    }

    private Map<String, ServiceTokenManager> serviceTokens = new HashMap<>();

    private BackendConfig backendConf;

    private TokenService tokenService;

    public BackendAuthenticationInterceptor(BackendConfig backendConf, LotusServiceConfig lotusServiceConf, TokenService tokenService) {
        this.backendConf = backendConf;
        this.tokenService = tokenService;
        this.restTemplate = new RestTemplate();

        serviceTokens.put("bravo", new ServiceTokenManager("bravo", backendConf.getBravoURL()));
        serviceTokens.put("oracle", new ServiceTokenManager("oracle", backendConf.getOracleEbsURL()));
        serviceTokens.put("ecosystem", new ServiceTokenManager("ecosystem", lotusServiceConf.getEcosystemUrl()));
        serviceTokens.put("attachment", new ServiceTokenManager("attachment", lotusServiceConf.getAttachmentURL()));

        for (ServiceTokenManager serviceTokenManager : serviceTokens.values()) {
            try {
                serviceTokenManager.token = getToken(serviceTokenManager.url);
                serviceTokenManager.expires = tokenService.getExpirationInstant(serviceTokenManager.token);
            } catch (Exception e) {
                log.warn("Could not acquire {} token: {}", serviceTokenManager.serviceName, e.getMessage());
            }
        }
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        log.info("RESTTemplate: Requesting backend {} ", request.getURI().toString());

        List<String> authHeaders = request.getHeaders().get(HttpHeaders.AUTHORIZATION);
        if (authHeaders != null && !authHeaders.isEmpty() && authHeaders.get(0).startsWith("Basic ")) {
            return execution.execute(request, body);
        }
        for (ServiceTokenManager serviceTokenManager : serviceTokens.values()) {
            if (serviceTokenManager.token == null || isSoon(serviceTokenManager.expires)) {
                serviceTokenManager.token = getToken(serviceTokenManager.getUrl());
                serviceTokenManager.expires = tokenService.getExpirationInstant(serviceTokenManager.token);
            }
            request.getHeaders().set(JWT_HEADER, JWT_HEADER_PREFIX + serviceTokenManager.token);
        }
        return execution.execute(request, body);
    }
    private String getToken(String endPoint) {
        Map<String, String> query = new HashMap<>();
        query.put("username", backendConf.getBackEndLogin());
        query.put("password", backendConf.getBackEndPwd());
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Map<String, String>> httpEntity = new HttpEntity<>(query, headers);

        HttpEntity<String> response = restTemplate.exchange(endPoint + "/login",
                HttpMethod.POST, httpEntity, String.class);
        List<String> auths = response.getHeaders().get(JWT_HEADER);
        if (auths != null && !auths.isEmpty()) {
            return auths.get(0).replace(JWT_HEADER_PREFIX, "");
        }
        return "";
    }

    private Boolean isSoon(Instant date) {
        Duration duration = Duration.between(Instant.now(), date);
        return duration.toHours() < 1;
    }
}
