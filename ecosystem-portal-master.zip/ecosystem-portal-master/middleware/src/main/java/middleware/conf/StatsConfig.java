package middleware.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("stats")
@Data
public class StatsConfig {

    private boolean enabled;

}

