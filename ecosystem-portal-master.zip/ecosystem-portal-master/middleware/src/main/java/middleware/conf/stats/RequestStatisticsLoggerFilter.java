package middleware.conf.stats;

import lombok.extern.slf4j.Slf4j;
import middleware.conf.StatsConfig;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter("/*")
@Slf4j
@Component
public class RequestStatisticsLoggerFilter implements Filter {

    @Value("${spring.application.name}")
    private String appName;

    @Autowired
    private StatsConfig statsConfig;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        if (!statsConfig.isEnabled()) {
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        final long time = System.currentTimeMillis();
        try {
            filterChain.doFilter(servletRequest, servletResponse);
        } finally {
            long requestTime = System.currentTimeMillis() - time;
            if (requestTime < 300000) { // Do not consider requests taking more than 5 minutes successful
                MDC.put("appName", appName);
                MDC.put("request-duration", Long.toString(requestTime));
                MDC.put("uri", ((HttpServletRequest) servletRequest).getRequestURI());
                MDC.put("metric-type", "servlet-request-time");
                MDC.put("response-code", String.valueOf(((HttpServletResponse) servletResponse).getStatus()));
                log.trace("{}: {} ms ", ((HttpServletRequest) servletRequest).getRequestURI(), requestTime);
            }
        }
    }

    @Override
    public void destroy() {
    }
}
