package middleware.conf;

import lombok.Data;

@Data
public class CredentialsEndPoint {

    private String login;
    private String password;
}
