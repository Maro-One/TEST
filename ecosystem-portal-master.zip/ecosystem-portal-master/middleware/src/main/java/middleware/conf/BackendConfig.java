package middleware.conf;


import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
@ConfigurationProperties("backend.api")
@Data
public class BackendConfig {

    private static final Logger log = LoggerFactory.getLogger(BackendConfig.class);

    private EndPoint bravo;
    private EndPoint oracleEbs;
    private EndPoint eInvoice;
    private EndPoint backEndGateWay;
    private EndPoint sapPo;


    private CredentialsEndPoint auth;

    @PostConstruct
    public void postConstruct() {
        if (sapPo != null) {
            log.warn("Configured sapPo endpoint is: {}", sapPo.getURL());
        } else{
            log.warn("sapPo endpoint is not configured");
        }
        if (bravo != null) {
            log.info("Configured Bravo endpoint is: {}", bravo.getURL());
        } else {
            log.warn("Bravo endpoint is not configured");
        }
        if (oracleEbs != null) {
            log.info("Configured Oracle EBS endpoint is: {}", oracleEbs.getURL());
        } else {
            log.warn("Oracle EBS endpoint is not configured");
        }
        if (backEndGateWay != null) {
            log.warn("Configured GateWay endpoint is: {}", backEndGateWay.getURL());
        } else{
            log.warn("GateWay endpoint is not configured");
        }
    }

    public String getBravoURL() {
        return bravo.getURL();
    }

    public String getEInvoiceURL() {
        return eInvoice.getURL();
    }
    public String getOracleEbsURL() {
        return oracleEbs.getURL();
    }
    public String getBackEndGateWayUrl() {
        return backEndGateWay.getURL();
    }

    public String getBackEndLogin() {
        return auth.getLogin();
    }

    public String getBackEndPwd() {
        return auth.getPassword();
    }

    public String getSapPoURL() {
        return sapPo.getURL();
    }

}

