package middleware.conf.stats;

import lombok.extern.slf4j.Slf4j;
import middleware.conf.StatsConfig;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Slf4j
public class RestTemplateStatisticsLoggingFilter implements ClientHttpRequestInterceptor {

    @Value("${spring.application.name}")

    private String appName;

    @Autowired
    private StatsConfig statsConfig;


    @Override
    public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] bytes, ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {
        if (!statsConfig.isEnabled()) {
            return clientHttpRequestExecution.execute(httpRequest, bytes);
        }

        final long time = System.currentTimeMillis();
        try {
            return clientHttpRequestExecution.execute(httpRequest, bytes);
        } finally {
            long requestTime = System.currentTimeMillis() - time;
            if (requestTime < 300000) { // Do not consider requests taking more than 5 minutes successful
                MDC.put("appName", appName);
                MDC.put("request-duration", Long.toString(requestTime));
                MDC.put("uri", httpRequest.getURI().toString());
                MDC.put("metric-type", "rest-template-time");
                log.trace("{}: {} ms ", httpRequest.getURI(), requestTime);
            }
        }
    }
}
