package middleware.security;

import junit.framework.TestCase;
import middleware.entities.User;
import middleware.exception.MaxAttemptsException;
import middleware.services.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserDetailsServiceImplTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserDetailsServiceImpl userDetailsService;

    @Test
    public void test_loadUserByUsername_success() {
        User user = User.builder().active(true).build();

        when(userService.findByUsername("test")).thenReturn(user);
        when(userService.isBlocked(user)).thenReturn(false);

        UserDetails result = userDetailsService.loadUserByUsername("test");

        TestCase.assertTrue(result.isEnabled());
    }

    @Test
    public void test_loadUserByUsername_UsernameNotFoundException_userNull() {
        User user = User.builder().active(true).build();

        when(userService.findByUsername("test")).thenReturn(null);

        try {
            UserDetails result = userDetailsService.loadUserByUsername("test");
        } catch (Exception e) {
            TestCase.assertEquals(UsernameNotFoundException.class, e.getClass());
        }
    }

    @Test
    public void test_loadUserByUsername_UsernameNotFoundException_userActiveNull() {
        User user = User.builder().login("test").build();

        when(userService.findByUsername("test")).thenReturn(user);

        try {
            UserDetails result = userDetailsService.loadUserByUsername("test");
        } catch (Exception e) {
            TestCase.assertEquals(UsernameNotFoundException.class, e.getClass());
        }
    }

    @Test
    public void test_loadUserByUsername_UsernameNotFoundException_userNotActive() {
        User user = User.builder().login("test").active(false).build();

        when(userService.findByUsername("test")).thenReturn(user);

        try {
            UserDetails result = userDetailsService.loadUserByUsername("test");
        } catch (Exception e) {
            TestCase.assertEquals(UsernameNotFoundException.class, e.getClass());
        }
    }

    @Test
    public void test_loadUserByUsername_MaxAttemptsException_userBlocked() {
        User user = User.builder().login("test").active(true).build();

        when(userService.findByUsername("test")).thenReturn(user);
        when(userService.isBlocked(user)).thenReturn(true);

        try {
            UserDetails result = userDetailsService.loadUserByUsername("test");
        } catch (Exception e) {
            TestCase.assertEquals(MaxAttemptsException.class, e.getClass());
            TestCase.assertEquals("test", e.getMessage());
        }
    }


}