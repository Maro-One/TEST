package middleware.resources;

import middleware.dto.EventDto;
import middleware.dto.InvoiceDto;
import middleware.dto.InvoicePageableResponse;
import middleware.dto.sap.invoice.InvoiceEventDto;
import middleware.dto.sap.invoice.InvoicePurchaseOrderResponseDto;
import middleware.dto.sap.invoice.SapInvoicePageableResponse;
import middleware.entities.User;
import middleware.services.InvoiceService;
import middleware.services.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class InvoiceResourceTest extends RestControllerConfigTest {

    @MockBean
    InvoiceService invoiceService;
    @MockBean
    UserService userService;

    User user;
    List<InvoicePurchaseOrderResponseDto> invoiceDtos;
    InvoicePageableResponse invoicePageableResponse;
    SapInvoicePageableResponse sapInvoicePageableResponse;

    @Before
    public void setup() {
        user = User.builder().agencyId(1).login("mockUser").roleLabel("ROLE_AGENCY").build();
        when(userService.findByUsername(anyString())).thenReturn(user);
        InvoicePurchaseOrderResponseDto invoiceDto1 = new InvoicePurchaseOrderResponseDto();
        invoiceDto1.setInvoiceNumber("123456");
        invoiceDto1.setSapInvoiceId(1L);
        invoiceDto1.setStatus("test");
        invoiceDto1.setAmountHT((double) 500L);
        invoiceDto1.setApprovalStatus("test");
        invoiceDto1.setEinvoiceId(2L);
        invoiceDto1.setPaymentStatus("test");
        invoiceDto1.setPurchaseOrderCode(123456L);

        InvoicePurchaseOrderResponseDto invoiceDto2 = new InvoicePurchaseOrderResponseDto();
        invoiceDto2.setInvoiceNumber("123458");
        invoiceDto2.setSapInvoiceId(1L);
        invoiceDto2.setStatus("tes2");
        invoiceDto2.setAmountHT((double) 200L);
        invoiceDto2.setApprovalStatus("test");
        invoiceDto2.setEinvoiceId(2L);
        invoiceDto2.setPaymentStatus("test");
        invoiceDto2.setPurchaseOrderCode(1234567L);
        this.invoiceDtos = new ArrayList<>();
        this.invoiceDtos .add(invoiceDto1); this.invoiceDtos.add(invoiceDto2);
        this.sapInvoicePageableResponse = new SapInvoicePageableResponse(this.invoiceDtos , 2L, Collections.emptySet());
    }

    @Test
    public void getInvoiceList_forbidden() throws Exception {
        User user = User.builder().agencyId(1).login("mockUser").roleLabel("ROLE_FOOBAR").build();
        when(userService.findByUsername(anyString())).thenReturn(user);

        mockMvc
                .perform(
                        MockMvcRequestBuilders
                                .get("/invoices/all/po1/s")
                                .queryParam("page", "0")
                                .queryParam("sortBy", "baseEcheance")
                                .queryParam("order", "desc")
                                .headers(getHttpHeaders(user))
                                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }

    @Test
    public void getInvoiceList_sortInputIncorrect() throws Exception {
        try {
            mockMvc.perform(
                    MockMvcRequestBuilders
                            .get("/invoices/all/po1/s")
                            .queryParam("page", "0")
                            .queryParam("sortBy", "someSortInput")
                            .queryParam("order", "desc")
                            .headers(getHttpHeaders(user))
                            .accept(MediaType.APPLICATION_JSON)).andDo(print());
        } catch (Exception e) {
            assertThat(e.getMessage()).contains("Les input du tri ne sont pas correct");
        }
    }

    @Test
    public void getInvoiceList_orderInputIncorrect() throws Exception {
        try {
            mockMvc.perform(
                    MockMvcRequestBuilders
                            .get("/invoices/all/po1/s")
                            .queryParam("page", "0")
                            .queryParam("sortBy", "baseEcheance")
                            .queryParam("order", "someOrder")
                            .headers(getHttpHeaders(user))
                            .accept(MediaType.APPLICATION_JSON)).andDo(print());
        } catch (Exception e) {
            assertThat(e.getMessage()).contains("Les input du tri ne sont pas correct");
        }
    }

    @Test
    public void getInvoiceList_success() throws Exception {
        when(invoiceService.getAllInvoices(anyInt(),
                anyString(),
                anyInt(),
                anyString(),
                anyString(),
                anyString(),
                anyString()))
                .thenReturn(sapInvoicePageableResponse);
        MvcResult mvcResult = mockMvc
                .perform(
                        MockMvcRequestBuilders
                                .get("/invoices/all/po1/s")
                                .queryParam("page", "0")
                                .queryParam("sortBy", "dueDate")
                                .queryParam("order", "desc")
                                .queryParam("status", "any")
                                .headers(getHttpHeaders(user))
                                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        SapInvoicePageableResponse response =
                mapFromJson(mvcResult.getResponse().getContentAsString(), SapInvoicePageableResponse.class);
        assertThat(response.getCount()).isEqualTo(2);
        assertThat(response.getContent()).isEqualTo(invoiceDtos);
    }

    @Test
    public void getInvoiceEvents_success() throws Exception {
        List<InvoiceEventDto> eventDtos = Arrays.asList(
                InvoiceEventDto.builder().eventCode("eventCode1").eventStatus("test1").build(),
                InvoiceEventDto.builder().eventCode("eventCode2").eventStatus("test2").build()
        );
        ResponseEntity<List<InvoiceEventDto>> actualResponse = ResponseEntity.ok().body(eventDtos);
        when(invoiceService.getInvoiceEventsByNumberAndYear(anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(actualResponse);

        MvcResult mvcResult = mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/invoices/invoice-timeline")
                        .queryParam("sapInvoiceId", "1")
                        .queryParam("einvoiceId", "1")
                        .queryParam("orderId", "1")
                        .queryParam("creationDate", "10 Dec 2023")
                        .queryParam("invoiceStatus", "validé")
                        .queryParam("requestSource", "s")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();

        InvoiceEventDto[] response =
                mapFromJson(mvcResult.getResponse().getContentAsString(), InvoiceEventDto[].class);
        assertThat(response.length).isEqualTo(2);
        assertThat(response[0].getEventCode()).isEqualTo(eventDtos.get(0).getEventCode());
    }

}
