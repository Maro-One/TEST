package middleware.resources;

import junit.framework.TestCase;
import middleware.entities.Credentials;
import middleware.entities.RegisterCredentials;
import middleware.entities.User;
import middleware.services.CaptchaService;
import middleware.services.EmailService;
import middleware.services.TokenService;
import middleware.services.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import javax.mail.MessagingException;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class UserResourceTest {
    @InjectMocks
    private UserResource userResource;
    @Mock
    private UserService userService;
    @Mock
    private TokenService tokenService;
    @Mock
    private EmailService emailService;
    @Mock
    private CaptchaService captchaService;

    @Before
    public void init(){
        ReflectionTestUtils.setField(userResource, "linkResetPasswordHost", "http://linkResetPasswordHost");
        ReflectionTestUtils.setField(userResource, "linkResetPasswordPath", "/linkResetPasswordPath");
    }
    @Test
    public void logOut(){
        TestCase.assertEquals(HttpStatus.OK, userResource.logOut(User.builder().build()).getStatusCode());
    }
    @Test
    public void resetPassword_withNullUser() {
        Credentials credentials = new Credentials();
        credentials.setCaptchaValue("captchaValue");
        credentials.setEntryCode("entryCode");
        credentials.setLogin("a@g.c");
        credentials.setPassword("pass");
        User user = new User();
        user.setLogin("login");
        when(captchaService.isValidCaptcha(credentials.getEntryCode(), credentials.getCaptchaValue())).thenReturn(true);
        when(userService.findByUsername(credentials.getLogin())).thenReturn(null);
        TestCase.assertEquals(HttpStatus.UNAUTHORIZED, userResource.resetPassword(credentials).getStatusCode());
    }
    @Test
    public void resetPassword() throws MessagingException {
        Credentials credentials = new Credentials();
        credentials.setCaptchaValue("captchaValue");
        credentials.setEntryCode("entryCode");
        credentials.setLogin("a@g.c");
        credentials.setPassword("pass");
        User user = new User();
        user.setLogin("login");
        when(captchaService.isValidCaptcha(credentials.getEntryCode(), credentials.getCaptchaValue())).thenReturn(true);
        when(userService.findByUsername(credentials.getLogin())).thenReturn(user);
        when(tokenService.getResetPasswordToken(any())).thenReturn("token");
        userResource.resetPassword(credentials);
        String url = "http://linkResetPasswordHost/linkResetPasswordPath";
        Map<String, Object> forMail = new HashMap<>();
        forMail.put("login", user.getLogin());
        forMail.put("allLink", url.concat("token"));
        forMail.put("shortLink", url);
        verify(emailService, times(1)).sendEmail(
                user.getEmail(),
                "Demande de récupération de mot de passe",
                "reset_password",
                forMail,
                null,
                null
        );
    }
    @Test
    public void resetPassword_withInvalidCaptche() {
        Credentials credentials = new Credentials();
        credentials.setCaptchaValue("captchaValue");
        credentials.setEntryCode("entryCode");
        credentials.setLogin("a@g.c");
        credentials.setPassword("pass");
        User user = new User();
        user.setLogin("login");
        when(captchaService.isValidCaptcha(credentials.getEntryCode(), credentials.getCaptchaValue())).thenReturn(false);
        TestCase.assertEquals(HttpStatus.BAD_REQUEST, userResource.resetPassword(credentials).getStatusCode());
    }
    @Test
    public void checkToken_withNoToken(){
        RegisterCredentials credentials = RegisterCredentials.builder().token(null).build();
        TestCase.assertEquals(HttpStatus.BAD_REQUEST,userResource.checkToken(credentials).getStatusCode());
    }

    @Test
    public void checkToken_withNoUser(){
        RegisterCredentials credentials = RegisterCredentials.builder()
                .token("token")
                .build();
        when(tokenService.getUsername(credentials.getToken())).thenReturn("login");
        when(userService.findByUsername("login")).thenReturn(null);
        TestCase.assertEquals(HttpStatus.NOT_FOUND,userResource.checkToken(credentials).getStatusCode());
    }
    @Test
    public void checkToken(){
        RegisterCredentials credentials = RegisterCredentials.builder()
                .token("token")
                .build();
        User user = new User();
        user.setLogin("login");
        user.setActive(true);
        when(tokenService.getUsername(credentials.getToken())).thenReturn("login");
        when(userService.findByUsername("login")).thenReturn(user);
        TestCase.assertEquals(HttpStatus.OK,userResource.checkToken(credentials).getStatusCode());
    }

    @Test
    public void changePassword_withWrongCredentials(){
        RegisterCredentials credentials = RegisterCredentials.builder().firstPassword("1").secondPassword("2").build();
        TestCase.assertEquals(HttpStatus.BAD_REQUEST,userResource.changePassword(credentials).getStatusCode());
    }
    @Test
    public void changePassword(){
        RegisterCredentials credentials = RegisterCredentials.builder()
                .firstPassword("pass@Y2K")
                .secondPassword("pass@Y2K")
                .token("token")
                .build();
        User user = new User();
        user.setActive(true);
        user.setLogin("login");
        when(tokenService.getUsername(credentials.getToken())).thenReturn("login");
        when(userService.findByUsername("login")).thenReturn(user);
        TestCase.assertEquals(HttpStatus.OK,userResource.changePassword(credentials).getStatusCode());
    }
}
