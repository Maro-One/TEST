package middleware.resources;

import middleware.dto.*;
import middleware.dto.sap.ImportPurchaseOrdersResponseSAP;
import middleware.entities.User;
import middleware.services.FundingRequestService;
import middleware.services.SupplierService;
import middleware.services.UserService;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class FundingRequestResourceTest extends RestControllerConfigTest {

    User agencyUser = User.builder().agencyId(1).login("mockUser").roleLabel("ROLE_AGENCY").build();
    User buyerUser = User.builder().agencyId(1).login("mockUser").roleLabel("ROLE_BUYER").build();
    User adminUser = User.builder().agencyId(1).login("mockUser").roleLabel("ROLE_ADMIN").build();
    @MockBean
    private FundingRequestService fundingRequestService;
    @MockBean
    private SupplierService supplierService;
    @MockBean
    private UserService userService;

    @Test
    public void getApprovedFundingApplicantsListByAgency() throws Exception {
        ApplicantPageableResponse expected =
                ApplicantPageableResponse
                        .builder()
                        .content(Arrays.asList(
                                FundingRequestApplicantDto.builder().companyName("Mock").build(),
                                FundingRequestApplicantDto.builder().companyName("Test").build()
                        ))
                        .count(2L)
                        .build();
        when(userService.findByUsername(anyString())).thenReturn(agencyUser);
        when(fundingRequestService.getPaginatedFundingRequestsApplicants(agencyUser.getRoleLabel(), 0, agencyUser.getAgencyId()))
                .thenReturn(expected);

        mockMvc.perform(
                        MockMvcRequestBuilders
                                .get("/funding-request/approved-funding-applicants")
                                .queryParam("page", "0")
                                .headers(getHttpHeaders(agencyUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(mapToJson(expected)));
    }

    @Test
    public void getAllFundingApplicantsList() throws Exception {
        ApplicantPageableResponse expected =
                ApplicantPageableResponse
                        .builder()
                        .content(Arrays.asList(
                                FundingRequestApplicantDto.builder().companyName("Mock").build(),
                                FundingRequestApplicantDto.builder().companyName("Test").build()
                        ))
                        .count(2L)
                        .build();
        when(userService.findByUsername(anyString())).thenReturn(buyerUser);
        when(fundingRequestService.getPaginatedFundingRequestsApplicants(buyerUser.getRoleLabel(), 0, null))
                .thenReturn(expected);

        mockMvc.perform(
                        MockMvcRequestBuilders
                                .get("/funding-request/all-applicants")
                                .queryParam("page", "0")
                                .headers(getHttpHeaders(buyerUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(mapToJson(expected)));
    }

    @Test
    public void getApprovedFundingRequestsBySupplier() throws Exception {
        RequestPageableResponse expected =
                RequestPageableResponse
                        .builder()
                        .content(Arrays.asList(
                                FundingRequestDto.builder().id(1).build(),
                                FundingRequestDto.builder().id(2).build()
                        ))
                        .count(2L)
                        .build();
        when(userService.findByUsername(anyString())).thenReturn(agencyUser);
        when(fundingRequestService.getFundingRequestsForSupplierByStatusUsingSap(agencyUser.getRoleLabel(), agencyUser.getAgencyId(), 1L, 0, null))
                .thenReturn(expected);

        mockMvc.perform(
                        MockMvcRequestBuilders
                                .get("/funding-request/approved-list/1")
                                .queryParam("bravoId", "1")
                                .queryParam("page", "0")
                                .headers(getHttpHeaders(agencyUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(mapToJson(expected)));
    }

    /*
    @Test
    public void getAllFundingRequestsBySupplier() throws Exception {
        RequestPageableResponse expected =
                RequestPageableResponse
                        .builder()
                        .content(Arrays.asList(
                                FundingRequestDto.builder().id(1).build(),
                                FundingRequestDto.builder().id(2).build()
                        ))
                        .count(2L)
                        .build();
        when(userService.findByUsername(anyString())).thenReturn(buyerUser);
        when(fundingRequestService.getFundingRequestsForSupplierByStatusWithOutPercentage(buyerUser.getRoleLabel(), null, null, 0, null))
                .thenReturn(expected);

        mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/funding-request/supplier-list-all")
                        .queryParam("bravoId", "1")
                        .queryParam("page", "0")
                        .headers(getHttpHeaders(buyerUser))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(mapToJson(expected)));
    }*/

    @Test
    public void getApprovedFundingRequestDetail() throws Exception {
        // Préparation de l'objet attendu
        FundingRequestDto expected = FundingRequestDto.builder().id(1).build();

        // Moquer la récupération de l'utilisateur et de la réponse attendue
        when(userService.findByUsername(anyString())).thenReturn(agencyUser);
        when(fundingRequestService.getFundingRequestDetailUsingSap(agencyUser.getAgencyId(), "s124", 12, "s"))
                .thenReturn(expected);

        // Effectuer la requête et vérifier les résultats
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .get("/funding-request/approved-funding-request-detail/s124/12/s")
                                .headers(getHttpHeaders(agencyUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(mapToJson(expected)));  // S'assurer que le mapping JSON est correct
    }


    @Test
    public void getApprovedFundingRequestDetail_notFound() throws Exception {
        when(fundingRequestService.getFundingRequestDetail(agencyUser.getAgencyId(), "s124", 12))
                .thenReturn(null);
        when(userService.findByUsername(anyString())).thenReturn(agencyUser);
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .get("/funding-request/approved-funding-request-detail/s124/12")
                                .headers(getHttpHeaders(agencyUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNotFound());
    }

    @Test
    public void getSupplierFundingRequestDetail() throws Exception {
        RequestPageableResponse expected =
                RequestPageableResponse
                        .builder()
                        .content(Arrays.asList(
                                FundingRequestDto.builder().id(1).build(),
                                FundingRequestDto.builder().id(2).build()
                        ))
                        .count(2L)
                        .build();
        when(userService.findByUsername(anyString())).thenReturn(agencyUser);
        when(fundingRequestService.getSupplierFundingRequestsByStatus(12L, "APPROVED", 0))
                .thenReturn(expected);

        mockMvc.perform(
                        MockMvcRequestBuilders
                                .get("/funding-request/funding-request-by-supplier/12")
                                .queryParam("page", "0")
                                .queryParam("status", "APPROVED")
                                .headers(getHttpHeaders(agencyUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(mapToJson(expected)));
    }

    @Test
    public void getSupplierFundingRequestDetail_notFound() throws Exception {
        when(fundingRequestService.getSupplierFundingRequestsByStatus(12L, "APPROVED", 0))
                .thenReturn(null);
        when(userService.findByUsername(anyString())).thenReturn(agencyUser);
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .get("/funding-request/funding-request-by-supplier/12")
                                .queryParam("page", "0")
                                .queryParam("status", "APPROVED")
                                .headers(getHttpHeaders(agencyUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNotFound());
    }

    @Test
    public void importPurchaseOrders_invalidExcelFile_fileEmpty() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", new byte[]{});
        when(userService.findByUsername(anyString())).thenReturn(adminUser);
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .multipart("/funding-request/import-Requests-SAP")
                                .file(file)
                                .headers(getHttpHeaders(adminUser)))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string("Please select a valid excel file"));
    }

    @Test
    public void importPurchaseOrders_invalidExcelFile_fileNameEmpty() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test".getBytes());
        when(userService.findByUsername(anyString())).thenReturn(adminUser);
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .multipart("/funding-request/import-Requests-SAP")
                                .file(file)
                                .headers(getHttpHeaders(adminUser)))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string("Please select a valid excel file"));
    }

    @Test
    public void importPurchaseOrders_invalidExcelFile_fileNameDoesNotContainXls() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test", "application/vnd.ms-excel", "test".getBytes());
        when(userService.findByUsername(anyString())).thenReturn(adminUser);
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .multipart("/funding-request/import-Requests-SAP")
                                .file(file)
                                .headers(getHttpHeaders(adminUser)))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string("Please select a valid excel file"));
    }

    @Test
    public void importPurchaseOrders_validExcelFile() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.xls", "application/vnd.ms-excel", "test".getBytes());

        // Mock the expected response with the correct type (ImportPurchaseOrdersResponseSAP)
        List<ImportPurchaseOrdersResponseSAP> expected = Arrays.asList(
                ImportPurchaseOrdersResponseSAP.builder().CommandeID("1").saved(true).build(),
                ImportPurchaseOrdersResponseSAP.builder().CommandeID("2").saved(true).build()
        );

        // Mock the user and service behavior
        when(userService.findByUsername(anyString())).thenReturn(adminUser);
        when(fundingRequestService.importPurchaseOrdersSAP(file)).thenReturn(expected);

        // Perform the request and verify
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .multipart("/funding-request/import-Requests-SAP")
                                .file(file)
                                .headers(getHttpHeaders(adminUser)))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json(mapToJson(expected))); // mapToJson should convert the object to JSON
    }


    @Test
    public void importPurchaseOrders_ioException() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.xls", "application/vnd.ms-excel", "test".getBytes());

        // Mock the service to throw IOException
        when(fundingRequestService.importPurchaseOrdersSAP(file)).thenThrow(IOException.class);
        when(userService.findByUsername(anyString())).thenReturn(adminUser);

        // Perform the request and verify that it handles the exception correctly
        mockMvc.perform(
                        MockMvcRequestBuilders
                                .multipart("/funding-request/import-Requests-SAP")
                                .file(file)
                                .headers(getHttpHeaders(adminUser)))
                .andDo(print())
                .andExpect(status().isInternalServerError())
                .andExpect(content().string("Couldn't read file."));
    }


    @Test
    public void updateFundingRequest() throws Exception {
        FundingRequestDto fundingRequestDto = FundingRequestDto.builder().id(1).bravoId(1L).purchaseOrderDescription("test").build();
        FundingRequestApplicantDto applicantDto = FundingRequestApplicantDto.builder().companyName("test").build();
        when(userService.findByUsername(anyString())).thenReturn(buyerUser);
        when(fundingRequestService.updateFundingRequest(1, 1)).thenReturn(fundingRequestDto);
        when(supplierService.getSupplierInfo(fundingRequestDto.getBravoId())).thenReturn(applicantDto);

        mockMvc.perform(
                        MockMvcRequestBuilders
                                .put("/funding-request/1")
                                .queryParam("fundingAgencyEmail", "test@test.com")
                                .headers(getHttpHeaders(buyerUser))
                                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

}
