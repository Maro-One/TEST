package middleware.resources;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import middleware.entities.User;
import middleware.services.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class RestControllerConfigTest {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    TokenService tokenService;

    public HttpHeaders getHttpHeaders(User user) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("user", ImmutableMap.of("login",user.getLogin()));
        String token = tokenService.getToken(data);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Authorization", "Bearer " + token);
        return httpHeaders;
    }

    public String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    public <T> T mapFromJson(String json, Class<T> clazz) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(json, clazz);
    }
}
