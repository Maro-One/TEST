package middleware.resources;

import junit.framework.TestCase;
import middleware.dto.AttachmentFromOraclePageableResponse;
import middleware.dto.sap.AttachmentSAPDto.AttachmentRequestDto;
import middleware.services.AttachmentService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class AttachmentResourceTest {

    @InjectMocks
    private AttachmentResource attachmentResource;
    @Mock
    private AttachmentService attachmentService;

    // --- Tests for GET method: getAttachmentsfromSap() ---

    @Test
    public void testGetAttachmentsfromSap_success() {
        String orderId = "1";
        AttachmentFromOraclePageableResponse response = new AttachmentFromOraclePageableResponse(Collections.emptyList());

        when(attachmentService.getAttachmentsfromSAPbyOrderId(orderId)).thenReturn(response);

        ResponseEntity<AttachmentFromOraclePageableResponse> result = attachmentResource.getAttachmentsfromSap(orderId);

        TestCase.assertEquals(HttpStatus.OK, result.getStatusCode());
        TestCase.assertEquals(response, result.getBody());
    }

    @Test
    public void testGetAttachmentsfromSap_nullResult() {
        String orderId = "1";

        when(attachmentService.getAttachmentsfromSAPbyOrderId(orderId)).thenReturn(null);

        ResponseEntity<AttachmentFromOraclePageableResponse> result = attachmentResource.getAttachmentsfromSap(orderId);

        TestCase.assertNull(result.getBody());
        TestCase.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetAttachmentsfromSap_invalidOrderId() {
        String orderId = "invalid"; // Simulate invalid order ID scenario
        when(attachmentService.getAttachmentsfromSAPbyOrderId(orderId)).thenThrow(new IllegalArgumentException("Invalid Order ID"));

        attachmentResource.getAttachmentsfromSap(orderId); // Should throw an exception
    }

    // --- Tests for POST method: getAttachmentsfromSapByRefCmdAppelList() ---

    @Test
    public void testGetAttachmentsfromSapByRefCmdAppelList_success() {
        String orderId = "1";
        String requestSource = "s";

        // Create an instance of AttachmentRequestDto and set its fields
        AttachmentRequestDto requestDto = new AttachmentRequestDto();
        requestDto.setRefCmdAppelList(Collections.singletonList("ref1"));
        requestDto.setPage(0);
        requestDto.setSortBy("date");
        requestDto.setOrder("asc");

        AttachmentFromOraclePageableResponse response = new AttachmentFromOraclePageableResponse(Collections.emptyList());

        when(attachmentService.getAttachmentsfromSAPbyRefCmdAppelList(orderId, requestDto.getRefCmdAppelList(), requestSource))
                .thenReturn(response);

        ResponseEntity<AttachmentFromOraclePageableResponse> result = attachmentResource.getAttachmentsfromSapByRefCmdAppelList(orderId, requestSource, requestDto);

        TestCase.assertEquals(HttpStatus.OK, result.getStatusCode());
        TestCase.assertEquals(response, result.getBody());
    }

    @Test
    public void testGetAttachmentsfromSapByRefCmdAppelList_nullResult() {
        String orderId = "1";
        String requestSource = "s";

        // Create an instance of AttachmentRequestDto and set its fields
        AttachmentRequestDto requestDto = new AttachmentRequestDto();
        requestDto.setRefCmdAppelList(Collections.singletonList("ref1"));
        requestDto.setPage(0);
        requestDto.setSortBy("date");
        requestDto.setOrder("asc");

        when(attachmentService.getAttachmentsfromSAPbyRefCmdAppelList(orderId, requestDto.getRefCmdAppelList(), requestSource))
                .thenReturn(null);

        ResponseEntity<AttachmentFromOraclePageableResponse> result = attachmentResource.getAttachmentsfromSapByRefCmdAppelList(orderId, requestSource, requestDto);

        TestCase.assertNull(result.getBody());
        TestCase.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetAttachmentsfromSapByRefCmdAppelList_invalidOrderId() {
        String orderId = "invalid"; // Simulate invalid order ID scenario
        String requestSource = "s";

        // Create an instance of AttachmentRequestDto and set its fields
        AttachmentRequestDto requestDto = new AttachmentRequestDto();
        requestDto.setRefCmdAppelList(Collections.singletonList("ref1"));
        requestDto.setPage(0);
        requestDto.setSortBy("date");
        requestDto.setOrder("asc");

        when(attachmentService.getAttachmentsfromSAPbyRefCmdAppelList(orderId, requestDto.getRefCmdAppelList(), requestSource))
                .thenThrow(new IllegalArgumentException("Invalid Order ID"));

        attachmentResource.getAttachmentsfromSapByRefCmdAppelList(orderId, requestSource, requestDto); // Should throw an exception
    }




}
