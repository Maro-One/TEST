package middleware.resources;

import junit.framework.TestCase;
import middleware.dto.FundingRequestApplicantDto;
import middleware.dto.ScoringDto;
import middleware.entities.User;
import middleware.services.SupplierService;
import middleware.services.UserService;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Collections;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class SupplierResourceTest extends RestControllerConfigTest {

    @MockBean
    private SupplierService supplierService;
    @MockBean
    private UserService userService;

    User user;
    FundingRequestApplicantDto applicantDto;
    ScoringDto scoringDto;

    @Before
    public void setup() {
        user = User.builder().agencyId(1).login("admin").build();
        applicantDto = FundingRequestApplicantDto.builder().companyName("MockCompany").build();
        scoringDto = ScoringDto.builder().build();
        when(userService.findByUsername(anyString())).thenReturn(user);

    }

    @Test
    public void getApplicantsInfo_roleAgency() throws Exception {
        when(supplierService.getSupplierInfoWithCheck(anyInt(), anyLong())).thenReturn(applicantDto);
        user.setRoleLabel("ROLE_AGENCY");
        MvcResult mvcResult = mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-info/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        FundingRequestApplicantDto result = mapFromJson(mvcResult.getResponse().getContentAsString(), FundingRequestApplicantDto.class);
        assertEquals(result.getCompanyName(), applicantDto.getCompanyName());
    }

    @Test
    public void getApplicantsInfo_roleAgency_unauthorized() throws Exception {
        when(supplierService.getSupplierInfoWithCheck(anyInt(), anyLong())).thenReturn(null);
        user.setRoleLabel("ROLE_AGENCY");
        mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-info/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is(HttpStatus.UNAUTHORIZED.value()));
    }

    @Test
    public void getApplicantsInfo_roleBuyer() throws Exception {
        when(supplierService.getSupplierInfo(anyLong())).thenReturn(applicantDto);
        user.setRoleLabel("ROLE_BUYER");
        MvcResult mvcResult = mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-info/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        FundingRequestApplicantDto result = mapFromJson(mvcResult.getResponse().getContentAsString(), FundingRequestApplicantDto.class);
        assertEquals(result.getCompanyName(), applicantDto.getCompanyName());
    }

    @Test
    public void getApplicantsInfo_randomRole() throws Exception {
        when(supplierService.getSupplierInfoWithCheck(anyInt(), anyLong())).thenReturn(null);
        user.setRoleLabel("ROLE_AGENCY");
        mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-info/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is(HttpStatus.UNAUTHORIZED.value()));
    }


    @Test
    public void getApplicantsScoring_roleAgency() throws Exception {
        when(supplierService.getSupplierScoring(anyLong())).thenReturn(scoringDto);
        user.setRoleLabel("ROLE_AGENCY");
        MvcResult mvcResult = mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-scoring/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        ScoringDto result = mapFromJson(mvcResult.getResponse().getContentAsString(), ScoringDto.class);
        TestCase.assertNotNull(result);
    }

    @Test
    public void getApplicantsScoring_roleAgency_unauthorized() throws Exception {
        when(supplierService.getSupplierScoringsForAgency(anyInt(), anyLong())).thenReturn(null);
        user.setRoleLabel("ROLE_AGENCY");
        mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-scoring/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is(HttpStatus.OK.value()));
    }

    @Test
    public void getApplicantsScoring_roleBuyer() throws Exception {
        when(supplierService.getSupplierScoring(anyLong())).thenReturn(scoringDto);
        user.setRoleLabel("ROLE_BUYER");
        MvcResult mvcResult = mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-scoring/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        ScoringDto result = mapFromJson(mvcResult.getResponse().getContentAsString(), ScoringDto.class);
        TestCase.assertNotNull(result);
    }

    @Test
    public void getApplicantsScoring_randomRole() throws Exception {
        user.setRoleLabel("ROLE_RANDOM");
        mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/supplier/supplier-scoring/1")
                        .headers(getHttpHeaders(user))
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }

    @Test
    public void searchApprovedFundingApplicantsList_roleAgency() throws Exception {
        user.setRoleLabel("ROLE_AGENCY");
        when(supplierService.searchApprovedFundingRequestsApplicants(anyInt(), anyString()))
                .thenReturn(Collections.singletonList(applicantDto));
        MvcResult mvcResult =
                mockMvc.perform(
                        MockMvcRequestBuilders.get("/supplier/search-approved-funding-applicants")
                                .queryParam("input", "test")
                                .accept(MediaType.APPLICATION_JSON)
                                .headers(getHttpHeaders(user))
                ).andDo(print()).andExpect(status().isOk()).andReturn();
        FundingRequestApplicantDto[] result = mapFromJson(mvcResult.getResponse().getContentAsString(), FundingRequestApplicantDto[].class);
        assertEquals(1, result.length);
        assertEquals(applicantDto.getCompanyName(), result[0].getCompanyName());
    }

    @Test
    public void searchApprovedFundingApplicantsList_randomRole() throws Exception {
        user.setRoleLabel("ROLE_RANDOM");
        mockMvc.perform(
                MockMvcRequestBuilders.get("/supplier/search-approved-funding-applicants")
                        .queryParam("input", "test")
                        .accept(MediaType.APPLICATION_JSON)
                        .headers(getHttpHeaders(user))
        ).andDo(print()).andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }

    @Test
    public void searchAllFundingApplicantsList_roleBuyer() throws Exception {
        user.setRoleLabel("ROLE_BUYER");
        when(supplierService.searchAllFundingRequestsApplicants(anyString()))
                .thenReturn(Collections.singletonList(applicantDto));
        MvcResult mvcResult =
                mockMvc.perform(
                        MockMvcRequestBuilders.get("/supplier/search-all-funding-applicants")
                                .queryParam("input", "test")
                                .accept(MediaType.APPLICATION_JSON)
                                .headers(getHttpHeaders(user))
                ).andDo(print()).andExpect(status().isOk()).andReturn();
        FundingRequestApplicantDto[] result = mapFromJson(mvcResult.getResponse().getContentAsString(), FundingRequestApplicantDto[].class);
        assertEquals(1, result.length);
        assertEquals(applicantDto.getCompanyName(), result[0].getCompanyName());
    }

    @Test
    public void searchAllFundingApplicantsList_randomRole() throws Exception {
        user.setRoleLabel("ROLE_RANDOM");
        mockMvc.perform(
                MockMvcRequestBuilders.get("/supplier/search-all-funding-applicants")
                        .queryParam("input", "test")
                        .accept(MediaType.APPLICATION_JSON)
                        .headers(getHttpHeaders(user))
        ).andDo(print()).andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }

    @Test
    @Ignore
    public void searchDeactivatedSuppliers() throws Exception {
        mockMvc.perform(
                MockMvcRequestBuilders.get("/supplier/search-deactivated-suppliers")
        ).andDo(print()).andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }
}
