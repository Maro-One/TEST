package middleware.resources;

import junit.framework.TestCase;
import middleware.entities.Captcha;
import middleware.services.CaptchaService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class CaptchaResourceTest {
    @InjectMocks
    private CaptchaRessource captchaRessource;
    @Mock
    private CaptchaService captchaService;

    @Test
    public void getCaptcha() {
        Captcha captcha = new Captcha();
        when(captchaService.generateCaptcha())
                .thenReturn(captcha);
        ResponseEntity<Captcha> responseEntity = new ResponseEntity<>(captcha, HttpStatus.OK);
        TestCase.assertEquals(responseEntity, captchaRessource.getCaptcha());
    }
}
