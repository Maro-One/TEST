package middleware.services;

import junit.framework.TestCase;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;

import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class SupplierServiceTest {
    @InjectMocks
    private SupplierService supplierService;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private BackendConfig backendConfig;
    @Mock
    private LotusServiceConfig lotusServiceConfig;
    @Mock
    private CategorieService categorieService;

    @Before
    public void init() {
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://ecosystemurl");
        when(backendConfig.getBravoURL()).thenReturn("http://bravourl");
    }

    @Test
    public void getSupplierInfoWithCheck() {
        long supplierId = 55L;
        int agencyId = 11;
        String companyName = "companyName";
        String url = "http://ecosystemurl/funding-request/agency-has-supplier-request-by-id/" + agencyId + "/" + supplierId;
        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(true);
        HttpEntity<List<Long>> requestEntity = new HttpEntity<>(Collections.singletonList(supplierId));
        Map<String, Integer> params = new HashMap<>();
        params.put("page", 0);
        List<FundingRequestApplicantDto> fundingRequestApplicantDtos = new ArrayList();
        fundingRequestApplicantDtos.add(FundingRequestApplicantDto.builder()
                .companyName(companyName)
                .build());
        ResponseEntity<List<FundingRequestApplicantDto>> response = new ResponseEntity<>(fundingRequestApplicantDtos, HttpStatus.OK);
        when(restTemplate.exchange(
                "http://bravourl/supplier/profilesBySupplierIds?page={page}",
                HttpMethod.POST, requestEntity,
                new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                },
                params)
        )
                .thenReturn(response);
        FundingRequestApplicantDto fundingRequestApplicantDto = supplierService.getSupplierInfoWithCheck(agencyId, supplierId);
        TestCase.assertEquals(fundingRequestApplicantDto.getCompanyName(), companyName);
    }

    @Test
    public void searchApprovedFundingRequestsApplicants() {
        int agencyId = 44;
        Map<Long, Long> resp = new HashMap<>();
        resp.put(44L, 44L);
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder.fromHttpUrl("http://ecosystemurl/funding-request/approved-funding-applicants-count/" + agencyId);
        when(restTemplate.exchange(fundingRequestsUrl.build().toUriString(), HttpMethod.GET, null,
                new ParameterizedTypeReference<Map<Long, Long>>() {
                })).thenReturn(new ResponseEntity<>(resp, HttpStatus.OK));
        HttpEntity<SupplierFilterDto> requestEntity =
                new HttpEntity<>(new SupplierFilterDto(new ArrayList<>(resp.keySet()), "input"));
        List<FundingRequestApplicantDto> supplierInfos = new ArrayList<>();
        supplierInfos.add(
                FundingRequestApplicantDto.builder().companyName("name").supplierBravoId(15L).build()
        );
        when(restTemplate.
                exchange("http://bravourl/supplier/profilesBySupplierIdsAndInputFilter", HttpMethod.POST, requestEntity,
                        new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                        }))
                .thenReturn(new ResponseEntity<>(supplierInfos, HttpStatus.OK));
        List<FundingRequestApplicantDto> result = supplierService.searchApprovedFundingRequestsApplicants(agencyId, "input");
        TestCase.assertEquals(supplierInfos, result);
    }

    @Test
    public void searchAllFundingRequestsApplicants() {
        Map<Long, Long> resp = new HashMap<>();
        resp.put(44L, 44L);
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder.fromHttpUrl("http://ecosystemurl/funding-request/all-funding-applicants-count");
        when(restTemplate.exchange(fundingRequestsUrl.build().toUriString(), HttpMethod.GET, null,
                new ParameterizedTypeReference<Map<Long, Long>>() {
                })).thenReturn(new ResponseEntity<>(resp, HttpStatus.OK));

        HttpEntity<SupplierFilterDto> requestEntity =
                new HttpEntity<>(new SupplierFilterDto(new ArrayList<>(resp.keySet()), "input"));
        List<FundingRequestApplicantDto> supplierInfos = new ArrayList<>();
        supplierInfos.add(
                FundingRequestApplicantDto.builder().companyName("name").supplierBravoId(15L).build()
        );
        when(restTemplate.
                exchange("http://bravourl/supplier/profilesBySupplierIdsAndInputFilter", HttpMethod.POST, requestEntity,
                        new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                        }))
                .thenReturn(new ResponseEntity<>(supplierInfos, HttpStatus.OK));
        List<FundingRequestApplicantDto> result = supplierService.searchAllFundingRequestsApplicants("input");
        TestCase.assertEquals(supplierInfos, result);
    }

    @Test
    public void getSupplierScoring() {
        Assessment[] assessmentsArray = {
                Assessment
                        .builder()
                        .supplierBravoId(Integer.valueOf(1319).longValue())
                        .assessmentDate("2019-01-11")
                        .assessmentType("CATEGORY")
                        .supplierPositioning("Emerging")
                        .financialRating(41.1)
                        .categories(Collections.singletonList(
                                CategorieDto.builder().categoryCode("311.31101").build()
                        ))
                        .build(),
                Assessment
                        .builder()
                        .supplierBravoId(Integer.valueOf(1319).longValue())
                        .assessmentDate("2020-01-11")
                        .assessmentType("CATEGORY")
                        .supplierPositioning("Developped")
                        .financialRating(61.4)
                        .capabilitiesRating(45.9)
                        .categories(Collections.singletonList(
                                CategorieDto.builder().categoryCode("311.31101").build()
                        ))
                        .build()
        };
        String url = "http://bravourl/supplier/1319/category-assessment/all";
        when(restTemplate.getForObject(url, Assessment[].class)).thenReturn(assessmentsArray);
        when(categorieService.getCategorieByCode("311.31101"))
                .thenReturn(CategorieDto.builder().codeSousFamille("311.31101").sousFamille("test code").build());
        when(restTemplate.getForObject("http://bravourl/supplier/1319", SupplierDto.class))
                .thenReturn(SupplierDto.builder().supplierId(1319L).supplierStatus("Activé").build());

        ScoringDto scoringDto = supplierService.getSupplierScoring(Integer.valueOf(1319).longValue());

        TestCase.assertEquals(Integer.valueOf(1319).longValue(), scoringDto.getSupplierBravoId().longValue());
        TestCase.assertEquals(null, scoringDto.getSupplierStatus());
        TestCase.assertEquals(61.4, scoringDto.getScoringFinancial().getScore());
        TestCase.assertEquals(49.39, scoringDto.getScoringFinancial().getChangeRate(), 20.3);
        TestCase.assertEquals(1, scoringDto.getScoringCapabilities().size());
        TestCase.assertEquals(45.9, scoringDto.getScoringCapabilities().get(0).getScore());
        TestCase.assertEquals(0., scoringDto.getScoringCapabilities().get(0).getChangeRate());
        TestCase.assertEquals("Developed", scoringDto.getScoringCapabilities().get(0).getSupplierPositioning());
        TestCase.assertEquals("test code", scoringDto.getScoringCapabilities().get(0).getCategory());
    }

    @Test
    public void getSupplierScoring_withMoreCategories() {
        Assessment[] assessmentsArray = {
                Assessment
                        .builder()
                        .supplierBravoId(Integer.valueOf(1319).longValue())
                        .assessmentDate("2010-01-01")
                        .assessmentType("ENTERPRISE")
                        .supplierPositioning("Developped")
                        .financialRating(41.1)
                        .capabilitiesRating(48.2)
                        .categories(Collections.emptyList())
                        .build(),
                Assessment
                        .builder()
                        .supplierBravoId(Integer.valueOf(1319).longValue())
                        .assessmentDate("2018-01-01")
                        .assessmentType("CATEGORY")
                        .supplierPositioning("Emerging")
                        .financialRating(41.1)
                        .capabilitiesRating(48.2)
                        .categories(Collections.singletonList(
                                CategorieDto.builder().categoryCode("311.31101").build()
                        ))
                        .build(),
                Assessment
                        .builder()
                        .supplierBravoId(Integer.valueOf(1319).longValue())
                        .assessmentDate("2019-01-01")
                        .assessmentType("CATEGORY")
                        .supplierPositioning("Developped")
                        .financialRating(60.6)
                        .capabilitiesRating(50.4)
                        .categories(Arrays.asList(
                                CategorieDto.builder().categoryCode("311.31101").build(),
                                CategorieDto.builder().categoryCode("311.31103").build()
                        ))
                        .build()
        };

        String url = "http://bravourl/supplier/1319/category-assessment/all";
        when(restTemplate.getForObject(url, Assessment[].class)).thenReturn(assessmentsArray);

        when(categorieService.getCategorieByCode("311.31101"))
                .thenReturn(CategorieDto.builder().codeSousFamille("311.31101").sousFamille("test code 1").build());
        when(categorieService.getCategorieByCode("311.31103"))
                .thenReturn(CategorieDto.builder().codeSousFamille("311.31102").sousFamille("test code 3").build());

        when(restTemplate.getForObject("http://bravourl/supplier/1319", SupplierDto.class))
                .thenReturn(SupplierDto.builder().supplierId(1319L).supplierStatus("Activé").build());

        ScoringDto scoringDto = supplierService.getSupplierScoring(Integer.valueOf(1319).longValue());

        TestCase.assertEquals(Integer.valueOf(1319).longValue(), scoringDto.getSupplierBravoId().longValue());
        TestCase.assertEquals(null, scoringDto.getSupplierStatus());

        TestCase.assertEquals(60.6, scoringDto.getScoringFinancial().getScore());
        TestCase.assertEquals(47.45, scoringDto.getScoringFinancial().getChangeRate(), 0.01);

        TestCase.assertEquals(2, scoringDto.getScoringCapabilities().size());
        TestCase.assertEquals(50.4, scoringDto.getScoringCapabilities().get(0).getScore());
        TestCase.assertEquals(2.2, scoringDto.getScoringCapabilities().get(0).getChangeRate(),4.56);
        TestCase.assertEquals("Developed", scoringDto.getScoringCapabilities().get(0).getSupplierPositioning());
        TestCase.assertEquals("test code 1", scoringDto.getScoringCapabilities().get(0).getCategory());

        TestCase.assertEquals(50.4, scoringDto.getScoringCapabilities().get(1).getScore());
        TestCase.assertEquals(0., scoringDto.getScoringCapabilities().get(1).getChangeRate());
        TestCase.assertEquals("Developed", scoringDto.getScoringCapabilities().get(1).getSupplierPositioning());
        TestCase.assertEquals(0, scoringDto.getScoringCapabilities().get(1).getPositionChangeRate());
        TestCase.assertEquals("test code 3", scoringDto.getScoringCapabilities().get(1).getCategory());
    }

}
