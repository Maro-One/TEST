package middleware.services;

import middleware.services.mail.MailContentBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import java.io.ByteArrayOutputStream;
import java.util.Properties;

import static org.mockito.BDDMockito.*;

@RunWith(MockitoJUnitRunner.class)
public class EmailServiceTest {

    @Mock
    private JavaMailSender emailSender;

    @Mock
    MailContentBuilder mailContentBuilder;

    @InjectMocks
    private EmailService emailService;

    @Before
    public void init() {
        ReflectionTestUtils.setField(emailService, "from", "test@ocpgroup.ma");
    }

    @Test
    public void test_sendEmail_withData() throws MessagingException {
        Properties props = new Properties();
        props.put("mail.host", "mail.sm.ocp");
        MimeMessage message = new MimeMessage(Session.getInstance(props, null));

        when(mailContentBuilder.build(any(), any())).thenReturn("content");
        when(emailSender.createMimeMessage()).thenReturn(message);

        emailService.sendEmail("to", "subject", "template", null, null, null);

        verify(emailSender, times(1)).send(eq(message));
    }

    @Test
    public void test_sendEmail_withAttachment() throws MessagingException {
        Properties props = new Properties();
        props.put("mail.host", "mail.sm.ocp");
        MimeMessage message = new MimeMessage(Session.getInstance(props, null));

        when(emailSender.createMimeMessage()).thenReturn(message);

        emailService.sendEmail("to", "subject", "template", new ByteArrayOutputStream(), null);

        verify(emailSender, times(1)).send(eq(message));

    }
}