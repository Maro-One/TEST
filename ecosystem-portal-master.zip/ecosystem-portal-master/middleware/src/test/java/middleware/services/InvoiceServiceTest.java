package middleware.services;

import junit.framework.TestCase;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class InvoiceServiceTest {

    public static final int AGENCY_ID = 55;
    private static final String MOCK_URL = "http://localhost:80";
    public static final String ORDER_ID = "s0254";
    public static final String INVOICE_ORACLE_ID = "o124";
    public static final String E_INVOICE_ID = "e478";

    @Mock
    RestTemplate restTemplate;

    @Mock
    LotusServiceConfig lotusServiceConfig;

    @Mock
    BackendConfig backendConfig;

    @InjectMocks
    private InvoiceService invoiceService;

    @Before
    public void setup() {
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn(MOCK_URL);
        when(backendConfig.getBackEndGateWayUrl()).thenReturn(MOCK_URL);
        when(backendConfig.getOracleEbsURL()).thenReturn(MOCK_URL);
        when(backendConfig.getEInvoiceURL()).thenReturn(MOCK_URL);
        when(lotusServiceConfig.getInscriptionURL()).thenReturn(MOCK_URL);
        ReflectionTestUtils.setField(invoiceService, "pageSize", 10);
    }

    @Test
    public void testGetgetPurchaseOrderInvoicesNotnull() {
        String url = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/" + AGENCY_ID + "/" + ORDER_ID;
        String urlInscription = MOCK_URL+"/supplier/supplierSapId/"+ORDER_ID;
        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(true);
        String invoicesUrl = MOCK_URL + "/purchase-orders/" + ORDER_ID + "/invoices";
        HttpEntity<List<String>> requestBody = new HttpEntity<>(Collections.emptyList());
        when(restTemplate.exchange(invoicesUrl, HttpMethod.POST, requestBody, InvoiceDto[].class))
                .thenReturn(ResponseEntity.ok(new InvoiceDto[0]));
        when(restTemplate.getForObject(urlInscription, SapInvoiceKeyDto.class)).thenReturn(new SapInvoiceKeyDto("","",""));
        InvoicePageableResponse purchaseOrderInvoices = invoiceService.getPurchaseOrderInvoices(AGENCY_ID, ORDER_ID, 0, "baseEcheance", "asc", null);
        TestCase.assertNotNull(purchaseOrderInvoices);
        TestCase.assertEquals(0L, (long) purchaseOrderInvoices.getCount());
    }

    @Test
    public void testGetgetPurchaseOrderInvoices() {
        String url = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/" + AGENCY_ID + "/" + ORDER_ID;
        String urlInscription = MOCK_URL+"/supplier/supplierSapId/"+ORDER_ID;
        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(true);
        String invoicesUrl = MOCK_URL + "/purchase-orders/" + ORDER_ID + "/invoices";
        HttpEntity<List<String>> requestBody = new HttpEntity<>(Collections.emptyList());
        when(restTemplate.exchange(invoicesUrl, HttpMethod.POST, requestBody, InvoiceDto[].class))
                .thenReturn(ResponseEntity.ok(new InvoiceDto[]{InvoiceDto.builder()
                        .einvoiceId(1l)
                        .status("IN.FMFI")
                        .baseEcheance(LocalDate.now())
                        .baseEcheance(LocalDate.now().minusMonths(1))
                        .build()})
                );
        when(restTemplate.getForObject(urlInscription, SapInvoiceKeyDto.class)).thenReturn(new SapInvoiceKeyDto("","",""));
        InvoicePageableResponse purchaseOrderInvoices = invoiceService.getPurchaseOrderInvoices(AGENCY_ID, ORDER_ID, 0, "baseEcheance", "asc", null);
        TestCase.assertEquals(1L, (long) purchaseOrderInvoices.getCount());
        TestCase.assertEquals("IN_DEPOSIT", purchaseOrderInvoices.getContent().get(0).getStatus());
    }


    @Test
    public void testGetgetPurchaseOrderInvoicesShoulmdReturnNull() {
        String urlInscription = MOCK_URL+"/supplier/supplierSapId/"+ORDER_ID;
        String url = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/" + AGENCY_ID + "/" + ORDER_ID;
        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(false);
        when(restTemplate.getForObject(urlInscription, SapInvoiceKeyDto.class)).thenReturn(new SapInvoiceKeyDto("","",""));
        InvoicePageableResponse purchaseOrderInvoices = invoiceService.getPurchaseOrderInvoices(AGENCY_ID, ORDER_ID, 0, "baseEcheance", "asc", null);
        TestCase.assertNull(purchaseOrderInvoices);
    }

    @Test
    public void getInvoiceEvents_unauthorized() {
        String url = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/"
                + AGENCY_ID + "/" + ORDER_ID;

        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(false);

        ResponseEntity<List<EventDto>> response = invoiceService.getInvoiceEvents(AGENCY_ID, INVOICE_ORACLE_ID, E_INVOICE_ID, ORDER_ID);
        TestCase.assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    public void getInvoiceEvents_caseEInvoiceIdAndInvoiceOracleIdNull() {
        String url = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/" + AGENCY_ID + "/" + ORDER_ID;

        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(true);

        ResponseEntity<List<EventDto>> response = invoiceService.getInvoiceEvents(AGENCY_ID, null, null, ORDER_ID);
        TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
        TestCase.assertEquals(0, Objects.requireNonNull(response.getBody()).size());
    }

    @Test
    public void getInvoiceEvents_einvoiceIdNull_invoiceOracleIdNotNull() {
        String url = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/" + AGENCY_ID + "/" + ORDER_ID;
        String oracleUrl = MOCK_URL + "/supplier/invoice-timeline?invoiceOracleId=" + INVOICE_ORACLE_ID;

        EventDto[] eventDtos = {
                EventDto.builder().eventCode("IN_PROCESS_OF_ACCOUNTING").build(),
                EventDto.builder().eventCode("IN_PROGRESS").build(),
                EventDto.builder().eventCode("APPROVED").build(),
        };

        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(true);
        when(restTemplate.getForObject(oracleUrl, EventDto[].class)).thenReturn(eventDtos);

        ResponseEntity<List<EventDto>> response = invoiceService.getInvoiceEvents(AGENCY_ID, INVOICE_ORACLE_ID, null, ORDER_ID);
        TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
        TestCase.assertEquals(3, Objects.requireNonNull(response.getBody()).size());
    }

    @Test
    public void getInvoiceEvents_einvoiceIdNotNull_invoiceOracleIdNull() throws ParseException {
        String checkUrl = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/" + AGENCY_ID + "/" + ORDER_ID;
        String eInvoiceEventsUrl = MOCK_URL + "/supplier/timeline?einvoiceId=" + E_INVOICE_ID + "&invoiceOracleId";
        String eInvoiceInvoiceUrl = MOCK_URL + "/supplier/invoices?einvoiceId=" + E_INVOICE_ID + "&invoiceOracleId";

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        EventDto[] eventDtos = {
                EventDto.builder().eventCode("IN.RECONC").eventDate(df.parse("2017-01-01")).build(),
                EventDto.builder().eventCode("IN.APP1").eventDate(df.parse("2017-04-01")).build(),
                EventDto.builder().eventCode("IN.APP1").eventDate(df.parse("2017-05-01")).build(),
                EventDto.builder().eventCode("UNPAID").eventDate(df.parse("2017-05-12")).build(),
                EventDto.builder().eventCode("CANCELLED").eventDate(df.parse("2017-05-13")).build(),
                EventDto.builder().eventCode("IN.ACCREJ").eventDate(df.parse("2017-05-13")).build(),
                EventDto.builder().eventCode("APPROVED").eventDate(df.parse("2017-06-01")).build(),
        };
        EInvoiceDto invoiceDto = EInvoiceDto.builder().invoiceNumber("inv1").amountHT(123456.).currency("DH").baseEcheance(df.parse("2017-06-31")).build();

        when(restTemplate.getForObject(checkUrl, Boolean.class)).thenReturn(true);
        when(restTemplate.getForObject(eInvoiceEventsUrl, EventDto[].class)).thenReturn(eventDtos);
        when(restTemplate.getForObject(eInvoiceInvoiceUrl, EInvoiceDto.class)).thenReturn(invoiceDto);

        ResponseEntity<List<EventDto>> response = invoiceService.getInvoiceEvents(AGENCY_ID, null, E_INVOICE_ID, ORDER_ID);
        TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
        TestCase.assertEquals(5, Objects.requireNonNull(response.getBody()).size());
    }

    @Test
    public void getInvoiceEvents_einvoiceIdNotNull_caseEmptyList_invoiceOracleIdNull() throws ParseException {
        String checkUrl = MOCK_URL + "/funding-request/agency-has-supplier-request-by-orderId/" + AGENCY_ID + "/" + ORDER_ID;
        String eInvoiceEventsUrl = MOCK_URL + "/supplier/timeline?einvoiceId=" + E_INVOICE_ID + "&invoiceOracleId";
        String eInvoiceInvoiceUrl = MOCK_URL + "/supplier/invoices?einvoiceId=" + E_INVOICE_ID + "&invoiceOracleId";

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        EInvoiceDto invoiceDto = EInvoiceDto.builder().invoiceNumber("inv1").amountHT(123456.).currency("DH").baseEcheance(df.parse("2017-06-31")).build();
        EventDto[] empty = {};

        when(restTemplate.getForObject(checkUrl, Boolean.class)).thenReturn(true);
        when(restTemplate.getForObject(eInvoiceEventsUrl, EventDto[].class)).thenReturn(empty);
        when(restTemplate.getForObject(eInvoiceInvoiceUrl, EInvoiceDto.class)).thenReturn(invoiceDto);

        ResponseEntity<List<EventDto>> response = invoiceService.getInvoiceEvents(AGENCY_ID, null, E_INVOICE_ID, ORDER_ID);
        TestCase.assertEquals(HttpStatus.OK, response.getStatusCode());
        TestCase.assertEquals(0, Objects.requireNonNull(response.getBody()).size());
    }


}
