package middleware.services;

import junit.framework.TestCase;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.CategorieDto;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class CategorieServiceTest {
    @InjectMocks
    private CategorieService categorieService;

    @Mock
    private RestTemplate restTemplate;
    @Mock
    private LotusServiceConfig lotusServiceConfig;

    @Before
    public void init() {
        when(lotusServiceConfig.getInscriptionURL()).thenReturn("http://inscriptionURL");
        when(restTemplate.getForObject("http://inscriptionURL/categories/category?code=220.220", CategorieDto.class)).thenReturn(CategorieDto.builder().build());
    }

    @Test
    public void testGetCategorieByCode(){
        CategorieDto categorieDto = categorieService.getCategorieByCode("220.220");
        TestCase.assertNotNull(categorieDto);
    }

}
