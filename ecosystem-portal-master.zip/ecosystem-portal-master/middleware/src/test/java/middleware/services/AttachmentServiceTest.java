package middleware.services;

import junit.framework.TestCase;
import middleware.conf.LotusServiceConfig;
import middleware.dto.AttachmentDto;
import middleware.dto.AttachmentFromOraclePageableResponse;
import middleware.dto.AttachmentPageableResponse;
import middleware.dto.sap.AttachmentSAPDto.SapAttachmentRequest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class AttachmentServiceTest{
    @InjectMocks
    private AttachmentService attachmentService;
    @Mock
    RestTemplate restTemplate;
    @Mock
    LotusServiceConfig lotusServiceConfig;

    @Mock
    private SapService sapService;


    @Test
    public void testGetSupplierApprovedAttachmentsByPurchaseOrder(){
        int agencyId = 55;
        String orderId = "s0254";
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://localhost:80");
        when(lotusServiceConfig.getAttachmentURL()).thenReturn("http://localhost:80");
        String url = "http://localhost:80/funding-request/agency-has-supplier-request-by-orderId/" + agencyId + "/" + orderId;
        when(restTemplate.getForObject(url, Boolean.class)).thenReturn(true);
        UriComponentsBuilder attachmentsUrl = UriComponentsBuilder.fromHttpUrl("http://localhost:80/attachments/approved-by-order/" + orderId);
        attachmentsUrl.queryParam("page", 0);
        attachmentsUrl.queryParam("sortBy", "updatedDate");
        attachmentsUrl.queryParam("order", "asc".toUpperCase());
        when(restTemplate.getForObject(attachmentsUrl.build().toUriString(), AttachmentPageableResponse.class)).thenReturn(
                new AttachmentPageableResponse(null, 10L)
        );
        AttachmentPageableResponse  attachmentPageableResponse = attachmentService.getSupplierApprovedAttachmentsByPurchaseOrder(agencyId, orderId, 0, "updatedDate", "asc");
        TestCase.assertNotNull(attachmentPageableResponse);
        TestCase.assertEquals(10L, (long)attachmentPageableResponse.getCount());

    }

    @Test
    public void testGetAttachmentsfromSAPbyRefCmdAppelList_singleOrder() {
        String orderId = "s0254";
        String requestSource = "s";
        List<String> refCmdAppelList = Collections.emptyList(); // Empty list for single element case
        SapAttachmentRequest sapAttachmentRequest = new SapAttachmentRequest();
        sapAttachmentRequest.setPonumber(orderId);

        when(sapService.getFromSapAttachment(anyString())).thenReturn(getMockedAttachments());

        AttachmentFromOraclePageableResponse response = attachmentService.getAttachmentsfromSAPbyRefCmdAppelList(orderId, refCmdAppelList, requestSource);

        assertNotNull(response);
        assertEquals(2, response.getContent().size());
    }

    @Test
    public void testGetAttachmentsfromSAPbyRefCmdAppelList_multipleOrders() {
        String orderId = "s0254";
        String requestSource = "s";
        List<String> refCmdAppelList = Arrays.asList("ref1", "ref2");

        when(sapService.getFromSapAttachment(anyString())).thenReturn(getMockedAttachments());

        AttachmentFromOraclePageableResponse response = attachmentService.getAttachmentsfromSAPbyRefCmdAppelList(orderId, refCmdAppelList, requestSource);

        assertNotNull(response);
        assertEquals(2, response.getContent().size());
    }

    @Test(expected = NullPointerException.class)
    public void testGetAttachmentsfromSAPbyRefCmdAppelList_exception() {
        // Pass an invalid argument to trigger an exception
        String requestSource = "s";
        attachmentService.getAttachmentsfromSAPbyRefCmdAppelList("invalid", null, requestSource);
    }

    // Helper method to mock attachments
    private List<AttachmentDto> getMockedAttachments() {
        AttachmentDto attachment1 = new AttachmentDto("ref1", "cmd1", "APPROVED", LocalDate.now(), 1000.0, "USD", "TYPE1", 123L);
        AttachmentDto attachment2 = new AttachmentDto("ref2", "cmd2", "APPROVED", LocalDate.now(), 2000.0, "USD", "TYPE2", 456L);
        return new ArrayList<>(Arrays.asList(attachment1, attachment2));
    }


    @Test(expected = IllegalArgumentException.class)
    public void testGetSupplierApprovedAttachmentsByPurchaseOrder_exception(){
       attachmentService.getSupplierApprovedAttachmentsByPurchaseOrder(55, "s545", 0, "updatedDate", "wrongOrder");
    }
}