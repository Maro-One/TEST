package middleware.services;

import junit.framework.TestCase;
import middleware.entities.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class TokenServiceTest {
    @InjectMocks
    private TokenService tokenService;

    @Before
    public void init(){
        ReflectionTestUtils.setField(tokenService, "secret", "secret");
        ReflectionTestUtils.setField(tokenService, "expiration", 1000000);
    }

    @Test
    public void testGetToken(){
        Map<String, Object> userData = new HashMap<>();
        userData.put("user","user");
        TestCase.assertNotNull(tokenService.getToken(userData));
    }

    @Test
    public void testGetBody(){
        Map<String, Object> userData = new HashMap<>();
        User user = User.builder().active(true).agencyId(1).build();
        userData.put("user",user);
        String token = tokenService.getToken(userData);
        TestCase.assertNotNull(token);
        TestCase.assertNotNull(tokenService.getBody(token));
    }
    @Test
    public void testGetExpiration(){
        Map<String, Object> userData = new HashMap<>();
        User user = User.builder().active(true).agencyId(1).build();
        userData.put("user",user);
        String token = tokenService.getToken(userData);
        Instant instant = tokenService.getExpirationInstant(token);
        TestCase.assertNotNull(instant);
        TestCase.assertTrue(instant.getEpochSecond() > 0);
    }
    @Test
    public void testGetUserName(){
        Map<String, Object> userData = new HashMap<>();
        User user = User.builder().active(true).agencyId(1).login("login").build();
        userData.put("user",user);
        String login = tokenService.getUsername(tokenService.getToken(userData));
        TestCase.assertEquals("login", login);
    }
}
