package middleware.services;


import com.opencsv.exceptions.CsvValidationException;
import junit.framework.TestCase;
import middleware.conf.LotusServiceConfig;
import middleware.entities.User;
import middleware.exception.ParseUsersCSVFileException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
    @InjectMocks
    private UserService userService;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private LotusServiceConfig lotusServiceConfig;
    @Mock
    private TokenService tokenService;
    @Mock
    private EmailService emailService;
    @Mock
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Test
    public void testFindByUsername() {
        Map<String, String> query = new HashMap<>();
        query.put("login", "login");
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://EcosystemUrl.ma");
        when(restTemplate.getForObject("http://EcosystemUrl.ma/funding-agency-account/active-account?login={login}", User.class, query)).thenReturn(
                new User()
        );
        TestCase.assertNotNull(userService.findByUsername("login"));
    }

    @Test
    public void testFindByUsername_throwsHttpClientErrorException() {
        Map<String, String> query = new HashMap<>();
        query.put("login", "login");
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://EcosystemUrl.ma");
        when(restTemplate.getForObject("http://EcosystemUrl.ma/funding-agency-account/active-account?login={login}", User.class, query))
                .thenThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR));
        TestCase.assertNull(userService.findByUsername("login"));
    }

    @Test
    public void testUpdateUserPassword() {
        UserService userServiceSpied = spy(userService);
        User user = new User();
        User user2 = User.builder()
                .password("passwordEncoded")
                .active(true)
                .attempts(0)
                .build();
        when(bCryptPasswordEncoder.encode("password")).thenReturn("passwordEncoded");
        when(userServiceSpied.update(user2)).thenReturn(user2);
        reset(userServiceSpied);
        userServiceSpied.updateUserPassword(user, "password");
        verify(userServiceSpied).update(user2);
    }

    @Test
    public void testUpdate() {
        User user = new User();
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://EcosystemUrl.ma");
        when(restTemplate.postForObject("http://EcosystemUrl.ma/funding-agency-account/update-account", user, User.class))
                .thenReturn(user);
        TestCase.assertNotNull(userService.update(user));
    }

    @Test
    public void testIsLockExpired() {
        ReflectionTestUtils.setField(userService, "lockDuration", 0);
        User user = User.builder()
                .lastAttempt(new Date())
                .build();

        // case last attempt not null
        TestCase.assertTrue(userService.isLockExpired(user));

        // else
        TestCase.assertFalse(userService.isLockExpired(User.builder().build()));
    }

    @Test
    public void testIsBlocked() {
        ReflectionTestUtils.setField(userService, "maxAttemps", 10);
        ReflectionTestUtils.setField(userService, "lockDuration", 100);

        // case user not null & attempts > max attempts && last attempt not null
        TestCase.assertTrue(userService.isBlocked(User.builder()
                .attempts(11)
                .lastAttempt(new Date())
                .build()));

        // case user not null & attempts < max attempts && last attempt null
        TestCase.assertFalse(userService.isBlocked(
                User.builder()
                        .attempts(5)
                        .build()));

        // case user null
        TestCase.assertTrue(userService.isBlocked(null));
    }

    @Test
    public void testCreateUser() {
        User user = new User();
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://ecosys");
        when(restTemplate.postForObject("http://ecosys/funding-agency-account/create-account", user, User.class))
                .thenReturn(user).thenThrow(new RuntimeException());
        TestCase.assertNotNull(userService.createUser(user));
        TestCase.assertNull(userService.createUser(user));
    }

    @Test
    public void testNotifyUser() throws MessagingException {
        ReflectionTestUtils.setField(userService, "linkResetPasswordHost", "linkResetPasswordHost");
        ReflectionTestUtils.setField(userService, "linkResetPasswordPath", "/linkResetPasswordPath/");
        Map<String, Object> forMail = new HashMap<>();
        forMail.put("login", "login");
        forMail.put("allLink", "linkResetPasswordHost/linkResetPasswordPath/token");
        forMail.put("shortLink", "linkResetPasswordHost/linkResetPasswordPath/");
        when(tokenService.getToken(any())).thenReturn("token");
        userService.notifyUser("a@g.c", "login");
        verify(emailService, times(1)).sendEmail(
                "a@g.c",
                "Compléter votre inscription",
                "reset_password_first",
                forMail,
                null,
                null);
    }

    @Test(expected = ParseUsersCSVFileException.class)
    public void parseUsersFile_lineLengthDoesNotEqual6Exception() throws CsvValidationException, IOException, ParseUsersCSVFileException {
        String sb = "login,email,firstName,lastName,agencyId,roleId\n" +
                "test\n";
        MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv", sb.getBytes());
        userService.parseUsersFile(file);
    }

    @Test(expected = ParseUsersCSVFileException.class)
    public void parseUsersFile_lineEmailAndNumberNotValid() throws CsvValidationException, IOException, ParseUsersCSVFileException {
        String sb = "login,email,firstName,lastName,agencyId,roleId\n" +
                "test,test@gmail.com,test,test,af1,1\n";
        MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv", sb.getBytes());
        userService.parseUsersFile(file);
    }

    @Test
    public void parseUsersFile_ioExceptionWhileReadingCsvFile() throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("login,email,firstName,lastName,agencyId,roleId\n");
        sb.append("test1,test1@test.com,test1,test1,1,1\n");
        sb.append("test2,test2@test.com,test2,test2,1,1\n");
        sb.append("test3,test3@test.com,test3,test3,1,1\n");
        MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv", sb.toString().getBytes());
        try {
            List<User> users = userService.parseUsersFile(file);
            TestCase.assertEquals(3, users.size());
            TestCase.assertEquals("test1", users.get(0).getLogin());
            TestCase.assertEquals("test2", users.get(1).getLogin());
            TestCase.assertEquals("test3", users.get(2).getLogin());
        } catch (Exception e) {
            TestCase.assertEquals("Not validate Email test, Not validate values af1, should be a numbers", e.getMessage());
        }
    }
}
