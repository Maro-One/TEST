package middleware.services;

import junit.framework.TestCase;
import middleware.conf.LotusServiceConfig;
import middleware.entities.Captcha;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class CaptchaServiceTest {
    @InjectMocks
    private CaptchaService captchaService;

    @Mock
    private LotusServiceConfig lotusServiceConfig;
    @Mock
    private RestTemplate restTemplate;
    @Before
    public void init() {
        when(lotusServiceConfig.getCaptchaURL()).thenReturn("http://captchaurl");
    }
    @Test
    public void generate(){
        when(restTemplate.getForObject("http://captchaurl/captcha", Captcha.class))
                .thenReturn(new Captcha());
        TestCase.assertNotNull(captchaService.generateCaptcha());
    }
    @Test
    public void isValidCaptcha(){
        String entryCode = "entryCode";
        String captchaValue =  "captchaValue";
        Captcha captcha = new Captcha();
        captcha.setCaptchaValue(captchaValue);
        captcha.setEntryCode(entryCode);
        when(restTemplate.postForObject("http://captchaurl/captcha",captcha, Boolean.class))
                .thenReturn(true);
        TestCase.assertTrue(captchaService.isValidCaptcha(entryCode, captchaValue));
    }
}
