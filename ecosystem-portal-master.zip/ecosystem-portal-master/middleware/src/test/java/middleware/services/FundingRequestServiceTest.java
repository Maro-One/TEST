package middleware.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.TestCase;
import middleware.conf.BackendConfig;
import middleware.conf.LotusServiceConfig;
import middleware.dto.*;
import middleware.dto.sap.ContractsRequest;
import middleware.dto.sap.ImportPurchaseOrdersResponseSAP;
import middleware.dto.sap.SapContratRequest;
import middleware.utils.SapResponseWrapper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.mail.MessagingException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class FundingRequestServiceTest {
    @InjectMocks
    private FundingRequestService fundingRequestService;


    @Mock
    private RestTemplate restTemplate;
    @Mock
    private BackendConfig backendConfig;
    @Mock
    private LotusServiceConfig lotusServiceConfig;
    @Mock
    private EmailService emailService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private SapService sapService;



    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        //when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://ecosystemurl");
        //when(backendConfig.getBravoURL()).thenReturn("http://bravorl");
       // when(backendConfig.getOracleEbsURL()).thenReturn("http://attachmenturl");
        when(backendConfig.getBackEndGateWayUrl()).thenReturn("http://coordinator");
        when(lotusServiceConfig.getInscriptionURL()).thenReturn("http://inscriptionurl");
        when(lotusServiceConfig.getCoordinatorURL()).thenReturn("http://coordinatorURL");
        // Configurer les URLs de mock
        when(backendConfig.getBravoURL()).thenReturn("http://mocked-backend-url");
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://mocked-lotus-url");



    }


    @Test
    public void getPaginatedFundingRequestsApplicants_withRoleAgency() {
        String role = "ROLE_AGENCY";
        int page = 1;

        // Mock the first REST call for getForObject (ensure any URL matches)
        Map<Long, Long> content = new HashMap<>();
        content.put(1L, 2L);
        MapPageableResponse countResult = MapPageableResponse.builder()
                .count(1L)
                .content(content)
                .build();

        when(restTemplate.getForObject(anyString(), eq(MapPageableResponse.class)))
                .thenReturn(countResult);

        // Mock the second REST call with RestTemplate.exchange (ensure matching request)
        HttpEntity<Object> requestEntity = new HttpEntity<>(content.keySet());
        Map<String, Integer> params = new HashMap<>();
        params.put("page", page);

        List<FundingRequestApplicantDto> fundingRequestApplicantDtos = new ArrayList<>();
        fundingRequestApplicantDtos.add(FundingRequestApplicantDto.builder()
                .supplierBravoId(1L)
                .build());

        ResponseEntity<List<FundingRequestApplicantDto>> response = new ResponseEntity<>(fundingRequestApplicantDtos, HttpStatus.OK);

        // Mock RestTemplate.exchange (match any URL and parameters)
        when(restTemplate.exchange(
                anyString(), // Match any URL
                eq(HttpMethod.POST), // HTTP method
                eq(requestEntity), // Request entity
                any(ParameterizedTypeReference.class), // Response type
                eq(params))) // Params
                .thenReturn(response);

        // Call the actual method
        ApplicantPageableResponse applicantPageableResponse = fundingRequestService.getPaginatedFundingRequestsApplicants(role, page, 1);

        // Verify and assert results
        TestCase.assertEquals(1L, applicantPageableResponse.getCount().longValue());
        TestCase.assertEquals(1, applicantPageableResponse.getContent().size());
    }





    /*@Test
    public void getPaginatedFundingRequestsApplicants_withRoleAgency() {
        // Setup test data
        String role = "ROLE_AGENCY";
        int page = 1;
        String url = "http://ecosystemurl/funding-request/approved-funding-applicants-count-pageable/1";

        // Mocking the URL creation and response for the agency role
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("page", page);

        Map<Long, Long> content = new HashMap<>();
        content.put(1L, 2L); // Mock some content (supplierId -> request count)

        MapPageableResponse mockCountResult = MapPageableResponse.builder()
                .count(1L)
                .content(content)
                .build();

        // Stubbing the getForObject call
        when(restTemplate.getForObject(fundingRequestsUrl.build().toUriString(), MapPageableResponse.class))
                .thenReturn(mockCountResult);

        // Mocking the exchange call for supplier profiles
        HttpEntity<Object> requestEntity = new HttpEntity<>(content.keySet());
        List<FundingRequestApplicantDto> mockApplicants = new ArrayList<>();
        mockApplicants.add(FundingRequestApplicantDto.builder()
                .supplierBravoId(1L)
                .build());

        ResponseEntity<List<FundingRequestApplicantDto>> mockResponse = new ResponseEntity<>(mockApplicants, HttpStatus.OK);

        // Stubbing the exchange call for supplier profiles by supplier IDs
        when(restTemplate.exchange(
                "http://bravorl/supplier/profilesBySupplierIds?page=0",
                HttpMethod.POST,
                requestEntity,
                new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                }, new HashMap<>()))
                .thenReturn(mockResponse);

        // Call the actual method being tested
        ApplicantPageableResponse actualResponse = fundingRequestService.getPaginatedFundingRequestsApplicants(role, page, 1);

        // Assertions to validate the response
        assertEquals(1L, actualResponse.getCount().longValue());
        assertEquals(1, actualResponse.getContent().size());
        assertEquals(1L, actualResponse.getContent().get(0).getSupplierBravoId().longValue());

        // Verify the calls to restTemplate
        verify(restTemplate).getForObject(fundingRequestsUrl.build().toUriString(), MapPageableResponse.class);
        verify(restTemplate).exchange(
                "http://bravorl/supplier/profilesBySupplierIds?page=0",
                HttpMethod.POST,
                requestEntity,
                new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                }, new HashMap<>()
        );
    }*/

   /* @Test
    public void getPaginatedFundingRequestsApplicants_withRoleAgency() {
        String role = "ROLE_AGENCY";
        int page = 1;
        String url = "http://ecosystemurl/funding-request/approved-funding-applicants-count-pageable/1";
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder.fromHttpUrl(url);
        fundingRequestsUrl.queryParam("page", page);
        Map<Long, Long> content = new HashMap<>();
        content.put(1L, 2L);
        MapPageableResponse countResult = MapPageableResponse.builder()
                .count(1L)
                .content(content)
                .build();
        when(restTemplate.getForObject(fundingRequestsUrl.build().toUriString(), MapPageableResponse.class))
                .thenReturn(countResult);
        HttpEntity<Object> requestEntity = new HttpEntity<>(content.keySet());
        Map<String, Integer> params = new HashMap<>();
        params.put("page", page);
        List<FundingRequestApplicantDto> fundingRequestApplicantDtos = new ArrayList<>();
        fundingRequestApplicantDtos.add(FundingRequestApplicantDto.builder()
                .supplierBravoId(1L)
                .build());
        ResponseEntity<List<FundingRequestApplicantDto>> response = new ResponseEntity<>(fundingRequestApplicantDtos, HttpStatus.OK);
        when(restTemplate.
                exchange("http://bravorl/supplier/profilesBySupplierIds?page=0", HttpMethod.POST, requestEntity,
                        new ParameterizedTypeReference<List<FundingRequestApplicantDto>>() {
                        }, params))
                .thenReturn(response);
        ApplicantPageableResponse applicantPageableResponse = fundingRequestService.getPaginatedFundingRequestsApplicants(role, page, 1);
        TestCase.assertEquals(1L, applicantPageableResponse.getCount().longValue());
        TestCase.assertEquals(1L, applicantPageableResponse.getContent().size());
    }*/

    @Test
    public void test_getPaginatedFundingRequestsApplicants_withOtherRole_contentEmpty() {
        // Arrange
        String role = "ROLE_TEST";
        int page = 0;

        // Mock the URL
        String expectedUrl = "http://ecosystemurl/funding-request/all-applicants-count-pageable?page=0";

        // Mock the ecosystem URL returned by the config class
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://ecosystemurl/");

        // Mock the response from getForObject
        MapPageableResponse mockResponse = MapPageableResponse.builder()
                .content(new HashMap<>()) // No content
                .count(0L) // Count is zero
                .build();

        when(restTemplate.getForObject(expectedUrl, MapPageableResponse.class))
                .thenReturn(mockResponse);

        // Act
        ApplicantPageableResponse actualResponse = fundingRequestService.getPaginatedFundingRequestsApplicants(role, page, null);

        // Assert
        assertEquals(0L, actualResponse.getCount().longValue());
        assertEquals(Collections.EMPTY_LIST, actualResponse.getContent());

        // Verify the restTemplate call
        verify(restTemplate).getForObject(expectedUrl, MapPageableResponse.class);
    }

    @Test
    public void getFundingRequestsForSupplierByStatus() {
        String role = "ROLE_AGENCY";
        int page = 0;
        int agencyId = 1;
        long bravoId = 1L;

        // Mock the URL for the getForObject() call (use anyString() to avoid strict matching)
        List<FundingRequestDto> content = new ArrayList<>();
        content.add(FundingRequestDto.builder().purchaseOrderId("1").billedAmount(20.).source("").build());
        RequestPageableResponse requestsResponse = RequestPageableResponse.builder()
                .count(1L)
                .content(content)
                .build();

        // Mocking restTemplate.getForObject() with any URL and response type
        when(restTemplate.getForObject(anyString(), eq(RequestPageableResponse.class)))
                .thenReturn(requestsResponse);

        // Mock the second REST call for restTemplate.exchange()
        List<String> ordersList = new ArrayList<>();
        ordersList.add("1");
        HttpEntity<List<String>> requestEntity = new HttpEntity<>(ordersList);
        String purchaseOrderDetailUrl = "http://coordinator/purchase-orders/purchase-details";
        FundingRequestDto[] fundingRequestDtos = new FundingRequestDto[1];
        fundingRequestDtos[0] = FundingRequestDto.builder().purchaseOrderId("1").billedAmount(20.).build();
        ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = new ResponseEntity<>(fundingRequestDtos, HttpStatus.OK);

        // Mocking restTemplate.exchange()
        when(restTemplate.exchange(eq(purchaseOrderDetailUrl), eq(HttpMethod.POST),
                eq(requestEntity), eq(FundingRequestDto[].class)))
                .thenReturn(oracleDetailsResponse);

        // Call the method being tested
        RequestPageableResponse requestPageableResponse = fundingRequestService
                .getFundingRequestsForSupplierByStatus(role, agencyId, bravoId, page, null);

        // Assertions
        TestCase.assertEquals(1L, requestPageableResponse.getCount().longValue());
        TestCase.assertEquals(1, requestPageableResponse.getContent().size());
    }




    /*@Test
    public void getFundingRequestsForSupplierByStatus() {
        String role = "ROLE_AGENCY";
        int page = 0;
        int agencyId = 1;
        long bravoId = 1L;

        String url = "http://ecosystemurl/funding-request/approved-applicant-funding-requests/" + agencyId + "/" + bravoId;
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder.fromHttpUrl(url);
        fundingRequestsUrl.queryParam("page", page);
        List<FundingRequestDto> content = new ArrayList<>();
        content.add(FundingRequestDto.builder().purchaseOrderId("1").billedAmount(20.).source("").build());
        RequestPageableResponse requestsResponse = RequestPageableResponse.builder()
                .count(1L)
                .content(content)
                .build();
        when(restTemplate.getForObject(fundingRequestsUrl.build().toUriString(),
                RequestPageableResponse.class))
                .thenReturn(requestsResponse);
        List<String> ordersList = new ArrayList<>();
        ordersList.add("1");
        HttpEntity<List<String>> requestEntity = new HttpEntity<>(ordersList);
        String purchaseOrderDetailUrl = "http://coordinator/purchase-orders/purchase-details";
        FundingRequestDto[] fundingRequestDtos = new FundingRequestDto[1];
        fundingRequestDtos[0] = FundingRequestDto.builder().purchaseOrderId("1").billedAmount(20.).build();
        ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = new ResponseEntity<>(fundingRequestDtos, HttpStatus.OK);
        when(restTemplate.exchange(purchaseOrderDetailUrl, HttpMethod.POST,
                requestEntity, FundingRequestDto[].class)).thenReturn(oracleDetailsResponse);
        RequestPageableResponse requestPageableResponse = fundingRequestService.getFundingRequestsForSupplierByStatus(role, agencyId, bravoId, page, null);
        TestCase.assertEquals(1, requestPageableResponse.getCount().longValue());
        TestCase.assertEquals(1, requestPageableResponse.getContent().size());
    } */

    /*
    @Test
    public void getFundingRequestsForSupplierByStatus_withOtherRole() {
        String url = "http://ecosystemurl/funding-request/supplier-funding-requests-all?page=0";
        FundingRequestDto fundingRequestDto = FundingRequestDto.builder().purchaseOrderId("s10").purchaseOrderAmount(20.).billedAmount(10.).source("").build();
        List<FundingRequestDto> content = Collections.singletonList(fundingRequestDto);
        RequestPageableResponse requestPageableResponse = RequestPageableResponse.builder().content(content).count(1L).build();
        FundingRequestDto[] orderList = {fundingRequestDto};

        when(restTemplate.getForObject(url, RequestPageableResponse.class)).thenReturn(requestPageableResponse);
        when(restTemplate.exchange(
                "http://coordinator/purchase-orders/purchase-details",
                HttpMethod.POST,
                new HttpEntity<>(Collections.singletonList("s10")),
                FundingRequestDto[].class))
                .thenReturn(new ResponseEntity<>(orderList, HttpStatus.OK));

        RequestPageableResponse actual = fundingRequestService.getFundingRequestsForSupplierByStatus("ROLE_TEST", null, 12L, 0, null);

        TestCase.assertEquals(1L, actual.getCount().longValue());
        TestCase.assertEquals(1, actual.getContent().size());
        TestCase.assertEquals(0.5, actual.getContent().get(0).getAchievementPercentage());
    }*/

    @Test
    public void getFundingRequestsForSupplierByStatus_withRoleAgency() {
        // Mock the base URL
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://ecosystemurl");

        // Define the expected URL for getForObject
        String fundingRequestsUrl = "http://ecosystemurl/funding-request/approved-applicant-funding-requests/1/12?page=0";

        // Define mock data for the funding request
        FundingRequestDto fundingRequestDto = FundingRequestDto.builder()
                .purchaseOrderId("o123")
                .source("SAP")
                .build();
        List<FundingRequestDto> content = Collections.singletonList(fundingRequestDto);
        RequestPageableResponse requestPageableResponse = RequestPageableResponse.builder()
                .content(content)
                .count(1L)
                .build();

        // Define the URL for the exchange call
        String purchaseOrderDetailUrl = "http://backend/purchase-orders/purchase-detailsWithOutPercentage";

        // Define mock response for the exchange call
        FundingRequestDto[] oracleOrderList = {fundingRequestDto};
        ResponseEntity<FundingRequestDto[]> responseEntity = new ResponseEntity<>(oracleOrderList, HttpStatus.OK);

        // Mock the responses
        when(restTemplate.getForObject(fundingRequestsUrl, RequestPageableResponse.class)).thenReturn(requestPageableResponse);
        /*when(restTemplate.exchange(
                eq(purchaseOrderDetailUrl),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(FundingRequestDto[].class)))
                .thenReturn(responseEntity);*/

        // Call the method
        RequestPageableResponse actual = fundingRequestService.getFundingRequestsForSupplierByStatusWithOutPercentage("ROLE_AGENCY", 1, 12L, 0, null);

        // Verify the results
        TestCase.assertEquals(1L, actual.getCount().longValue());
        TestCase.assertEquals(1, actual.getContent().size());
        TestCase.assertEquals("o123", actual.getContent().get(0).getPurchaseOrderId());
    }






   /* @Test
    public void getFundingRequestDetail() {
        Integer agencyId = 1;
        String orderId = "1";
        Integer requestId = 1;
        String fundingRequestUrl = "http://ecosystemurl/funding-request/funding-request-detail/" + requestId;
        FundingRequestDto fundingRequestDetailDto = FundingRequestDto.builder()
                .status("APPROVED")
                .fundingAgencyId(agencyId)
                .billedAmount(10.0)
                .purchaseOrderAmount(155.0)
                .source("")
                .build();
        when(restTemplate.getForObject(fundingRequestUrl, FundingRequestDto.class))
                .thenReturn(fundingRequestDetailDto);
        HttpEntity<Long> requestEntity = new HttpEntity<>(Long.parseLong(orderId));
        Map<String, Double> apprAmount = new HashMap<>();
        ResponseEntity<Double> attachmentResponse = new ResponseEntity<>(1000.0, HttpStatus.OK);
        when(restTemplate.
                exchange("http://attachmenturl/attachments/approved-amount",
                        HttpMethod.POST, requestEntity,
                        new ParameterizedTypeReference<Double>() {
                        }))
                .thenReturn(attachmentResponse);
        FundingRequestService fundingRequestService1 = Mockito.spy(fundingRequestService);
        Mockito.doReturn(FundingRequestDto.builder()
                .billedAmount(100.2)
                .purchaseOrderAmount(47.2).build()).when(fundingRequestService1).getOracleOrderDetailsById(orderId);
        FundingRequestDto resp = fundingRequestService1.getFundingRequestDetail(agencyId, orderId, requestId);
        TestCase.assertEquals(1000.0, resp.getApprovalAttachmentAmount());
    }*/

    @Test
    public void getFundingRequestDetail_null() {
        Integer agencyId = 1;
        String orderId = "1";
        Integer requestId = 1;
        String fundingRequestUrl = "http://ecosystemurl/funding-request/funding-request-detail/" + requestId;

        //when(restTemplate.getForObject(fundingRequestUrl, FundingRequestDto.class)).thenReturn(null);

        FundingRequestDto actual = fundingRequestService.getFundingRequestDetail(agencyId, orderId, requestId);

        TestCase.assertNull(actual);
    }

    @Test
    public void getFundingRequestDetail_restClientException() {
        Integer agencyId = 1;
        String orderId = "1";
        Integer requestId = 1;
        String fundingRequestUrl = "http://ecosystemurl/funding-request/funding-request-detail/" + requestId;

       // when(restTemplate.getForObject(fundingRequestUrl, FundingRequestDto.class)).thenThrow(new RestClientException("500 TEST"));

        FundingRequestDto actual = fundingRequestService.getFundingRequestDetail(agencyId, orderId, requestId);

        TestCase.assertNull(actual);
    }

    @Test
    public void getSupplierFundingRequestsByStatus() {
        // Mock the lotusServiceConfig to return a valid URL
        when(lotusServiceConfig.getEcosystemUrl()).thenReturn("http://ecosystemurl");

        // Create the expected response
        RequestPageableResponse fundingRequestDetailDto = RequestPageableResponse.builder().build();

        // Mock the REST call to return the expected response
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder
                .fromHttpUrl("http://ecosystemurl/funding-request/funding-requests-by-supplier/1");
        fundingRequestsUrl.queryParam("page", 0);
        fundingRequestsUrl.queryParam("status", "APPROVED");

        when(restTemplate.getForObject(fundingRequestsUrl.build().toUriString(), RequestPageableResponse.class))
                .thenReturn(fundingRequestDetailDto);

        // Call the method under test
        RequestPageableResponse result = fundingRequestService.getSupplierFundingRequestsByStatus(1L, "APPROVED", 0);

        // Validate the response
        assertEquals(fundingRequestDetailDto, result);

        // Verify that the restTemplate.getForObject was called with the correct URL
        verify(restTemplate).getForObject(fundingRequestsUrl.build().toUriString(), RequestPageableResponse.class);
    }



    @Test
    public void updateFundingRequest_successful() {
        // Mock the URL creation
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder
                .fromHttpUrl("http://ecosystemurl/funding-request/1")
                .queryParam("agencyId", 1);

        // Mocking the RestTemplate exchange call with a successful response
        ResponseEntity<FundingRequestDto> mockResponse = new ResponseEntity<>(
                FundingRequestDto.builder().build(), HttpStatus.OK);

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.PUT),
                eq(null),
                eq(FundingRequestDto.class))
        ).thenReturn(mockResponse);

        // Running the test
        FundingRequestDto result = fundingRequestService.updateFundingRequest(1, 1);
        assertNotNull(result); // Ensure the result is not null
    }

    @Test
    public void updateFundingRequest_withException() {
        // Simulating an exception thrown by RestTemplate
        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.PUT),
                eq(null),
                eq(FundingRequestDto.class))
        ).thenThrow(new RuntimeException("Exception occurred"));

        // Running the test, expecting the method to return null
        FundingRequestDto result = fundingRequestService.updateFundingRequest(1, 1);
        assertNull(result); // Ensure result is null
    }

    /*
    @Test
    public void updateFundingRequest_withException() {
        TestCase.assertNull(fundingRequestService.updateFundingRequest(1, 1));
    } */

    @Test
    public void refuseFundingRequest() throws MessagingException {
        // Mocking the URL creation
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder
                .fromHttpUrl("http://ecosystemurl/funding-request/refuse/1")
                .queryParam("comment", "comment")
                .queryParam("agencyId", "1");

        // Mocking the response from RestTemplate
        ResponseEntity<FundingRequestDto> mockResponse = new ResponseEntity<>(
                FundingRequestDto.builder()
                        .purchaseOrderDescription("PurchaseOrderDescription")
                        .build(), HttpStatus.OK);

        when(restTemplate.exchange(
                anyString(), // using anyString() for URL matching
                eq(HttpMethod.PUT),
                eq(null),
                eq(FundingRequestDto.class))
        ).thenReturn(mockResponse);

        // Mocking the email service call
        Map<String, Object> forMail = new HashMap<>();
        forMail.put("comment", "comment");
        forMail.put("purchaseOrderDescription", "PurchaseOrderDescription");

        doNothing().when(emailService).sendEmail(
                eq("a@g.c"),
                eq("Refus de la demande de financement"),
                eq("funding_request_rejection"),
                eq(forMail),
                eq(null),
                eq(null)
        );

        // Running the test
        FundingRequestDto result = fundingRequestService.refuseFundingRequest(1, "comment", "a@g.c", 1);
        assertNotNull(result); // Ensure result is not null

        // Verifying email service was called
        verify(emailService).sendEmail(
                "a@g.c",
                "Refus de la demande de financement",
                "funding_request_rejection",
                forMail,
                null,
                null
        );
    }

    /*@Test
    public void refuseFundingRequest() throws MessagingException {
        UriComponentsBuilder fundingRequestsUrl = UriComponentsBuilder.fromHttpUrl("http://ecosystemurl/funding-request/refuse/1");
        fundingRequestsUrl.queryParam("comment", "comment");
        fundingRequestsUrl.queryParam("agencyId", "1");
        ResponseEntity<FundingRequestDto> result = new ResponseEntity<>(FundingRequestDto.builder().purchaseOrderDescription("PurchaseOrderDescription").build(), HttpStatus.OK);
        when(restTemplate.exchange(fundingRequestsUrl.build().toUriString(), HttpMethod.PUT, null,
                FundingRequestDto.class))
                .thenReturn(result);
        Map<String, Object> forMail = new HashMap<>();
        forMail.put("comment", "comment");
        forMail.put("purchaseOrderDescription", "PurchaseOrderDescription");

        doNothing().when(emailService).sendEmail(
                "a@g.c",
                "Refus de la demande de financement",
                "funding_request_rejection",
                forMail,
                null,
                null
        );
        TestCase.assertNotNull(fundingRequestService.refuseFundingRequest(1, "comment","a@g.c",1));
        verify(emailService).sendEmail(
                "a@g.c",
                "Refus de la demande de financement",
                "funding_request_rejection",
                forMail,
                null,
                null
        );
    }*/

    @Test
    public void refuseFundingRequest_withException() {
        TestCase.assertNull(fundingRequestService.refuseFundingRequest(1, "comment","a@g.c",1));
    }
    /*@Test
    public void getOracleOrderDetailsById() {
        FundingRequestDto[] fundingRequestDtos = new FundingRequestDto[]{FundingRequestDto.builder().id(10).build()};
        ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = new ResponseEntity<>(fundingRequestDtos, HttpStatus.OK);
        when(restTemplate.exchange("http://coordinator/purchase-orders/purchase-details", HttpMethod.POST,
                new HttpEntity<>(Collections.singletonList("1")), FundingRequestDto[].class))
                .thenReturn(oracleDetailsResponse);
        FundingRequestDto resp = fundingRequestService.getOracleOrderDetailsById("1");
        TestCase.assertEquals(10, resp.getId().intValue());
    }
    */
    @Test
    public void getOracleOrderDetailsById_emptyList() {
        FundingRequestDto[] fundingRequestDtos = {};
        ResponseEntity<FundingRequestDto[]> oracleDetailsResponse = new ResponseEntity<>(fundingRequestDtos, HttpStatus.OK);

        when(restTemplate.exchange("http://coordinator/purchase-orders/purchase-details", HttpMethod.POST,
                new HttpEntity<>(Collections.singletonList("1")), FundingRequestDto[].class))
                .thenReturn(oracleDetailsResponse);

        TestCase.assertNull(fundingRequestService.getOracleOrderDetailsById("1"));
    }

    @Test
    public void getOracleOrderDetailsByReferenceAndOperationUnit() {
        FundingRequestDto purchaseOrderDetails = FundingRequestDto.builder().id(12).build();
        when(restTemplate.getForObject(
                "http://coordinator/purchase-orders/purchase-details-by-reference/reference/operationUnit",
                FundingRequestDto.class))
                .thenReturn(purchaseOrderDetails);
        TestCase.assertEquals(12, fundingRequestService.getOracleOrderDetailsByReferenceAndOperationUnit("reference", "operationUnit").getId().intValue());
    }



    @Test
    public void testImportPurchaseOrdersSAP_success() throws IOException {
        // Create an in-memory Excel file
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Purchase Orders");

        // Create header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("CommandeID");
        headerRow.createCell(1).setCellValue("ContractID");
        headerRow.createCell(2).setCellValue("agencyID");

        // Create data rows
        Row dataRow1 = sheet.createRow(1);
        dataRow1.createCell(0).setCellValue("3100043");
        dataRow1.createCell(1).setCellValue("");
        dataRow1.createCell(2).setCellValue(1);

        Row dataRow2 = sheet.createRow(2);
        dataRow2.createCell(0).setCellValue("3100055");
        dataRow2.createCell(1).setCellValue("");
        dataRow2.createCell(2).setCellValue(1);

        Row dataRow3 = sheet.createRow(3);
        dataRow3.createCell(0).setCellValue("");
        dataRow3.createCell(1).setCellValue("220000034");
        dataRow3.createCell(2).setCellValue(1);

        // Write the workbook data to the output stream
        workbook.write(out);
        workbook.close();

        // Create a MockMultipartFile using the in-memory Excel file
        ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
        MockMultipartFile file = new MockMultipartFile("file", "test.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", in);

        // Simulate purchase order data
        List<FundingRequestService.PurchaseOrderFundingRequestSAP> purchaseOrders = new ArrayList<>();
        purchaseOrders.add(new FundingRequestService.PurchaseOrderFundingRequestSAP("AGENCY001", "3100043", 1));

        // Simulate SAP response for orders
        SapResponseWrapper sapResponseCommande = new SapResponseWrapper();
        FundingRequestDto fundingRequestDtoCommande = new FundingRequestDto();
        fundingRequestDtoCommande.setPurchaseOrderId("3100043");
        fundingRequestDtoCommande.setBravoId(198L);
        sapResponseCommande.setFundingRequestDtos(Collections.singletonList(fundingRequestDtoCommande));
        sapResponseCommande.setErrorMessages(Collections.singletonList("No errors"));

        // Simulate SAP response for contracts
        SapResponseWrapper sapResponseContract = new SapResponseWrapper();
        FundingRequestDto fundingRequestDtoContract = new FundingRequestDto();
        fundingRequestDtoContract.setPurchaseOrderId("220000034");
        sapResponseContract.setFundingRequestDtos(Collections.singletonList(fundingRequestDtoContract));
        sapResponseContract.setErrorMessages(Collections.singletonList("No errors"));

        // Mock the SAP service calls for purchase order and contract
        when(sapService.getFromSapWithErrorMessages(any(), any()))
                .thenReturn(sapResponseCommande)
                .thenReturn(sapResponseContract);

        // Mock the call to get supplier information
        FundingRequestApplicantDto supplierInfo = new FundingRequestApplicantDto();
        supplierInfo.setSupplierBravoId(131L);
        /*when(restTemplate.getForObject(eq("http://mocked-backend-url/supplier/profileBySupplierId/131"), eq(FundingRequestApplicantDto.class)))
                .thenReturn(supplierInfo);*/

        // Execute the method being tested
        List<ImportPurchaseOrdersResponseSAP> responses = fundingRequestService.importPurchaseOrdersSAP(file);

        // Verify that the responses are correct
        assertEquals(3, responses.size());
        ImportPurchaseOrdersResponseSAP response = responses.get(0);
        assertEquals("3100043", response.getCommandeID());
        assertEquals("", response.getContractID());
        assertTrue(response.isSaved());

        ImportPurchaseOrdersResponseSAP response1 = responses.get(1);
        assertEquals("3100055", response1.getCommandeID());
        assertEquals("", response1.getContractID());
        assertFalse(response1.isSaved());

        ImportPurchaseOrdersResponseSAP response2 = responses.get(2);
        assertEquals("", response2.getCommandeID());
        assertEquals("220000034", response2.getContractID());
        assertFalse(response2.isSaved());

         }





    /**
     * Excel file data converted into base64
     * orderRef operationUnit agencyId
     * or10     ou1           1
     * or11     ou2
     * or12     ou3           2
     * or13     ou4           1
     * or14     ou5           1
     */
   /* @Test
    public void importPurchaseOrders() throws IOException {
        String excelFileBase64 = "UEsDBBQABgAIAAAAIQBi7p1oXgEAAJAEAAATAAgCW0NvbnRlbnRfVHlwZXNdLnhtbCCiBAIooAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACslMtOwzAQRfdI/EPkLUrcskAINe2CxxIqUT7AxJPGqmNbnmlp/56J+xBCoRVqN7ESz9x7MvHNaLJubbaCiMa7UgyLgcjAVV4bNy/Fx+wlvxcZknJaWe+gFBtAMRlfX41mmwCYcbfDUjRE4UFKrBpoFRY+gOOd2sdWEd/GuQyqWqg5yNvB4E5W3hE4yqnTEOPRE9RqaSl7XvPjLUkEiyJ73BZ2XqVQIVhTKWJSuXL6l0u+cyi4M9VgYwLeMIaQvQ7dzt8Gu743Hk00GrKpivSqWsaQayu/fFx8er8ojov0UPq6NhVoXy1bnkCBIYLS2ABQa4u0Fq0ybs99xD8Vo0zL8MIg3fsl4RMcxN8bZLqej5BkThgibSzgpceeRE85NyqCfqfIybg4wE/tYxx8bqbRB+QERfj/FPYR6brzwEIQycAhJH2H7eDI6Tt77NDlW4Pu8ZbpfzL+BgAA//8DAFBLAwQUAAYACAAAACEAtVUwI/QAAABMAgAACwAIAl9yZWxzLy5yZWxzIKIEAiigAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKySTU/DMAyG70j8h8j31d2QEEJLd0FIuyFUfoBJ3A+1jaMkG92/JxwQVBqDA0d/vX78ytvdPI3qyCH24jSsixIUOyO2d62Gl/pxdQcqJnKWRnGs4cQRdtX11faZR0p5KHa9jyqruKihS8nfI0bT8USxEM8uVxoJE6UchhY9mYFaxk1Z3mL4rgHVQlPtrYawtzeg6pPPm3/XlqbpDT+IOUzs0pkVyHNiZ9mufMhsIfX5GlVTaDlpsGKecjoieV9kbMDzRJu/E/18LU6cyFIiNBL4Ms9HxyWg9X9atDTxy515xDcJw6vI8MmCix+o3gEAAP//AwBQSwMEFAAGAAgAAAAhAHdRJD1mAwAAPAgAAA8AAAB4bC93b3JrYm9vay54bWysVWtvnDoQ/V7p/gfEdwLmDQqplpcaqamiNE2lKlLlBROsBcw1JrtR1P/eMSybpKmqveldsTb2mMOZmTPD6ftd2yj3hA+UdZGKTgxVIV3BStrdReqX61zzVWUQuCtxwzoSqQ9kUN+f/fPudMv4Zs3YRgGAbojUWog+1PWhqEmLhxPWkw4sFeMtFrDkd/rQc4LLoSZEtI1uGoart5h26owQ8mMwWFXRgqSsGFvSiRmEkwYLoD/UtB8WtLY4Bq7FfDP2WsHaHiDWtKHiYQJVlbYIz+86xvG6Abd3yFF2HC4X/siAwVzeBKZXr2ppwdnAKnEC0PpM+pX/yNARehGC3esYHIdk65zcU5nDAyvuvpGVe8Byn8CQ8ddoCKQ1aSWE4L0RzTlwM9Wz04o25GaWroL7/hNuZaYaVWnwILKSClJGqgdLtiUvNvjYxyNtwGqarmmr+tlBzpdcKUmFx0Zcg5AXeKgM1w1MR54EYawaQXiHBUlYJ0CHe7/+VnMTdlIzULhyRf4dKSdQWKAv8BVGXIR4PVxiUSsjbyI1CW+/DOD+7QWrwfXyG34oV2tc3qZk2AjW3z5TKH5dDv9Bo7iQjuvg+cxuvv81CkCSh4sOLwVX4P48/Qi5+IzvITOQ/3JfuOcQemR97woeou+PdmZbZpy4WmoZhmabcaAFuetoyDM8H5lu5sbxD3CGu2HB8CjqfdIldKTazm9MF3i3WJARjrR8ovFo7H+anH8ZFtsP6bBsbzeUbIcnecilsvtKu5JtI1VDBrTHh5fL7WT8SktRg74s04Eymvc+EHpXA2NkOp6sLW5KZpH6aMVJYHnZSkvzONds23W1WHJb5b7rgfD8PPEnRvozSlMjBWrTrHST+HMCskbQsWWTnYKsKjyU7+DnJZqSuDxW4KYAsctpOhggwwzkCbITHwcxzaAzCvSQbaw8I7A1I7MczfYDU/MhY1pip2bmeFmaxY7Mj/wQhP9HO5zkHi5fGMmyxlxcc1xs4Lt0RaoYDyCo2SHg+5xs7PixYQFFO0cQSxQYWhy7tuakueV4KE0yJ38iK92v3tiMfH16mmAxQqHKGp3WoRzz/e5hs5o39nl6UXvhVSrjvn/6Twc/g/cNOfJwfnPkweTTxfXFpI3fOqBPAZbjJAt9ScvZTwAAAP//AwBQSwMEFAAGAAgAAAAhAIE+lJfzAAAAugIAABoACAF4bC9fcmVscy93b3JrYm9vay54bWwucmVscyCiBAEooAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKxSTUvEMBC9C/6HMHebdhUR2XQvIuxV6w8IybQp2yYhM3703xsqul1Y1ksvA2+Gee/Nx3b3NQ7iAxP1wSuoihIEehNs7zsFb83zzQMIYu2tHoJHBRMS7Orrq+0LDppzE7k+ksgsnhQ45vgoJRmHo6YiRPS50oY0as4wdTJqc9Adyk1Z3su05ID6hFPsrYK0t7cgmilm5f+5Q9v2Bp+CeR/R8xkJSTwNeQDR6NQhK/jBRfYI8rz8Zk15zmvBo/oM5RyrSx6qNT18hnQgh8hHH38pknPlopm7Ve/hdEL7yim/2/Isy/TvZuTJx9XfAAAA//8DAFBLAwQUAAYACAAAACEAsgNKBe0CAAAICAAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbJyVW2/aMBTH3yftO1h+J4mTkAICKhpWrQ+Tpl2fjeOA1STObAOtpn33HTtNoKGb0kqUXM7p7/zPxYf59UNZoANXWshqgYkXYMQrJjNRbRf4+7fb0QQjbWiV0UJWfIEfucbXy/fv5kep7vWOc4OAUOkF3hlTz3xfsx0vqfZkzSuw5FKV1MCj2vq6Vpxm7p/Kwg+DIPFLKircEGZqCEPmuWB8Ldm+5JVpIIoX1IB+vRO1bmklG4Irqbrf1yMmyxoQG1EI8+igGJVsdretpKKbAvJ+IDFl6EHBJ4S/qA3j3l9EKgVTUsvceED2G82X6U/9qU9ZR7rMfxCGxL7iB2EbeEKFb5NExh0rPMGiN8KSDmbLpWZ7kS3w7/VkEidhEozIZJWM4iRej1YpiUZpehMSMp1+IMn0D17OMwEdtlkhxfMFXpFZmmB/OXfz80Pwoz67R4ZuvvKCM8MhBsHIjudGynvreAevAiBq52CJlBlx4CkvigUGKtK/XIwmgN9FWM5P9220WzfQnxXaUM1TWfwUmdlBSDg4Gc/pvjBf5PEjF9udgbexF0PqdnZm2eOaawZDC2K8yGbCZAFU+EalsIcPZo4+NOqfoJEXxyQOknCM0YZrcyssFCO210aWbegnVkOBvjkKXI8dJYrCICKvoEDDHAWuLSX2Xk2B3B0Fri0l8MbjOJlcQUKXSfhNRVz919TQ5VzJI4JzASnrmtotQ2Z2ll4qKFTSuq7AF4qkod+HZTD3D9BE9mS7ObeR57b03BZ2Nh8UdDKgpoNlgG8nI+rJOLfFPRmhE34S90wA5D5YAPh2AsY9Aee25OVcoWeDQ4FvF+qqF+rcNunlGrtc/1FsmJDBAsC3EzDtCTi3kd5ApOP/VdsuhqFTB76dAtIbrZtnxlO6bl5h59hJ7Te8WTzNIajpln+iaisqjQqeuwVyhZFqdkzgwb2RtV0r9lhtpIHd0D7t4BeXw7GwKwflUpr2AfaP3/2GL/8CAAD//wMAUEsDBBQABgAIAAAAIQClugknWAcAAMcgAAATAAAAeGwvdGhlbWUvdGhlbWUxLnhtbOxZW4sbNxR+L/Q/DPPu+DbjyxIn+JptsrsJWSclj1pb9iirGRlJ3o0JgZI89aVQSEtfCn1roZQGGmjoSx/6UwIJbfojeqQZe6S1nOumpGXXsHjk7xwdnXP06czR+Yt3YuodYS4IS1p++VzJ93AyYmOSTFv+jeGg0PA9IVEyRpQluOUvsPAvXvj4o/NoS0Y4xh7IJ2ILtfxIytlWsShGMIzEOTbDCfw2YTxGEh75tDjm6Bj0xrRYKZVqxRiRxPcSFIPaYfTHD6Ds6mRCRti/sNTepzBFIoUaGFG+r3TjTMTAjg/LCiEWoku5d4Roy4eJxux4iO9I36NISPih5Zf0n1+8cL6ItjIhKjfIGnID/ZfJZQLjw4qek08PVpMGQRjU2iv9GkDlOq5f79f6tZU+DUCjEaw0tcXWWa90gwxrgNKvDt29eq9atvCG/uqaze1QfSy8BqX6gzX8YNAFL1p4DUrx4Ro+7DQ7PVu/BqX42hq+Xmr3grqlX4MiSpLDNXQprFW7y9WuIBNGt53wZhgM6pVMeY6CbFhll5piwhK5KddidJvxAQAUkCJJEk8uZniCRpDGXUTJASfeDplGkHgzlDABw6VKaVCqwn/1CfQ3HVG0hZEhrewCS8TakLLHEyNOZrLlXwatvgF59uTJ0/uPn97/9emDB0/v/5zNrVVZctsomZpyL77/8u9vP/P++uW7Fw+/Sqc+iRcm/vlPnz//7feXqYcV56549vWj548fPfvmiz9/fOjQ3ubowIQPSYyFt4ePvesshgU67McH/M0khhEilgSKQLdDdV9GFnBvgagL18G2C29yYBkX8NL8tmXrfsTnkjhmvhLFFnCXMdph3OmAK2ouw8PDeTJ1T87nJu46QkeuubsosQLcn8+AXolLZTfClpnXKEokmuIES0/9xg4xdqzuFiGWX3fJiDPBJtK7RbwOIk6XDMmBlUi50DaJIS4Ll4EQass3uze9DqOuVffwkY2EbYGow/ghppYbL6G5RLFL5RDF1HT4DpKRy8j9BR+ZuL6QEOkppszrj7EQLpmrHNZrBP0KMIw77Lt0EdtILsmhS+cOYsxE9thhN0LxzGkzSSIT+4k4hBRF3jUmXfBdZu8Q9QxxQMnGcN8k2Ar3q4ngBpCraVKeIOqXOXfE8hJm9n5c0AnCLpZp89hi1zYnzuzozKdWau9gTNExGmPs3fjEYUGHzSyf50ZfjoBVtrErsS4jO1fVc4IF9nRds06RO0RYKbuPp2yDPbuLE8SzQEmM+CbNexB1K3XhlHNS6VU6OjSBewTqP8gXp1OuCtBhJHd/k9ZrEbLOLvUs3Pm64Fb8XmePwb68/ab7EmTwG8sAsb+2b4aIWhPkCTNEUGC46BZErPDnIupc1WJzp9zE3rR5GKAwsuqdmCSvLH5OlD3hv1P2uAuYUyh43IrfpdTZRCnbJwqcTbj/YFnTQ/PkGoaTZJ2zzqqas6rG/99XNZv28lktc1bLnNUyrrev91LL5OULVDZ5l0f3fOKNLZ8JoXRfLijeEbrrI+CNZjyAQd2O0j3JVQtwFsHXrMFk4aYcaRmPM/kpkdF+hGbQGirrZudUZKqnwpsxAR0jPax7qfiEbt13mse7bJx2Ostl1dVMXSiQzMdL4WoculQyRdfqefdupV73Q6e6y7o0QMm+iRHGZLYRVYcR9eUgROFlRuiVnYoVTYcVDaV+GaplFFeuANNWUYFXbg9e1Ft+GKQdZGjGQXk+VnFKm8nL6KrgnGqkNzmTmhkAJfYyA/JIN5WtG5enVpem2mtE2jLCSDfbCCMNI3gRzrLTbLmfZqybeUgt85QrlrshN6PeeB+xViRyghtoYjIFTbzjll+rhnCtMkKzlj+BjjF8jWeQO0K9dSE6hXuXkeTphn8bZplxIXtIRKnDNemkbBATiblHSdzy1fJX2UATzSHatnIFCOGDNa4JtPKhGQdBt4OMJxM8kmbYjRHl6fQRGD7lCuevWvztwUqSzSHc+9H42Dugc34dQYqF9bJy4JgIuDgop94cE7gJWxFZnn8nDqaMds2rKJ1D6TiiswhlJ4pJ5ilck+jKHP208oHxlK0ZHLruwoOpOmDf+dR99VGtPGeQZn5mWqyiTk03mb6/Q96wKj9ELatS6tbv1CLnuuaS6yBRnafEK07d1zgQDNPyySzTlMXrNKw4Oxu1TTvFgsDwRG2D31ZnhNMTb3vyg9zJrFUHxLKu1Imv78zNW212cBvIowf3h3MqhQ4l3FlzBEVfegOZ0gZskTsyqxHhmzfnpOXfLYXtoFsJu4VSI+wXgmpQKjTCdrXQDsNquR+WS71O5R4cLDKKy2F6Xz+AKwy6yG7t9fjazX28vKU5N2Jxkekr+aI2XN/clyvWzX16De8N1c287xEgnbu1yqBZbXZqhWa1PSgEvU6j0OzWOoVerVvvDXrdsNEc3PO9Iw0O2tVuUOs3CrVyt1sIaiVlfqNZqAeVSjuotxv9oH0vK2Ng5Sl9ZL4A92q7LvwDAAD//wMAUEsDBBQABgAIAAAAIQB5oYBspAIAAFIGAAANAAAAeGwvc3R5bGVzLnhtbKRVbWvbMBD+Pth/EPruynbjLAm2y9LUUOjGoB3sq2LLiahejCRnzsb++052Xhw6ttF+iU7n03PP3XNS0ptOCrRjxnKtMhxdhRgxVeqKq02Gvz4VwQwj66iqqNCKZXjPLL7J379LrdsL9rhlzCGAUDbDW+eaBSG23DJJ7ZVumIIvtTaSOtiaDbGNYbSy/pAUJA7DKZGUKzwgLGT5PyCSmue2CUotG+r4mgvu9j0WRrJc3G+UNnQtgGoXTWiJumhqYtSZY5Le+yKP5KXRVtfuCnCJrmtespd052ROaHlGAuTXIUUJCeOL2jvzSqQJMWzHvXw4T2utnEWlbpUDMYGob8HiWenvqvCfvHOIylP7A+2oAE+ESZ6WWmiDHEgHnes9iko2RNxSwdeG+7CaSi72gzv2jl7tQ5zk0HvvJJ7HYbFwiAtxYhV7AuDIU5DPMaMK2KCD/bRvIL2CSRtg+rh/RG8M3UdxMjpA+oR5utamgsk+9+PoylPBagdEDd9s/ep0A79r7Ryon6cVpxutqPClDCAnA8opmRCPfvq/1RfYXY1UKwvp7qsMwz3yTTiaUMjBHPCGjccfow3Yb4ZFXX2JD4gj2hekT+mR1zvDn/11FTA5Bwi0brlwXP2BMGBW3bkFoVfA+avXN+eUBTpRsZq2wj2dPmb4bH9iFW9lfIr6wnfa9RAZPtsPXqlo6nOwzj1YGC9YUWt4hn/eLT/MV3dFHMzC5SyYXLMkmCfLVZBMbperVTEP4/D21+gBeMP179+rPIWLtbACHglzKPZQ4uPZl+HRZqDfzyjQHnOfx9PwYxKFQXEdRsFkSmfBbHqdBEUSxavpZHmXFMmIe/LKZyIkUTQ8OJ58snBcMsHVUaujQmMviATbvxRBjkqQ859B/hsAAP//AwBQSwMEFAAGAAgAAAAhANqhxIPXAAAAugEAABQAAAB4bC9zaGFyZWRTdHJpbmdzLnhtbGyQ0WrDMAxF3wf7B+P31Um7jTEc96GwL9g+wMRqYojlTJLL+vdzYWww51HnnouE7PErLeoCxDHjoPtdpxXgmEPEadAf728PL1qxeAx+yQiDvgLro7u/s8yiahd50LPI+moMjzMkz7u8AtbknCl5qSNNhlcCH3gGkLSYfdc9m+QjajXmglL3HrQqGD8LnH6BsxydFZcpACmCM9XDwBpx1tySn3QF8lKPv/Xlf+qn2rmqGJoa9V3DSr+htazsN7SWlcOG1rLyuKG1rDz9aab+3n0DAAD//wMAUEsDBBQABgAIAAAAIQDMnTUpSgEAAHMCAAARAAgBZG9jUHJvcHMvY29yZS54bWwgogQBKKAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMkl9PwyAUxd9N/A4N7y3QbUZJ28U/2ZNLTJzR7A3hbmss0ADa9dtLu63WzAcf4Zz745wbsvleVdEXWFcanSOaEBSBFkaWepujl9UivkaR81xLXhkNOWrBoXlxeZGJmglj4cmaGqwvwUWBpB0TdY523tcMYyd2oLhLgkMHcWOs4j4c7RbXXHzwLeCUkCuswHPJPccdMK4HIjoipRiQ9aeteoAUGCpQoL3DNKH4x+vBKvfnQK+MnKr0bR06HeOO2VIcxMG9d+VgbJomaSZ9jJCf4rfl43NfNS51tysBqMikYMIC98YWS7PjCmS05q2Mbt+5zPBI7TZZceeXYembEuRd+9fAuSm80Bc6PBPwISI7FDopr5P7h9UCFSlJSUymMSUrStnshk3Jusvwa76LfLhQxyT/JE4YoSydjYgnQJHhs29SfAMAAP//AwBQSwMEFAAGAAgAAAAhAHr4fZyLAQAAGQMAABAACAFkb2NQcm9wcy9hcHAueG1sIKIEASigAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnJLBbtswDIbvBfYOhu6NnG4oikBWUaQtetiwAEl6Z2U6ESpLgsQYyZ5+tI2mzrbTbiR/6ucnSur+2Lqiw5Rt8JWYz0pRoDehtn5Xie3m+fpOFJnA1+CCx0qcMIt7/eVKrVKImMhiLtjC50rsieJCymz22EKesexZaUJqgThNOxmaxhp8DObQoid5U5a3Eo+Evsb6Op4Nxei46Oh/Tetger78ujlFBtbqIUZnDRDfUv+wJoUcGiqejgadklNRMd0azSFZOulSyWmq1gYcLtlYN+AyKvlZUC8I/dJWYFPWqqNFh4ZCKrL9xWu7EcUbZOxxKtFBsuCJsfq2MRliFzMl/YwH6xzvtcaCB5oDI3LjKA7h9Mw0tt/0fGjg4LKxNxiBWLhE3VjiYT+bFST6B/l8Sj4wjNwT1nHmlG+4Ok/6w3sZ2gj+xMI5+m79e97GTXgEwo+1XhbVeg8Ja36J89rPBfXCG02uN1nuwe+w/uj5W+g/wev40/X8dlZ+Lfl9JzUlP/+0/g0AAP//AwBQSwECLQAUAAYACAAAACEAYu6daF4BAACQBAAAEwAAAAAAAAAAAAAAAAAAAAAAW0NvbnRlbnRfVHlwZXNdLnhtbFBLAQItABQABgAIAAAAIQC1VTAj9AAAAEwCAAALAAAAAAAAAAAAAAAAAJcDAABfcmVscy8ucmVsc1BLAQItABQABgAIAAAAIQB3USQ9ZgMAADwIAAAPAAAAAAAAAAAAAAAAALwGAAB4bC93b3JrYm9vay54bWxQSwECLQAUAAYACAAAACEAgT6Ul/MAAAC6AgAAGgAAAAAAAAAAAAAAAABPCgAAeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHNQSwECLQAUAAYACAAAACEAsgNKBe0CAAAICAAAGAAAAAAAAAAAAAAAAACCDAAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1sUEsBAi0AFAAGAAgAAAAhAKW6CSdYBwAAxyAAABMAAAAAAAAAAAAAAAAApQ8AAHhsL3RoZW1lL3RoZW1lMS54bWxQSwECLQAUAAYACAAAACEAeaGAbKQCAABSBgAADQAAAAAAAAAAAAAAAAAuFwAAeGwvc3R5bGVzLnhtbFBLAQItABQABgAIAAAAIQDaocSD1wAAALoBAAAUAAAAAAAAAAAAAAAAAP0ZAAB4bC9zaGFyZWRTdHJpbmdzLnhtbFBLAQItABQABgAIAAAAIQDMnTUpSgEAAHMCAAARAAAAAAAAAAAAAAAAAAYbAABkb2NQcm9wcy9jb3JlLnhtbFBLAQItABQABgAIAAAAIQB6+H2ciwEAABkDAAAQAAAAAAAAAAAAAAAAAIcdAABkb2NQcm9wcy9hcHAueG1sUEsFBgAAAAAKAAoAgAIAAEggAAAAAA==";
        MockMultipartFile file = new MockMultipartFile("test", "test.xls", "application/vnd.ms-excel", Base64.decodeBase64(excelFileBase64));
        FundingRequestDto fundingRequestDto = FundingRequestDto.builder().supplierOracleCode("sup1").status("PENDING").bravoId(1L).fundingAgencyId(1).build();

        when(restTemplate.getForObject("http://coordinator/purchase-orders/purchase-details-by-reference/or10/ou1", FundingRequestDto.class)).thenReturn(FundingRequestDto.builder().supplierOracleCode("sup1").build());
        when(restTemplate.getForObject("http://bravorl/supplier/profileByCommonCode/sup1", FundingRequestApplicantDto.class)).thenReturn(FundingRequestApplicantDto.builder().supplierBravoId(1L).build());

        when(restTemplate.getForObject("http://coordinator/purchase-orders/purchase-details-by-reference/or11/ou2", FundingRequestDto.class)).thenReturn(FundingRequestDto.builder().supplierOracleCode("sup2").build());
        when(restTemplate.getForObject("http://bravorl/supplier/profileByCommonCode/sup2", FundingRequestApplicantDto.class)).thenReturn(null);

        when(restTemplate.getForObject("http://coordinator/purchase-orders/purchase-details-by-reference/or12/ou3", FundingRequestDto.class)).thenReturn(null);

        when(restTemplate.getForObject("http://coordinator/purchase-orders/purchase-details-by-reference/or13/ou4", FundingRequestDto.class)).thenThrow(new RestClientException("500 Internal Server Test"));

        when(restTemplate.getForObject("http://coordinator/purchase-orders/purchase-details-by-reference/or14/ou5", FundingRequestDto.class)).thenReturn(FundingRequestDto.builder().supplierOracleCode("sup3").build());
        when(restTemplate.getForObject("http://bravorl/supplier/profileByCommonCode/sup3", FundingRequestApplicantDto.class)).thenThrow(new RestClientException("500 Internal Server Test"));


        List<ImportPurchaseOrdersResponse> actual = fundingRequestService.importPurchaseOrders(file);

        verify(restTemplate, times(1)).postForEntity("http://ecosystemurl/funding-request/import-all", Collections.singletonList(fundingRequestDto), ResponseEntity.class);
        TestCase.assertEquals(5, actual.size());

        TestCase.assertEquals(1, actual.get(0).getAgencyIDString().intValue());
        TestCase.assertEquals("or10", actual.get(0).getOrderReference());
        TestCase.assertEquals("ou1", actual.get(0).getOperationUnit());
        TestCase.assertEquals("Saved", actual.get(0).getMessage());
        TestCase.assertTrue(actual.get(0).isSaved());

        TestCase.assertEquals(1, actual.get(1).getAgencyIDString().intValue());
        TestCase.assertEquals("or11", actual.get(1).getOrderReference());
        TestCase.assertEquals("ou2", actual.get(1).getOperationUnit());
        TestCase.assertEquals("The supplier info is not found in bravo for Oracle code sup2", actual.get(1).getMessage());
        TestCase.assertFalse(actual.get(1).isSaved());

        TestCase.assertEquals(2, actual.get(2).getAgencyIDString().intValue());
        TestCase.assertEquals("or12", actual.get(2).getOrderReference());
        TestCase.assertEquals("ou3", actual.get(2).getOperationUnit());
        TestCase.assertEquals("No data found while trying to get poOracleDetails for orderReference or12 and operationUnit ou3", actual.get(2).getMessage());
        TestCase.assertFalse(actual.get(2).isSaved());

        TestCase.assertEquals(1, actual.get(3).getAgencyIDString().intValue());
        TestCase.assertEquals("or13", actual.get(3).getOrderReference());
        TestCase.assertEquals("ou4", actual.get(3).getOperationUnit());
        TestCase.assertEquals("Error while getting Oracle Order Details By Reference or13 And OperationUnit ou4", actual.get(3).getMessage());
        TestCase.assertFalse(actual.get(3).isSaved());

        TestCase.assertEquals(1, actual.get(4).getAgencyIDString().intValue());
        TestCase.assertEquals("or14", actual.get(4).getOrderReference());
        TestCase.assertEquals("ou5", actual.get(4).getOperationUnit());
        TestCase.assertEquals("Error while trying to get supplier info from bravo for Oracle code sup3", actual.get(4).getMessage());
        TestCase.assertFalse(actual.get(1).isSaved());
    }  */

    @Test
    public void getBravoIdBySapIdTest() {

        String inscriptionUrl ="http://inscriptionurl/supplier/bravoIdBySapId/0070000022";
        when(restTemplate.getForEntity(inscriptionUrl , BravoDto.class)).thenReturn(new ResponseEntity<>(new BravoDto(true,"ok","602"),HttpStatus.OK));
        BravoDto bravoDto = fundingRequestService.getBravoIdBySapId("0070000022");
        TestCase.assertEquals("602", bravoDto.getBravo_id());
    }

    @Test
    public void getPurchaseDetailSap() {
        String S4URL = "http://coordinatorURL/search-purchase-orders/all";
        FundingRequestService.PurchaseOrderFundingRequest purchaseOrderFundingRequest = new FundingRequestService.PurchaseOrderFundingRequest("4700000003", "", 1,"SAP");
        SearchPurchaseOrderFilters searchPurchaseOrderFilters = SearchPurchaseOrderFilters.builder()
                .purchaseOrderReference(purchaseOrderFundingRequest.getOrderReference())
                .isApproved("true")
                .build();
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = "{\"status\":null,\"cps\":null,\"isApproved\":\"true\",\"minPrice\":null,\"maxPrice\":null,\"minApprovalDate\":null,\"maxApprovalDate\":null,\"purchaseOrderReference\":\"4700000003\",\"employeeNumber\":null,\"purchaseOrderDescription\":null,\"supplierId\":null,\"progressStatus\":null,\"purchaseOrderId\":null,\"operationUnit\":null,\"supplierCode\":null,\"rfqCode\":null,\"onlyNewPurchaseOrders\":null,\"posWithPendingReceipts\":null,\"posWithPendingPayments\":null,\"page\":null,\"size\":null,\"sortBy\":null,\"minDate\":null,\"maxDate\":null,\"emailAddress\":null}";
        HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, requestHeaders);
        ResponseEntity<DataResponse<PurchaseOrderSearch>> response;
        when(restTemplate.exchange(
                S4URL, HttpMethod.POST, requestEntity, new ParameterizedTypeReference<DataResponse<PurchaseOrderSearch>>() {
                })).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        ResponseEntity<DataResponse<PurchaseOrderSearch>> response2 = fundingRequestService.getPurchaseDetailSap(purchaseOrderFundingRequest.getOrderReference());
        TestCase.assertEquals(HttpStatus.OK,response2.getStatusCode());
    }
    /*
    @Test
    public void test(){
        when(backendConfig.getSapPoURL()).thenReturn("http://pvlxd124037.ocpgroup.ma:50100/RESTAdapter");
        String SapPO = backendConfig.getSapPoURL();
        FundingRequestService.PurchaseOrderFundingRequestSAP purchaseOrderFundingRequestSAP = new FundingRequestService.PurchaseOrderFundingRequestSAP("2200000732","4500002643");
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = "{\"CommandeID\":\"2200000732\",\"ContractID\":\"4500002643\"}";
        HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, requestHeaders);
        when(restTemplate.exchange(Mockito.eq(SapPO+"/PurDocGetDetail"),
                Mockito.eq(HttpMethod.POST),
                Mockito.any(HttpEntity.class),
                Mockito.<ParameterizedTypeReference<FundingRequestSAPDto>>any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        fundingRequestService.getSAPDetailsByCommandeIDOrContractID(purchaseOrderFundingRequestSAP.getCommandeID(),purchaseOrderFundingRequestSAP.getContractID());
    }*/

    @Test
    public void testGetSAPDetailsByContractID() throws JsonProcessingException, IOException {
        // Given
        String contractID = "2200000732";
        String type = "contract";
        Boolean uniqueLine = false;

        ContractsRequest contractsRequest = new ContractsRequest();
        contractsRequest.setContractNumber(Arrays.asList(contractID));

        SapContratRequest sapContratRequest = new SapContratRequest();
        sapContratRequest.setContracts(contractsRequest);

        String jsonRequest = objectMapper.writeValueAsString(sapContratRequest);

        // Mocking the SAP service response
        SapResponseWrapper mockResponse = new SapResponseWrapper();
        FundingRequestDto dto = new FundingRequestDto();
        dto.setPurchaseOrderId("3400000813");
        mockResponse.setFundingRequestDtos(Arrays.asList(dto));
        mockResponse.setErrorMessages(Arrays.asList("No errors"));

        //when(sapService.getFromSapWithErrorMessages(jsonRequest, type)).thenReturn(mockResponse);
        when(sapService.getFromSapWithErrorMessages(any(), any())).thenReturn(mockResponse);
        // When
        SapResponseWrapper result = fundingRequestService.getSAPDetailsByCommandeIDOrContractID(contractID, type, uniqueLine);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getFundingRequestDtos().size());
        assertEquals("3400000813", result.getFundingRequestDtos().get(0).getPurchaseOrderId());
        assertTrue(result.getErrorMessages().contains("No errors"));
    }

    @Test
    public void getFundingRequestDetailUsingSap_contract() throws IOException {
        Integer agencyId = 1;
        String orderId = "12345";
        Integer requestId = 1;
        String requestSource = "s";

        // Mock FundingRequestDto response from the REST call
        FundingRequestDto mockFundingRequestDto = new FundingRequestDto();
        mockFundingRequestDto.setStatus("APPROVED");
        mockFundingRequestDto.setFundingAgencyId(agencyId);
        mockFundingRequestDto.setSource("contract");
        mockFundingRequestDto.setPurchaseOrderRef(orderId);

        when(restTemplate.getForObject(anyString(), eq(FundingRequestDto.class)))
                .thenReturn(mockFundingRequestDto);

        // Mock SapResponseWrapper from the sapService
        SapResponseWrapper mockSapResponse = new SapResponseWrapper();
        FundingRequestDto sapFundingRequestDto = new FundingRequestDto();
        sapFundingRequestDto.setBilledAmount(100.0);
        sapFundingRequestDto.setPaidAmount(50.0);
        sapFundingRequestDto.setPurchaseOrderCategory("category");
        sapFundingRequestDto.setPurchaseOrderPaymentTermsName("Net 30");
        sapFundingRequestDto.setPurchaseOrderStatus("COMPLETED");
        sapFundingRequestDto.setAchievementPercentage(90.0);
        mockSapResponse.setFundingRequestDtos(Collections.singletonList(sapFundingRequestDto));

        when(sapService.getFromSapWithErrorMessages(anyString(), eq("contract"))).thenReturn(mockSapResponse);

        // Call the method to test
        FundingRequestDto result = fundingRequestService.getFundingRequestDetailUsingSap(agencyId, orderId, requestId, requestSource);

        // Assertions
        assertNotNull(result);
        assertEquals(100.0, result.getBilledAmount(), 0.01);
        assertEquals(50.0, result.getPaidAmount(), 0.01);
        assertEquals("category", result.getPurchaseOrderCategory());
        assertEquals("Net 30", result.getPurchaseOrderPaymentTermsName());
        assertEquals("COMPLETED", result.getPurchaseOrderStatus());
        assertEquals(0.9, result.getAchievementPercentage(), 0.01);

        verify(restTemplate).getForObject(anyString(), eq(FundingRequestDto.class));
        verify(sapService).getFromSapWithErrorMessages(anyString(), eq("contract"));
    }

    @Test
    public void getFundingRequestDetailUsingSap_commande() throws IOException {
        Integer agencyId = 1;
        String orderId = "12345";
        Integer requestId = 1;
        String requestSource = "s";

        // Mock FundingRequestDto response from the REST call
        FundingRequestDto mockFundingRequestDto = new FundingRequestDto();
        mockFundingRequestDto.setStatus("APPROVED");
        mockFundingRequestDto.setFundingAgencyId(agencyId);
        mockFundingRequestDto.setSource("commande");
        mockFundingRequestDto.setPurchaseOrderRef(orderId);

        when(restTemplate.getForObject(anyString(), eq(FundingRequestDto.class)))
                .thenReturn(mockFundingRequestDto);

        // Mock SapResponseWrapper from the sapService
        SapResponseWrapper mockSapResponse = new SapResponseWrapper();
        FundingRequestDto sapFundingRequestDto = new FundingRequestDto();
        sapFundingRequestDto.setBilledAmount(200.0);
        sapFundingRequestDto.setPaidAmount(100.0);
        sapFundingRequestDto.setPurchaseOrderCategory("category2");
        sapFundingRequestDto.setPurchaseOrderPaymentTermsName("Net 60");
        sapFundingRequestDto.setPurchaseOrderStatus("IN_PROGRESS");
        sapFundingRequestDto.setAchievementPercentage(80.0);
        mockSapResponse.setFundingRequestDtos(Collections.singletonList(sapFundingRequestDto));

        when(sapService.getFromSapWithErrorMessages(anyString(), eq("commande"))).thenReturn(mockSapResponse);

        // Call the method to test
        FundingRequestDto result = fundingRequestService.getFundingRequestDetailUsingSap(agencyId, orderId, requestId, requestSource);

        // Assertions
        assertNotNull(result);
        assertEquals(200.0, result.getBilledAmount(), 0.01);
        assertEquals(100.0, result.getPaidAmount(), 0.01);
        assertEquals("category2", result.getPurchaseOrderCategory());
        assertEquals("Net 60", result.getPurchaseOrderPaymentTermsName());
        assertEquals("IN_PROGRESS", result.getPurchaseOrderStatus());
        assertEquals(0.8, result.getAchievementPercentage(), 0.01);

        verify(restTemplate).getForObject(anyString(), eq(FundingRequestDto.class));
        verify(sapService).getFromSapWithErrorMessages(anyString(), eq("commande"));
    }



   /*
    @Test

    public void test2(){
        when(backendConfig.getSapPoURL()).thenReturn("http://pvlxd124037.ocpgroup.ma:50100/RESTAdapter");
        FundingRequestSAPDto fundingRequestSAPDto = FundingRequestSAPDto.builder().id(1).build();
        DocumentResponceSap documentResponceSap = DocumentResponceSap.builder().Document(Arrays.asList(fundingRequestSAPDto)).build();
        SapResponce sapResponce = SapResponce.builder().MT_PurDocGetDetailResponse(documentResponceSap).build();
        when(restTemplate.exchange(Mockito.eq("http://pvlxd124037.ocpgroup.ma:50100/RESTAdapter/PurDocGetDetail"),Mockito.eq(HttpMethod.POST),Mockito.any(),Mockito.eq(SapResponce.class))).thenReturn(new ResponseEntity(sapResponce,HttpStatus.OK));
        fundingRequestService.getSAPDetailsByCommandeIDOrContractID("2200000732","4500002643");
        int a = 7;
    }*/
}
