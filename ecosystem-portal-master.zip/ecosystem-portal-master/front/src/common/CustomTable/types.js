// @flow
export type THeadType = {
	id: string,
	label: string,
	sort?: { action: Function, type?: "desc" | "asc" }
};
export type TRowType = any;
export type TActionType = {
	label: string,
	actionFunc: Function,
	fields: Array<string>,
	shouldRender?: Function,
	Component?: any
};
export type TCellHover = { id: string, value: string };
