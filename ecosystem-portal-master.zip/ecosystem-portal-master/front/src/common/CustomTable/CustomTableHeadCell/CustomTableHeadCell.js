// @flow

import React from "react";
import { StyledTableCell } from "./styles";

type Props = {
	children: any,
	cellWidth: number,
};

const CustomTableHeadCell = ({ children, cellWidth}: Props) => {
	return <StyledTableCell style={{
	  width: cellWidth
	}}>{children}</StyledTableCell>;
};

export default CustomTableHeadCell;
