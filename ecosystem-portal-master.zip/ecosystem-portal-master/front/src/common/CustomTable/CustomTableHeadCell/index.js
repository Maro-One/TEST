import CustomTableHeadCell from "./CustomTableHeadCell";

export default CustomTableHeadCell;