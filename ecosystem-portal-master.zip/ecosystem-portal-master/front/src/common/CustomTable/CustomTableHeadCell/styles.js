import { withStyles, TableCell } from "@material-ui/core";
import colors from "../../../utils/colors";

export const StyledTableCell = withStyles(() => ({
	head: {
		backgroundColor: colors.titanWhite,
		color: colors.lynch,
		textTransform: "uppercase",
		fontSize: 12,
		height: 40,
		padding: 0,
		paddingLeft: 16
	},
}))(TableCell);