// @flow

import Table from "@material-ui/core/Table";
import TableContainer from "@material-ui/core/TableContainer";
import React from "react";
import CustomTableBody from "./CustomTableBody";
import CustomTableHead from "./CustomTableHead";
import { useStyles } from "./styles";
import type { THeadType, TRowType, TActionType, TCellHover } from "./types";
import TableStatusControllerSpinner from "../SpinnerNew/TableStatusControllerSpinner";
import MessageTableCellComponent from "../MessageTableCell/MessageTableCell"; // Import the new message cell component

type Props = {
	thead: THeadType[],
	trows: TRowType[],
	taction?: TActionType| TActionType[],
	tcellHover?: TCellHover,
	dataStatus?: "SUCCESS" | "ERROR" | "LOADING"
};

const CustomTable = ({
	thead,
	trows = [],
	taction,
	tcellHover,
	dataStatus = "SUCCESS"
}: Props) => {
	const classes = useStyles();
	const colSpan = thead.length + (taction ? 1 : 0);
	const cellWidth = 100.0/colSpan + "%";
	if(taction) {
		taction = taction && (taction instanceof Array) ? taction : [taction];
	}else{
		taction = [];
	}
	return (
		<TableContainer classes={{ root: classes.tableContainer }}>
			<Table className={classes.table}>
				<CustomTableHead cellWidth={cellWidth} thead={thead} taction={taction} />
				<TableStatusControllerSpinner colSpan={colSpan} dataStatus={dataStatus}>
					<CustomTableBody
						trows={trows.map((row) => ({
							...row,
							message: <MessageTableCellComponent message={row.message} /> // Use the new message cell component
						  }))}
			  
						thead={thead}
						taction={taction}
						tcellHover={tcellHover}
					/>
				</TableStatusControllerSpinner>
			</Table>
		</TableContainer>
	);
};

export default CustomTable;
