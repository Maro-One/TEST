// @flow

import React from "react";
import type { Node } from "react";
import { EvenTableCell, OddTableCell } from "./styles";

type Props = {
	index: number,
	children: Node
};

const CustomTableBodyCell = ({ index, children, ...props }: Props) => {
	let Cell = EvenTableCell;
	if (index % 2 !== 0) {
		Cell = OddTableCell;
	}

	return <Cell {...props}>{children}</Cell>;
};

export default CustomTableBodyCell;
