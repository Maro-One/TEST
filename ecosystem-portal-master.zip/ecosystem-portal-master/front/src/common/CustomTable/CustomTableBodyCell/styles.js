import { withStyles, TableCell } from "@material-ui/core";
import colors from "../../../utils/colors";

export const EvenTableCell = withStyles(() => ({
	body: {
		backgroundColor: colors.white,
	},
}))(TableCell);

export const OddTableCell = withStyles(() => ({
	body: {
		backgroundColor: colors.whisperWhite,
	},
}))(TableCell);