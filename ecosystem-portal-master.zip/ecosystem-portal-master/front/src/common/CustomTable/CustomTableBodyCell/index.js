import CustomTableBodyCell from "./CustomTableBodyCell";

export default CustomTableBodyCell;