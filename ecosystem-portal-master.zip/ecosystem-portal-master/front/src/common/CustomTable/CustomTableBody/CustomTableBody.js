// @flow

import { TableBody, TableRow } from "@material-ui/core";
import React from "react";
import type { Node } from "react";
import CustomToolTip from "../../CustomToolTip";
import CustomTableBodyCell from "../CustomTableBodyCell";
import {StyledButton} from "../styles";
import type { TCellHover, TActionType, THeadType } from "../types";
import ButtonGroup from "@material-ui/core/ButtonGroup";

const renderAction = (
	index: number,
	taction: TActionType,
	row: Object
): Node => {
	const { fields, shouldRender, Component } = taction;
	const value = fields
		? fields.reduce((obj, f) => ({ ...obj, [f]: row[f] }), {})
		: null;
	if(shouldRender === undefined || shouldRender(row)) {
		if(Component){
			return <Component onClick={() => taction.actionFunc(value)}>
				{taction.label}
			</Component>
		}
		return <StyledButton onClick={() => taction.actionFunc(value)}>
			{taction.label}
		</StyledButton>;
	}
	return <></>;
};

const renderCell = (
	index: number,
	head: THeadType,
	row: Object,
	tcellHover: TCellHover | typeof undefined
): Node => {
	let cell = (
		<CustomTableBodyCell key={head.id} index={index}>
			{row[head.id]}
		</CustomTableBodyCell>
	);
	if (tcellHover && tcellHover.id === head.id) {
		cell = (
			<CustomTableBodyCell key={head.id} index={index}>
				<CustomToolTip
					title={row[tcellHover.value]}
					arrow
					placement="bottom-start"
				>
					{row[head.id]}
				</CustomToolTip>
			</CustomTableBodyCell>
		);
	}
	return cell;
};

type Props = {
	thead: THeadType[],
	trows: Array<Object>,
	taction?: Array<TActionType>,
	tcellHover?: TCellHover
};

const CustomTableBody = ({
	trows,
	thead,
	taction,
	tcellHover
}: Props) => (
	<TableBody>
		{trows.map((row, index) => (
			<TableRow key={index}>
				{thead.map(head => renderCell(index, head, row, tcellHover))}
				<CustomTableBodyCell index={index}>
					<ButtonGroup>
						{taction && taction.map((action) => renderAction(index, action, row))}
					</ButtonGroup>
				</CustomTableBodyCell>
			</TableRow>
		))}
	</TableBody>
);

export default CustomTableBody;
