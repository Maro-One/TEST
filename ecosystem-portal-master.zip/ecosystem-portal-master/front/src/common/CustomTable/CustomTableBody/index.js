import CustomTableBody from "./CustomTableBody";

export default CustomTableBody;