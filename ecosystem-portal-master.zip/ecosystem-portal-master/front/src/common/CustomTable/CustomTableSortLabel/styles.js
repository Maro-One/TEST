import colors from "../../../utils/colors";
const sortCellColor = colors.lynch + "!important";
const styles = {
	arrowImg: {
		paddingLeft: "9px",
		color: sortCellColor,
	},
	TableSortLabelStyles: {
		root: {
			color: sortCellColor,
		},
		active: {
			color: sortCellColor,
		},
		
		iconDirectionDesc: {
			color: sortCellColor,
		},
		iconDirectionAsc: {
			color: sortCellColor,
		},
		icon: {
			color: sortCellColor,
			height: "14px"
		},
	}
};

export default styles;
