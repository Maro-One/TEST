// @flow

import React from "react";
import TableSortLabel from "@material-ui/core/TableSortLabel";
import UpDownArrowIcon from "../../../images/UpDownArrow.svg";
import makeStyles from "@material-ui/core/styles/makeStyles";
import styles from "./styles";
import withStyles from "@material-ui/core/styles/withStyles";

const useStyles = makeStyles(styles);

type Props = {
	active: boolean;
	direction?: string;
	onClick: Function;
	children: any;
}

const StyledTableSortLabel = withStyles(styles.TableSortLabelStyles)(TableSortLabel);
const CustomTableSortLabel = ({active, direction, onClick, children}: Props) => {
	const classes = useStyles();
	return <StyledTableSortLabel
		active={active}
		direction={direction}
		onClick={onClick}
		hideSortIcon
	>
		{children}
		{!active && <img alt="arrow" className={classes.arrowImg} src={UpDownArrowIcon}/>}
	</StyledTableSortLabel>
};

export default CustomTableSortLabel;
