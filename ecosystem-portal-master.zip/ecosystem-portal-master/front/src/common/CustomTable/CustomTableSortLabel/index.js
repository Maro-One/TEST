import CustomTableSortLabel from "./CustomTableSortLabel";

export default CustomTableSortLabel;
