import { withStyles, TableCell } from "@material-ui/core";
import colors from "../../../utils/colors";

export const ActionTableCell = withStyles(() => ({
	head: {
		backgroundColor: colors.titanWhite,
		color: colors.lynch,
		width: 120,
		height: 40,
		paddingTop: 0,
		paddingBottom: 0
	},
}))(TableCell);