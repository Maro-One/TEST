import React from "react";
import {TableHead, TableRow} from "@material-ui/core";
import CustomTableHeadCell from "../CustomTableHeadCell";
import {ActionTableCell} from "./styles";
import type {THeadType, TActionType} from "../types";
import CustomTableSortLabel from "../CustomTableSortLabel";

type Props = {
	taction?: TActionType,
	thead: THeadType[],
	cellWidth: number,
}
const CustomTableHead = ({thead, taction, cellWidth}: Props) => {
	return (
		<TableHead>
			<TableRow>
				{thead.map((head) => (
					<CustomTableHeadCell cellWidth={cellWidth}  key={head.id}>
						{head.sort ? <CustomTableSortLabel
							active={head.sort.type !== undefined}
							direction={head.sort.type ? head.sort.type: undefined}
							onClick={head.sort.action}
						>
							{head.label}
						</CustomTableSortLabel> :
							<>{head.label}</>
						}
					</CustomTableHeadCell>
				))}
				{taction && <ActionTableCell  style={{
				  width: cellWidth
				}}>{""}</ActionTableCell>}
			</TableRow>
		</TableHead>
	);
};

export default CustomTableHead;
