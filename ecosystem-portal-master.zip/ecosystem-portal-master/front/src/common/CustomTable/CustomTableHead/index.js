import CustomTableHead from "./CustomTableHead";

export default CustomTableHead;