import { makeStyles, withStyles, TableCell, Button } from "@material-ui/core";
import colors from "../../utils/colors";
import fonts from "../../utils/fonts";

export const useStyles = makeStyles({
	tableContainer: {
		borderRadius: 2
	},
	table: {
		minWidth: 650
	}
});

export const StyledTableCell = withStyles(() => ({
	head: {
		backgroundColor: colors.titanWhite,
		color: colors.lynch,
		textTransform: "uppercase",
		fontSize: 12,
		height: 40,
		padding: 0,
		paddingLeft: 16
	}
}))(TableCell);

// New style for the message cell specifically
export const MessageTableCell = withStyles(() => ({
	body: {
		wordWrap: "break-word",
		wordBreak: "break-all",
		whiteSpace: "normal",
		width: "40%", // Wider width for message column
	}
}))(TableCell);

// Style for other smaller columns
export const NarrowTableCell = withStyles(() => ({
	body: {
		width: "15%", // Narrower width for other columns
	}
}))(TableCell);

export const ActionTableCell = withStyles(() => ({
	head: {
		backgroundColor: colors.titanWhite,
		color: colors.lynch,
		width: 120,
		height: 40,
		paddingTop: 0,
		paddingBottom: 0
	}
}))(TableCell);

export const EvenTableCell = withStyles(() => ({
	body: {
		backgroundColor: colors.white
	}
}))(TableCell);

export const OddTableCell = withStyles(() => ({
	body: {
		backgroundColor: colors.whisperWhite
	}
}))(TableCell);

export const StyledButton = withStyles(() => ({
	root: {
		height: 32,
		fontSize: 12,
		color: colors.white,
		backgroundColor: colors.waikawaGray2,
		fontFamily: fonts.robotoBold,
		"&:hover": {
			backgroundColor: colors.limeade
		}
	}
}))(Button);

export const RefuseButton = withStyles(() => ({
	root: {
		height: 32,
		fontSize: 12,
		color: colors.white,
		backgroundColor: colors.lima,
		fontFamily: fonts.robotoBold,
		"&:hover": {
			backgroundColor: colors.limeade
		}
	}
}))(Button);
