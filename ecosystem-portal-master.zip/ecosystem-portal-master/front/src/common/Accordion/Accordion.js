// @flow
/* eslint-disable react/no-multi-comp */

import * as React from "react";
import cx from "classnames";
import {makeStyles} from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Collapse from "@material-ui/core/Collapse/Collapse";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import IconButton from "@material-ui/core/IconButton";

//fix pipeline
const useStyles = makeStyles((theme) => ({
	"root": {
		"height": "70px",
		"backgroundColor": "#ffffff",
		"borderBottom": "1px solid #eef1f3",
		"fontFamily": "Roboto",
		"borderTopRightRadius": "8px",
		"borderTopLeftRadius": "8px"
	},
	"title": {
		"fontFamily": "Roboto",
		"fontSize": "12px",
		"color": "#8092a5",
		"textTransform": "uppercase",
		"margin": "5px 5px 5px 25px"
	},
	"secondeGrid": {"textAlign": "right"},
	"expand": {
		"color": "#7ed321",
		"&:hover": {"color": "#8092a5"},
		"transform": "rotate(0deg)",
		"margin": "5px 10px 5px 5px",
		"transition": theme.transitions.create("transform", {"duration": theme.transitions.duration.shortest})
	},
	"expandOpen": {"transform": "rotate(180deg)"},
	"content": {
		"backgroundColor": "#fff",
		"borderBottomLeftRadius": "8px",
		"borderBottomRightRadius": "8px",
		"minHeight": "65px",
		"padding": "5px 25px"
	}
}));

type Props = {
  children?: React.Node,
  title: string
};

const Accordion = ({
	children,
	title
}: Props) => {
	const [
		open,
		setOpen
		// $FlowFixMe
	] = React.useState(true);
	const classes = useStyles();
	// eslint-disable-next-line
  function handleToggle () {
		setOpen((prevOpen) => !prevOpen);
	}
	return (
		<React.Fragment>
			<Grid
				alignItems="center"
				className={classes.root}
				container
				direction="row"
				justify="space-between"
			>
				<Grid
					item
					xs={4}
				>
					<div className={classes.title}>{title}</div>
				</Grid>
				<Grid
					className={classes.secondeGrid}
					item
					xs={8}
				>
					<IconButton
						aria-expanded={open}
						aria-label="show more"
						className={cx(classes.expand, {[classes.expandOpen]: open})}
						onClick={handleToggle}
					>
						<ExpandMoreIcon fontSize="small" />
					</IconButton>
				</Grid>
			</Grid>
			<Collapse
				in={open}
			>
				<div className={classes.content}>
					{children}
				</div>
			</Collapse>
		</React.Fragment>
	);
};
export default Accordion;
