import { makeStyles } from "@material-ui/core";
import colors from "../../utils/colors";
import fonts from "../../utils/fonts";

const useStyles = makeStyles({
	root: {
		width: 300,
		height: 48,
		backgroundColor: props => props.bgColor,
		color: colors.white,
		fontFamily: fonts.robotoBold,
		fontSize: 16,
		"&:hover": {
			backgroundColor: props => props.bgColor
		}
	}
});

export default useStyles;
