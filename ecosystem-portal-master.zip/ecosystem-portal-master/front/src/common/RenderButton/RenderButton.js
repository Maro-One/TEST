// @flow
import React from "react";
import { Button } from "@material-ui/core";
import useStyles from "./styles";
import colors from "../../utils/colors";

type Props = {
	label: string,
	color: "primary" | "secondary",
	action: Function
};

const RenderButton = ({ label, color, action }: Props) => {
	let bgColor = colors.pistachioGreen;
	if (color === "secondary") {
		bgColor = colors.regentGray;
	}
	const classes = useStyles({ bgColor });
	return (
		<Button
			variant="contained"
			classes={{ root: classes.root }}
			onClick={action}
		>
			{label}
		</Button>
	);
};

export default RenderButton;
