import { makeStyles } from "@material-ui/core/styles";
import colors from "../../utils/colors";

const useStyles = makeStyles({
	link: {
		height: "100%",
		textDecoration: "none",
		color: colors.waikawaGray,
		display: "flex",
		alignItems: "center",
		fontSize: "15px",
		lineHeight: "15px"
	},
	sparator: {
		fontSize: "20px",
		lineHeight: "15px",
		color: colors.periwinkleGray2,
	},
	linkIcon: {
		marginRight: 8,
		lineHeight: "15px",
		marginBottom: "1px",
		color:  colors.periwinkleGray2
	},
	header: {
		height: 67,
		display: "flex",
		alignItems: "center",
		padding: "0 24px",
		borderBottom: `1px solid ${colors.mischka}`,
		color: colors.waikawaGray
	}
});

export default useStyles;
