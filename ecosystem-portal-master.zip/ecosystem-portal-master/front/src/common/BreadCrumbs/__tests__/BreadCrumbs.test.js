import React from "react";
import renderer from "react-test-renderer";
import BreadCrumbs from "../BreadCrumbs";
import {MemoryRouter} from "react-router";

it("BreadCrumbs renders correctly", () => {
	const tree = renderer
		.create(<MemoryRouter>
			<BreadCrumbs items={[{
				label: "label",
				to: "/to",
				fontWeight: "500"
			}]}>
				{"Some children"}
			</BreadCrumbs>
		</MemoryRouter>);
	expect(tree).toMatchSnapshot();
});
