// @flow
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Typography from "@material-ui/core/Typography";
import React from "react";
import { Link } from "react-router-dom";
import useStyles from "./styles";
import HomeIcon from "@material-ui/icons/Home";

type ItemType = {
	label: string,
	to?: string,
	fontWeight?: string
};

type Props = {
	items: ItemType[],
	children?: any
};

const BreadCrumbs = ({ items, children }: Props) => {
	const classes = useStyles();
	return (
		<div className={classes.header}>
			<Breadcrumbs separator={<span className={classes.sparator}>›</span>} aria-label="breadcrumb">
				{items.map((item, index) =>
					item.to ? (
						<Link key={index} to={item.to} className={classes.link}>
							{index === 0 && <HomeIcon className={classes.linkIcon} />}
							{item.label && item.label}
						</Link>
					) : (
						<Typography
							key={index}
							color="textPrimary"
							className={classes.link}
							style={{ fontWeight: item.fontWeight }}
						>
							{item.label}
						</Typography>
					)
				)}
			</Breadcrumbs>
			{children && children}
		</div>
	);
};

export default BreadCrumbs;
