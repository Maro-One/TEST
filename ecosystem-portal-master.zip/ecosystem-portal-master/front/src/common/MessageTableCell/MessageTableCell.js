import React from "react";
import { TableCell, withStyles } from "@material-ui/core";
import PropTypes from "prop-types"; // Make sure PropTypes is imported
import colors from "../../utils/colors";

// Custom cell style for message column
export const MessageTableCell = withStyles(() => ({
	body: {
		whiteSpace: "pre", // To wrap text to multiple lines
		backgroundColor: colors.white,
		padding: 8,
		maxWidth: 300, // Limiting width for better readability
		wordBreak: "break-word",
	},
}))(TableCell);

// MessageTableCell component to render multiline messages
const MessageTableCellComponent = ({ message }) => {
	return (
		<MessageTableCell>
			<strong>{message}</strong>
		</MessageTableCell>
	);
};

// Add propTypes for validation without required
MessageTableCellComponent.propTypes = {
	message: PropTypes.string, // Define 'message' as a string (not required)
};

export default MessageTableCellComponent;
