// @flow

import MessageTableCell from "./MessageTableCell";

export default MessageTableCell;
