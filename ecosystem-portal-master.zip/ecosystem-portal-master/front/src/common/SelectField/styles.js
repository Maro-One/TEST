import fonts from "../../utils/fonts";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import React from "react";
import {makeStyles} from "@material-ui/core/styles";
import colors from "../../utils/colors";

export const selectStyles = {
	container: provided => ({
		width: 170,
		height: 40,
		fontFamily: fonts.robotoRegular,
		fontSize: 14
	}),
	indicatorSeparator: provided => ({
		...provided,
		backgroundColor: "none"
	}),
	menu: provided => ({
		...provided,
		width: "inherit",
		cursor: "pointer",
		position: "relative",
		top: "0%"
	}),
	option: (base, {isSelected}) => ({
		...base,
		"background": "none",
		"color": isSelected
			? "#5BA702"
			: "black",
		":active": {
			...base[":active"],
			"backgroundColor": "#6ea764"
		}
	}),
};

const useStyles = makeStyles({
	arrowDropDownIcon: {
		color: colors.regentGray,
		margin: "0 5px"
	}
});

const DropdownIndicator = () => {
	const classes = useStyles();
	return <ArrowDropDownIcon className={classes.arrowDropDownIcon}/>;
};

export const components = {DropdownIndicator};
