// @flow

import React from "react";
import Select from "react-select";
import { components, selectStyles } from "./styles";

const SelectField = (props: any) => (
	<Select {...props} components={{ ...components }} styles={selectStyles} />
);
export default SelectField;
