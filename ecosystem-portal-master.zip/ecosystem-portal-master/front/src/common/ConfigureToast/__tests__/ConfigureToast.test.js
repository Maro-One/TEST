import React from "react";
import renderer from "react-test-renderer";
import ConfigureToast from "../ConfigureToast";

it("ConfigureToast renders correctly", () => {
	const tree = renderer.create(<ConfigureToast />);
	expect(tree).toMatchSnapshot();
});
