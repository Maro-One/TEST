import {makeStyles} from "@material-ui/core/styles";
import colors from "../../utils/colors";
import fonts from "../../utils/fonts";
import withStyles from "@material-ui/core/styles/withStyles";
import IconButton from "@material-ui/core/IconButton";

const useStyles = makeStyles({
	toast: {
		backgroundColor: colors.cloudBurstBlue,
		color: colors.white,
		fontFamily: fonts.robotoRegular
	}
});
export const StyledIconButton = withStyles({
	root:{
		color: colors.white
	}
})(IconButton);
export default useStyles;
