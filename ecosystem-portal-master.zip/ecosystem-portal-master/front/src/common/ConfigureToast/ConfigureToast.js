// @flow
import React from "react";
import useStyles from "../../Layout/styles";
import {toast} from "react-toastify";
import CloseIcon from "@material-ui/icons/Close";
import {StyledIconButton} from "./styles";

const ConfigureToast = () => {
	const classes = useStyles();
	toast.configure({
		position: toast.POSITION.BOTTOM_RIGHT,
		toastClassName: classes.toast,
		bodyClassName: classes.toastBody,
		closeButton: (
			<StyledIconButton>
				<CloseIcon />
			</StyledIconButton>
		)
	});
	return <></>;
};

export default ConfigureToast;
