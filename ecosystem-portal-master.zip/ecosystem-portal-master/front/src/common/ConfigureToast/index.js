import ConfigureToast from "./ConfigureToast";

export default ConfigureToast;
