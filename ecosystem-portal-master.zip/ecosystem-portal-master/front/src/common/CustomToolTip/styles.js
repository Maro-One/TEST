// @flow

import { makeStyles } from "@material-ui/core/styles";
import colors from "../../utils/colors";
import fonts from "../../utils/fonts";

const useStyles = makeStyles({
	arrow: {
		color: colors.riverBlack
	},
	tooltip: {
		backgroundColor: colors.riverBlack,
		minHeight: 30,
		maxWidth: "max-content",
		borderRadius: 4,
		fontFamily: fonts.robotoRegular,
		fontSize: 14,
		color: colors.white,
		opacity: 1,
		display: "flex",
		alignItems: "center",
		alignContent: "center"
	}
});

export default useStyles;
