// @flow

import React from "react";
import useStyles from "./styles";
import { Tooltip } from "@material-ui/core";

const CustomToolTip = (props: any) => {
	const classes = useStyles();

	return <Tooltip arrow classes={classes} {...props} />;
};

export default CustomToolTip;
