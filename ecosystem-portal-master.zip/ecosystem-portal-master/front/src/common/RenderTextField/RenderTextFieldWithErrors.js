// @flow
import React from "react";
import RenderTextField from "./RenderTextField";
import makeStyles from "@material-ui/core/styles/makeStyles";
import styles, {errorTooltipStyles} from "./styles";
import CustomToolTip from "../CustomToolTip";
import withStyles from "@material-ui/core/styles/withStyles";

const useStyles = makeStyles(styles);

const ErrorTooltip = withStyles(errorTooltipStyles)(CustomToolTip);
type Meta = {
	touched: boolean,
	error: string
}
type Props = {
	autoComplete: string,
	className: string,
	input: any,
	meta: Meta,
	autoFocus: boolean,
	onClickShowPassword: Function,
	showPassword: boolean,
	showPswdIcon: boolean,
	input: { name: string }
};
const RenderTextFieldWithErrors = (props: Props) => {
	const classes = useStyles();
	const {"meta": {touched, error}, "input": {name}} = props;
	if (name === "firstPassword") {
		if (touched && error) {
			return <ErrorTooltip
				title={<div className={classes.rulesBox}
				            interactive>
					Le mot de passe devrait contenir au moins 8 caractères, dont :
					<ul>
						<li>Une lettre majuscule.</li>
						<li>Une lettre minuscule.</li>
						<li>Un caractère spécial (@, $, !, %, *, ?, &).</li>
						<li>Un chiffre.</li>
					</ul>
				</div>}
				arrow={false}
				placement="top"
			>
				<RenderTextField {...props} />
			</ErrorTooltip>
		}
		return <RenderTextField {...props} />;
	}
	return (
		<>
			{touched && error && <div className={classes.errorBox}>{"*"} {error}</div>}
			<RenderTextField {...props} />
		</>);
};

export default RenderTextFieldWithErrors;
