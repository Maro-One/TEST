// @flow
/* eslint-disable no-confusing-arrow */
import * as React from "react";
import {TextField, IconButton, InputAdornment} from "@material-ui/core";
import {Visibility, VisibilityOff} from "@material-ui/icons";

type Props = {
    autoComplete: string,
    className: string,
    input: any,
    meta: any,
    autoFocus: boolean,
    onClickShowPassword: Function,
    showPassword: boolean,
    showPswdIcon: boolean
};

const handleMouseDownPassword = (event) => {
	event.preventDefault();
};

/**
 * Generic function for rendering input
 * @param {object} input params
 * @returns {React.Component} input component
 */
const RenderTextField = function RenderTextField ({
	onClickShowPassword,
	autoComplete,
	autoFocus,
	className,
	input,
	showPassword,
	showPswdIcon,
	"meta": {touched, invalid},
	...custom
}: Props): React$Element<string> {
	return (<TextField
		error={touched && invalid}
		{...input}
		{...custom}
		autoComplete={autoComplete}
		autoFocus={autoFocus}
		className={className}
		fullWidth
		// eslint-disable-next-line react/jsx-sort-props
		InputProps={{
			"endAdornment": (showPswdIcon
				? <InputAdornment position="end">
					<IconButton
						aria-label="toggle password visibility"
						edge="end"
						onClick={onClickShowPassword}
						onMouseDown={handleMouseDownPassword}
					>
						{showPassword
							? <VisibilityOff />
							: <Visibility />}
					</IconButton>
				</InputAdornment>
				: <div />
			)
		}}
		margin="normal"
		required
		variant="outlined"
	/>);
};

export default RenderTextField;
