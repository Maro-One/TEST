import colors from "../../utils/colors";

const styles = {
	errorBox: {
		paddingBottom: "10px",
		color: colors.red
	},
};
export const errorTooltipStyles = (theme) => ({
	tooltip: {
		backgroundColor: colors.whisperWhite,
		color: colors.red,
		boxShadow: theme.shadows[1],
		fontSize: 13,
	}
});

export default styles;
