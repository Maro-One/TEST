// @flow

import React from "react";
import SpinnerNew from "./SpinnerNew";
import {FormattedMessage} from "react-intl";
type Props = {
	status?: "SUCCESS" | "ERROR" | "LOADING";
	children?: any
}

const StatusControllerSpinner = ({status, children}: Props) => {
	switch (status) {
		case "LOADING":
			return <SpinnerNew type={"logo_loading"}/>;
		case "SUCCESS":
			return children ? children : "";
		default:
			return <FormattedMessage
				id="spinner.error.message"
				defaultMessage="Une erreur est survenue lors de la récupération des données."
			/>
			;
	}
};
export default StatusControllerSpinner;
