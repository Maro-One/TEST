import SpinnerNew from "./SpinnerNew";

export default SpinnerNew;
