// @flow

import React from "react";
import type { Node } from "react";
import { TableBody, TableRow } from "@material-ui/core";
import TableCell from "@material-ui/core/TableCell";
import StatusControllerSpinner from "./StatusControllerSpinner";

type Props = {
	dataStatus?: "SUCCESS" | "ERROR" | "LOADING",
	colSpan: number,
	children: Node
};
const TableStatusControllerSpinner = ({
	dataStatus,
	colSpan,
	children
}: Props) => {
	if (dataStatus === "SUCCESS") return children;
	return (
		<TableBody>
			<TableRow>
				<TableCell colSpan={colSpan}>
					<StatusControllerSpinner status={dataStatus} />
				</TableCell>
			</TableRow>
		</TableBody>
	);
};

export default TableStatusControllerSpinner;
