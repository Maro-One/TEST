/* eslint-disable react/no-multi-comp */
// @flow

import * as React from "react";
import { makeStyles, withStyles } from "@material-ui/core/styles";
import CircularProgress from "@material-ui/core/CircularProgress";
import LinearProgress from "@material-ui/core/LinearProgress";
import "./style.scss";
import logoOCP from "../../images/Secondary.png";

const useStylesFacebook = makeStyles({
	root: {
		position: "absolute",
		left: "50%",
		transform: "translateX(-50%)"
	},
	top: { color: "#eef3fd" },
	bottom: {
		color: "#7bcb09",
		animationDuration: "550ms",
		position: "absolute",
		left: 0
	}
});

const FacebookProgress = props => {
	const classes = useStylesFacebook();

	return (
		<div className={classes.root}>
			<CircularProgress
				className={classes.top}
				size={24}
				thickness={4}
				value={100}
				variant="determinate"
				{...props}
			/>
			<CircularProgress
				className={classes.bottom}
				disableShrink
				size={24}
				thickness={4}
				variant="indeterminate"
				{...props}
			/>
		</div>
	);
};

const ColorLinearProgress = withStyles({
	colorPrimary: { backgroundColor: "#7bcb09" },
	barColorPrimary: { backgroundColor: "#EDFFD2" }
})(LinearProgress);

type Props = {
	type?: "circular" | "linear" | "logo_loading"
};

const SpinnerNew = ({ type = "circular" }: Props) => (
	<React.Fragment>
		{type === "circular" && <FacebookProgress />}
		{type === "linear" && (
			<React.Fragment>
				<ColorLinearProgress />
				<div className="logo-container">
					<img className="logo-container__logo" src={logoOCP} alt="OCP Group" />
				</div>
			</React.Fragment>
		)}
		{type === "logo_loading" && (
			<React.Fragment>
				<div className="logo-container">
					<img
						className="logo-container__login"
						src={logoOCP}
						alt="OCP Group"
					/>
				</div>
			</React.Fragment>
		)}
	</React.Fragment>
);

export default SpinnerNew;
