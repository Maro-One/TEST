import { makeStyles } from "@material-ui/core";
import colors from "../../utils/colors";

const useStyles = makeStyles({
	container: {
		width: "max-content",
		padding: "0 10px",
		minHeight: 24,
		fontSize: 12,
		color: colors.goblinGreen,
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		borderRadius: 13
	}
});

export default useStyles;
