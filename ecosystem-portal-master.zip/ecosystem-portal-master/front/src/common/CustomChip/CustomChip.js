// @flow

import React from "react";
import {formatStatus, truncString} from "../../utils/helper";
import CustomToolTip from "../CustomToolTip";
import useStyles from "./styles";
import colors from "../../utils/colors";

type Props = {
    value: string,
    formatFunction?: Function
};

const CustomChip = ({value = "", formatFunction = formatStatus}: Props) => {
	const classes = useStyles();
	let [label, color, fontColor] = formatFunction(value);
	if(!fontColor){
		fontColor = colors.goblinGreen;
	}
	return (
		<CustomToolTip arrow={false} placement="bottom-start" title={label}>
			<div
				className={classes.container}
				style={{backgroundColor: color, color: fontColor}}
			>
				{truncString(label, 20)}
			</div>
		</CustomToolTip>
	);
};

export default CustomChip;
