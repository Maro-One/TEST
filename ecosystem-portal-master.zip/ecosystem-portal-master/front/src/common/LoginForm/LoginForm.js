// @flow

import * as React from "react";
import styles from "./styles";
import { withStyles } from "@material-ui/core/styles";
import { Grid, Container, Typography, CssBaseline } from "@material-ui/core";
import { Button } from "@material-ui/core";
import { Field } from "redux-form";
import RenderTextField from "../RenderTextField";
import SpinnerNew from "../SpinnerNew/SpinnerNew";
import { Link } from "react-router-dom";
import type { HttpResponseType } from "../../store/commonTypes";
import {FormattedMessage} from "react-intl";

type Props = {
	classes: Object,
	handleSubmit: Function,
	error: HttpResponseType,
	showPassword: boolean,
	onClickShowPassword: Function,
	isValid: boolean,
	isProgress: boolean
};
const UNAUTHORIZED = 401;
const FORBIDDEN = 403;

const LoginForm = ({
	classes,
	handleSubmit,
	error,
	showPassword,
	onClickShowPassword,
	isValid,
	isProgress
}: Props) => (
	<Container component="div" maxWidth="xs">
		<Grid container>
			<Grid className={classes.image} item md={6} />
		</Grid>
		<CssBaseline />
		<div className={classes.paper}>
			<Typography className={classes.h1} component="h1" variant="h5">
				<FormattedMessage id="login.form.signin" defaultMessage="Se connecter"/>
			</Typography>
			<Typography className={classes.h2} component="h2" variant="subtitle1">
				<FormattedMessage id="login.form.subtitle" defaultMessage="Veuillez saisir vos identifiants pour vous connecter à la plateforme."/>
			</Typography>

			<form className={classes.form} id="formLogin" onSubmit={handleSubmit}>
				<Field
					autoFocus
					className={
						error === UNAUTHORIZED || error === FORBIDDEN
							? classes.textFieldError
							: classes.textField
					}
					component={RenderTextField}
					label={<FormattedMessage id="login.form.login" defaultMessage="Login" />}
					name="login"
					showPswdIcon={false}
					type="text"
				/>
				{(error === UNAUTHORIZED || error === FORBIDDEN) && (
					<Typography className={classes.h3} component="h4" variant="subtitle2">
						<span className={classes.messageError}>
							<FormattedMessage
								id="login.form.error.message"
								defaultMessage="Login ou Mot de passe non valide"
							/>
						</span>
					</Typography>
				)}
				<Grid container>
					<Grid className={classes.pswLink} item xs={12}>
						<Link
							className={classes.pswLink}
							to="/reset-password"
							variant="body2"
						>
							<FormattedMessage
								id="login.form.password.forgotten"
								defaultMessage="Mot de passe oublié ?"
							/>
						</Link>
					</Grid>
				</Grid>
				<Field
					autoComplete="current-password"
					autoFocus={false}
					className={
						error === UNAUTHORIZED || error === FORBIDDEN
							? classes.textFieldError
							: classes.textField
					}
					component={RenderTextField}
					label={
						<FormattedMessage
							id="login.form.password"
							defaultMessage="Mot de passe"
						/>
					}
					name="password"
					onClickShowPassword={onClickShowPassword}
					showPassword={showPassword}
					showPswdIcon
					type={showPassword ? "text" : "password"}
				/>
				<Button
					className={classes.submit}
					color="primary"
					disabled={!isValid}
					fullWidth
					type="submit"
					variant="contained"
				>
					<FormattedMessage
						id="login.form.connection"
						defaultMessage="CONNEXION"
					/>

				</Button>
			</form>
		</div>
		{isProgress ? (
			<SpinnerNew type={"logo_loading"} />
		) : (
			<div style={{ height: "138px" }} />
		)}
	</Container>
);
export default withStyles(styles)(LoginForm);
