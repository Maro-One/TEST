// @flow

import backgroundImg from "../../images/logo-Login.svg";

const styles = {
	"container": {
		"top": "50%",
		"left": "50%",
		"position": "absolute",
		"margin": "0",
		"transform": "translate(-50%, -50%)",
		"maxWidth": "500px"
	},
	"image": {
		height: 84,
		"backgroundImage": `url(${backgroundImg})`,
		"backgroundRepeat": "no-repeat",
		"backgroundSize": "100% 100%",
		"backgroundPosition": "center",
		"position": "relative"
	},
	"h1": {
		"fontWeight": "bold",
		"paddingBottom": "16px"
	},
	"h2": {"paddingBottom": "16px"},
	"paper": {
		"marginTop": "50px",
		"display": "flex",
		"flexDirection": "column"
	},
	"form": {
		"width": "100%",
		"marginTop": "8px"
	},
	"textField": {
		"& label.Mui-focused": {"color": "green"},
		"& .MuiInput-underline:after": {"borderBottomColor": "green"},
		"& .MuiOutlinedInput-root": {"&.Mui-focused fieldset": {"borderColor": "green"}},
		"&.MuiFormControl-marginNormal": {
			"marginTop": "4px",
			"marginBottom": "16px"
		}
	},
	"pswLink": {
		"textAlign": "right",
		"color": "#9ea4b3",
		"&:hover": {"color": "#008000"}
	},
	"submit": {
		"margin": "24px 0px 16px",
		"backgroundColor": "#7bcb09",
		"&:hover": {"backgroundColor": "#008000"}
	},
	"messageError" : {"color": "red"},
	"textFieldError": {
		"& label.Mui-focused": {"color": "red"},
		"& .MuiInput-underline:after": {"borderBottomColor": "red"},
		"& .MuiOutlinedInput-root": {"&.Mui-focused fieldset": {"borderColor": "red"}},
		"&.MuiFormControl-marginNormal": {
			"marginTop": "4px",
			"marginBottom": "16px"
		},
		"& .MuiOutlinedInput-notchedOutline": {"borderColor": "red"},
		"& .MuiInputLabel-outlined.MuiInputLabel-shrink": {"color": "red"}
	}
};

export default styles;
