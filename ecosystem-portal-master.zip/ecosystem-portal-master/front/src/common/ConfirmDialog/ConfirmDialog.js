import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import withStyles from "@material-ui/core/styles/withStyles";
import {buttonStyles} from "./styles";
import FormattedMessage from "react-intl/lib/components/message";

type Props =  {
	handleAccept: Function,
	handleClose: Function,
	isOpen: boolean,
	dialogDesc : any,
	dialogTitle: any,
	acceptLabel: any,
	acceptDisabled?: boolean
}
const StyledButton = withStyles(buttonStyles)(Button);
export default function ConfirmDialog({handleAccept, handleClose, isOpen, dialogTitle, dialogDesc, acceptLabel, acceptDisabled = false}:Props) {
	return (
		<Dialog
			open={isOpen}
			maxWidth={"sm"}
			fullWidth={true}
			onClose={handleClose}
			aria-labelledby="alert-dialog-title"
			aria-describedby="alert-dialog-description"
		>
			<DialogTitle id="alert-dialog-title">{dialogTitle}</DialogTitle>
			<DialogContent>
				<DialogContentText id="alert-dialog-description">
					{dialogDesc}
				</DialogContentText>
			</DialogContent>
			<DialogActions>
				<Button onClick={handleClose} color="default">
					<FormattedMessage
						id="confirm.dialog.abort"
						defaultMessage="Annuler"
					/>
				</Button>
				<StyledButton disabled={acceptDisabled} onClick={handleAccept} variant="contained" color="primary" autoFocus>
					{acceptLabel}
				</StyledButton>
			</DialogActions>
		</Dialog>
	);
}
