import colors from "../../utils/colors";

export const buttonStyles = {
	root: {
		backgroundColor: colors.lima,
		"&:hover": {
			backgroundColor: colors.limeade,
		}
	}
};
