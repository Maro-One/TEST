// @flow
import * as React from "react";
import PublishIcon from "@material-ui/icons/Publish";
import {withStyles} from "@material-ui/core";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";
type Props = {
  input: any;
  haveFile: any;
  inputkey: any;
}
const adaptFileEventToValue = (delegate) => (event) => delegate(event);

const InputFileComponent = ({
	"input": {onChange},
	haveFile, inputkey,
	...props
}: Props) => (
	<React.Fragment>
		<Tooltip
			placement="top"
			title="import funding request file"
		>
			<StyledButton disabled={haveFile}>
				<label
					htmlFor="file"
					style={{
						"width": "100%",
						"height": "100%"
					}}
				>
					<PublishIcon
						style={{"verticalAlign": "middle"}}
					/>
				</label>
			</StyledButton>
		</Tooltip>
		<input
			id="file"
			key={inputkey}
			onChange={adaptFileEventToValue(onChange)}
			style={{"display": "none"}}
			type="file"
			{...props}
		/>
	</React.Fragment>);

const StyledButton = withStyles({
	"root": {
		"color": "#8092a5",
		"borderRadius": "4px",
		"border": "solid 1px #dae0e6",
		"padding": 0,
		"&:hover": {
			"color": "#fff",
			"background-color": "#7bcb09"
		},
		"&:disabled": {
			"color": "#8092a5",
			"borderRadius": "4px",
			"border": "solid 1px #dae0e6",
			"background-color": "unset"
		}
	},
	"label": {"line-height": "34px"}
})(Button);

export default InputFileComponent;
