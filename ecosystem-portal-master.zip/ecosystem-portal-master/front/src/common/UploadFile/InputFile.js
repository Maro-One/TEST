// @flow
import React from "react";
import {Field} from "redux-form";
import InputFileComponent from "./InputFileComponent";

type Props = {
  haveFile: any;
  fieldName: any;
  handleFileUpload: any;
  inputkey: any;
}
const InputFile = ({haveFile, fieldName, handleFileUpload, inputkey}: Props) => (
	<Field
		component={InputFileComponent}
		haveFile={haveFile}
		inputkey={inputkey}
		name={fieldName}
		onChange={handleFileUpload}
	/>);


export default InputFile;
