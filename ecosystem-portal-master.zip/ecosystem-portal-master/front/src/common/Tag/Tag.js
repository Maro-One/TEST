// @flow
import React from "react";
import useStyles from "./styles";
import colors from "../../utils/colors";

type Props = {
    days: number
}

const Tag = ({days}: Props) => {
	let value = Math.floor(days)+"Jrs";
	let bgColor = colors.catskillWhite;
	let color = "#112B50";
	if (days < 0) {
		value = " +"+Math.abs(Math.floor(days + 1))+"Jrs";
		bgColor = "#FFDEDE";
		color = "#FF402C";
	}
	const classes = useStyles({bgColor, color});
	return (
		<div className={classes.container}>
			{value}
		</div>
	);
};

export default Tag;