import { makeStyles } from "@material-ui/core";

const useStyles = makeStyles({
	container: {
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		color: props => props.color,
		backgroundColor: props => props.bgColor,
		marginLeft: 8,
		height: 22,
		minWidth: 10,
		fontSize: 12,
		fontFamily: "Roboto-Regular",
		padding: "0 9px",
		borderRadius: 5
	}
});

export default useStyles;