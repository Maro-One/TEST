import { makeStyles } from "@material-ui/core/styles";
import Logo from "../../../images/logo_header.svg";

const useStyles = makeStyles(theme => ({
	root: {
		height: 80,
		background: "linear-gradient(225deg, #232E51 0%, #171E3A 100%)",
		display: "flex",
		justifyContent: "center"
	},
	content: {
		width: 1440,
		padding: "0 32px",
		display: "flex",
		justifyContent: "space-between",
		alignItems: "center",
		color: "white"
	},
	searchContainer: {
		width: 440,
		[theme.breakpoints.down("md")]: {
			width: "30%"
		}
	},
	logo: {
		width: 154,
		height: 48,
		background: `url(${Logo})`
	}
}));

export default useStyles;
