import React from "react";
import useStyles from "./styles";
import ProfileContainer from "../Profile/ProfileContainer";
import Search from "../../../pages/Search";
import {Link} from "react-router-dom";

const NavBar = () => {
	const classes = useStyles();
	return (
		<div className={classes.root}>
			<div className={classes.content}>
				<Link to={"/"}><div className={classes.logo} /></Link>
				<div className={classes.searchContainer}>
					<Search />
				</div>
				<ProfileContainer />
			</div>
		</div>
	);
};

export default NavBar;
