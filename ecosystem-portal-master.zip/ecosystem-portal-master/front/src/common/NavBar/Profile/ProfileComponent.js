// @flow

import { IconButton } from "@material-ui/core";
import React from "react";
import useStyles from "./styles";
import {useDispatch, useSelector} from "react-redux";
import {logUserOut} from "../../../pages/LoginPage/actions";

const ProfileComponent = () => {
	const classes = useStyles();
	const dispatch = useDispatch();
	const user = useSelector(state => state.user);
	return (
		<div className={classes.container}>
			<div className={classes.profile}>
				<span>{`${user.firstName} ${user.lastName}`}</span>
				<span className={classes.organism}>{user.agency}</span>
			</div>
			<IconButton onClick={()=> dispatch(logUserOut)}>
				<span className={classes.iconLogout} />
			</IconButton>
		</div>
	);
};

export default ProfileComponent;