// @flow

import { makeStyles } from "@material-ui/core/styles";
import fonts from "../../../utils/fonts";
import IconLogout from "../../../images/icon_deconnexion.svg";

const useStyles = makeStyles(theme => ({
	container: {
		minWidth: 170,
		height: 55,
		display: "flex",
		justifyContent: "space-between",
		alignItems: "center",
		fontFamily: fonts.roboto,
		textTransform: "uppercase"
	},
	profile: {
		display: "flex",
		flexDirection: "column",
		alignItems: "flex-end"
	},
	organism: {
		opacity: 0.7
	},
	iconLogout: {
		width: 32,
		height: 32,
		background: `url(${IconLogout})`
	}
}));

export default useStyles;
