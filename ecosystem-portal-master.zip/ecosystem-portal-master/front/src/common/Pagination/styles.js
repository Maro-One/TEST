import fonts from "../../utils/fonts";
import { withStyles, TablePagination, makeStyles } from "@material-ui/core";

export const useStyles = makeStyles({
	container: {
		width: "max-content"
	}
});

export const StyledTablePagination = withStyles({
	root: {
		width: "max-content"
	},
	caption: {
		border: "1px solid #D4D8EA",
		boxSizing: "border-box",
		borderRadius: "6px",
		height: "36px",
		backgroundColor: "#FAFAFC",
		lineHeight: "36px",
		padding: "0 10px",
		margin: "0 10px",
		color: "#333D66",
		fontFamily: fonts.robotoRegular,
		fontSize: "14px"
	}
})(TablePagination);

export const pageActionsStyles = {
	button: {
		width: "40px",
		border: "1px solid #CCD1E5",
		backgroundColor: "#FFFFFF",
		"&:hover": {
			border: "1px solid #CCD1E5",
			backgroundColor: "#CCCCCC"
		}
	}
};
