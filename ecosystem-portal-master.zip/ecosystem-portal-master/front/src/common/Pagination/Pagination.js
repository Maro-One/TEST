// @flow

import React from "react";
import LabelDisplayRows from "./LabelDisplayRows";
import PageActions from "./PageActions";
import { StyledTablePagination, useStyles } from "./styles";

type Props = {
	perPage?: number,
	count: number,
	page: number,
	onChangePage: ({ page: number }) => void
};

const Pagination = ({
	perPage = 10,
	count,
	page,
	onChangePage,
	...props
}: Props) => {
	const customOnChangePage = (event, page) => {
		onChangePage(page);
	};
	const classes = useStyles();
	return (
		<div className={classes.container}>
			<StyledTablePagination
				component={"div"}
				rowsPerPageOptions={[]}
				count={count}
				labelDisplayedRows={LabelDisplayRows}
				ActionsComponent={PageActions}
				rowsPerPage={perPage}
				page={page}
				onChangePage={customOnChangePage}
				{...props}
			/>
		</div>
	);
};
export default Pagination;
