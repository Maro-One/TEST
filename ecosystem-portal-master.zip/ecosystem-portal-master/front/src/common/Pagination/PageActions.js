// @flow
import React from "react";
import ButtonGroup from "@material-ui/core/ButtonGroup";
import {KeyboardArrowLeft, KeyboardArrowRight} from "@material-ui/icons";
import Button from "@material-ui/core/Button";
import makeStyles from "@material-ui/core/styles/makeStyles";
import {pageActionsStyles} from "./styles";
import {TablePaginationActionsProps} from "@material-ui/core/TablePagination/TablePaginationActions";

const useStyles = makeStyles(pageActionsStyles);

const PageActions = ({count, page, onChangePage, rowsPerPage, disabled}: TablePaginationActionsProps) => {
	const classes = useStyles();
	const lastPage = count <=  rowsPerPage ? 0 : Math.ceil(count / rowsPerPage) - 1; // Zero indexed
	const disableNext = disabled || page === lastPage;
	const disablePrev = disabled || page === 0;
	return (
		<ButtonGroup
			className={classes.group}
			color="primary"
			aria-label="outlined primary button group"
		>
			<Button
				className={classes.button}
				onClick={(e)=>onChangePage(e, page-1)}
				disabled={disablePrev}
				aria-label="Previous Page"
			>
				<KeyboardArrowLeft />
			</Button>
			<Button
				className={classes.button}
				onClick={(e)=>onChangePage(e, page+1)}
				disabled={disableNext}
				aria-label="Next Page"
			>
				<KeyboardArrowRight />
			</Button>
		</ButtonGroup>);
};

export default PageActions;
