// @flow

type Props = {
	from: number,
	to: number,
	count: number,
	page: number
};
const LabelDisplayRows = ({ from, to, count, page }: Props) =>
	`${from} - ${to} of ${count}`;

export default LabelDisplayRows;
