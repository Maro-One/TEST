// @flow

import React from "react";
import useStyles from "./styles";
import FormattedMessage from "react-intl/lib/components/message";

const Footer = () => {
	const classes = useStyles();
	const current_year = new Date().getFullYear();
	return (
		<div className={classes.footer}>
			<FormattedMessage
				id="footer.message"
				values={{current_year}}
				defaultMessage="&#9400; OCP S.A {current_year} - Tous droits réservés"
			/>
		</div>
	);
};

export default Footer;
