//@flow

import { makeStyles } from "@material-ui/core/styles";
import colors from "../../utils/colors";

const useStyles = makeStyles({
	footer: {
		flexShrink: 0,
		textAlign: "center",
		height: 25,
		color: colors.lynch,
		marginBottom: 48
	}
});

export default useStyles;
