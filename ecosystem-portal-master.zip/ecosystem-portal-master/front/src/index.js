import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import * as React from "react";
import ReactDOM from "react-dom";
import store, {persistor} from "./store";
import {Provider} from "react-redux";
import routes from "./routes";
import "./style/index.scss";
import {Router} from "react-router";
import history from "./utils/history";
import {PersistGate} from "redux-persist/integration/react";
import ConnectedIntlProvider from "./pages/ConnectedIntlProvider";
import "react-toastify/dist/ReactToastify.css";
import ConfigureToast from "./common/ConfigureToast";
import piwik from "./config/piwik";

const piwikHistory = piwik.connectToHistory(history);

const App = (
	<Provider store={store}>
		<PersistGate loading="loading..." persistor={persistor}>
			<ConnectedIntlProvider >
				<ConfigureToast/>
				<Router history={piwikHistory}>{routes}</Router>
			</ConnectedIntlProvider>
		</PersistGate>
	</Provider>
);

ReactDOM.render(App, document.getElementById("root"));
