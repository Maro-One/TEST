// @flow
import * as React from "react";
import {Route, Switch} from "react-router";
import Layout from "./Layout";
import LoginPageContainer from "./pages/LoginPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";
import ChangePasswordPage from "./pages/ResetPasswordPage/container/ChangePasswordPage";

const routes = (
	<Switch>
		<Route path="/login" component={LoginPageContainer}/>
		<Route path="/reset-password" component={ResetPasswordPage}/>
		<Route path="/new-password/:token" component={ChangePasswordPage}/>
		<Route path="/" component={Layout}/>
	</Switch>
);

export default routes;
