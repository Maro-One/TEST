// @flow
import {takeLatest} from "redux-saga/effects";
import type {importFileFormSubmit} from "../actions/action";
import {IMPORT_USERS_FILE_FORM_SUBMIT, importFileError, importFileSuccess} from "../actions/action";
import {callEndpoint} from "../../../store/sagas/callEndpointSaga";

/**
 * Listens for the submit attachment action and trigger the request flow, cancelling the previous
 * request if it was still ongoing.
 * @return {null} nothing
 */
const usersImport =
	function* usersImport({file}: importFileFormSubmit): Generator<any, void, any> {
		const formData = new FormData();
		if (file !== null) {
			formData.append("file", file);
		}
		yield* callEndpoint(
			{
				"url": "api/import-users",
				"data": formData,
				"method": "post"
			},
			{
				successActionCreator: importFileSuccess,
				errorActionCreator: importFileError
			}
		);
	};


/**
 * Listens for the get item groups action and trigger the request flow, cancelling the previous
 * request if it was still ongoing.
 * @return {null} nothing
 */
export default function* (): Generator<any, void, any> {
	yield takeLatest(IMPORT_USERS_FILE_FORM_SUBMIT, usersImport);
}
