// @flow

import React from "react";
import {connect} from "react-redux";

import {change} from "redux-form";
import InputFile from "../../../common/UploadFile";
import { isNotEmpty } from "../../../utils/helper";
import {INPUT_NAME} from "../actions/action";

type Props = {
	fieldName: string;
	fileAttchment: any;
	inputkey: number
}
/* eslint-disable react/no-set-state */
const UploadFileContainer = ({fieldName, fileAttchment, inputkey}: Props) => (
	
	<InputFile
		fieldName={fieldName}
		handleFileUpload={change}
		haveFile={isNotEmpty(fileAttchment) && isNotEmpty(fileAttchment.values) && isNotEmpty(fileAttchment.values[INPUT_NAME])}
		inputkey={inputkey}
	/>
);

const mapStateToProps = (state) => ({"fileAttchment": state.form.newAttachment});
const mapDispatchToProps = {"restFormFile": change};

export default connect(mapStateToProps, mapDispatchToProps)(UploadFileContainer);

