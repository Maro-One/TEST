// @flow
import * as React from "react";
import AdminImport from "../components/AdminImport";
import {change, reduxForm} from "redux-form";
import {connect} from "react-redux";
import {IMPORT_USERS_FILE_FORM_DELETE, importFileFormSubmit, INPUT_NAME, STORE_NAME} from "../actions/action"
import FormattedMessage from "react-intl/lib/components/message";
import CustomTable from "../../../common/CustomTable";

type Props = {
	restFormFile: Function,
	importFileFormSubmit: Function,
	deleteResponse: Function,
	importUsersFile: any,
	erorr: any,
	status: "SUCCESS" | "ERROR" | "LOADING" | "",
	importResponse: any,
};
const showInStatus = (status) => (status !== "" && status !== "ERROR");
const AdminImportContainer = ({
	restFormFile,
	importUsersFile,
	importFileFormSubmit,
	importResponse,
	deleteResponse,
	erorr, status
}: Props) => {
	
	
	const handleOnSubmit = () => {
		importFileFormSubmit(
			((importUsersFile !== undefined && importUsersFile.values !== undefined && importUsersFile.values[INPUT_NAME])
				? importUsersFile.values[INPUT_NAME][0]
				: null),
		);
	}
	const thead = [
		{
			id: "login", label:
				<FormattedMessage
					id="login"
					defaultMessage="login"
				/>
		},
		{
			id: "message", label:
				<FormattedMessage
					id="message"
					defaultMessage="Message"
				/>
		},
		{
			id: "saved", label:
				<FormattedMessage
					id="saved"
					defaultMessage="Saved"
				/>
			
		},
	];
	const trows = importResponse && importResponse.map((i) => ({
		login: <strong>{i.login}</strong>,
		message: <strong>{i.message}</strong>,
		saved: <strong>{i.saved ? <FormattedMessage
			id="saved"
			defaultMessage="saved"
		/> :
			<FormattedMessage
				id="not.saved"
				defaultMessage="not saved"
			/>}</strong>,
	}));
	return (
		<React.Fragment>
			<AdminImport
				onSubmit={handleOnSubmit}
				importUsersFile={importUsersFile}
				restFormFile={restFormFile}
				deleteResponse={deleteResponse}
			
			/>
			<div>
				{showInStatus(status) && <CustomTable dataStatus={status} thead={thead} trows={trows}/>}
				{erorr &&
				<FormattedMessage defaultMessage="une erreur est survenue. veuillez réessayer plus tard"
				                  id="import.file.error"
				/>
				
				}
			</div>
		</React.Fragment>
	);
};

const mapStateToProps = (store) => ({
	"importUsersFile": store.form.importFile,
	"importResponse": store.usersImport.response,
	"erorr": store.usersImport.error,
	"status": store.usersImport.status
	
});

const mapDispatchToProps = {
	"restFormFile": change,
	"importFileFormSubmit": importFileFormSubmit,
	"deleteResponse": () => ({type: IMPORT_USERS_FILE_FORM_DELETE})
};

const ConnectedAdminImportContainer = connect(mapStateToProps, mapDispatchToProps)(AdminImportContainer);
export default reduxForm({"form": STORE_NAME})(ConnectedAdminImportContainer);
