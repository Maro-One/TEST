import * as React from "react";
import UploadFileContainer from "../containers/UploadFileContainer";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import {makeStyles} from "@material-ui/core";
import SendIcon from "@material-ui/icons/Send";
import {CheckFileValidity, isNotEmpty} from "../../../utils/helper";
import {INPUT_NAME, STORE_NAME, ToKB} from "../actions/action";
import style from "./style";
import {StyledDeletIcon, StyledIconButton, StyledSendButton} from "./Buttons";
import { FormattedMessage } from "react-intl";

type Props = {
	importUsersFile: any,
	fileNotValid: boolean,
	fileName: string,
	restFormFile: Function,
	onSubmit: Function,
	deleteResponse: Function,
	change: Function
};

const useStyles = makeStyles(style);

const AdminImport = ({
	importUsersFile,
	fileName = INPUT_NAME,
	restFormFile,
	onSubmit,
	change,
	deleteResponse
}: Props) => {
	const classes = useStyles();
	const [enable, setEnable] = React.useState(false);
	
	const [key, setKey] = React.useState("");
	
	const handleSubmit = () => {
		onSubmit();
		setEnable(true)
	};
	const deleteFile = () => () => {
		restFormFile(STORE_NAME, fileName, null);
		setKey(Math.random());
		deleteResponse();
		setEnable(false)
		
	};
	
	const [fileNotValid,
		setFileNotValid
		// $FlowFixMe
	] = React.useState(false);

	React.useEffect(()=>{
		setFileNotValid(!isNotEmpty(importUsersFile) ||
		!isNotEmpty(importUsersFile.values) ||
		!isNotEmpty(importUsersFile.values[fileName]) ||
			CheckFileValidity(importUsersFile.values[fileName][0]))
	},[fileName, importUsersFile]);
	return <React.Fragment>
		<Paper
			className={classes.root}
			elevation={0}
		>
			<form autoComplete="off">
				<Grid
					alignItems="center"
					container
					justify="space-between"
				>
					<Grid
						item
						xs={1}
					>
						<UploadFileContainer
							change={change}
							fieldName={fileName}
							formName="users_request"
							inputkey={key}
						/>
					</Grid>
				</Grid>
			
			</form>
		</Paper>
		{isNotEmpty(importUsersFile)
		&& isNotEmpty(importUsersFile.values)
		&& isNotEmpty(importUsersFile.values[fileName]) &&
		(<React.Fragment>
			
			<Paper
				className={classes.root}
				elevation={0}
			>
				<Grid
					alignItems="center"
					container
				>
					<Grid
						item
						xs={6}
					>
						<span style={{"color": "#7bcb09"}}> {importUsersFile.values[fileName][0].name} </span>
						<span
							style={{"color": "#8092a5"}}> {`${(importUsersFile.values[fileName][0].size / ToKB)
								.toFixed(1)} (KB)`}
        				</span>
					</Grid>
					<Grid
						item
						style={{"textAlign": "right"}}
						xs={6}
					>
						<StyledIconButton
							aria-hidden="true"
							aria-label="delete"
							onClick={deleteFile()}
							size="small"
						>
							<StyledDeletIcon/>
						</StyledIconButton>
					</Grid>
				</Grid>
				{fileNotValid && <div style={{"color": "red"}}>
					<FormattedMessage defaultMessage="error" id="input.file.error"/>
				</div>}
			</Paper>
			<Paper
				className={classes.root}
				elevation={0}
			>
				<Grid
					className={classes.centerContainer}
					item
					xs={1}
				>
					<StyledSendButton
						disabled={enable || fileNotValid}
						id="send"
						onClick={handleSubmit}
					>
						<SendIcon/>
					</StyledSendButton>
				</Grid>
			</Paper>
		</React.Fragment>)}
	</React.Fragment>
	
};

export default AdminImport;

