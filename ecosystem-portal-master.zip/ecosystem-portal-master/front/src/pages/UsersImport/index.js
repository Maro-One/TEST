import ImportUsers from "./containers/AdminImportContainer";

export default ImportUsers;
