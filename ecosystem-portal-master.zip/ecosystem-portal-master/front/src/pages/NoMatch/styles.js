import { makeStyles } from "@material-ui/core";
import ErrorIcon from "../../images/icon_404.svg";
import fonts from "../../utils/fonts";

const useStyles = makeStyles({
	container: {
		display: "flex",
		flexDirection: "column",
		justifyContent: "center",
		alignItems: "center",
		minHeight: 500
	},
	iconGrid: {
		width: 660,
		height: 330,
		background: `url(${ErrorIcon})`,
		backgroundSize: "cover",
		backgroundRepeat: "no-repeat",
		backgroundPosition: "center"
	},
	title: {
		fontFamily: fonts.robotoBold,
		fontSize: 26
	},
	subtitle: {
		fontFamily: fonts.robotoRegular,
		fontSize: 16
	}
});

export default useStyles;
