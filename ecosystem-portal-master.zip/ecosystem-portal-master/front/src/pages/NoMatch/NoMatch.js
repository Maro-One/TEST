import React from "react";
import { Grid, Typography } from "@material-ui/core";
import useStyles from "./styles";
import RenderButton from "../../common/RenderButton";
import { useHistory } from "react-router";
import {FormattedMessage} from "react-intl";

const NoMatch = () => {
	const classes = useStyles();
	const history = useHistory();
	const pushToHomePage = () => history.push("/");
	return (
		<Grid container spacing={2} classes={{ container: classes.container }}>
			<Grid item classes={{ item: classes.iconGrid }} />
			<Grid item>
				<Typography variant="h5" classes={{ h5: classes.title }}>
					<FormattedMessage
						id="nomatch.error"
						defaultMessage="Cette page contient une erreur ou n'existe pas"
					/>
				</Typography>
			</Grid>
			<Grid item>
				<Typography
					variant="subtitle1"
					classes={{ subtitle1: classes.subtitle }}
				>
					<FormattedMessage
						id="nomatch.message"
						defaultMessage="Nous vous invitons à revenir à la page d'accueil"
					/>
				</Typography>
			</Grid>
			<Grid item>
				<RenderButton
					label={<FormattedMessage
						id="nomatch.message1"
						defaultMessage="Retour à l'accueil"
					/>}
					color="primary"
					action={pushToHomePage}
				/>
			</Grid>
		</Grid>
	);
};

export default NoMatch;
