// @flow

import backgroundImg from "../../../images/login.png";
import logoIcon from "../../../images/icon_group.svg";

const styles = {
	"root": {
		"height": "100vh",
		"position": "relative"
	},
	"image": {
		"backgroundImage": `url(${backgroundImg})`,
		"backgroundRepeat": "no-repeat",
		"backgroundSize": "100% 100%",
		"backgroundPosition": "center",
		"position": "relative"
	},
	"logo": {
		"position": "absolute",
		"background-size": "75%",
		"backgroundColor": "white",
		"borderRadius": "8px",
		"backgroundImage": `url(${logoIcon})`,
		"backgroundRepeat": "no-repeat",
		"backgroundPosition": "center",
		"width": "76px",
		"height": "84px",
		"marginTop": "20px",
		"marginLeft": "20px"
	},
	"paper": {
		"position": "relative",
		"margin": "32px",
		"display": "flex",
		"flexDirection": "column",
		"alignItems": "center"
	},
	"avatar": {
		"margin": "8px",
		"backgroundColor": "gray"
	},
	"form": {
		"width": "100%",
		"marginTop": "8px"
	},
	"submit": {"margin": "24px 0px 16px"},
	"footer": {
		"font-family": "Lato-Bold",
		"color": "#4a4a4a",
		"opacity": ".61",
		"position": "fixed",
		"bottom": "20px",
		"right": "40px"
	}
};

export default styles;
