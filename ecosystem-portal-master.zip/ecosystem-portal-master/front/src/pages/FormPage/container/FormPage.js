// @flow

import * as React from "react";
import styles from "./styles";
import {withStyles} from "@material-ui/core/styles";
import {Grid, CssBaseline, Paper} from "@material-ui/core";
import {FormattedMessage} from "react-intl";


type Props = {
  children: any,
    classes: Object
};
const current_year = new Date().getFullYear();

const FormPage = ({children, classes}: Props) => (
	<Grid
		className={classes.root}
		component="main"
		container
	>
		<CssBaseline />
		<Grid
			className={classes.image}
			item
			md={3}
			sm={false}
			xs={false}
		>
		</Grid>

		<Grid
			component={Paper}
			container
			direction="column"
			elevation={6}
			item
			justify="center"
			md={9}
			sm={12}
			square
			xs={12}
		>
			<div className={classes.paper}>
				{children}
			</div>
			<div className={classes.footer}>
				<FormattedMessage
					 id="footer.message"
					 values={{current_year}}
					//evol
					 defaultMessage="© OCP S.A {current_year} - Tous droits réservés"
				/>
			</div>
		</Grid>
	</Grid>
);

export default withStyles(styles)(FormPage);
