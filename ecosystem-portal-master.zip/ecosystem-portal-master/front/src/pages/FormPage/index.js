import FormPage from "./container/FormPage";

export default FormPage;
