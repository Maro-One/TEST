// @flow

import React from "react";
import SearchIcon from "@material-ui/icons/Search";
import { components } from "react-select";
import colors from "../../utils/colors";
import fonts from "../../utils/fonts";
import { makeStyles } from "@material-ui/core";
import type { ElementConfig } from "react";

const useStyles = makeStyles({
	noOptionsContainer: {
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		textAlign: "center",
		height: 150,
		width: "100%",
		color: colors.cello,
		fontSize: 18,
		fontFamily: fonts.robotoMedium
	}
});

export const DropdownIndicator = (
	props: ElementConfig<typeof components.DropdownIndicator>
) => {
	return (
		<components.DropdownIndicator {...props}>
			<SearchIcon />
		</components.DropdownIndicator>
	);
};

export const NoOptionsMessage = (
	props: ElementConfig<typeof components.DropdownIndicator>
) => {
	const classes = useStyles();
	return (
		<components.DropdownIndicator {...props}>
			<div className={classes.noOptionsContainer}>
				Désolé, nous n&apos;avons trouvé aucun résultat
			</div>
		</components.DropdownIndicator>
	);
};

export const customStyles = {
	indicatorsContainer: (provided: Object) => ({
		...provided,
		color: colors.cello
	}),
	container: (provided: Object) => ({
		...provided,
		//width: 440,
		width: "100%",
		height: 40
	}),
	control: (provided: Object) => ({
		...provided,
		height: "100%"
	}),
	dropdownIndicator: (provided: Object) => ({
		...provided,
		color: colors.cello,
		"&:hover": {
			color: colors.cello
		}
	}),
	indicatorSeparator: (provided: Object) => ({
		...provided,
		display: "none"
	}),
	option: (provided: Object) => ({
		...provided,
		color: colors.cello
	})
};
