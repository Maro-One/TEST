import {
	SEARCH_SUPPLIER,
	SEARCH_SUPPLIER_SUCCESS,
	SEARCH_SUPPLIER_ERROR
} from "./constants";
import type { SearchActionTypes, SelectOptionType } from "./actionTypes";

export const searchSupplier = (value: string): SearchActionTypes => ({
	type: SEARCH_SUPPLIER,
	payload: value
});

export const searchSupplierSuccess = (
	searchOptions: Array<SelectOptionType>
): SearchActionTypes => ({
	type: SEARCH_SUPPLIER_SUCCESS,
	payload: searchOptions
});

export const searchSupplierFailed = (error: string): SearchActionTypes => ({
	type: SEARCH_SUPPLIER_ERROR,
	payload: error
});
