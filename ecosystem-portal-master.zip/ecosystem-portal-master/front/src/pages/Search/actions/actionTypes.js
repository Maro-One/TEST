import type { ActionWithPayloadType } from "../../../store/actions/types";
import type { SupplierType } from "../../../pages/SupplierDetailPage/types";

export type SelectOptionType = {
	value: string,
	lable: string
};

export type SearchSupplierActionType = ActionWithPayloadType<
	"SEARCH_SUPPLIER",
	string
>;

type SearchSupplierSuccessActionType = ActionWithPayloadType<
	"SEARCH_SUPPLIER_SUCCESS",
	{ options: Array<SupplierType> }
>;

type SearchSupplierFailedActionType = ActionWithPayloadType<
	"SEARCH_SUPPLIER_ERROR",
	string
>;

export type SearchActionTypes =
	| SearchSupplierActionType
	| SearchSupplierSuccessActionType
	| SearchSupplierFailedActionType;
