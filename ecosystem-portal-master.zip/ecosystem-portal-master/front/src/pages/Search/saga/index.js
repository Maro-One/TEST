import { takeLatest } from "redux-saga/effects";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";
import { searchSupplierSuccess, searchSupplierFailed } from "../actions";
import { SEARCH_SUPPLIER } from "../actions/constants";
import { SearchSupplierActionType } from "../actions/actionTypes";
import type { SupplierType } from "../../../pages/SupplierDetailPage/types";
import getUserRole from "../../../store/selectors/getUserRole";
import {select} from "redux-saga/effects";
import {ROLE_BUYER} from "../../../utils/UserRole";

function* handleSearchSupplier(action: SearchSupplierActionType): Saga<void> {
	const userRole: UserRole = yield select(getUserRole);
	let SEARCH_API = "/api/supplier/search-approved-funding-applicants";
	if(userRole === ROLE_BUYER){
		SEARCH_API = "/api/supplier/search-all-funding-applicants"
	}
	yield* callEndpoint(
		{
			url: SEARCH_API,
			params: { input: action.payload },
			method: "get"
		},
		{
			dataTransform: (resp: Array<SupplierType>) =>
				resp.map(supplier => ({
					value: supplier,
					label: supplier.companyName
				})),
			successActionCreator: searchSupplierSuccess,
			errorActionCreator: searchSupplierFailed
		}
	);
}

export function* watchSearchSupplier(): Saga<void> {
	yield takeLatest(SEARCH_SUPPLIER, handleSearchSupplier);
}
