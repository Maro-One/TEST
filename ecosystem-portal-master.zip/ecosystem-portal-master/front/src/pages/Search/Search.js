import React, { useState } from "react";
import { connect } from "react-redux";
import { useHistory } from "react-router";
import Select from "react-select";
import { searchSupplier } from "./actions";
import { customStyles, DropdownIndicator, NoOptionsMessage } from "./styles";
import type { SelectOptionType } from "./actions/actionTypes";
import {FormattedMessage} from "react-intl";

type Props = {
	options: Array<SelectOptionType>,
	loading: boolean,
	dispatchSearchValue: typeof searchSupplier
};

const Search = ({ options, loading, dispatchSearchValue }: Props) => {
	const [open, setOpen] = useState(false);

	const history = useHistory();

	const onSelect = selectedOption => {
		if (selectedOption) {
			history.push(`/supplier/${selectedOption.value.supplierBravoId}`);
		}
	};

	const onInputChange = (inputValue, { action }) => {
		if (action === "input-change" && inputValue !== "") {
			dispatchSearchValue(inputValue);
			if (!open) {
				setOpen(true);
			}
		}
		if (action === "menu-close") {
			setOpen(false);
		}
	};

	return (
		<Select
			components={{ DropdownIndicator, NoOptionsMessage }}
			onInputChange={onInputChange}
			onChange={onSelect}
			menuIsOpen={open}
			styles={customStyles}
			options={options}
			filterOption={() => true}
			isLoading={loading}
			isClearable
			placeholder={<FormattedMessage id="search.placeholder" defaultMessage="Rechercher" />}
		/>
	);
};

const mapStateToProps = state => ({
	options: state.search.options,
	loading: state.search.loading
});

const mapDispatchToProps = {
	dispatchSearchValue: searchSupplier
};

export default connect(mapStateToProps, mapDispatchToProps)(Search);
