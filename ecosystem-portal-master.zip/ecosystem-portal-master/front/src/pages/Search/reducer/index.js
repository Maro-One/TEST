import {
	SEARCH_SUPPLIER,
	SEARCH_SUPPLIER_ERROR,
	SEARCH_SUPPLIER_SUCCESS
} from "../actions/constants";
import type { SearchActionTypes, SelectOptionType } from "./actionTypes";

type StoreType = {
	options: Array<SelectOptionType>,
	loading: boolean,
	success: boolean | null,
	error: string | null
};

const InitialState = {
	options: [],
	loading: false,
	success: null,
	error: null
};

const reducer = (
	state: StoreType = InitialState,
	action: SearchActionTypes
): StoreType => {
	switch (action.type) {
		case SEARCH_SUPPLIER:
			return {
				...state,
				loading: true
			};
		case SEARCH_SUPPLIER_SUCCESS:
			return {
				...state,
				options: action.payload,
				loading: false,
				success: true
			};
		case SEARCH_SUPPLIER_ERROR:
			return {
				...state,
				loading: false,
				success: false,
				error: action.payload
			};
		default:
			return state;
	}
};

export default reducer;
