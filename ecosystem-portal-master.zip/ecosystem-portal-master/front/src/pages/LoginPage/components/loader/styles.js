const styles = {
	loader: {
		position: "fixed",
		textAlign: "center",
		zIndex: 10050,
		backgroundColor: "#333!important",
		opacity: 0.5,
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
	},
	spinner: {
		position: "relative",
		top: "40%",
	}
};

export default styles;
