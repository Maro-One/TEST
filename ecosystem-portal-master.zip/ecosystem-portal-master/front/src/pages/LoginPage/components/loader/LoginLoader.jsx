import React from "react";
import SpinnerNew from "../../../../common/SpinnerNew";
import makeStyles from "@material-ui/core/styles/makeStyles";
import styles from "./styles";

const useStyles = makeStyles(styles);

function LoginLoader() {
	const classes = useStyles();
	return (
		<div className={classes.loader}>
			<div className={classes.spinner} >
				<SpinnerNew type={"logo_loading"}/>
			</div>
		</div>
	);
}

export default LoginLoader;