// @flow
import type { SendLoginRequestAction } from "../actions";
import {
	clearUserInformation,
	errorFetchingUserInformation,
	LOGOUT,
	SEND_LOGIN_REQUEST,
	setUserInformation
} from "../actions";
import { call, put, select, takeLatest } from "redux-saga/effects";
import { request } from "../../../utils/helper";
import history from "../../../utils/history";
import getUserToken from "../../../store/selectors/getUserToken";
import jwtDecode from "jwt-decode";

/**
 * Listens for the get item groups action and trigger the request flow, cancelling the previous
 * request if it was still ongoing.
 * @return {null} nothing
 */
export const loginRequest = function* loginRequest({
	username,
	password
}: SendLoginRequestAction): Generator<any, void, any> {
	try {
		const response = yield call(request, {
			url: "/api/login",
			data: {
				login: username,
				password
			},
			method: "post"
		});
		const { authorization: token } = response.headers;
		const user = yield call(request, {
			url: "/api/userinfos",
			headers: { Authorization: "Bearer " + token }
		});
		const { exp } = jwtDecode(token);
		yield put(setUserInformation({ ...user.data, exp, token }));
		yield call(history.push, "/");
	} catch (error) {
		if (error.response) {
			yield put(
				errorFetchingUserInformation(
					error.response.statusText,
					error.response.status
				)
			);
		} else {
			yield put(errorFetchingUserInformation(error.message));
		}
	}
};

const logoutRequest = function* logoutRequest(): Generator<any, void, any> {
	try {
		const token = yield select(getUserToken);
		yield put(clearUserInformation());
		yield call(history.push, "/login");
		yield call(request, {
			url: "api/log-out",
			headers: { Authorization: token }
		});
	} catch (error) {
		const HttpErrorStatus = 500;
		yield put(errorFetchingUserInformation("error", HttpErrorStatus));
	}
};

/**
 * Listens for the get item groups action and trigger the request flow, cancelling the previous
 * request if it was still ongoing.
 * @return {null} nothing
 */
export default function*(): Generator<any, void, any> {
	yield takeLatest(SEND_LOGIN_REQUEST, loginRequest);
	yield takeLatest(LOGOUT, logoutRequest);
}
