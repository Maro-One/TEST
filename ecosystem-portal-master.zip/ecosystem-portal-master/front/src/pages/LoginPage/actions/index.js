// @flow
export const SEND_LOGIN_REQUEST = "SEND_LOGIN_REQUEST";

export type SendLoginRequestAction = {
	type: string,
	username: string,
	password: string
};

type Credentials = {
	login: string,
	password: string
};

export const sendLoginRequest = ({
	login,
	password
}: Credentials): SendLoginRequestAction => ({
	username: login,
	password,
	type: SEND_LOGIN_REQUEST
});

export const SET_USER_INFORMATION = "SET_USER_INFORMATION";

export type SetUserInformation = {
	type: string,
	payload: {
		token: string,
		firstName: string,
		lastName: string,
		agency: string,
		exp: number,
		roleLabel: string,
	}
};

export const setUserInformation = (userInfo: any): SetUserInformation => ({
	type: SET_USER_INFORMATION,
	payload: {
		token: userInfo.token,
		agency: userInfo.agencyName,
		firstName: userInfo.firstName,
		lastName: userInfo.lastName,
		roleLabel: userInfo.roleLabel,
		exp: userInfo.exp
	}
});

export const ERROR_FETCHING_USER_INFORMATION =
	"ERROR_FETCHING_USER_INFORMATION";

export type ErrorFetchingUserInformation = {
	type: string,
	error: string,
	httpStatus: number
};

export const errorFetchingUserInformation = (
	error: string,
	httpStatus: number
): ErrorFetchingUserInformation => ({
	error,
	httpStatus,
	type: ERROR_FETCHING_USER_INFORMATION
});

export const LOGOUT = "LOGOUT";

export type Logout = {
	type: string
};

export const logUserOut = { type: LOGOUT };

export const CLEAR_USER_INFORMATION = "CLEAR_USER_INFORMATION";

export type ClearUserInformation = {
	type: string
};

export const clearUserInformation = (): ClearUserInformation => ({
	type: CLEAR_USER_INFORMATION
});

export const LOGIN_FAILED = "LOGIN_FAILED";

export type LoginFailed = {
	type: "LOGIN_FAILED"
};

export const loginFailed = (): LoginFailed => ({ type: LOGIN_FAILED });
