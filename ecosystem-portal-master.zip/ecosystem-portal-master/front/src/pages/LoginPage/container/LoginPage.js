// @flow

import React, {Component} from "react";
import {connect} from "react-redux";
import {reduxForm} from "redux-form";
import {push as pushCreator} from "react-router-redux";
import {sendLoginRequest} from "../actions";
import FormPage from "../../FormPage/container/FormPage";
import LoginForm from "../../../common/LoginForm/LoginForm";

type Props = {
	token?: string,
	push: string => any,
	onSubmit: Function,
	resetPassword?: Node,
	error: any,
	isProgress?: ?boolean,
	isFormValid: boolean
};

type State = { showPassword: boolean };

const validate = values => {
	const errors = {};
	const requiredFields = ["login", "password"];
	requiredFields.forEach(field => {
		if (!values[field]) {
			errors[field] = "Required";
		}
	});
	return errors;
};

class LoginPage extends Component<Props, State> {
	constructor(props: Props) {
		super(props);
		this.handleClickShowPassword = this.handleClickShowPassword.bind(this);
		this.state = { showPassword: false };
	}

	componentDidMount() {
		const { push, token } = this.props;

		if (token !== null) {
			push("/");
		}
	}

	handleClickShowPassword: Function;

	handleClickShowPassword() {
		const { showPassword } = this.state;
		this.setState({ showPassword: !showPassword });
	}

	render() {
		const {
			error,
			onSubmit,
			resetPassword,
			isProgress,
			isFormValid
		} = this.props;
		const { showPassword } = this.state;
		return (
			<FormPage>
				<LoginForm
					error={error}
					handleSubmit={onSubmit}
					isProgress={isProgress}
					isValid={isFormValid}
					onClickShowPassword={this.handleClickShowPassword}
					resetPassword={resetPassword}
					showPassword={showPassword}
				/>
			</FormPage>
		);
	}
}

const mapStateToProps = state => ({
	token: state.user && state.user.token,
	error: state.user.httpStatus,
	isProgress: state.user && state.user.isLoading,
	isFormValid: state.form?.login.syncErrors === undefined
});

const mapDispatchToProps = {
	push: pushCreator,
	sendLoginRequest
};

const mergeProps = (stateProps, dispatchProps, otherProps) => ({
	...stateProps,
	...dispatchProps,
	resetPassword: otherProps.resetPassword,
	onSubmit: otherProps.handleSubmit(dispatchProps.sendLoginRequest)
});

const ConnectedLoginPage = connect(
	mapStateToProps,
	mapDispatchToProps,
	mergeProps
)(LoginPage);

export default reduxForm({
	form: "login",
	validate
})(ConnectedLoginPage);
