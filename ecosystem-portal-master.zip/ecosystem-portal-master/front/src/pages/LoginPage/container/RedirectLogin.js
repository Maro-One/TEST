// @flow

import * as React from "react";
import getUserToken from "../../../store/selectors/getUserToken";
import {useSelector} from "react-redux";
import {useHistory} from "react-router";

type Props = {
	token?: string,
	push: string => any,
	children: React.Node
};
const RedirectLogin = ({ children }: Props) => {
	const token = useSelector(getUserToken);
	const history = useHistory();
	if (token) {
		return children;
	} else {
		history.push("/login");
	}
	return null;
};

export default RedirectLogin;
