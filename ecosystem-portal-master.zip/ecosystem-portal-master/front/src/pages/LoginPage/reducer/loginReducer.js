// @flow

import {
	CLEAR_USER_INFORMATION,
	ERROR_FETCHING_USER_INFORMATION,
	SEND_LOGIN_REQUEST,
	SET_USER_INFORMATION
} from "../actions";

type StateType = $Shape<{
	isLoading: boolean
}>;

const InitialState: StateType = {
	isLoading: false
};

export default function(state: StateType = InitialState, action: any): Object {
	switch (action.type) {
		case SEND_LOGIN_REQUEST:
			return { ...state, isLoading: true };
		case SET_USER_INFORMATION:
			return {
				...state,
				...action.payload,
				token: "Bearer " + action.payload.token,
				exp: action.payload.exp,
				roleId: action.payload.roleId,
				roleLabel: action.payload.roleLabel,
				isLoading: false
			};
		case ERROR_FETCHING_USER_INFORMATION:
			return {
				...state,
				isLoading: false,
				error: action.error,
				httpStatus: action.httpStatus
			};
		case CLEAR_USER_INFORMATION:
			return {
				user: null,
				token: null,
				isLoading: false,
				exp: null,
				roleId: null,
				roleLabel: null
			};
		default:
			return state;
	}
}
