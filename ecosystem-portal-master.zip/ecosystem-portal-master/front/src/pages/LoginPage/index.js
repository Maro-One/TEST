import LoginPage from "./container/LoginPage";
import {FormattedMessage} from "react-intl";
import React from "react";
import {Link} from "react-router-dom";


const LoginPageContainer = () => (
	<LoginPage resetPassword={<Link
		className=""
		to="/reset-password"
	>
		<FormattedMessage
			defaultMessage="Mot de passe oublié ?"
			id="login.forgotPassword"
		/>
	</Link>}
	/>
);

export default LoginPageContainer;
