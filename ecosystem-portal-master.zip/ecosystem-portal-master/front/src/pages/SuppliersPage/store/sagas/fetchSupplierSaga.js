// @flow
import {takeLatest} from "redux-saga/effects";
import {FETCH_SUPPLIERS, fetchSuppliersFailure, fetchSuppliersSuccess} from "../actions";
import type {FetchSuppliersAction} from "../actions";
import {callEndpoint} from "../../../../store/sagas/callEndpointSaga";
import {Saga} from "redux-saga";
import getUserRole from "../../../../store/selectors/getUserRole";
import { select } from "redux-saga/effects";
import type {UserRole} from "../../../../utils/UserRole";
import {ROLE_BUYER} from "../../../../utils/UserRole";

const fetchSuppliersSaga = function* ({page = 0, perPage}: FetchSuppliersAction) {
	const userRole: UserRole = yield select(getUserRole);
	let url = "/api/funding-request/approved-funding-applicants";
	if(userRole === ROLE_BUYER){
		url = "/api/funding-request/all-applicants";
	}
	yield* callEndpoint(
		{
			url,
			params: {page: page},
			method: "get"
		},
		{
			dataTransform: (resp) => ({
				suppliers: resp.content,
				count: resp.count
			}),
			successActionCreator: fetchSuppliersSuccess,
			errorActionCreator: fetchSuppliersFailure
		});
};

// eslint-disable-next-line require-jsdoc
export default function*(): Saga<void> {
	yield takeLatest(FETCH_SUPPLIERS, fetchSuppliersSaga);
}
