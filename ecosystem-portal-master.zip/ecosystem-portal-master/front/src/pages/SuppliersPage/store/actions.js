// @flow

import type { SupplierProps } from "./types";

export const FETCH_SUPPLIERS = "FETCH_SUPPLIERS";
export type FetchSuppliersAction = {
	type: typeof FETCH_SUPPLIERS,
	page: number,
	perPage: number
};
export const fetchSuppliers = (
	page: number,
	perPage: number
): FetchSuppliersAction => ({
	type: FETCH_SUPPLIERS,
	page,
	perPage
});

export const FETCH_SUPPLIERS_SUCCESS = "FETCH_SUPPLIERS_SUCCESS";
export type FetchSuppliersSuccessAction = {
	type: typeof FETCH_SUPPLIERS_SUCCESS,
	suppliers: SupplierProps[],
	count: number
};
export const fetchSuppliersSuccess = ({
	suppliers,
	count
}: {
	suppliers: SupplierProps[],
	count: number
}): FetchSuppliersSuccessAction => ({
	type: FETCH_SUPPLIERS_SUCCESS,
	suppliers,
	count
});

export const FETCH_SUPPLIERS_FAILURE = "FETCH_SUPPLIERS_FAILURE";
export type FetchSuppliersFailureAction = {
	type: typeof FETCH_SUPPLIERS_FAILURE
};
export const fetchSuppliersFailure = (): FetchSuppliersFailureAction => ({
	type: FETCH_SUPPLIERS_FAILURE
});

export const SUPPLIERS_CHANGE_PAGE = "SUPPLIERS_CHANGE_PAGE";
export type SuppliersChangePage = {
	type: typeof SUPPLIERS_CHANGE_PAGE,
	page: number
};
export const changeSuppliersPage = (page: number): SuppliersChangePage => ({
	type: SUPPLIERS_CHANGE_PAGE,
	page
});
export type SuppliersAction =
	| FetchSuppliersAction
	| FetchSuppliersSuccessAction
	| FetchSuppliersFailureAction
	| SuppliersChangePage;
