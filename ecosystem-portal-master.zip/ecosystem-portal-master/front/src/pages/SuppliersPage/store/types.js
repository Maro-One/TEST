// @flow

export type SupplierProps = {
  supplierBravoId: number,
	supplierOracleCode: string,
  companyName: string,
	dunsOrICECode: string,
	professionalEmail: string,
	fundingRequestsCount: number,
};

export type SuppliersStoreType = {
  suppliers: {[page: number] : SupplierProps[]},
  status: "SUCCESS" | "ERROR" | "LOADING",
  page: number,
  perPage: number,
  count: number,
};
