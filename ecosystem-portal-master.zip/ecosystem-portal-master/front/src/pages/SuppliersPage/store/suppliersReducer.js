// @flow

import type { SuppliersAction } from "./actions";
import type { SuppliersStoreType } from "./types";
import {
	FETCH_SUPPLIERS,
	FETCH_SUPPLIERS_FAILURE,
	FETCH_SUPPLIERS_SUCCESS,
	SUPPLIERS_CHANGE_PAGE
} from "./actions";

const DEFAULT_STATE: SuppliersStoreType = {
	status: "LOADING",
	page: 0,
	perPage: 10,
	suppliers: {},
	count: 0
};

// eslint-disable-next-line require-jsdoc
export default function(
	state: SuppliersStoreType = DEFAULT_STATE,
	action: SuppliersAction
) {
	switch (action.type) {
		case FETCH_SUPPLIERS:
			return Object.assign({}, state, {
				status: "LOADING"
			});
		case FETCH_SUPPLIERS_SUCCESS:
			state.suppliers[state.page] = action.suppliers;
			return Object.assign({}, state, {
				status: "SUCCESS",
				count: action.count,
				suppliers: state.suppliers
			});
		case FETCH_SUPPLIERS_FAILURE:
			return Object.assign({}, state, {
				status: "ERROR"
			});
		case SUPPLIERS_CHANGE_PAGE:
			return Object.assign({}, state, {
				page: action.page
			});
		default:
			return state;
	}
}
