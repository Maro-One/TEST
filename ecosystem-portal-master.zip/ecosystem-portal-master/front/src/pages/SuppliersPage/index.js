import SuppliersContainer from "./container/SuppliersContainer";

export default SuppliersContainer;
