// @flow
import React, {Fragment} from "react";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import TableBody from "@material-ui/core/TableBody";
import makeStyles from "@material-ui/core/styles/makeStyles";
import styles, {DetailsButtonStyles} from "./styles";
import Table from "@material-ui/core/Table";
import Button from "@material-ui/core/Button";
import withStyles from "@material-ui/core/styles/withStyles";
import classNames from "classnames";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Pagination from "../../../../common/Pagination";
import type {SupplierProps} from "../../store/types";
import {useHistory} from "react-router";
import TableStatusControllerSpinner from "../../../../common/SpinnerNew/TableStatusControllerSpinner";
import type {StatusType} from "../../../../store/commonTypes";
import FormattedMessage from "react-intl/lib/components/message";

const useStyles = makeStyles(styles);

type Props = {
    suppliers: SupplierProps[],
    count: number,
    perPage: number,
    page: number,
    status: StatusType,
    changePage: Function
};
const DetailsButton = withStyles(DetailsButtonStyles)(Button);

const SuppliersList = ({
	suppliers = [],
	count,
	perPage,
	page,
	changePage,
	status
}: Props) => {
	const classes = useStyles();
	const history = useHistory();
	const goToSupplierDetailsAction = (supplier: SupplierProps) => () => {
		history.push(`/supplier/${supplier.supplierBravoId}`);
	};
	const pagination = (
		<Pagination
			perPage={perPage}
			count={count}
			page={page}
			onChangePage={changePage}
		/>
	);
	return (
		<Fragment>
			<Toolbar>
				<Typography className={classes.title} variant="h6">
					<FormattedMessage id={"supplier.list.suppliers"} defaultMessage={"Fournisseurs"} /> <span className={classes.titleNum}>({count})</span>
				</Typography>
				{pagination}
			</Toolbar>
			<TableContainer>
				<Table
					className={classes.table}
					size="small"
					aria-label="a dense table"
				>
					<TableHead>
						<TableRow className={classes.tableHead}>
							<TableCell className={classes.tableHeadCell}><FormattedMessage id={"supplier.list.rs"}
								defaultMessage={"Raison sociale"}/>
							</TableCell>
							<TableCell className={classes.tableHeadCell}><FormattedMessage id={"supplier.list.ice"}
								defaultMessage={"ice"}/></TableCell>
							<TableCell className={classes.tableHeadCell}><FormattedMessage id={"supplier.list.email"}
								defaultMessage={"Adresse Email"}/>
							</TableCell>
							<TableCell className={classes.tableHeadCell}>
								<FormattedMessage id={"supplier.list.nc"}
												  defaultMessage={"Nombre de commandes"}/>
							</TableCell>
							<TableCell/>
						</TableRow>
					</TableHead>
					<TableStatusControllerSpinner colSpan={5} dataStatus={status}>
						<TableBody>
							{suppliers &&
                            suppliers.map((supplier: SupplierProps, index) => (
                            	<TableRow
                            		className={classNames(classes.tableRow, {
                            			[classes.oddRow]: index % 2 === 1
                            		})}
                            		key={supplier.supplierBravoId}
                            	>
                            		<TableCell
                            			className={classNames(
                            				classes.tableRowCell,
                            				classes.tableRowCellName
                            			)}
                            			component="th"
                            			scope="row"
                            		>
                            			{supplier.companyName}
                            		</TableCell>
                            		<TableCell className={classes.tableRowCell}>
                            			{supplier.dunsOrICECode}
                            		</TableCell>
                            		<TableCell className={classes.tableRowCell}>
                            			{supplier.professionalEmail}
                            		</TableCell>
                            		<TableCell className={classes.tableRowCell}>
                            			{supplier.fundingRequestsCount}
                            		</TableCell>
                            		<TableCell
                            			align={"right"}
                            			className={classes.tableHeadCell}
                            		>
                            			<DetailsButton
                            				onClick={goToSupplierDetailsAction(supplier)}
                            				variant="contained"
                            			>
									    	<Typography variant="subheading" color="inherit" noWrap>
										    	<FormattedMessage id={"supplier.list.see.detail"}
                            					defaultMessage={"voir détails"} />
										    </Typography>
                            			</DetailsButton>
                            		</TableCell>
                            	</TableRow>
                            ))}
						</TableBody>
					</TableStatusControllerSpinner>
				</Table>
			</TableContainer>
			<Toolbar>
				<Typography className={classes.totalNumSuppliers} variant="caption">
					{count}&nbsp;<FormattedMessage id={`supplier.list.supplier${count > 1 ? "s" : ""}`}
						defaultMessage={"Fournisseurs"} />
				</Typography>
				{pagination}
			</Toolbar>
		</Fragment>
	);
};
export default SuppliersList;
