import SuppliersList from "./SuppliersList";

export default SuppliersList;
