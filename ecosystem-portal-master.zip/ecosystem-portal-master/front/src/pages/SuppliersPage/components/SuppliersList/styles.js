import fonts from "../../../../utils/fonts";

const styles = {
	tableHeadCell: {
		"textTransform": "uppercase",
		"fontSize": "12px",
		"fontFamily": fonts.robotoRegular,
		"color": "#727CA2",
	},
	tableHead: {
		"borderRadius": "6px",
		"backgroundColor": "#F8F8FF",
		"lineHeight": "40px",
		"height": "40px",
	},
	tableRow: {
		"lineHeight": "80px",
		"height": "80px",
	},
	tableRowCell: {
		"fontSize": "14px",
		"lineHeight": "19px",
		"fontFamily": fonts.robotoRegular,
		"color": "#333D66",
		"fontWeight": "400",
	},
	tableRowCellName: {
		"fontSize": "16px",
		"fontWeight": 600,
	},
	oddRow: {
		"backgroundColor": "#FAFAFC",
	},
	title: {
		"flex": "1 1 100%",
		"fontFamily": fonts.robotoMedium,
		"color": "#333D66",
		"fontSize":"24px",
	},
	titleNum: {
		"fontFamily": fonts.robotoRegular,
		"color": "#586493",
		"fontWeight": "300",
	},
	totalNumSuppliers: {
		"flex": "1 1 100%",
		"color": "#727CA2",
		"fontFamily": fonts.robotoRegular,
		"fontSize": "16px",
		"fontStyle": "italic",
		"line-height": "19px",
	},
};

export const DetailsButtonStyles = () => ({
	root: {
		"color": "#FFFFFF",
		"backgroundColor": "#6779A9",
		"fontFamily": fonts.robotoBold,
		"fontWeight": "bold",
		"fontSize": "12px",
		"&:hover": {
			"backgroundColor": "#6578A0",
		},
	},
});

export default styles;
