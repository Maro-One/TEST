// @flow

import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { changeSuppliersPage, fetchSuppliers } from "../store/actions";

const useSuppliers = () => {
	const { suppliers, perPage, page, count, status } = useSelector(
		({ suppliers }) => ({
			suppliers: suppliers.suppliers ? suppliers.suppliers[suppliers.page] : [],
			perPage: suppliers.perPage,
			page: suppliers.page,
			status: suppliers.status,
			count: suppliers.count
		})
	);
	const dispatch = useDispatch();

	const changePage = (page: number) => dispatch(changeSuppliersPage(page));

	useEffect(() => {
		dispatch(fetchSuppliers(page, perPage));
	}, [page, perPage, dispatch]);

	return { suppliers, perPage, count, page, status, changePage };
};
export default useSuppliers;
