// @flow
const styles = {
	paper: {
		padding: "1rem",
	},
};

export default styles;
