import Paper from "@material-ui/core/Paper";
import makeStyles from "@material-ui/core/styles/makeStyles";
import React from "react";
import SuppliersList from "../components/SuppliersList";
import styles from "./styles";
import useSuppliers from "../hooks/useSuppliers";

const useStyles = makeStyles(styles);

const SuppliersContainer = () => {
	const classes = useStyles();
	const {suppliers, perPage, count, page, status, changePage} = useSuppliers();
	return (
		<Paper elevation={0} square className={classes.paper}>
			<SuppliersList
				suppliers={suppliers}
				perPage={perPage}
				count={count}
				page={page}
				status={status}
				changePage={changePage}
			/>
		</Paper>
	);
};

export default SuppliersContainer;
