// @flow

import {reduxForm} from "redux-form";
import {connect, useSelector} from "react-redux";
import {push as pushCreator} from "react-router-redux";
import React from "react";
import FormPage from "../../FormPage/container/FormPage";
import PasswordForm from "../components/PasswordForm/PasswordForm";
import {changeUserPassword, checkTokenRequest} from "../store/actions";
import useTokenExpiration from "../hooks/useTokenExpiration";
import type {ChangePasswordStore} from "../store/types/types";


type Props = {
	token?: string,
	push: string => any,
	handleSubmit: Function,
	checkToken: Function,
	error: Object,
	params: { token: string },
	route: { path: string },
	formRegister: Object
}
const validate = (values) => {
	const errors = {};
	const requiredFields = [
		"firstPassword",
		"secondPassword"
	];
	requiredFields.forEach((field) => {
		if (!values[field]) {
			errors[field] = "Champs requis.";
		}
	});
	if (values.firstPassword) {
		if (!values.firstPassword.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)) {
			errors.firstPassword = "Le mot de passe ne respecte pas les règles.";
		}
	}
	if (values.firstPassword && values.secondPassword) {
		if (values.firstPassword !== values.secondPassword) {
			errors.secondPassword = "Les mots de passe ne correspondent pas.";
		}
	}
	return errors;
};

const isValid = (formRegister) => (formRegister && formRegister.values &&
	JSON.stringify(validate(formRegister.values)) === JSON.stringify({}));

const RegisterContainer = (props: Props) => {
	useTokenExpiration();
	const {status, errorCode}: ChangePasswordStore = useSelector(({changePassword}: any) => changePassword);
	const {error, handleSubmit, formRegister} = props;
	return (
		<FormPage>
			<PasswordForm
				disableSubmit={!isValid(formRegister)}
				error={error}
				status={status}
				errorCode={errorCode}
				handleSubmit={handleSubmit}
			/>
		</FormPage>
	);
}

const mapStateToProps = (state) => (
	{
		"token": state.user && state.user.token,
		// "error": state.error,
		"formRegister": state.form.register
		
	}
);

const mapDispatchToProps = {
	changeUserPassword,
	"push": pushCreator,
	"checkToken": checkTokenRequest
};

const mergeProps = (stateProps, dispatchProps, formProps) => ({
	...formProps,
	...stateProps,
	...dispatchProps,
	"handleSubmit": formProps.handleSubmit((form) => dispatchProps.changeUserPassword(form))
});

const ConnectedLoginPage = connect(mapStateToProps, mapDispatchToProps, mergeProps)(RegisterContainer);

export default reduxForm({
	"form": "register",
	validate
})(ConnectedLoginPage);
