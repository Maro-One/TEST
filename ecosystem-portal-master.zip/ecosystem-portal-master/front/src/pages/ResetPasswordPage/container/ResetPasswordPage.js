// @flow

import React from "react";
import {connect} from "react-redux";
import {reduxForm} from "redux-form";
import ResetPasswordForm from "../components/ResetPasswordForm";
import FormPage from "../../FormPage/container/FormPage";
import {resetPasswordRequest} from "../store/actions";

type Props = {
    previousRequestStatus: Object,
    handleSubmit: Function,
    isFormValid: boolean,
	form: string,
};

const validate = (values) => {
	const errors = {};
	const requiredFields = ["login","captchaValue"];
	requiredFields.forEach((field) => {
		if (!values[field]) {
			errors[field] = "Required";
		}
	});
	return errors;
};


const ResetPasswordPage = ({previousRequestStatus, handleSubmit, isFormValid, form}: Props) => (
	<FormPage
		subtitleId="resetPassword.subtitle"
		titleId="resetPassword.title"
	>
		<ResetPasswordForm
			formName={form}
			handleSubmit={handleSubmit}
			isValid={isFormValid}
			previousRequestStatus={previousRequestStatus}
		/>
	</FormPage>
);


const mapStateToProps = (state) => (
	{
		"previousRequestStatus": state.resetPassword.resetPassword,
		"isFormValid": state.form.resetPasswordForm.syncErrors === undefined
	}
);

const mapDispatchToProps = {resetPasswordRequest};

const mergeProps = (stateProps, dispatchProps, formProps) => ({
	...formProps,
	...stateProps,
	...dispatchProps,
	"handleSubmit": formProps.handleSubmit((form) => dispatchProps.resetPasswordRequest(form))
});

const ConnectedResetPassword = connect(mapStateToProps, mapDispatchToProps, mergeProps)(ResetPasswordPage);
export default reduxForm({
	"form": "resetPasswordForm",
	validate
})(ConnectedResetPassword);
