// @flow

import type {
	CheckTokenRequestAction,
	ResetPasswordRequestAction
} from "../actions";
import {
	CHANGE_USER_PASSWORD, changeUserPasswordFailure,
	CHECK_TOKEN_REQUEST,
	errorOnResetPasswordRequest,
	GET_CAPTCHA,
	getCaptchaError,
	getCaptchaSuccess,
	RESET_PASSWORD,
	resetPasswordRequestSuccessful
} from "../actions";
import {call, put, takeLatest} from "redux-saga/effects";
import {request} from "../../../../utils/helper";
import {errorFetchingUserInformation} from "../../../LoginPage/actions";
import history from "../../../../utils/history";
import {callEndpoint} from "../../../../store/sagas/callEndpointSaga";
import {toast} from "react-toastify";

const HTTP_STATUS = {
	BAD_REQUEST: 400,
	NOT_FOUND: 404,
	INTERNAL_SERVER_ERROR: 500,
	UNAUTHORIZED: 401
};

const getMessage = response => {
	switch (response.status) {
		case HTTP_STATUS.BAD_REQUEST:
			return "register.urlNoValide";
		case HTTP_STATUS.NOT_FOUND:
			return "register.UserNotFound";
		case HTTP_STATUS.INTERNAL_SERVER_ERROR:
			return "register.serverError";
		case HTTP_STATUS.UNAUTHORIZED:
			return "register.error";
		default:
			return "";
	}
};

export type ChangeUserPassword = {
	type: string,
	firstPassword: string,
	secondPassword: string,
	token: string
};

/**
 * Listens for the get item groups action and trigger the request flow, cancelling the previous
 * request if it was still ongoing.
 * @return {null} nothing
 */
const changePasswordRequest = function* changePasswordRequest({
	firstPassword,
	secondPassword
}: ChangeUserPassword): Generator<any, void, any> {
	try {
		yield call(request, {
			url: "/api/change-password",
			data: {
				firstPassword,
				secondPassword,
				token: history.location.pathname.split("/")[2]
			},
			method: "post"
		});
		yield call(toast, "Votre mot de passe à été changé avec succès.", {type: "success"});
		yield call(history.push, "/login");
	} catch (error) {
		yield put(changeUserPasswordFailure({errorCode: error.response.status, error: error.response.statusText}));
	}
};

/**
 * Listens for the get item groups action and trigger the request flow, cancelling the previous
 * request if it was still ongoing.
 * @return {null} nothing
 */
const resetPasswordRequest = function* resetPasswordRequest({
	data
}: ResetPasswordRequestAction): Generator<any, void, any> {
	try {
		yield call(request, {
			url: "/api/reset-password",
			data: data,
			method: "post"
		});
		yield put(resetPasswordRequestSuccessful());
	} catch (error) {
		yield put(
			errorOnResetPasswordRequest(error.response.data, error.response.status)
		);
	}
};

const checkTokenRequest = function* checkTokenRequest({
	token
}: CheckTokenRequestAction): Generator<any, void, any> {
	try {
		const response = yield call(request, {
			url: "/api/checktoken",
			data: {token},
			method: "post"
		});
		
		const errorMessage = getMessage(response);
		yield put(errorFetchingUserInformation(errorMessage, response.status));
	} catch (error) {
		const errorMessage = getMessage(error.response);
		yield put(
			errorFetchingUserInformation(errorMessage, error.response.status)
		);
	}
};

const getCaptchaRequest = function* getCaptchaRequest(): Generator<any,
	void,
	any> {
	yield* callEndpoint(
		{
			url: "/api/captcha"
		},
		{
			successActionCreator: getCaptchaSuccess,
			errorActionCreator: getCaptchaError
		}
	);
};

/**
 * Listens for the get item groups action and trigger the request flow, cancelling the previous
 * request if it was still ongoing.
 * @return {null} nothing
 */
export default function* (): Generator<any, void, any> {
	yield takeLatest(RESET_PASSWORD, resetPasswordRequest);
	yield takeLatest(CHECK_TOKEN_REQUEST, checkTokenRequest);
	yield takeLatest(CHANGE_USER_PASSWORD, changePasswordRequest);
	yield takeLatest(GET_CAPTCHA, getCaptchaRequest);
}
