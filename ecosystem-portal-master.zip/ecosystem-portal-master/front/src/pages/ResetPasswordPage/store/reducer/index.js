// @flow

import {
	RESET_PASSWORD,
	RESET_PASSWORD_ENDED,
	RESET_PASSWORD_REQUEST_ERROR,
	RESET_PASSWORD_REQUEST_SUCCESS
} from "../actions";

/**
 * Stores the item groups information
 * @param {int} state The current state
 * @param {object} action The action to handle
 * @returns {int} The new state
 */
export default function (state:Object = {response: null}, action: any) {
	switch (action.type) {
		case RESET_PASSWORD:
		case RESET_PASSWORD_ENDED:
			return {...state, response: null};
		case RESET_PASSWORD_REQUEST_ERROR:
			return {
				...state, response: {
					type: "ERROR",
					"httpStatus": action.httpStatus,
					"error": action.error
				}
			};
		case RESET_PASSWORD_REQUEST_SUCCESS:
			return {
				...state,
				response: {type: "SUCCESS"}
			};
		default:
			return state;
	}
}



