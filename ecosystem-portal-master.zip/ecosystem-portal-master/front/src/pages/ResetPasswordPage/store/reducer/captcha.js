// @flow

import type {CaptchaType, GetCaptchaAction, GetCaptchaErrorAction, GetCaptchaSuccessAction} from "../actions";
import {GET_CAPTCHA, GET_CAPTCHA_ERROR, GET_CAPTCHA_SUCCESS} from "../actions";

type captchaActionType = (GetCaptchaAction |
    GetCaptchaErrorAction | GetCaptchaSuccessAction);


/**
 * Stores the purchase requests information
 * @param   {int} state The current state
 * @param   {object} action The action to handle
 * @returns {int} The new state
 */
export default function (
	state:CaptchaType = {data:{image:"",entryCode:""},status:""},
	action:captchaActionType
) {
	switch (action.type) {
		case GET_CAPTCHA:
			return {...state,status: "partial"};
		case GET_CAPTCHA_ERROR:
			return  {...state,status: "error"};
		case GET_CAPTCHA_SUCCESS:
			const {captcha} = action;
			return {...state,data: captcha, status: "success"};
		default:
			return state;
	}
}

