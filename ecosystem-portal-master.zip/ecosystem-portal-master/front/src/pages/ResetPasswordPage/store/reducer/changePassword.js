// @flow
import {CHANGE_USER_PASSWORD, CHANGE_USER_PASSWORD_FAILURE} from "../actions";
import type {ChangePasswordStore} from "../types/types";
import type {ChangeUserPasswordActions} from "../actions";

const ChangePasswordStoreDefault: ChangePasswordStore = {
	status: "SUCCESS"
};

function changePasswordReducer(state: ChangePasswordStore = ChangePasswordStoreDefault, action: ChangeUserPasswordActions) {
	switch (action.type) {
		case CHANGE_USER_PASSWORD:
			return {...state, status: "LOADING"};
		case CHANGE_USER_PASSWORD_FAILURE:
			return {...state, status: "SUCCESS", error: action.error, errorCode: action.errorCode};
		default:
			return state;
	}
}

export default changePasswordReducer;
