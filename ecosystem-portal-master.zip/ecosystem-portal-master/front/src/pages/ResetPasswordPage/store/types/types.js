// @flow

export type ChangePasswordStore = {
	errorCode?: number,
	error?: string,
	status?: "SUCCESS" | "LOADING"
}
