// @flow
import type {ChangePasswordStore} from "../types/types";

export const RESET_PASSWORD = "RESET_PASSWORD";

export type ResetDataType = {
	"email": string,
	"captchaValue": string,
	"entryCode": string,
}
export type ResetPasswordRequestAction = {
	"type": "RESET_PASSWORD",
	"data": ResetDataType
};

export const resetPasswordRequest = (data: ResetDataType): ResetPasswordRequestAction => ({
	"type": RESET_PASSWORD,
	data
});

export const RESET_PASSWORD_REQUEST_ERROR = "RESET_PASSWORD_REQUEST_ERROR";

export type ErrorOnResetPasswordRequest = {
	"type": string,
	"error": string,
	"httpStatus": number,
};

export const errorOnResetPasswordRequest = (error: string, httpStatus: number): ErrorOnResetPasswordRequest => ({
	error,
	httpStatus,
	"type": RESET_PASSWORD_REQUEST_ERROR
});

export const RESET_PASSWORD_REQUEST_SUCCESS = "RESET_PASSWORD_REQUEST_SUCCESS";

export type ResetPasswordRequestSuccessful = {
	"type": string,
};

export const resetPasswordRequestSuccessful = (): ResetPasswordRequestSuccessful => (
	{
		"type": RESET_PASSWORD_REQUEST_SUCCESS,
	}
);

export const RESET_PASSWORD_ENDED = "RESET_PASSWORD_ENDED";

export type ResetPasswordEndedRequestAction = {
	"type": "RESET_PASSWORD_ENDED",
};

export const resetPasswordEndedRequest: ResetPasswordEndedRequestAction = {
	"type": RESET_PASSWORD_ENDED
};

export const SEND_REGISTER_REQUEST = "SEND_REGISTER_REQUEST";

export type SendRegisterRequestAction = {
	"type": string,
	"firstPassword": string,
	"secondPassword": string,
	"token": string
};

export type GroupOfPassword = {
	"firstPassword": string,
	"secondPassword": string
}

export const sendRegisterRequest = ({
	firstPassword,
	secondPassword
}: GroupOfPassword, token: string): SendRegisterRequestAction => ({
	firstPassword,
	secondPassword,
	token,
	"type": SEND_REGISTER_REQUEST
});

export const CHECK_TOKEN_REQUEST = "CHECK_TOKEN_REQUEST";

export type CheckTokenRequestAction = {
	"type": string,
	"token": string
};

export const checkTokenRequest = (token: string): CheckTokenRequestAction => ({
	token,
	"type": CHECK_TOKEN_REQUEST
});

export const CHANGE_USER_PASSWORD = "CHANGE_USER_PASSWORD";

export type ChangeUserPassword = {
	"type": string,
	"firstPassword": string,
	"secondPassword": string
};

export const changeUserPassword =
	({firstPassword, secondPassword}: GroupOfPassword): ChangeUserPassword => (
		{
			"type": CHANGE_USER_PASSWORD,
			firstPassword,
			secondPassword
		}
	);
export const CHANGE_USER_PASSWORD_FAILURE = "CHANGE_USER_PASSWORD_FAILURE";

export type ChangeUserPasswordFailure = {
	type: string,
	errorCode: number,
	error: string
};
export const changeUserPasswordFailure = ({errorCode, error}: ChangePasswordStore): ChangeUserPasswordFailure => (
	{
		"type": CHANGE_USER_PASSWORD_FAILURE,
		errorCode,
		error
	}
);
export  type ChangeUserPasswordActions = ChangeUserPasswordFailure | ChangeUserPassword;

export type CaptchaDataType = {
	entryCode: string,
	image: string
}

export type CaptchaType = {
	data: CaptchaDataType,
	status: string,
}

export const GET_CAPTCHA = "GET_CAPTCHA";

export type GetCaptchaAction = {
	"type": "GET_CAPTCHA"
};

export const getCaptcha = {"type": "GET_CAPTCHA"};

export const GET_CAPTCHA_ERROR = "GET_CAPTCHA_ERROR";

export type GetCaptchaErrorAction = {
	"type": "GET_CAPTCHA_ERROR"
};

export const getCaptchaError = (): GetCaptchaErrorAction => ({"type": "GET_CAPTCHA_ERROR"});

export const GET_CAPTCHA_SUCCESS = "GET_CAPTCHA_SUCCESS";

export type GetCaptchaSuccessAction = {
	"type": "GET_CAPTCHA_SUCCESS",
	captcha: CaptchaDataType
};

export const getCaptchaSuccess = (captcha: CaptchaDataType): GetCaptchaSuccessAction => ({
	"type": "GET_CAPTCHA_SUCCESS",
	captcha
});



