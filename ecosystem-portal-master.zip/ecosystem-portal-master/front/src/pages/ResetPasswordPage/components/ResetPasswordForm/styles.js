// @flow
import colors from "../../../../utils/colors";
const styles = {
	"container": {
		"top": "50%",
		"left": "50%",
		"position": "absolute",
		"margin": "0",
		"transform": "translate(-50%, -50%)",
		"maxWidth": "500px"
	},
	"h1": {
		"fontWeight": "bold",
		"paddingBottom": "16px"
	},
	"h2": {"paddingBottom": "16px"},
	"paper": {
		"display": "flex",
		"flexDirection": "column"
	},
	"form": {
		"width": "100%",
		"marginTop": "8px"
	},
	"textField": {
		"& label.Mui-focused": {"color": "green"},
		"& .MuiInput-underline:after": {"borderBottomColor": "green"},
		"& .MuiOutlinedInput-root": {"&.Mui-focused fieldset": {"borderColor": "green"}},
		"&.MuiFormControl-marginNormal": {
			"marginTop": "4px",
			"marginBottom": "16px"
		}
	},
	"a": {
		"color": "#9ea4b3",
		"&:hover": {"color": "#008000"},
		"paddingTop": "20px",
		"textAlign": "center"
	},
	"submit": {
		"margin": "24px 0px 16px",
		"backgroundColor": "#7bcb09",
		"&:hover": {"backgroundColor": "#008000"}
	},
	"textFieldError": {
		"& label.Mui-focused": {"color": "red"},
		"& .MuiInput-underline:after": {"borderBottomColor": "red"},
		"& .MuiOutlinedInput-root": {"&.Mui-focused fieldset": {"borderColor": "red"}},
		"&.MuiFormControl-marginNormal": {
			"marginTop": "4px",
			"marginBottom": "16px"
		},
		"& .MuiOutlinedInput-notchedOutline": {"borderColor": "red"},
		"& .MuiInputLabel-outlined.MuiInputLabel-shrink": {"color": "red"}

	},
	mailSent: {
		color: colors.goblinGreen,
		height:250,
		width: 250,
	},
	mailSentContainer: {
		textAlign: "center"
	}
};

export default styles;
