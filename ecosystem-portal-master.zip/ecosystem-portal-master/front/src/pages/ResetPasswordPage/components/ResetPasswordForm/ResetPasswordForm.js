/* eslint-disable react/jsx-no-literals */
// @flow

import * as React from "react";
import styles from "./styles";
import {withStyles} from "@material-ui/core/styles";
import {Field} from "redux-form";
import {Button, Container, CssBaseline, Typography} from "@material-ui/core";
import {Link} from "react-router-dom";
import RenderTextField from "../../../../common/RenderTextField";
import Captcha from "../Captcha/Captcha";
import {useDispatch, useSelector} from "react-redux";
import MailIcon from "@material-ui/icons/Mail";
import {resetPasswordEndedRequest} from "../../store/actions";
import {useHistory} from "react-router";
import {FormattedMessage} from "react-intl";

type Props = {
    classes: Object,
    handleSubmit: Function,
    isValid: boolean,
    formName: string
};

const ResetPasswordForm = ({handleSubmit, classes, isValid, formName}: Props) => {
	const resetResponse = useSelector(state => state.resetPassword.response);
	const dispatch = useDispatch();
	const history = useHistory();
	return (
		<Container
			className={classes.container}
			component="div"
			maxWidth="xs"
		>
			<CssBaseline/>

			<div className={classes.paper}>
				{(resetResponse && resetResponse.type === "SUCCESS") ?
					(<>
						<div className={classes.mailSentContainer}>
							<MailIcon className={classes.mailSent}/>
							<Typography
								className={classes.h1}
								component="h1"
								variant="h5"
							>
								<FormattedMessage
									id="reset.password.message"
									defaultMessage="Un mail de réinitialisation vous a été envoyé."
								/>
							</Typography>
						</div>
						<Link
							className={classes.a}
							onClick={() => {
								dispatch(resetPasswordEndedRequest);
								history.push("/login");
							}}
							variant="body2"
						>
							<FormattedMessage
								id="reset.password.relogin"
								defaultMessage="Retour au login"
							/>
						</Link>
					</>) : (<><Typography
						className={classes.h1}
						component="h1"
						variant="h5"
					>
                        Mot de passe oublié?
					</Typography>
					<Typography
						className={classes.h2}
						component="h2"
						variant="subtitle1"
					>
						<FormattedMessage
							id="reset.password.email"
							defaultMessage="Entrez votre adresse e-mail ci-dessous pour récupérer votre compte"
						/>
					</Typography>

					<form
						className={classes.form}
						id="formResetLogin"
						onSubmit={handleSubmit}
					>
						<Field
							autoFocus
							className={resetResponse && resetResponse.httpStatus === 401
								? classes.textFieldError
								: classes.textField}
							component={RenderTextField}
							label={	<FormattedMessage id="reset.password.login" defaultMessage="Login" />}
							name="login"
							showPswdIcon={false}
							type="text"
						/>
						{resetResponse && resetResponse.httpStatus === 401 &&
                            <div style={{color: "#f44336"}}>{resetResponse.error}</div>}
						<Captcha formName={formName}/>
						<Button
							className={classes.submit}
							color="primary"
							disabled={!isValid}
							fullWidth
							type="submit"
							variant="contained"
						>
							<FormattedMessage id="reset.password.link" defaultMessage="Demander un lien de réinitialisation" />
						</Button>
					</form>
					<Link
						className={classes.a}
						to="/"
						variant="body2"
					>
						<FormattedMessage id="reset.password.relogin" defaultMessage="Retour au login" />
					</Link>
					</>)}

			</div>
		</Container>
	);
};

export default withStyles(styles)(ResetPasswordForm);
