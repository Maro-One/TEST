// @flow

import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import {change, Field} from "redux-form";
import {getCaptcha} from "../../store/actions";
import refresh from "../../../../images/icon_refresh.png";
import RenderTextField from "../../../../common/RenderTextField";

type Props = {
    formName: string
};

const Captcha = ({formName}: Props) => {

	const dispatch = useDispatch();

	useEffect(() => {
		dispatch(getCaptcha);
	}, [dispatch]);

	const captcha = useSelector(state => state.captcha.data);
	useEffect(() => {
		dispatch(change(formName, "entryCode", captcha.entryCode));
		dispatch(change(formName, "captchaValue", ""));
	}, [captcha, dispatch, formName]);

	const resetErrors = useSelector(state => state.resetPassword.response);
	useEffect(() => {
		if(resetErrors && resetErrors.type === "ERROR"){
			dispatch(getCaptcha);
		}
	}, [dispatch, resetErrors]);
	return (
		<div className="captcha">
			<img
				alt="captcha_image"
				className="captcha__img"
				src={`data:image/png;base64,${captcha.image}`}
			/>
			<img
				alt="captcha_refresh"
				className="captcha__refresh"
				onClick={() => dispatch(getCaptcha)}
				src={refresh}
			/>
			<div className="captcha__input">
				<Field
					component={RenderTextField}
					label="Captcha"
					name="captchaValue"
					type="text"
				/>
			</div>
			{resetErrors && resetErrors.httpStatus === 400 &&
			<div style={{color: "#f44336"}}>{resetErrors.error}</div>}
		</div>
	);
};

// const mapStateToProps = (store) => ({
// 	"captcha": store.captcha.data,
// 	"status": store.captcha.status
// });
//
//
// const mapDispatchToProps = {
// 	"retrieveCaptcha": getCaptcha,
// 	"changeField": change
// };

export default Captcha;
