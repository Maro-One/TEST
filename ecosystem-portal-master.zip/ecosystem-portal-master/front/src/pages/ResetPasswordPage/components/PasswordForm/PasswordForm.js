// @flow

import * as React from "react";
import {Field} from "redux-form";
import styles from "./styles";
import {Button, Container, Typography} from "@material-ui/core";
import {withStyles} from "@material-ui/core/styles";
import RenderTextFieldWithErrors from "../../../../common/RenderTextField/RenderTextFieldWithErrors";
import {useState} from "react";
import {FormattedHTMLMessage, FormattedMessage} from "react-intl";
import SpinnerNew from "../../../../common/SpinnerNew";

type Props = {
	classes: Object,
	handleSubmit: Function,
	error: Object,
	disableSubmit: boolean,
	status: string,
	errorCode: number
};

const PasswordForm = ({handleSubmit, classes, disableSubmit, status, errorCode}: Props) => {
	const [showPassword, setShowPassWord] = useState(false);
	const onClickShowPassword = () => {
		setShowPassWord((currentValue) => !currentValue);
	};
	return (
		<Container
			className={classes.container}
			component="div"
			maxWidth="xs"
		>
			<div className={classes.paper}>
				<Typography
					className={classes.h1}
					component="h1"
					variant="h5"
				>
					<FormattedMessage id="password.greeting.message" defaultMessage="Bienvenue dans votre plateforme Tamwil"/>
				</Typography>
				<Typography
					className={classes.h2}
					component="h2"
					variant="subtitle1"
				>
					<FormattedMessage id="password.create.message" defaultMessage="Créer un nouveau mot de passe"/>
				</Typography>
				{errorCode && <div className={classes.errors}>
					<FormattedHTMLMessage id={"password.change.error." + errorCode} defaultMessage={"Une erreur est survenue lors du changement de mot de passe."}/>
				</div>}
				<form
					className={classes.form}
					id="registerForm"
					onSubmit={handleSubmit}
				>
					<Field
						autoFocus
						className={classes.textField}
						component={RenderTextFieldWithErrors}
						onClickShowPassword={onClickShowPassword}
						label={<FormattedMessage id="password.new.message" defaultMessage="Nouveau mot de passe"/>}
						name="firstPassword"
						showPswdIcon={true}
						type={showPassword ? "text" : "password"}
					/>
					<Field
						autoComplete="current-password"
						autoFocus={false}
						className={classes.textField}
						component={RenderTextFieldWithErrors}
						label={<FormattedMessage id="password.confirm.message" defaultMessage="Confirmer nouveau mot de passe"/>}
						name="secondPassword"
						showPswdIcon={false}
						type="password"
					/>
					<Button
						className={classes.submit}
						color="primary"
						disabled={status === "LOADING" || disableSubmit}
						fullWidth
						type="submit"
						variant="contained"
					>
						<FormattedMessage id="password.submit.message" defaultMessage="Confirmer"/>
					</Button>
				</form>
				{status === "LOADING" ? (
					<SpinnerNew type={"logo_loading"} />
				) : (
					<div style={{ height: "138px" }} />
				)}
			</div>
		</Container>
	);
};
export default withStyles(styles)(PasswordForm);
