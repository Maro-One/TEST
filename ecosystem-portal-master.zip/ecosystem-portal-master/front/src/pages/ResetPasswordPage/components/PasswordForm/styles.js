// @flow

import colors from "../../../../utils/colors";

const styles = {
	"container": {
		"top": "50%",
		"left": "50%",
		"position": "absolute",
		"margin": "0",
		"transform": "translate(-50%, -50%)",
		"maxWidth": "500px"
	},
	"h1": {
		"fontWeight": "bold",
		"paddingBottom": "16px"
	},
	"h2": {"paddingBottom": "16px"},
	"paper": {
		"display": "flex",
		"flexDirection": "column"
	},
	"error": {"color": "red"},
	"form": {
		"width": "100%",
		"marginTop": "8px"
	},
	"textField": {
		"& label.Mui-focused": {"color": "green"},
		"& .MuiInput-underline:after": {"borderBottomColor": "green"},
		"& .MuiOutlinedInput-root": {"&.Mui-focused fieldset": {"borderColor": "green"}},
		"&.MuiFormControl-marginNormal": {
			"marginTop": "4px",
			"marginBottom": "16px"
		}
	},
	"a": {
		"color": "#9ea4b3",
		"&:hover": {"color": "#008000"}
	},
	"submit": {
		"margin": "24px 0px 16px",
		"backgroundColor": "#7bcb09",
		"&:hover": {"backgroundColor": "#008000"}
	},
	"textFieldError": {
		"& label.Mui-focused": {"color": "red"},
		"& .MuiInput-underline:after": {"borderBottomColor": "red"},
		"& .MuiOutlinedInput-root": {"&.Mui-focused fieldset": {"borderColor": "red"}},
		"&.MuiFormControl-marginNormal": {
			"marginTop": "4px",
			"marginBottom": "16px"
		},
		"& .MuiOutlinedInput-notchedOutline": {"borderColor": "red"},
		"& .MuiInputLabel-outlined.MuiInputLabel-shrink": {"color": "red"}
	},
	"checkbox": {
		"color": "green[400]",
		"& .MuiCheckbox-colorSecondary.Mui-checked": {"color": "green"}
	},
	"terms": {
		"color": "#1ca950",
		"&:hover": {"color": "green"}
	},
	"errors":{
		padding: "10px",
		border: "1px solid " + colors.waikawaGray,
		backgroundColor: colors.titanWhite,
		borderRadius: "4px",
		color: colors.red
	}
};

export default styles;
