import ResetPasswordPage from "./container/ResetPasswordPage";

export default ResetPasswordPage;