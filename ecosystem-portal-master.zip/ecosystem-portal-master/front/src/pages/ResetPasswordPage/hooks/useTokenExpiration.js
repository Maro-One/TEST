// @flow
import {useHistory, useParams} from "react-router";
import jwtDecode from "jwt-decode";
import {useDispatch} from "react-redux";
import {toast} from "react-toastify";
import {useEffect, useMemo} from "react";
import {useIntl} from "react-intl";

const useTokenExpiration = () => {
	const {token} = useParams();
	const history = useHistory();
	const dispatch = useDispatch();
	const intl = useIntl();
	const {isTokenExpired, diffInSec} = useMemo((): { isTokenExpired: boolean; diffInSec: number } => {
		const ret = {
			isTokenExpired: true,
			diffInSec: 0
		};
		if (token) {
			const {exp} = jwtDecode(token);
			const currentTimestampInSec = Date.now() / 1000;
			if (exp > currentTimestampInSec) {
				ret.isTokenExpired = false;
				ret.diffInSec = exp - currentTimestampInSec;
			}
			return ret;
		}
	}, [token]);
	useEffect(() => {
		const timeoutHandler = setTimeout(() => {
			toast(
				intl.formatMessage({id: "reset.password.link.expired", defaultMessage: "Votre lien de réinitialisation a expiré"}),
				{
					type: toast.TYPE.ERROR,
					autoClose: false
				}
			);
			history.push("/reset-password");
		}, diffInSec * 1000);
		return () => clearTimeout(timeoutHandler);
	}, [isTokenExpired, diffInSec, dispatch, history, intl]);
};

export default useTokenExpiration;
