import SupplierDetailBuyerContainer from "./container/SupplierDetailBuyerContainer";
export default SupplierDetailBuyerContainer;
