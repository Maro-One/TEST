// @flow

import React from "react";
import PurchaseOrderDetailComponent from "../component/PurchaseOrderDetailComponent";
import ConfirmDialog from "../../../common/ConfirmDialog";
import useConfirmValidation from "../../SupplierDetailPage/hooks/useConfirmValidation";
import FormattedMessage from "react-intl/lib/components/message";
import {RefuseButton} from "../../../common/CustomTable/styles";
import useConfirmRejection from "../../SupplierDetailPage/hooks/useConfirmRejection";
import TextField from "@material-ui/core/TextField";
import usePurchaseOrders from "../hooks/usePurchaseOrders";



const SupplierDetailBuyerContainer = () => {
	const {setOrderToValidate, handleAccept, confirmDialogOpen, handleClose, openConfirmDialog} = useConfirmValidation();
	const {
		setOrderToRefuse,
		handleRefuseAccept,
		confirmRefuseDialogOpen,
		handleRefuseClose,
		openConfirmRefuseDialog,
		rejectionComment,
		handleRejectionCommentChange
	} = useConfirmRejection();


	const {
		supplier,
		handleOnPurchaseOrdersPageChange,
		onFilterChange
	} = usePurchaseOrders();
	const handleOnPurchaseOrderValidate = (po) => {
		setOrderToValidate(po);
		openConfirmDialog();
	};
	const handleOnPurchaseOrderRefuse = (po) => {
		setOrderToRefuse(po);
		openConfirmRefuseDialog();
	};

	const taction = [
		{
			label: <FormattedMessage defaultMessage="Refuser" id="supplier.details.byers.refuse"/>,
			actionFunc: handleOnPurchaseOrderRefuse,
			fields: ["id", "fundingAgencyEmail", "bravoId"],
			shouldRender: () => false,
			Component: RefuseButton
		},
		{
			label: <FormattedMessage defaultMessage="Valider" id="supplier.details.byers.validate"/>,
			actionFunc: handleOnPurchaseOrderValidate,
			fields: ["id", "fundingAgencyEmail"],
			shouldRender: ({status}) => status !== "REFUSED" && status !== "APPROVED"
		}
	];
	const tHead = [
		{id: "funder", label: <FormattedMessage id={"supplier.details.byers.funder"} defaultMessage={"financeur"}/>},
		{
			id: "companyName",
			label: <FormattedMessage id={"supplier.details.byers.companyName"} defaultMessage={"company Name"}/>
		}
	]
	return (<>
		<PurchaseOrderDetailComponent
			supplier={supplier}
			taction={taction}
			tHead={tHead}
			onFilterChange={onFilterChange}
			onPurchaseOrdersPageChange={handleOnPurchaseOrdersPageChange}
		/>
		<ConfirmDialog
			handleAccept={handleAccept}
			handleClose={handleClose}
			isOpen={confirmDialogOpen}
			dialogDesc={<FormattedMessage
				defaultMessage="Voulez-vous vraiment valider cette demande?"
				id="supplier.details.byers.dialogDesc"/>}
			dialogTitle={<FormattedMessage
				defaultMessage="Message de confirmation"
				id="supplier.details.byers.dialogTitle"/>}
			acceptLabel={<FormattedMessage
				id="confirm.dialog.accept"
				defaultMessage="Accepter"/>}
		/>
		<ConfirmDialog
			handleAccept={handleRefuseAccept}
			handleClose={handleRefuseClose}
			isOpen={confirmRefuseDialogOpen}
			acceptDisabled={!rejectionComment || rejectionComment === ""}
			acceptLabel={<FormattedMessage id="confirm.dialog.confirm" defaultMessage="Confirmer"/>}
			dialogDesc={<TextField
				id="rejection-comment"
				label={<FormattedMessage
					id="confirm.dialog.comment"
					defaultMessage="Commentaire *"
				/>}
				multiline
				rows={4}
				fullWidth
				variant="outlined"
				value={rejectionComment}
				onChange={handleRejectionCommentChange}
			/>}
			dialogTitle={<FormattedMessage
				defaultMessage="Motif de rejet"
				id="supplier.details.byers.refus.dialogTitle"
			/>}
		/>
	</>
	);
};

export default SupplierDetailBuyerContainer;

