// @flow

import { useDispatch, useSelector } from "react-redux";
import {  useEffect } from "react";
import {getPurchaseOrders,  setFilterValue} from "../../SupplierDetailPage/actions";
/**
 * A hook for loading Purchase Orders and handle page changes.
 */
export default function() {
	const dispatch = useDispatch();

	const { supplierDetail ,filter } = useSelector(
		({ supplierDetail, purchaseOrder: {purchaseOrder :{filter}}}) => ({
			supplierDetail,
			 filter: filter?.selectedValue
		})
	);


	const onFilterChange = value => dispatch(setFilterValue(value));

	const handleOnPurchaseOrdersPageChange = page => {
		dispatch(getPurchaseOrders(0, page, filter));
	};
	useEffect(() => {
		dispatch(getPurchaseOrders(0, 0, filter));
	}, [dispatch, filter]);
	return {
		supplier :supplierDetail,
		filter,
		handleOnPurchaseOrdersPageChange,
		onFilterChange
	};
}
