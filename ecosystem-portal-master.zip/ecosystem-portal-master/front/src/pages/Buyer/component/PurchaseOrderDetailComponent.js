// @flow
import React from "react";
import PurchaseOrdersList from "../../SupplierDetailPage/components/PurchaseOrdersList";
import type {TActionType} from "../../../common/CustomTable/types";
import type {SupplierDetailStoreType} from "../../SupplierDetailPage/types";
import FormattedMessage from "react-intl/lib/components/message";
import SelectField from "../../../common/SelectField";
import {ROLE_BUYER} from "../../../utils/UserRole";

type Props = {
	supplier: SupplierDetailStoreType,
	onPurchaseOrdersPageChange: Function,
	taction: TActionType | TActionType[],
	tHead: any,
	onFilterChange: Function
};

const PurchaseOrderDetailComponent = ({
	supplier: {
		purchaseOrders,
	},
	onPurchaseOrdersPageChange,
	taction,
	tHead,
	onFilterChange
}: Props) => {

	const options = [{
		label: <FormattedMessage id="status.approved"
		                         defaultMessage={"Approuvée"}/>,
		value: "APPROVED"
	}, {
		label: <FormattedMessage id="status.refused"
		                         defaultMessage={"Refusée"}/>,
		value: "REFUSED"
	}, {
		label: <FormattedMessage id="status.pending"
		                         defaultMessage={"En attente"}/>,
		value: "PENDING"
	}
	];
	const onChange = (option, {action}) => {
		switch (action) {
			case "select-option":
				onFilterChange(option.value);
				break;
			case "clear":
				onFilterChange(null);
				break;
			default:
				break;
		}
	};
	const filterComponent = (
		<SelectField
			ariaLabelledby="statusFilter"
			options={options}
			placeholder={<FormattedMessage
				id="command.filter"
				defaultMessage="Filtrer par status"
			/>}
			isClearable
			onChange={onChange}
		/>
	);
	return (

		<PurchaseOrdersList
			purchaseOrders={purchaseOrders}
			onPurchaseOrdersPageChange={onPurchaseOrdersPageChange}
			taction={taction}
			tHead={tHead}
			filterComponent={filterComponent}
			userRole={ROLE_BUYER}
		/>
	);
};

export default PurchaseOrderDetailComponent;
