// @flow

import {select, takeLatest} from "redux-saga/effects";
import {callEndpoint} from "../../../store/sagas/callEndpointSaga";
import {
	getPurchaseOrders,
	getPurchaseOrdersError,
	getPurchaseOrdersSuccess,
	getSupplierInfoError,
	getSupplierInfoSuccess,
	getSupplierScoringError,
	getSupplierScoringSuccess
} from "../actions";
import {
	GET_PURCHASE_ORDERS,
	GET_SUPPLIER_INFO,
	GET_SUPPLIER_SCORING,
	REFUSE_PURCHASE_ORDER,
	VALIDATE_PURCHASE_ORDER
} from "../actions/constants";
import {
	PURCHASE_ORDERS_API,
	PURCHASE_ORDERS_BUYER_API,
	REFUSE_PURCHASE_ORDER_BUYER_API,
	SUPPLIER_INFO_API,
	SUPPLIER_SCORING_API,
	VALIDATE_PURCHASE_ORDER_BUYER_API
} from "./apiConstants";
import type {Saga} from "redux-saga";
import type {
	GetPurchaseOrdersActionType,
	GetSupplierInfoActionType,
	GetSupplierScoringActionType,
	RefusePurchaseOrderActionType,
	ValidatePurchaseOrderActionType
} from "../actions/actionTypes";
import type {PurchaseOrderResponsePayloadType} from "../types";
import type {UserRole} from "../../../utils/UserRole";
import {ROLE_BUYER} from "../../../utils/UserRole";
import getUserRole from "../../../store/selectors/getUserRole";

function* handleGetSupplierInfo(action: GetSupplierInfoActionType): Saga<void> {
	yield* callEndpoint(
		{
			url: SUPPLIER_INFO_API + action.payload.id,
			method: "get"
		},
		{
			successActionCreator: getSupplierInfoSuccess,
			errorActionCreator: getSupplierInfoError
		}
	);
}

export function* watchGetSupplierInfo(): Saga<void> {
	yield takeLatest(GET_SUPPLIER_INFO, handleGetSupplierInfo);
}

function* handleGetSupplierScoring(
	action: GetSupplierScoringActionType
): Saga<void> {
	yield* callEndpoint(
		{
			url: SUPPLIER_SCORING_API + action.payload.id,
			method: "get"
		},
		{
			successActionCreator: getSupplierScoringSuccess,
			errorActionCreator: getSupplierScoringError
		}
	);
}

export function* watchGetSupplierScoring(): Saga<void> {
	yield takeLatest(GET_SUPPLIER_SCORING, handleGetSupplierScoring);
}

function* handleGetPurchaseOrders(
	action: GetPurchaseOrdersActionType
): Saga<void> {
	const userRole: UserRole = yield select(getUserRole);
	let api = null, params={};
	if (userRole === ROLE_BUYER) {
		api = PURCHASE_ORDERS_BUYER_API
		params= action.payload.filter!==null ? {filter :action.payload.filter}: {}
	} else {
		api = PURCHASE_ORDERS_API + action.payload.id;
	}
	yield* callEndpoint(
		{
			url: api,
			params: {page: action.payload.page, ...params},
			method: "get"
		},
		{
			dataTransform: (resp: PurchaseOrderResponsePayloadType) => ({
				list: resp.content,
				count: resp.count,
				page: action.payload.page
			}),
			successActionCreator: getPurchaseOrdersSuccess,
			errorActionCreator: getPurchaseOrdersError
		}
	);
}

export function* watchGetPurchaseOrders(): Saga<void> {
	yield takeLatest(GET_PURCHASE_ORDERS, handleGetPurchaseOrders);
}

function* handleValidatePurchaseOrder(
	action: ValidatePurchaseOrderActionType
): Saga<void> {
	const userRole: UserRole = yield select(getUserRole);
	if (userRole !== ROLE_BUYER) {
		return;
	}
	const {supplierID, page} = yield select(({supplierDetail: {purchaseOrders: {data: {page, list}}}}) => ({
		page,
		supplierID: list[0].bravoId
	}));
	yield* callEndpoint(
		{
			url: VALIDATE_PURCHASE_ORDER_BUYER_API + action.payload.id,
			params: {fundingAgencyEmail: action.payload.fundingAgencyEmail},
			method: "put"
		},
		{
			dataTransform: () => {
			},
			successActionCreator: () => getPurchaseOrders(supplierID, page),
			errorActionCreator: () => {
			}
		}
	);
}

export function* watchValidatePurchaseOrder(): Saga<void> {
	yield takeLatest(VALIDATE_PURCHASE_ORDER, handleValidatePurchaseOrder);
}


function* handleRefusePurchaseOrder(
	action: RefusePurchaseOrderActionType
): Saga<void> {
	const userRole: UserRole = yield select(getUserRole);
	if (userRole !== ROLE_BUYER) {
		return;
	}
	yield* callEndpoint(
		{
			url: REFUSE_PURCHASE_ORDER_BUYER_API + action.payload.fundingRequestId + "/" + action.payload.bravoId,
			params: {comment: action.payload.comment},
			method: "put"
		},
		{
			dataTransform: () => {
			},
			successActionCreator: () => getPurchaseOrders(action.payload.bravoId, action.payload.page),
			errorActionCreator: () => {
			}
		}
	);
}

export function* watchRefusePurchaseOrder(): Saga<void> {
	yield takeLatest(REFUSE_PURCHASE_ORDER, handleRefusePurchaseOrder);
}
