// @flow
export const SUPPLIER_INFO_API = "/api/supplier/supplier-info/";
export const SUPPLIER_SCORING_API = "/api/supplier/supplier-scoring/";
export const PURCHASE_ORDERS_API = "/api/funding-request/approved-list/";
export const PURCHASE_ORDERS_BUYER_API = "/api/funding-request/supplier-list-all-SAP/";
export const VALIDATE_PURCHASE_ORDER_BUYER_API = "/api/funding-request/";
export const REFUSE_PURCHASE_ORDER_BUYER_API = "/api/funding-request/refuse/";
