// @flow

import {
	GET_SUPPLIER_INFO,
	GET_SUPPLIER_INFO_ERROR,
	GET_SUPPLIER_INFO_SUCCESS,
	GET_SUPPLIER_SCORING,
	GET_SUPPLIER_SCORING_ERROR,
	GET_SUPPLIER_SCORING_SUCCESS,
	GET_PURCHASE_ORDERS,
	GET_PURCHASE_ORDERS_SUCCESS,
	GET_PURCHASE_ORDERS_ERROR
} from "../actions/constants";
import type {SupplierDetailStoreType} from "../types";
import type { SupplierDetailActionType } from "../actions/actionTypes";

const DefaultState: SupplierDetailStoreType = {
	supplierInfo: {
		data: null,
		loading: false,
		success: false,
		error: null
	},
	supplierScorings: {
		data: [],
		loading: false,
		success: false,
		error: null
	},
	purchaseOrders: {
		data: {
			list: [],
			count: 0,
			page: 0
		},
		loading: false,
		success: false,
		error: null
	}
};

const reducer = (
	state: SupplierDetailStoreType = DefaultState,
	action: SupplierDetailActionType
): SupplierDetailStoreType => {
	switch (action.type) {
		case GET_SUPPLIER_INFO:
			return {
				...state,
				supplierInfo: { ...state.supplierInfo, loading: true }
			};
		case GET_SUPPLIER_INFO_SUCCESS:
			return {
				...state,
				supplierInfo: {
					...state.supplierInfo,
					loading: false,
					success: true,
					data: action.payload
				}
			};
		case GET_SUPPLIER_INFO_ERROR:
			return {
				...state,
				supplierInfo: {
					...state.supplierInfo,
					loading: false,
					success: false,
					error: action.payload.error
				}
			};
		case GET_SUPPLIER_SCORING:
			return {
				...state,
				supplierScorings: {
					...state.supplierScorings,
					loading: true
				}
			};
		case GET_SUPPLIER_SCORING_SUCCESS:
			return {
				...state,
				supplierScorings: {
					...state.supplierScorings,
					loading: false,
					success: true,
					data: action.payload
				}
			};
		case GET_SUPPLIER_SCORING_ERROR:
			return {
				...state,
				supplierScorings: {
					...state.supplierScorings,
					loading: false,
					success: false,
					error: action.payload.error
				}
			};
		case GET_PURCHASE_ORDERS:
			return {
				...state,
				purchaseOrders: {
					...state.purchaseOrders,
					loading: true,
					status: "LOADING"
				}
			};
		case GET_PURCHASE_ORDERS_SUCCESS:
			return {
				...state,
				purchaseOrders: {
					...state.purchaseOrders,
					loading: false,
					success: true,
					status: "SUCCESS",
					data: {
						...state.purchaseOrders.data,
						...action.payload
					}
				}
			};
		case GET_PURCHASE_ORDERS_ERROR:
			return {
				...state,
				purchaseOrders: {
					...state.purchaseOrders,
					loading: false,
					success: false,
					status: "ERROR",
					error: action.payload.error
				}
			};
		default:
			return state;
	}
};

export default reducer;
