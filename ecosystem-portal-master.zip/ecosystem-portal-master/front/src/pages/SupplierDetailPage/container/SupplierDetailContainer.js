// @flow

import React, {useEffect} from "react";
import {connect, useSelector} from "react-redux";
import {useParams} from "react-router";
import {
	getPurchaseOrders,
	getSupplierInfo,
	getSupplierScoring
} from "../actions";
import SupplierDetailComponent from "../components/SupplierDetailComponent";
import type {SupplierDetailStoreType, HistoryType} from "../types";
import FormattedMessage from "react-intl/lib/components/message";
import type {UserRole} from "../../../utils/UserRole";
import getUserRole from "../../../store/selectors/getUserRole";

type Props = {
	supplier: SupplierDetailStoreType,
	history: HistoryType,
	dispatchGetSupplierInfo: typeof getSupplierInfo,
	dispatchGetSupplierScoring: typeof getSupplierScoring,
	dispatchGetPurchaseOrders: typeof getPurchaseOrders
};

const SupplierDetailContainer = ({
	supplier,
	history,
	dispatchGetSupplierInfo,
	dispatchGetSupplierScoring,
	dispatchGetPurchaseOrders
}: Props) => {
	const {bravoId} = useParams();
	const userRole: UserRole = useSelector(getUserRole);
	useEffect(() => {
		if (!isNaN(bravoId)) {
			dispatchGetSupplierInfo(bravoId);
			dispatchGetSupplierScoring(bravoId);
			dispatchGetPurchaseOrders(bravoId, 0);
		} else {
			history.push("/404");
		}
	}, [
		bravoId,
		dispatchGetSupplierInfo,
		dispatchGetSupplierScoring,
		dispatchGetPurchaseOrders,
		history
	]);
	
	const handleOnPurchaseOrderDetail = ({ id, purchaseOrderId, purchaseOrderRef, requestSource }) => {
		// Si purchaseOrderId est null ou différent de purchaseOrderRef, utilise purchaseOrderRef
		const orderIdentifier = purchaseOrderId && purchaseOrderId === purchaseOrderRef ? purchaseOrderId : purchaseOrderRef;
		history.push(`/order/${orderIdentifier}/${bravoId}/${id}/${requestSource}`);
	};
	
	
	const handleOnPurchaseOrdersPageChange = page => {
		dispatchGetPurchaseOrders(bravoId, page);
	};
	const taction = {
		label: <FormattedMessage defaultMessage="Voir détails" id="supplier.list.see.detail" />,
		actionFunc: handleOnPurchaseOrderDetail,
		fields: ["id", "purchaseOrderId", "purchaseOrderRef", "requestSource"], // Ajoute "purchaseOrderRef"
		shouldRender: () => true
	};
	
	return (
		<SupplierDetailComponent
			supplier={supplier}
			taction={taction}
			userRole={userRole}
			onPurchaseOrdersPageChange={handleOnPurchaseOrdersPageChange}
		/>
	);
};

const mapStateToProps = state => ({
	supplier: state.supplierDetail
});

const mapDispatchToProps = {
	dispatchGetSupplierInfo: getSupplierInfo,
	dispatchGetSupplierScoring: getSupplierScoring,
	dispatchGetPurchaseOrders: getPurchaseOrders
};

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(SupplierDetailContainer);
