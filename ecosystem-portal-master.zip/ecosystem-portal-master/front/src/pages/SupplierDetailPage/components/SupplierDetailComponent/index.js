import SupplierDetailComponent from "./SupplierDetailComponent";

export default SupplierDetailComponent;