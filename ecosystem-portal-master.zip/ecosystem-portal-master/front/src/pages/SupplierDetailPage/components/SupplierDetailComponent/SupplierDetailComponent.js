// @flow
import MailOutlineIcon from "@material-ui/icons/MailOutline";
import React from "react";
import BreadCrumbs from "../../../../common/BreadCrumbs";
import PurchaseOrdersList from "../PurchaseOrdersList";
import SupplierScoring from "../SupplierScoring";
import useStyles from "./styles";
import SpinnerNew from "../../../../common/SpinnerNew/SpinnerNew";
import type {SupplierDetailStoreType} from "../../types";
import FormattedMessage from "react-intl/lib/components/message";
import type {TActionType} from "../../../../common/CustomTable/types";
import type {UserRole} from "../../../../utils/UserRole";

type Props = {
    supplier: SupplierDetailStoreType,
    onPurchaseOrdersPageChange: Function,
    taction: TActionType | TActionType[],
	tHead: any,
	userRole: UserRole
};

const SupplierDetailComponent = ({
	 supplier: {
		 supplierInfo: {data, loading},
		 supplierScorings,
		 purchaseOrders,
	 },
	 onPurchaseOrdersPageChange	,
	taction,
	tHead,
	userRole

}: Props) => {
	const classes = useStyles();

	let breadcrumbItems = [{
		label: <FormattedMessage id="supplier.list.suppliers" defaultMessage="Fournisseurs"/>,
		to: "/"
	}];

	let supplierInfoContent = <BreadCrumbs items={breadcrumbItems}/>;

	if (!loading && data) {
		const {companyName, dunsOrICECode, professionalEmail} = data;
		breadcrumbItems = [
			{label: <FormattedMessage id="supplier.list.suppliers" defaultMessage="Fournisseurs"/>, to: "/"},
			{
				label: companyName,
				fontWeight: "bold"
			}
		];
		supplierInfoContent = (
			<BreadCrumbs items={breadcrumbItems}>
				<span className={classes.supplierInfo}>
					{dunsOrICECode && <>(ICE: {dunsOrICECode} )</>}
					{!dunsOrICECode && <span>&nbsp;</span>}
					<span className={classes.mailHolder}>
						<MailOutlineIcon className={classes.mailIcon}/>
						{professionalEmail}
					</span>
				</span>
			</BreadCrumbs>
		);
	}
	
	if (loading || supplierScorings.loading || purchaseOrders.loading) {
		return (
			<>
				<BreadCrumbs items={breadcrumbItems}/>
				{!supplierScorings.loading && (
					<SupplierScoring supplierScorings={supplierScorings}/>
				)}
				<div className={classes.loadingDiv}>
					<SpinnerNew type="logo_loading"/>
				</div>
			</>
		);
	}

	return (
		<>
			{supplierInfoContent}
			<SupplierScoring supplierScorings={supplierScorings}/>
			<PurchaseOrdersList
				purchaseOrders={purchaseOrders}
				onPurchaseOrdersPageChange={onPurchaseOrdersPageChange}
				taction={taction}
				tHead={tHead}
				userRole={userRole}
			/>
		</>
	);
};

export default SupplierDetailComponent;
