import { makeStyles } from "@material-ui/core/styles";
import colors from "../../../../utils/colors";

const useStyles = makeStyles({
	container: {
		backgroundColor: colors.white
	},
	header: {
		height: 67,
		display: "flex",
		alignItems: "center",
		padding: "0 24px",
		borderBottom: `1px solid ${colors.mischka}`,
		color: colors.waikawaGray
	},
	supplierInfo: {
		marginLeft: 11,
		flexGrow: 100,
		display: "flex",
		justifyContent: "space-between"
	},
	mailHolder: {
		display: "flex",
		alignItems: "center"
	},
	mailIcon: {
		color: colors.periwinkleGray,
		height: "20px",
		marginRight: "5px",
		marginTop: "1px"
	},
	loadingDiv: {
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		height: "100%"
	}
});

export default useStyles;
