import {makeStyles} from "@material-ui/core/styles";
import colors from "../../../../../utils/colors";
import fonts from "../../../../../utils/fonts";
import TableCell from "@material-ui/core/TableCell";
import TableRow from "@material-ui/core/TableRow";
import withStyles from "@material-ui/core/styles/withStyles";
import {Chip} from "@material-ui/core";


const useStyles = makeStyles({
	container: {
		borderBottom: `1px solid ${colors.mischka}`
	},
	subContainer: {
		padding: 10,
	},
	itemBox: {
		margin: "32px auto",
		border: `1px solid ${colors.mischka}`,
		borderRadius: 6,
		minHeight: 174,
		padding: "24px 0",
	},
	itemBoxTitle: {
		fontSize: 14,
		color: colors.lynch,
		textTransform: "uppercase",
		textAlign: "center",
		marginBottom: "20px"
	},
	itemBoxSubTitle: {
		fontSize: 12,
		color: colors.lynch,
		textTransform: "capitalize",
		textAlign: "center",
		marginBottom: "20px",
		lineHeight: "1.5rem"
	},
	itemBoxValue:{
		fontSize: 24,
		textTransform: "capitalize",
		fontFamily: fonts.robotoBold,
		color: colors.rhinoBlue,
		textAlign: "center"
	},
	ratingCapaBox:{
		borderRight: "1px solid #E9ECF4",
		marginBottom: "10px"
	},
	tableBox:{
		padding: "0 20px"
	},
	negativeRate:{
		color: colors.statusError,
		fontSize: "14px",
		display: "flex"
	},
	positiveRate:{
		color: colors.lima,
		fontSize: "14px",
		display: "flex"
	},
	statusmainActivity:{
		fontFamily: "Roboto-Medium",
		fontSize: "15px",
		textAlign: "center"
	},
	statusBox:{
		borderRight: "1px solid #E9ECF4"
	}
});

export const StyledTableCell = withStyles((theme) => ({
	head: {
		fontSize: 12,
		color: colors.lynch,
		textTransform: "capitalize",
		textAlign: "left",
		margin:0,
		padding: 0,
		border: "none"
	},
	body: {
		fontSize: 15,
		textTransform: "capitalize",
		fontFamily: fonts.robotoRegular,
		color: colors.indigo2,
		margin:0,
		padding: "15px 0",
		border: "none",
		borderBottom: "1px solid #E9ECF4",
		textAlign: "left",
		lineHeight: "18px",
		minWith: "200px"
	},
}))(TableCell);
export const StyledTableCellBold = withStyles(
	{
		body: {
			fontFamily: fonts.robotoMedium,
			minWith: "200px"
		},
	}
)(StyledTableCell);
export const StyledTableRow = withStyles({
	root: {
		border: "none",
	},
})(TableRow);
export const StyledScoreChip = withStyles({
	root: {
		backgroundColor: colors.titanWhite,
		width: "82px",
		fontSize: 15,
		fontFamily: fonts.robotoMedium,
	},
})(Chip);
export default useStyles;
