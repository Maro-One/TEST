// @flow
import React, {useState} from "react";
import Grid from "@material-ui/core/Grid";
import useStyles, {StyledScoreChip, StyledTableCell, StyledTableCellBold, StyledTableRow} from "./styles";
import type {ScoringType, StoreType} from "../../../types";
import FormattedMessage from "react-intl/lib/components/message";
import TableHead from "@material-ui/core/TableHead";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import Button from "@material-ui/core/Button";
import CustomToolTip from "../../../../../common/CustomToolTip";
import {truncString} from "../../../../../utils/helper";
import Typography from "@material-ui/core/Typography";
import ChangeRate from "./ChangeRate";

type Props = {
	supplierScorings: StoreType<ScoringType>
};

const SupplierScoring = ({
	supplierScorings: {data, loading, success}
}: Props) => {
	const classes = useStyles();
	const [showAll, setShowAll] = useState(false);
	const showMore = () => {
		setShowAll(!showAll);
	};
	let content = null;
	if (success && !loading && data) {
		const {supplierStatus, scoringCapabilities, scoringFinancial, mainActivity} = data;
		const rows = showAll ? scoringCapabilities : scoringCapabilities.slice(0, 2);
		content = (
			<div className={classes.container}>
				<Grid container direction="row" justify="space-evenly" alignItems="center" className={classes.subContainer}>
					<Grid item container direction="column" xs={4} alignItems="center" className={classes.itemBox} spacing={4}>
						<Grid item direction={"row"} container justify={"center"}>				
							<Grid item md={6} xs={10} direction="column" alignItems="center" justify={"center"} className={classes.statusBox}>
								<Grid item className={classes.itemBoxSubTitle}><FormattedMessage id="supplier.scoring.status"/></Grid>
								<Grid item direction={"row"} container alignItems={"center"} justify={"center"}>
									<Grid item className={classes.statusmainActivity}>{(supplierStatus) ? supplierStatus : "--"}</Grid>
								</Grid>
							</Grid>
							<Grid item md={6} xs={10} direction="column" alignItems="center" justify={"center"}>
								<Grid item className={classes.itemBoxSubTitle}><FormattedMessage id="supplier.scoring.main.activity"/></Grid>
								<Grid item direction={"row"} container alignItems={"center"} justify={"center"}>
									<Grid item className={classes.statusmainActivity}>{(mainActivity) ? mainActivity : "--"}</Grid>
								</Grid>
							</Grid>
						</Grid>
					</Grid>
					<Grid item container direction="column" xs={7} alignItems="center" className={classes.itemBox}>
						<span className={classes.itemBoxTitle}><FormattedMessage id="supplier.scoring.positioning"/></span>
						<Grid item container justify="center" direction="row">
							<Grid item md={3} xs={10} direction="column" alignItems="center" justify={"center"} className={classes.ratingCapaBox}>
								<Grid item className={classes.itemBoxSubTitle}><FormattedMessage id="supplier.scoring.rating"/></Grid>
								<Grid item direction={"row"} container alignItems={"center"} justify={"center"}>
									<Grid item className={classes.itemBoxValue}>{(scoringFinancial && scoringFinancial.score) ? scoringFinancial.score + "%" : "--"}</Grid>
									{scoringFinancial && (<ChangeRate changeRate={scoringFinancial.changeRate } />)}
								</Grid>
							</Grid>
							<Grid item md={9} xs={10} direction="column" alignItems="center" justify={"center"} className={classes.tableBox}>
								<Table aria-label="simple table">
									<TableHead>
										<StyledTableRow>
											<StyledTableCell><FormattedMessage id="supplier.scoring.capabilities"/></StyledTableCell>
											<StyledTableCell><FormattedMessage id="supplier.scoring.category"/></StyledTableCell>
											<StyledTableCell><FormattedMessage id="supplier.scoring.position"/></StyledTableCell>
										</StyledTableRow>
									</TableHead>
									<TableBody>
										{rows.length === 0 && (
											<StyledTableRow>
												<StyledTableCell>
													<Grid direction={"row"} container alignItems={"center"}>
														<Grid item>
															{"--"}
														</Grid>
													</Grid>
												</StyledTableCell>
												<StyledTableCell>
													<Grid direction={"row"} container alignItems={"center"}>
														<Grid item>
															{"--"}
														</Grid>
													</Grid>
												</StyledTableCell>
												<StyledTableCellBold>
													<Grid direction={"row"} container alignItems={"center"}>
														<Grid item>
															{"--"}
														</Grid>
													</Grid>
												</StyledTableCellBold>
											</StyledTableRow>
										)}
										{rows.map((row) => (
											<StyledTableRow key={row.category}>
												<StyledTableCell>
													<Grid direction={"row"} container alignItems={"center"}>
														<Grid item>
															<StyledScoreChip label={row.score ? row.score + "%" : "--"}/>
														</Grid>
														<ChangeRate changeRate={row.changeRate} />
													</Grid>
												</StyledTableCell>
												<StyledTableCell>
													<CustomToolTip
														arrow={false}
														placement="bottom-start"
														title={row.category}
													>
														<Typography>{truncString(row.category, 24)}</Typography>
													</CustomToolTip>
												</StyledTableCell>
												<StyledTableCellBold>
													<Grid direction={"row"} container alignItems={"center"}>
														<Grid item>
															{row.supplierPositioning}
														</Grid>
														<ChangeRate changeRate={row.positionChangeRate} arrowOnly />
													</Grid>
												</StyledTableCellBold>
											</StyledTableRow>
										))}
									</TableBody>
								</Table>
								{scoringCapabilities.length > 2 && <div style={{textAlign: "center"}}>
									<Button onClick={showMore} variant={"text"}>
										<FormattedMessage id={"supplier.scoring." + (showAll ? "showless" : "showall")}/>
									</Button>
								</div>}
							</Grid>
						</Grid>
					</Grid>
				</Grid>
			</div>
		);
	}
	
	return content;
};

export default SupplierScoring;
