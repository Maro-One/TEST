// @flow

import React from "react";
import Grid from "@material-ui/core/Grid";
import classnames from "classnames";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import ArrowDropUpIcon from "@material-ui/icons/ArrowDropUp";
import useStyles from "./styles";

type Props = {
	arrowOnly?: boolean,
  changeRate: number
}

const ChangeRate = ({changeRate, arrowOnly = false}: Props) => {
	const classes = useStyles();
	return (
		changeRate !== 0 && 
    <>
    	<Grid item
    		className={classnames({[classes.negativeRate]: changeRate < 0, [classes.positiveRate]: changeRate > 0})}>
    		{changeRate < 0 && <ArrowDropDownIcon fontSize="small"/>}
    		{changeRate > 0 && <ArrowDropUpIcon fontSize="small"/>}
    	</Grid>
    	{arrowOnly || (
    		<Grid item className={classnames({[classes.negativeRate]: changeRate < 0, [classes.positiveRate]: changeRate >= 0})}>
    			{changeRate}%
    		</Grid>
    	)}
    </>
	);
};

export default ChangeRate;