import SupplierScoring from "./SupplierScoring/SupplierScoring";

export default SupplierScoring;