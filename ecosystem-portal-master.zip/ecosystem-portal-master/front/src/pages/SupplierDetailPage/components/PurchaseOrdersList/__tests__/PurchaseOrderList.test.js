import React from "react";
import renderer from "react-test-renderer";
import PurchaseOrdersList from "../PurchaseOrdersList";
import {ROLE_AGENCY} from "../../../../../utils/UserRole";
import ConnectedIntlProvider from "../../../../ConnectedIntlProvider";

it("PurchaseOrderList renders correctly", () => {
	const tree = renderer
		.create(
			<ConnectedIntlProvider>
				<PurchaseOrdersList
					purchaseOrders={
						{
							data: {
								list: [
									{
										id: 1,
										bravoId: 1,
										supplierOracleCode: "supplierOracleCode",
										purchaseOrderId: "purchaseOrderId",
										purchaseOrderRef: "purchaseOrderRef",
										businessUnitName: "businessUnitName",
										status: "APPROVED",
										purchaseOrderStatus: "APPROVED",
										purchaseOrderDescription: "purchaseOrderDescription",
										purchaseOrderApprovalDate: "29 May 2020",
										purchaseOrderAmount: 10,
										achievementPercentage: 1,
										achievementPercentageCallOf: 1,
										fundingAgencyName: "fundingAgencyName",
										approvalAttachmentAmount: 5,
										billedAmount: 5,
										paidAmount: 7,
										purchaseOrderCategory: "purchaseOrderCategory",
										fundingAgencyEmail: "a@g.c",
									}
								],
								count: 1,
								page: 0
							},
							loading: false
						}
					}
					onPurchaseOrdersPageChange={() => {
					}}
					taction={[]}
					userRole={ROLE_AGENCY}
				/></ConnectedIntlProvider>)
		.toJSON();
	expect(tree).toMatchSnapshot();
});
