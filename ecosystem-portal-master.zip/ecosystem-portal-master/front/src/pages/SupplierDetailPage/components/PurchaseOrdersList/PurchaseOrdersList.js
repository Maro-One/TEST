// @flow

import React from "react";
import CustomChip from "../../../../common/CustomChip";
import CustomTable from "../../../../common/CustomTable";
import Pagination from "../../../../common/Pagination";
import { formatDate, formatPercentForContractOrCmd,formatCurrencyForContractOrCmd } from "../../../../utils/formatters";
import useStyles from "./styles";
import type { PurchaseOrdersDataType, PurchaseOrderType, StoreType } from "../../types";
import type { TActionType } from "../../../../common/CustomTable/types";
import { Grid } from "@material-ui/core";
import type { UserRole } from "../../../../utils/UserRole";
import { ROLE_BUYER } from "../../../../utils/UserRole";
import { FormattedMessage } from "react-intl";

type Props = {
	purchaseOrders: StoreType<PurchaseOrdersDataType>,
	onPurchaseOrdersPageChange: Function,
	taction: TActionType | TActionType[],
	tHead: any,
	filterComponent?: any,
	userRole: UserRole
};

const PurchaseOrdersList = ({
	purchaseOrders: { data, loading, status },
	onPurchaseOrdersPageChange, taction,
	tHead = [],
	filterComponent = null, userRole
}: Props) => {
	const classes = useStyles();
	const isBuyerRole = userRole === ROLE_BUYER;

	const thead = [
		{ id: "ref", label: <FormattedMessage id={"purchase.order.list.ref.order"} defaultMessage={"ref commande"} /> },
		{ id: "statusComp", label: <FormattedMessage id={"purchase.order.list.status"} defaultMessage={"status"} /> },
		{
			id: "approbationDate",
			label: <FormattedMessage id={"purchase.order.list.date"} defaultMessage={"date d'approbation"} />
		},
		{
			id: "amount",
			label: <FormattedMessage id={"purchase.order.list.amount"} defaultMessage={"montant commande"} />
		},
		{
			id: "achievementPercent",
			label: <FormattedMessage id={"purchase.order.list.achievement.percentage"} defaultMessage={"pourcentage de réalisation"} />
		},
		...tHead
	];
	const tcellHover = { id: "ref", value: "description" };

	let trows = [];

	if (!loading && data && data.list) {
		const { list } = data;
		list.map((po: PurchaseOrderType) => ( console.log("purchaseOrder.purchaseOrderApprovalDate",po.purchaseOrderApprovalDate)
		));
		trows = list.map((po: PurchaseOrderType) => {
			// Choix entre purchaseOrderId et purchaseOrderRef selon les conditions mentionnées
			const orderIdentifier = po.purchaseOrderId && po.purchaseOrderId === po.purchaseOrderRef ? po.purchaseOrderId : po.purchaseOrderRef;
			return {
				id: po.id,
				bravoId: po.bravoId,
				purchaseOrderId: po.purchaseOrderId, // Garde les deux valeurs pour les besoins
				purchaseOrderRef: po.purchaseOrderRef, // Garde les deux valeurs pour les besoins
				ref: <strong>{po.purchaseOrderRef}</strong>,
				description: po.purchaseOrderDescription,
				status: isBuyerRole ? po.status : po.purchaseOrderStatus,
				statusComp: <CustomChip value={isBuyerRole ? po.status : po.purchaseOrderStatus} />,
				approbationDate: po.purchaseOrderApprovalDate ? formatDate(new Date(po.purchaseOrderApprovalDate)) : undefined,
				amount: formatCurrencyForContractOrCmd(po.purchaseOrderAmount, po.purchaseOrderId === po.purchaseOrderRef),
				achievementPercent: formatPercentForContractOrCmd(
					po.purchaseOrderId === po.purchaseOrderRef ?
							 	po.achievementPercentage : po.achievementPercentageCallOf, 
					 			po.purchaseOrderId === po.purchaseOrderRef),
				fundingAgencyEmail: po.fundingAgencyEmail,
				[tHead[0]?.id]: po.fundingAgencyName,
				[tHead[1]?.id]: po.companyName,
				requestSource: po.supplierOracleCode != null ? "o" : "s", // Si supplierOracleCode est null la source des données utilisée est oracle
				orderIdentifier // Ajoute cet identifiant dans chaque ligne pour être utilisé dans le `handleOnPurchaseOrderDetail`
			};
		});
		

	}

	const pagination = (
		<Pagination
			count={data.count}
			page={data.page}
			onChangePage={onPurchaseOrdersPageChange}
		/>
	);
	return <div className={classes.container}>
		<div className={classes.header}>
			<div className={classes.headerTitle}>
				<FormattedMessage id="purchase.order.list.orders" defaultMessage="Commandes" />&nbsp;
				<span className={classes.headerSubtitle}>({data.count})</span>
			</div>
			<Grid
				item
				container
				xs={12}
				md={6}
				className={classes.gridItem}
				justify="flex-end"
			>
				{filterComponent}
				{pagination}
			</Grid>

		</div>
		<CustomTable
			thead={thead}
			trows={trows}
			taction={taction}
			tcellHover={tcellHover}
			dataStatus={status}
		/>
		<div className={classes.footer}>
			<span className={classes.footerContent}>
				{data.count} <FormattedMessage id={`purchase.order.list.order${data.count > 1 ? "s" : ""}`}
					defaultMessage="Commandes" />
			</span>
			{pagination}
		</div>
	</div>;
};

export default PurchaseOrdersList;
