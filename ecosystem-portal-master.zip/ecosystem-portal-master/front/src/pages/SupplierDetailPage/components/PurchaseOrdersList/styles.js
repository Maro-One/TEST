import {makeStyles} from "@material-ui/core/styles";
import colors from "../../../../utils/colors";
import fonts from "../../../../utils/fonts";

const useStyles = makeStyles({
	container: {
		padding: 24
	},
	header: {
		margin: "10px 0 36px 0",
		width: "100%",
		display: "flex",
		justifyContent: "space-between",
		alignItems: "center"
	},
	headerTitle: {
		fontSize: 24,
		fontFamily: fonts.robotoMedium,
		color: colors.rhinoBlue,
		width: 300
	},
	headerSubtitle: {
		fontFamily: fonts.robotoLight
	},
	footer: {
		marginTop: 33,
		width: "100%",
		display: "flex",
		justifyContent: "space-between",
		alignItems: "center"
	},
	footerContent: {
		width: 300,
		fontSize: 16,
		fontStyle: "italic",
		fontFamily: fonts.robotoLight,
		color: colors.rhinoBlue
	},
	gridItem: {
		display: "flex",
		alignItems: "center"
	}
});


export default useStyles;
