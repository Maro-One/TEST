// @flow

import React from "react";
import type {SupplierDetailStoreType} from "../../../types";
import SupplierDetailComponent from "../../SupplierDetailComponent";
import {useSelector} from "react-redux";
import getUserRole from "../../../../../store/selectors/getUserRole";
type Props = {
	supplier: SupplierDetailStoreType,
	onPurchaseOrdersPageChange: Function,
	taction: string,
};

const SupplierDetailBuyerComponent = (props: Props) => {
	const userRole = useSelector(getUserRole);
	return <SupplierDetailComponent
		{...props}
		userRole={userRole}
	/>
};

export default SupplierDetailBuyerComponent;
