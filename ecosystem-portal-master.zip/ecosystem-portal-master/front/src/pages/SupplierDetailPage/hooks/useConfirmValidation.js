// @flow
import {validatePurchaseOrder} from "../actions";
import useConfirmModal from "./useConfirmModal";

export default function useConfirmValidation() {
	const {setValue, handleAccept, confirmDialogOpen, handleClose, openConfirmDialog} = useConfirmModal((orderToValidate) => validatePurchaseOrder(
		orderToValidate.id,
		orderToValidate.fundingAgencyEmail
	));
	return {
		setOrderToValidate: setValue,
		handleAccept,
		confirmDialogOpen,
		handleClose,
		openConfirmDialog
	};
}
