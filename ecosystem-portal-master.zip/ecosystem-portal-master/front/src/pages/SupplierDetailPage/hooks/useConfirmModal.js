// @flow

import {useState} from "react";
import {useDispatch} from "react-redux";

const useConfirmModal = (acceptAction) => {
	const [value, setValue] = useState<any>(undefined);
	const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
	const dispatch = useDispatch();
	const handleAccept = () => {
		setConfirmDialogOpen(false);
		if (value)
			dispatch(acceptAction(value));
	};
	const handleClose = () => {
		setConfirmDialogOpen(false);
	};
	const openConfirmDialog = () => {
		setConfirmDialogOpen(true);
	};
	return {
		setValue,
		handleAccept,
		confirmDialogOpen,
		handleClose,
		openConfirmDialog
	};
};

export default useConfirmModal;
