// @flow
import {useState} from "react";
import useConfirmModal from "./useConfirmModal";
import {refusePurchaseOrder} from "../actions";
import {useSelector} from "react-redux";

const useConfirmRejection = () => {
	const [rejectionComment, setRejectionComment] = useState("");
	
	const handleRejectionCommentChange = (event) => {
		setRejectionComment(event.target.value);
	};
	const {page} = useSelector(({supplierDetail: {purchaseOrders: {data: {page}}}}) => ({page}));
	const {setValue, handleAccept, confirmDialogOpen, handleClose, openConfirmDialog} = useConfirmModal((orderToRefuse) => {
		return refusePurchaseOrder(
			orderToRefuse.id,
			orderToRefuse.bravoId,
			rejectionComment,
			page
		)});
	return {
		setOrderToRefuse: setValue,
		handleRefuseAccept: handleAccept,
		confirmRefuseDialogOpen: confirmDialogOpen,
		handleRefuseClose: handleClose,
		openConfirmRefuseDialog: openConfirmDialog,
		rejectionComment,
		handleRejectionCommentChange
	}
};

export default useConfirmRejection;
