// @flow


export type SupplierType = {
	supplierBravoId: number,
	supplierOracleCode: string,
	companyName: string,
	dunsOrICECode: string,
	professionalEmail: string,
	fundingRequestsCount: number
};
export type ScoringCapabilitiesProps = {
	score: number,
	changeRate: number,
	supplierPositioning: string,
	category: string,
}
export type ScoringFinancialProps = {
	score: number,
	changeRate: number
}
export type ScoringType = {
	supplierBravoId: number,
	supplierStatus: string,
	scoringCapabilities: ScoringCapabilitiesProps[],
	scoringFinancial: ScoringFinancialProps,
	mainActivity: string
};
export type PurchaseOrderType = {
	id: number,
	bravoId: number,
	supplierOracleCode: string,
	purchaseOrderId: string,
	purchaseOrderRef: string,
	businessUnitName: string,
	status: "PENDING" | "APPROVED" | "SENT_TO_AGENCY",
	purchaseOrderStatus: string,
	purchaseOrderDescription: string,
	purchaseOrderApprovalDate: string,
	purchaseOrderAmount: number,
	achievementPercentage: number,
	achievementPercentageCallOf: number,
	fundingAgencyName: string,
	approvalAttachmentAmount: number,
	billedAmount: number,
	paidAmount: number,
	purchaseOrderCategory: string,
	fundingAgencyEmail: string,
	companyName: string,
};

export type PurchaseOrderRequestPayloadType = {
	id: number,
	page: number
};

export type PurchaseOrderResponsePayloadType = {
	content: PurchaseOrderType[],
	count: number
};

export type PurchaseOrdersDataType = {
	list: PurchaseOrderType[],
	count: number,
	page: number
};

export type StoreType<T> = {
    data: T | null,
    loading: boolean,
    success: boolean,
    status?: "SUCCESS" | "ERROR" | "LOADING",
    error: string | null
};

export type SupplierDetailStoreType = {
	supplierInfo: StoreType<SupplierType>,
	supplierScorings: StoreType<ScoringType>,
	purchaseOrders: StoreType<PurchaseOrdersDataType>
};

export type HistoryType = {
    push: Function
};
export type SetFilterValue = {
    type: "SET_FILTER_VALUE",
    value: string,
    name?: string
};
export type FundingOrdersPage = {
    type: "CHANGE_FUNDING_ORDER",
    page: number
}
