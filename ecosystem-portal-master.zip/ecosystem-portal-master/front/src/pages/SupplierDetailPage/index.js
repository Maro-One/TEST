// @flow
import SupplierDetailContainer from "./container/SupplierDetailContainer";

export default SupplierDetailContainer;
