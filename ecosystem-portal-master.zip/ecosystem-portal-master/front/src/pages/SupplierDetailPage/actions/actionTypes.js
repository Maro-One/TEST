// @flow

import type {
	ActionWithPayloadType,
	ERROR_TYPE
} from "../../../store/actions/types";

import type {
	SupplierType,
	ScoringType,
	PurchaseOrderRequestPayloadType,
	PurchaseOrdersDataType
} from "../types";

type ObjectIdType = { id: number };

// GET SUPPLIER INFO ACTION TYPES
export type GetSupplierInfoActionType = ActionWithPayloadType<
	"GET_SUPPLIER_INFO",
	ObjectIdType
>;

type GetSupplierInfoSuccessActionType = ActionWithPayloadType<
	"GET_SUPPLIER_INFO_SUCCESS",
	SupplierType
>;

type GetSupplierInfoErrorActionType = ActionWithPayloadType<
	"GET_SUPPLIER_INFO_ERROR",
	ERROR_TYPE
>;

// GET SUPPLIER SCORING ACTION TYPES
export type GetSupplierScoringActionType = ActionWithPayloadType<
	"GET_SUPPLIER_SCORING",
	ObjectIdType
>;

type GetSupplierScoringSuccessActionType = ActionWithPayloadType<
	"GET_SUPPLIER_SCORING_SUCCESS",
	ScoringType
>;

type GetSupplierScoringErrorActionType = ActionWithPayloadType<
	"GET_SUPPLIER_SCORING_ERROR",
	ERROR_TYPE
>;

// GET PURCHASE ORDERS ACTION TYPES
export type GetPurchaseOrdersActionType = ActionWithPayloadType<
	"GET_PURCHASE_ORDERS",
	PurchaseOrderRequestPayloadType
>;

type GetPurchaseOrdersSuccessActionType = ActionWithPayloadType<
	"GET_PURCHASE_ORDERS_SUCCESS",
	PurchaseOrdersDataType
>;

type GetPurchaseOrdersErrorActionType = ActionWithPayloadType<
	"GET_PURCHASE_ORDERS_ERROR",
	ERROR_TYPE
>;

export type ValidatePurchaseOrderActionType = ActionWithPayloadType<
	"VALIDATE_PURCHASE_ORDER",
	{
		id: number,
		fundingAgencyEmail: string,
	}
	>;
export type RefusePurchaseOrderActionType = ActionWithPayloadType<
	"REFUSE_PURCHASE_ORDER",
	{
		fundingRequestId: number,
		bravoId: number,
		comment: string,
		page: number
	}
	>;
export type SupplierDetailActionType =
	| GetSupplierInfoActionType
	| GetSupplierInfoSuccessActionType
	| GetSupplierInfoErrorActionType
	| GetSupplierScoringActionType
	| GetSupplierScoringSuccessActionType
	| GetSupplierScoringErrorActionType
	| GetPurchaseOrdersActionType
	| GetPurchaseOrdersSuccessActionType
	| GetPurchaseOrdersErrorActionType
	| ValidatePurchaseOrderActionType
	| RefusePurchaseOrderActionType;
