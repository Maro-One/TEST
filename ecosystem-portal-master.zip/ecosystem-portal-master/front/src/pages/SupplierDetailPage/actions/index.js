// @flow

import {
	CHANGE_FUNDING_ORDER,
	GET_PURCHASE_ORDERS,
	GET_PURCHASE_ORDERS_ERROR,
	GET_PURCHASE_ORDERS_SUCCESS,
	GET_SUPPLIER_INFO,
	GET_SUPPLIER_INFO_ERROR,
	GET_SUPPLIER_INFO_SUCCESS,
	GET_SUPPLIER_SCORING,
	GET_SUPPLIER_SCORING_ERROR,
	GET_SUPPLIER_SCORING_SUCCESS, REFUSE_PURCHASE_ORDER, VALIDATE_PURCHASE_ORDER
} from "./constants";
import type {RefusePurchaseOrderActionType, SupplierDetailActionType, ValidatePurchaseOrderActionType} from "./actionTypes";
import type {
	SupplierType,
	PurchaseOrdersDataType,
	ScoringType,
	SetFilterValue,
	FundingOrdersPage

} from "../types";
import {SET_FILTER_VALUE} from "../../PurchaseOrderPage/actions/constants";

// GET SUPPLIER INFO ACTIONS
export const getSupplierInfo = (id: number): SupplierDetailActionType => ({
	type: GET_SUPPLIER_INFO,
	payload: { id }
});

export const getSupplierInfoSuccess = (
	data: SupplierType
): SupplierDetailActionType => ({
	type: GET_SUPPLIER_INFO_SUCCESS,
	payload: data
});

export const getSupplierInfoError = (
	error: string
): SupplierDetailActionType => ({
	type: GET_SUPPLIER_INFO_ERROR,
	payload: { error }
});

// GET SUPPLIER SCORING ACTIONS
export const getSupplierScoring = (id: number): SupplierDetailActionType => ({
	type: GET_SUPPLIER_SCORING,
	payload: { id }
});

export const getSupplierScoringSuccess = (
	data: ScoringType
): SupplierDetailActionType => ({
	type: GET_SUPPLIER_SCORING_SUCCESS,
	payload: data
});

export const getSupplierScoringError = (
	error: string
): SupplierDetailActionType => ({
	type: GET_SUPPLIER_SCORING_ERROR,
	payload: { error }
});

// GET PURCHASE ORDERS ACTIONS
type Filter= "APPROVED" | "REFUSED" | "PENDING" | null;
export const getPurchaseOrders = (
	id: number,
	page: number,
	filter:  Filter
): SupplierDetailActionType => ({
	type: GET_PURCHASE_ORDERS,
	payload: { id, page, filter }
});

export const getPurchaseOrdersSuccess = (
	data: PurchaseOrdersDataType
): SupplierDetailActionType => ({
	type: GET_PURCHASE_ORDERS_SUCCESS,
	payload: data
});

export const getPurchaseOrdersError = (
	error: string
): SupplierDetailActionType => ({
	type: GET_PURCHASE_ORDERS_ERROR,
	payload: { error }
});

// VALIDATE PURCHASE ORDER ACTION
export const validatePurchaseOrder = (
	id: number,
	fundingAgencyEmail: string
): ValidatePurchaseOrderActionType => ({
	type: VALIDATE_PURCHASE_ORDER,
	payload: { id, fundingAgencyEmail }
});

// REFUSE PURCHASE ORDER ACTION
export const refusePurchaseOrder = (
	fundingRequestId: number,
	bravoId: number,
	comment: string,
	page: number
): RefusePurchaseOrderActionType => ({
	type: REFUSE_PURCHASE_ORDER,
	payload: { fundingRequestId, bravoId, comment, page }
});
// funding order pageable action

export const changeFundingOrdersPage = (page: number):FundingOrdersPage  => ({
	type: CHANGE_FUNDING_ORDER,
	page
});
// purchase order Filter
export const setFilterValue = (value: string): SetFilterValue => ({
	type: SET_FILTER_VALUE,
	name: "PURCHASE_ORDER",
	value
});
