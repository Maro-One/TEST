/* eslint-disable */
// @flow
import React, { useEffect, useState } from "react";
import CustomChip from "../../../../common/CustomChip";
import CustomTable from "../../../../common/CustomTable";
import Pagination from "../../../../common/Pagination";
import SelectField from "../../../../common/SelectField";
import { formatCurrency, formatDate } from "../../../../utils/formatters";
import AttachmentsInvoicesSection from "../AttachmentsInvoicesSection";
import type { AttachmentType } from "../../store/types";
import { formatAttachmentStatus } from "../../../../utils/helper";
import { getCurrentOrderFor, sortAttachments } from "../../actions";
import { LOADING } from "../../../../utils/constants";
import { useDispatch } from "react-redux";
import { FormattedMessage } from "react-intl";
type Props = {
	changeActiveTab: Function,
	attachments: AttachmentType[],
	changePage: Function,
	count: number,
	page: number,
	perPage: number,
	invoicesCount: number,
	Appel_Commandes_Count: number,
	status?: string,
	sort: any,
	refCmdAppelList: Array<string>,// NEW PROP
	purchaseOrderId?: string, // Ajout de cette prop optionnelle
	isContract?: boolean,
	isOracleData?: boolean
};

const Attachments = ({
	changeActiveTab,
	attachments = [],
	count = 0,
	perPage = 10,
	invoicesCount = 0,
	Appel_Commandes_Count = 0,
	status,
	refCmdAppelList, // NEW PROP
	sort = {},
	purchaseOrderId = null, // Ajout de cette prop
	isContract,
	isOracleData
}: Props) => {
	const dispatch = useDispatch();

const [currentPage, setCurrentPage] = useState(0);
const [selectedStatus, setSelectedStatus] = useState(null);
const [filteredAttachments, setFilteredAttachments] = useState(attachments);

useEffect(() => {
  if (selectedStatus) {
    const filtered = attachments.filter(
      (attachment) => attachment.status === selectedStatus ||  attachment.refCmdAppel === selectedStatus

    );
	console.log("here in attachement.js ");
	console.log(+refCmdAppelList);
    setFilteredAttachments(filtered);
  } else {
    setFilteredAttachments(attachments);
  }
  
}, [attachments, selectedStatus]);

const handlePageChange = (newPage: number) => {
	console.log("here in attachement.js ");
	console.log(+refCmdAppelList);
  setCurrentPage(newPage);
};

const indexOfLastItem = (currentPage + 1) * perPage;
const indexOfFirstItem = indexOfLastItem - perPage;
const currentAttachments = filteredAttachments.slice(
  indexOfFirstItem,
  indexOfLastItem
);

const pagination = (
  <Pagination
    perPage={perPage}
    count={filteredAttachments.length}
    page={currentPage}
    onChangePage={handlePageChange}
  />
);

	const thead = [
		{
			id: "RefAttachement", label: (
				<FormattedMessage
					id="attachment.ref"
					defaultMessage="REF Attachement"
				/>
			)
		},
		{ id: "REF_APPEL_DE_COMMANDE", label:
				<FormattedMessage
					id="REF APPEL DE COMMANDE"
					defaultMessage="REF APPEL DE COMMANDE"
				/>
		},
		{
			id: "status", label: (
				<FormattedMessage
					id="attachment.status"
					defaultMessage="STATUT"
				/>
			)
		},
		{
			id: "validationDate", label: (
				<FormattedMessage
					id="attachment.date"
					defaultMessage="Date de validation"
				/>
			),
			sort: {
				action: () => dispatch(sortAttachments("updatedDate")),
				type: getCurrentOrderFor(sort, "updatedDate")
			}
		},
		{
			id: "amount", label: (
				<FormattedMessage
					id="attachment.amount"
					defaultMessage="Montant attachement"
				/>
			),
			sort: {
				action: () => dispatch(sortAttachments("totalAmount")),
				type: getCurrentOrderFor(sort, "totalAmount")
			}
		}
	];
	const trows = purchaseOrderId ?
		currentAttachments.map((attachment: AttachmentType) => ({
		RefAttachement: <strong>{attachment.refAttachment}</strong>,
		REF_APPEL_DE_COMMANDE: <strong>{attachment.poHeaderIp}</strong>,
		status: <CustomChip value={attachment.status} formatFunction={formatAttachmentStatus}/>,
		validationDate: formatDate(new Date(attachment.dateValidation)),
		amount: formatCurrency(attachment.montantAttachement)

	}))
	: []; // Empty rows if purchaseOrderId is null;

  const handleFilterChange = (option, { action }) => {
    switch (action) {
      case "select-option":
        setSelectedStatus(option.value);
        break;
      case "clear":
        setSelectedStatus(null);
        break;
      default:
        break;
    }
  };

  const options = [
    ...new Set(attachments.map((attachment) => attachment.status)),
    
  ].map((status) => ({
    label: status,
    value: status,
  }));

  const filterComponent = (
    <SelectField
      ariaLabelledby="statusFilter"
      options={options}
      placeholder={
        <FormattedMessage
          id="attachment.filter"
          defaultMessage="Filtrer par status"
        />
      }
      isClearable
      isLoading={status === LOADING}
      onChange={handleFilterChange}
    />
  );
console.log("ffffffffffffffffffffffffffffffffffffffff");
	return (
		<AttachmentsInvoicesSection
			isContract={isContract}
			isOracleData={isOracleData}
			pagination={pagination}
			changeActiveTab={changeActiveTab}
			activeTab={"attachments"}
			attachmentsCount={purchaseOrderId ? count : 0} // Display 0 if purchaseOrderId is null
			invoicesCount={invoicesCount}
			Appel_Commandes_Count={Appel_Commandes_Count}
      		filterComponent={filterComponent}
		>
			<CustomTable dataStatus={status} thead={thead} trows={trows} />
		</AttachmentsInvoicesSection>
	);
};
export default Attachments;