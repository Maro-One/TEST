// @flow

import React from "react";
import CommonSection from "../CommonSection";
import type { PurchaseOrderDetailsType } from "../../store/types";
import { formatCurrency,formatPercent } from "../../../../utils/formatters";
import {FormattedMessage} from "react-intl";

type Props = {
	purchaseOrder: PurchaseOrderDetailsType
};

const OrderDetails = ({ purchaseOrder }: Props) => {
	// Function to handle display of currency values or a dash if zero
	const formatOrDash = (amount: number,isCommande:boolean) => {

		if(isCommande || (purchaseOrder.supplierOracleCode != null && purchaseOrder.supplierOracleCode !== undefined)){
			return formatCurrency(amount);
		}
		return  "_" ;
	 
	};

	// Function to handle display of percentage of contract and cmd
	const formatPercentage = (value: number,isCommande:boolean) => {

		if(isCommande || (purchaseOrder.supplierOracleCode != null && purchaseOrder.supplierOracleCode !== undefined)){
			return formatPercent(value);
		}
		return  "_" ;
	};


	const isCommande=purchaseOrder.purchaseOrderId===purchaseOrder.purchaseOrderRef;

	const items = purchaseOrder
		? [
			{
				label:
					<FormattedMessage
						id="order.amount"
						defaultMessage="Montant de la Commande"
					/>
				,
				content: formatOrDash(purchaseOrder.purchaseOrderAmount,isCommande)
			},
			{
				label:
					<FormattedMessage
						id="order.billable.amount"
						defaultMessage="Montant Facturable"
					/>
				,
				content: formatCurrency(purchaseOrder.approvalAttachmentAmount)
			},
			{
				label:
					<FormattedMessage
						id="order.bill.amount"
						defaultMessage="Montant Facturé"
					/>
				,
				content: formatCurrency(purchaseOrder.billedAmount)
			},
			{
				label:

					<FormattedMessage
						id="order.paid.amount"
						defaultMessage="Montant Payé"
					/>
				,
				content: formatCurrency(purchaseOrder.paidAmount)
			},
			{
				label:
					<FormattedMessage
						id="order.achievement.percentage"
						defaultMessage="% de réalisation"
					/>
				,
				content: formatPercentage(isCommande? purchaseOrder.achievementPercentage:purchaseOrder.achievementPercentageCallOf,isCommande),
				tooltip:
					<FormattedMessage
						id="order.billing.percentage"
						defaultMessage="% par rapport au montant facturé"
					/>

			}
		  ]
		: [];
	return (
		<CommonSection
			hideBottomBorder
			title={<FormattedMessage
				id="order.detail"
				defaultMessage="Détails Commande"
			/>}
			items={items}
		/>
	);
};

export default OrderDetails;
