import React from "react";
import SelectField from "../../../../common/SelectField";
import Pagination from "../../../../common/Pagination";
import CustomTable from "../../../../common/CustomTable";
import CustomChip from "../../../../common/CustomChip";
import AttachmentsInvoicesSection from "../AttachmentsInvoicesSection";
import type { InvoiceType, SortType, FilterType } from "../../store/types";
import { formatCurrency, formatDate } from "../../../../utils/formatters";
import { useDispatch, useSelector } from "react-redux";
import { getCurrentOrderFor, sortInvoices } from "../../actions";
import InvoicesTimeline from "../../container/InvoicesTimeline";
import Drawer from "@material-ui/core/Drawer";
import { withStyles } from "@material-ui/styles";
import { useParams } from "react-router";
import getUserRole from "../../../../store/selectors/getUserRole";
import { ROLE_AGENCY } from "../../../../utils/UserRole";
import { formatInvoiceStatus, getDiffInDays } from "../../../../utils/helper";
import { LOADING } from "../../../../utils/constants";
import {FormattedMessage} from "react-intl";
import Tag from "../../../../common/Tag";
import { makeStyles } from "@material-ui/core";


const useStyles = makeStyles({
	dateWithTagCell: {
		display: "flex",
	}
});

const MyDrawer = withStyles({
	root: { minWidth: "560px" },
	paper: { backgroundColor: "#f8f8f8" }
})(Drawer);

type Props = {
	changeActiveTab: Function,
	invoices: InvoiceType[],
	changePage: Function,
	count: number,
	page: number,
	perPage: number,
	status?: string,
	attachmentsCount: number,
	Appel_Commandes_Count: number,
	sort?: SortType,
	filter: FilterType,
	onFilterChange: Function,
	purchaseOrderId?: string, // Ajout de cette prop optionnelle
	isContract?: boolean,
	requestSourceI?: string,
	isOracleData?: boolean
};
const  Invoices = ({
	changeActiveTab,
	attachmentsCount,
	Appel_Commandes_Count,
	changePage,
	count = 0,
	page = 0,
	status,
	perPage = 10,
	invoices = [],
	sort,
	filter,
	onFilterChange,
	purchaseOrderId = null, // Ajout de cette prop
	isContract,
	requestSourceI = null,
	isOracleData
}: Props) => {
	const classes = useStyles();
	const dispatch = useDispatch();
	//const { purchaseOrderId: routePurchaseOrderId } = useParams(); // Récupération de l'ID via useParams si pas fourni en prop
	const finalPurchaseOrderId = purchaseOrderId ;//|| routePurchaseOrderId; // Utiliser soit la prop, soit l'ID via route
	const {requestSource} = useParams();
	const finalRequestSource = requestSource;

	const [state, setstate] = React.useState({
		isToggled: false,
		purchaseOrderId: null,
		einvoiceId: null,
		invoiceNumber: null,
		sapInvoiceId: null,
		filingDate: null,
		dueDate: null,
		amount: null,
		status: null,
		requestSourceI: null
	});
	const handleToggleDrawer = ({
		purchaseOrderId,
		einvoiceId,
		invoiceNumber,
		sapInvoiceId,
		filingDate,
		dueDate,
		amount,
		approvalStatus,
		status,
		requestSourceI
	}) => {
		setstate(prevState => ({
			isToggled: !prevState.isToggled,
			purchaseOrderId,
			einvoiceId,
			invoiceNumber,
			sapInvoiceId,
			filingDate,
			dueDate,
			amount,
			status,
			requestSourceI
		}));
	};

	const userRole = useSelector(getUserRole);
	const shouldRenderActionButton = () => {
		return userRole === ROLE_AGENCY;
	};

	const renderDateWithTag = (value: string, status: string, classes: any) => {
		if (value) {
			const date = new Date(value);
			const formattedDate = formatDate(date);
			switch (status) {
				case "REFUSED":
				case "IN_PAID":
				case "INVOICE_PAID":
				case "IN_LITIGATION":
					return formattedDate;
				default:{
					const today = new Date();
					const days = getDiffInDays(today, date);
					return (
						<div className={classes.dateWithTagCell}>
							{formattedDate}
							<Tag days={days} />
						</div>
					)
				}
			}
		} else {
			return null;
		}
	};

	const taction = {
		label:
			<FormattedMessage
				id="invoice.timeline"
				defaultMessage="voir Timeline"
			/> ,
		actionFunc: handleToggleDrawer,
		fields: [
			"purchaseOrderId",
			"einvoiceId",
			"invoiceNumber",
			"sapInvoiceId",
			"filingDate",
			"dueDate",
			"amount",
			"status",
			"requestSourceI"
		]
	};
	const thead = [
		{ id: "RefFacture",
			label:
				<FormattedMessage
					id="invoice.ref"
					defaultMessage="REF Facture"
				/>
		},
		{ id: "status",
			label:
				<FormattedMessage
					id="invoice.status"
					defaultMessage="STATUT"
				/>
		},
		{
			id: "filingDate",
			label:
				<FormattedMessage
					id="invoice.date.deposit"
					defaultMessage="Date dépôt"
				/>
			,
			sort: {
				action: () => dispatch(sortInvoices("baseEcheance")),
				type: getCurrentOrderFor(sort, "baseEcheance")
			}
		},
		{
			id: "dueDate",
			label:
				<FormattedMessage
					id="invoice.date.deadline"
					defaultMessage="Date d’échéance"
				/>
			,
			sort: {
				action: () => dispatch(sortInvoices("dueDate")),
				type: getCurrentOrderFor(sort, "dueDate")
			}
		},
		{
			id: "amount",
			label:
				<FormattedMessage
					id="invoice.amount"
					defaultMessage="Montant Facture(HT)"
				/>
			,
			sort: {
				action: () => dispatch(sortInvoices("amountHT")),
				type: getCurrentOrderFor(sort, "amountHT")
			}
		}
	];
	if(Appel_Commandes_Count > 0) {
	    thead.splice(1, 0, { id: "REF_APPEL_DE_COMMANDE", label:
				<FormattedMessage
					id="REF APPEL DE COMMANDE"
					defaultMessage="REF APPEL DE COMMANDE"
				/>,
		})
	}
	
	const trows = 	finalPurchaseOrderId ?
		invoices.map((invoice: InvoiceType) => ({
			RefFacture: <strong>{"#" + invoice.invoiceNumber}</strong>,
			REF_APPEL_DE_COMMANDE: <strong>{invoice.purchaseOrderCode}</strong>,
			status: <CustomChip value={invoice.status} formatFunction={formatInvoiceStatus} />,
			filingDate: formatDate(new Date(invoice.baseEcheance)),
			dueDate: renderDateWithTag(invoice.dueDate, invoice.status, classes),
			amount: formatCurrency(invoice.amountHT),
			purchaseOrderId: finalPurchaseOrderId, // Utiliser l'ID défini
			einvoiceId: invoice.einvoiceId,
			invoiceNumber: invoice.invoiceNumber,
			sapInvoiceId: invoice.sapInvoiceId,
			requestSourceI: finalRequestSource
		}))
		: []; // Empty rows if purchaseOrderId is null

	const pagination = (
		<Pagination
			perPage={perPage}
			count={count}
			page={page}
			onChangePage={changePage}
		/>
	);

	const options = filter?.list?.map(s => ({
		label: formatInvoiceStatus(s)[0],
		value: s
	}));
	const onChange = (option, { action }) => {
		switch (action) {
			case "select-option":
				onFilterChange(option.value);
				break;
			case "clear":
				onFilterChange(null);
				break;
			default:
				break;
		}
	};
	const filterComponent = (
		<SelectField
			ariaLabelledby="statusFilter"
			options={options}
			placeholder={<FormattedMessage
				id="invoice.filter"
				defaultMessage="Filtrer par status"
			/>}
			isClearable
			isLoading={status === LOADING}
			onChange={onChange}
		/>
	);
	return (
		<>
			<AttachmentsInvoicesSection
				pagination={pagination}
				isContract={isContract}
				isOracleData={isOracleData}
				changeActiveTab={changeActiveTab}
				activeTab={"invoices"}
				attachmentsCount={attachmentsCount}
				invoicesCount={finalPurchaseOrderId ? count : 0} // 0 si pas d'ID de commande
				Appel_Commandes_Count={Appel_Commandes_Count}
				filterComponent={filterComponent}
			>
				<CustomTable
					thead={thead}
					trows={trows}
					dataStatus={status}
					taction={taction}
					shouldRenderActionButton={shouldRenderActionButton}
				/>
			</AttachmentsInvoicesSection>
			{shouldRenderActionButton() && (
				<MyDrawer
					anchor="left"
					onClose={handleToggleDrawer}
					open={state.isToggled}
				>
					<InvoicesTimeline
						einvoiceId={state.einvoiceId}
						invoiceNumber={state.invoiceNumber}
						purchaseOrderId={purchaseOrderId}
						sapId={state.sapInvoiceId}
						filingDate={state.filingDate}
						dueDate={state.dueDate}
						amount={state.amount}
						status = {state.status?.props?.value}
						requestSourceI={finalRequestSource}
					/>

				</MyDrawer>

			)}
		</>
	);
};

export default Invoices;
