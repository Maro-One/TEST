// @flow
import React from "react";
import Grid from "@material-ui/core/Grid";
import timeLineNoData from "../../../../../images/timeLineNoData.svg";
import {FormattedMessage} from "react-intl";
import "./styles.scss";

const NoDataTimeLine = () => (
	<Grid
		container
	>
		<Grid
			item
			style={{"textAlign": "center"}}
			xs={12}
		>
			<img
				alt={"no data"}
				src={timeLineNoData}
			/>
		</Grid>
		<Grid
			item
			xs={12}
		>
			<FormattedMessage
				defaultMessage="Empty list"
				id="eventList.empty"
			>
				{(msg) => <p className={"noDataLabel"}>{msg}</p>}
			</FormattedMessage>
		</Grid>
	</Grid>);

export default NoDataTimeLine;
