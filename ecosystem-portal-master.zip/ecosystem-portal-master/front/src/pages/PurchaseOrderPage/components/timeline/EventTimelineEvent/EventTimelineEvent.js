// @flow

import React from "react";
import { FormattedMessage } from "react-intl";
import EventTimelineDate from "../EventTimelineDate";
import type { Node } from "react";
import classNames from "classnames";
import Grid from "@material-ui/core/Grid";
import "./style.scss";
import { eventStatusMap } from "../../../../../utils/constants";

type Props = {
	timeEvent: any,
	children: Node
};

const isTodoEvent = eventStatus => eventStatus === "NOT_STARTED";

const getMappedEventCode = eventCode => eventStatusMap[eventCode] || eventCode;

const EventTimelineEvent = ({ timeEvent, children }: Props) => (
	<Grid
		alignItems={"flex-start"}
		className={classNames(
			"event-timeline__timeline__event",
			{
				"event-timeline__timeline__event--has-body": children,
				"event-timeline__timeline__event--done-before": !isTodoEvent(
					timeEvent.eventStatus
				),
				"event-timeline__timeline__event--to-be-done": isTodoEvent(
					timeEvent.eventStatus
				)
			},
			"width"
		)}
		container
		justify="space-between"
		spacing={0}
	>
		<Grid item xs={2}>
			<EventTimelineDate timestamp={timeEvent.eventDate} />
		</Grid>
		<Grid alignItems={"center"} item xs={1}>
			<div
				className={classNames({
					"event-timeline__timeline__event__bullet--to-be-done": isTodoEvent(
						timeEvent.eventStatus
					),
					"event-timeline__timeline__event__bullet--done": !isTodoEvent(
						timeEvent.eventStatus
					),
					"event-timeline__timeline__event__bullet--rejected": true,
					"event-timeline__timeline__event__bullet--late": timeEvent.isEventLate
				})}
			/>
		</Grid>
		<Grid item xs={9}>
			<div className="event-timeline__timeline__event__description__main">
				{timeEvent.eventCode && (
					<FormattedMessage id={getMappedEventCode(timeEvent.eventCode)} />
				)}
			</div>
			<div className="event-timeline__timeline__event__description__subtitle">
				{children}
			</div>
		</Grid>
	</Grid>
);

export default EventTimelineEvent;
