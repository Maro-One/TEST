// @flow

import * as React from "react";
import "./style.scss";
import type {Node} from "react";

type Props = {
  label: Node,
  values: Node[]
};

const MetadataMultiLine = ({label, values}: Props) => (
	<div className="metadata-multi-line">
		<p className="metadata-multi-line__label">
			{label}
			{" : "}
		</p>
		<ul className="metadata-multi-line__list">
			{values.map((listValue, index) => (
				<li
					className="metadata-multi-line__list-item"
					// eslint-disable-next-line react/no-array-index-key
					key={index}
				>
					{listValue}
				</li>
			))}
		</ul>
	</div>
);

export default MetadataMultiLine;
