// @flow

import React from "react";
import {FormattedMessage} from "react-intl";
import EventTimelineEvent from "../EventTimelineEvent";
import StatusControllerSpinner from "../../../../../common/SpinnerNew/StatusControllerSpinner";
import EventMetadataSupplier from "../EventMetadataSupplier";
import {makeStyles} from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import NoDataTimeLine from "../NoDataTimeLine";

const useStyles = makeStyles(() => ({
	"root": {
		"height": "80px",
		"backgroundColor": "#ffffff",
		"fontFamily": "Roboto"
	},
	"title": {
		"flexGrow": 1,
		"fontSize": "24px",
		"color": "#172B4D",
		"fontWeight": "500",
		"margin": "5px 5px 5px 25px"
	},
	"status": {
		"textAlign": "right",
		"fontSize": "16px",
		"color": "#485563",
		"margin": "5px 25px 5px 5px"
	},
	"subTitle":{
		"flexGrow": 1,
		"fontSize": "16px",
		"color": "#727CA2",
		"fontWeight": "500",
		"margin": "5px 5px 5px 25px"
	},
	"values":{
		"flexGrow": 1,
		"fontSize": "12px",
		"color": "#333D66",
		"fontWeight": "bold",
		"margin": "5px 5px 5px 25px"

	},
	"tag": {"verticalAlign": "sub"}
}));

type Props = {
  timeEvents: any,
  status: ("SUCCESS" | "ERROR" | "LOADING" | typeof undefined),
  id: string,
  subTitle: Object,
  title: Object,
	creationDate: string,
	baseEcheance: string,
	amountHT: string
}

const EventTimeline = ({timeEvents,
						   creationDate,baseEcheance
						   ,status,
					   amountHT,title}: Props) => {
	const classes = useStyles();
	return (
		<div
			className="event-timeline"
			style={{"width": "560px"}}
		>
			<Grid
				alignItems="center"
				className={classes.root}
				container
				justify="space-between"
			>
				<Grid
					item
					xs={12}
				>
					<div className={classes.title} >
						{title}
					</div>
				</Grid>
			</Grid>
			<Grid
				alignItems="center"
				className={classes.root}
				container
				justify="space-between"
			>
				<Grid
					item
					xs={4}
				>
					<div className={classes.subTitle} >
						<FormattedMessage id="timeline.metadata.DepositDate" />
					</div>
					<div className={classes.values}>
						{creationDate}
					</div>
				</Grid><Grid
					item
					xs={4}
				>
					<div className={classes.subTitle} >
						<FormattedMessage id="timeline.metadata.deadlineDate" />
					</div>
					<div className={classes.values}>
						{baseEcheance}
					</div>

				</Grid><Grid
					item
					xs={4}
				>
					<div className={classes.subTitle} >
						<FormattedMessage id="timeline.metadata.amount" />
					</div>
					<div className={classes.values}>
						{amountHT} (HT)
					</div>
				</Grid>
			</Grid>
			<div style={{"margin": "17px"}}>
				<Grid container>
					<Grid
						item
						xs={12}
					>
						<StatusControllerSpinner status={status}>
							<div className="event-timeline__timeline">
								{(!timeEvents || timeEvents.size === 0) &&
		  							<NoDataTimeLine />
								}
								{timeEvents && timeEvents.map((timeEvent, index) => (
									<EventTimelineEvent
										// eslint-disable-next-line react/no-array-index-key
										key={index}
										timeEvent={timeEvent}
									>
										<EventMetadataSupplier
											eventType={timeEvent.eventCode}
											metadata={timeEvent.metadata}
										/>
									</EventTimelineEvent>
								))}
							</div>
						</StatusControllerSpinner>
					</Grid>
				</Grid>
			</div>
		</div>);
};
export default EventTimeline;
