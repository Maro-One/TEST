import EventMetadataSupplierInvoicePaid from "./EventMetadataSupplierInvoicePaid";

export default EventMetadataSupplierInvoicePaid;
