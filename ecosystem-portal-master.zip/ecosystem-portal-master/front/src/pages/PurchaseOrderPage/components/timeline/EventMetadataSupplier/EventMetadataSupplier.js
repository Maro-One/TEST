// @flow

import * as React from "react";
import EventMetadataSupplierInvoiceRejected from "./EventMetadataSupplierInvoice";
import EventMetadataSupplierInvoicePaid from "./EventMetadataSupplierInvoicePaid";
import EventMetadataSupplierInvoiceNotPaid from "./EventMetadataSupplierInvoiceNotPaid";

type Props = {
	metadata?: any,
	eventType: string
};

const EventMetadataSupplier = ({ metadata, eventType }: Props) => {
	if (!metadata) {
		return null;
	}
	switch (eventType) {
		case "IN_REJECTED":
			return (
				<EventMetadataSupplierInvoiceRejected
					metadata={metadata}
				/>
			);
		case "INVOICE_PAID":
			return (
				<EventMetadataSupplierInvoicePaid
					metadata={metadata}
				/>
			);
		default:
			return (
				<EventMetadataSupplierInvoiceNotPaid
					metadata={metadata}
				/>
			);
	}
};

export default EventMetadataSupplier;
