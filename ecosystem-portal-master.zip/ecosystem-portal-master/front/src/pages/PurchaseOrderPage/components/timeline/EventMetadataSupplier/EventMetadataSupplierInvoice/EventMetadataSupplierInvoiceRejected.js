// @flow

import * as React from "react";
import {FormattedMessage} from "react-intl";
import MetadataLine from "../MetadataLine";

type Props = {
  metadata: any
};

const EventMetadataSupplierInvoiceRejected = ({metadata}: Props) => (
	<div>
		{metadata.rejetDate && <MetadataLine
			label={<FormattedMessage id="timeline.metadata.rejetDate"  />}
			value={metadata.rejetDate}
		/>}
		{metadata.rejetInfo && <MetadataLine
			label={<FormattedMessage id="timeline.metadata.rejetInfo" />}
			value={metadata.rejetInfo}
		/>}
	</div>
);

export default EventMetadataSupplierInvoiceRejected;
