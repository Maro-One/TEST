// @flow

import * as React from "react";
import {FormattedMessage, FormattedNumber} from "react-intl";
import MetadataLine from "../MetadataLine";

type Props = {
  metadata: any
};

const EventMetadataSupplierInvoicePaid = ({metadata }: Props) => (
	<div>
		<MetadataLine
			label={<FormattedMessage id="timeline.metadata.amountReg"  />}
			value={<FormattedNumber
				value={metadata.amountReg}
			/>}
		/>
		<MetadataLine
			label={<FormattedMessage
				id="timeline.metadata.refReg"
			/>}
			value={metadata.refReg}
		/>
	</div>
);

export default EventMetadataSupplierInvoicePaid;
