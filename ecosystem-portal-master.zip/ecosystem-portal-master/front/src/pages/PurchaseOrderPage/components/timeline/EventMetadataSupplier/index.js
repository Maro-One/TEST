import EventMetadataSupplier from "./EventMetadataSupplier";

export default EventMetadataSupplier;
