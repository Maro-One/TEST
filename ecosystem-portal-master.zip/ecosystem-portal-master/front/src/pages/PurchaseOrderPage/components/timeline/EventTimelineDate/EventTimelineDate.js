// @flow

import React from "react";
import "./style.scss";
import {FormattedDate} from "react-intl";
import Grid from "@material-ui/core/Grid";

type Props = {
  timestamp: number
};

const EventTimelineDate = ({timestamp }: Props) => {
	if (timestamp === null) {
		return <div className="event-timeline-date" />;
	}
	const date = new Date(timestamp);

	return (
		<Grid
			className="event-timeline-date"
			container
			direction="column"
			justify="center"
			spacing={0}
		>
			<Grid
				className="date-day"
				item
				xs={12}
			>
				<FormattedDate
					day="2-digit"
					value={date}
				/>
			</Grid>
			<Grid
				className="date-month"
				item
				xs={12}
			>
				<FormattedDate
					month="short"
					value={date}
				/>
			</Grid>
			<Grid
				className="date-year"
				item
				xs={12}
			>
				<FormattedDate
					value={date}
					year="numeric"
				/>
			</Grid>
		</Grid>
	);
};

export default EventTimelineDate;
