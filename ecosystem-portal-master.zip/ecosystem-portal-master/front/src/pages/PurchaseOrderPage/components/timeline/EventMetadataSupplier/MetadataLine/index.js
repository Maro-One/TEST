import MetadataLine from "./MetadataLine";

export default MetadataLine;
