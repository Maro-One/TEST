// @flow

import * as React from "react";
import {FormattedMessage, FormattedNumber} from "react-intl";
import MetadataLine from "../MetadataLine";

type Props = {
  metadata: any
};

const EventMetadataSupplierInvoiceNotPaid = ({metadata }: Props) => (
	<div>
		<MetadataLine
			label={<FormattedMessage id="timeline.metadata.amount"/>}
			value={<FormattedNumber
				value={metadata.amounttc}
			/>}
		/>
	</div>
);

export default EventMetadataSupplierInvoiceNotPaid;
