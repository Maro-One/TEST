import EventTimelineEvent from "./EventTimelineEvent";

export default EventTimelineEvent;
