// @flow

import * as React from "react";
import type {Node} from "react";
import "./style.scss";

type Props = {
  label: Node,
  value: Node,
};

const MetadataLine = ({label, value}: Props) => (
	<p className="metadata-line">
		{label}
		{" : "}
		<span>
			{value}
		</span>
	</p>
);

export default MetadataLine;
