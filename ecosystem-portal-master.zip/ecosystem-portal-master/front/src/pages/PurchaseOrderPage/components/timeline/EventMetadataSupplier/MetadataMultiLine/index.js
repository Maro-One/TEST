import MetadataMultiLine from "./MetadataMultiLine";

export default MetadataMultiLine;
