// @flow
import React from "react";
import CommonSection from "../CommonSection";
import type {PurchaseOrderDetailsType} from "../../store/types";
import {formatDate} from "../../../../utils/formatters";
import CustomChip from "../../../../common/CustomChip";
import {formatPurchaseOrderStatus, truncString} from "../../../../utils/helper";
import {FormattedMessage} from "react-intl";

type Props = {
	purchaseOrder: PurchaseOrderDetailsType
};
const OrderIdenification = ({ purchaseOrder }: Props) => {
	console.log("purchaseOrder.purchaseOrderApprovalDate",purchaseOrder.purchaseOrderApprovalDate);
	const items = purchaseOrder
		? [
			{
				label:
					<FormattedMessage
						id="order.number"
						defaultMessage="N° commande"
					/>
				,
				content: purchaseOrder.purchaseOrderRef
			},
			{
				label:
					<FormattedMessage
						id="order.date.approval"
						defaultMessage="date d’approbation"
					/>
				,
				content: purchaseOrder.purchaseOrderApprovalDate ? 
					formatDate(new Date(purchaseOrder.purchaseOrderApprovalDate)) :  undefined
			},
			{
				label:
					<FormattedMessage
						id="order.status"
						defaultMessage="STATUT"
					/>

				,
				content: <CustomChip value={purchaseOrder.purchaseOrderStatus} formatFunction={formatPurchaseOrderStatus}/>
			},
			{
				label:
					<FormattedMessage
						id="order.category"
						defaultMessage="Catégorie"
					/>
				,
				tooltip: purchaseOrder.purchaseOrderCategory,
				content: truncString(purchaseOrder.purchaseOrderCategory, 20)
			},
			{
				label:

					<FormattedMessage
						id="order.date.payment"
						defaultMessage="Délai de paiement"
					/>
				,
				tooltip: purchaseOrder.purchaseOrderPaymentTermsDescription,
				content: truncString(purchaseOrder.purchaseOrderPaymentTermsDescription,20)
			}
		  ]
		: [];

	const lineBreakItem = purchaseOrder
		? {
			label:
				<FormattedMessage
					id="order.object"
					defaultMessage="OBJET DE LA COMMANDE"
				/>
			,
			content: purchaseOrder.purchaseOrderDescription
		  }
		: undefined;
	return (
		<CommonSection
			lineBreakItem={lineBreakItem}
			title={
				<FormattedMessage
					id="order.identique"
					defaultMessage="Identifiants Commande"
				/>
			}
			isLineBreak
			items={items}
		/>
	);
};

export default OrderIdenification;
