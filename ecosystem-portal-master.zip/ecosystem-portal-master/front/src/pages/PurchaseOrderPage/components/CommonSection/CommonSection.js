// @flow
import React from "react";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import makeStyles from "@material-ui/core/styles/makeStyles";
import styles from "./styles";
import * as classnames from "classnames";
import CustomToolTip from "../../../../common/CustomToolTip";
import Divider from "@material-ui/core/Divider";

const useStyles = makeStyles(styles);

type Item = {
	label: string,
	tooltip?: string,
	content: any
};
type Props = {
	title: string,
	items: Item[],
	hideBottomBorder?: boolean,
	isLineBreak?: boolean,
	lineBreakItem?: Item
};

const CommonSection = ({
	items,
	title,
	hideBottomBorder = false,
	isLineBreak = false,
	lineBreakItem
}: Props) => {
	const classes = useStyles();
	return (
		<Grid
			container
			direction={"column"}
			className={classnames(classes.container, {
				[classes.hideBottomBorder]: hideBottomBorder
			})}
		>
			<Grid className={classes.titleContainer} item xs={12}>
				<Typography className={classes.title} variant={"h6"} component={"h6"}>
					{title}
				</Typography>
			</Grid>
			<Grid
				item
				className={classnames(isLineBreak && classes.hideBottomBorder)}
				container
				direction={"row"}
				wrap={"wrap"}
			>
				{items &&
					items.map((item: Item, index) => (
						<Grid key={index} className={classes.item} item>
							<Typography
								className={classes.label}
								variant={"h6"}
								component={"h6"}
							>
								{item.label}
							</Typography>
							{item.tooltip ? (
								<CustomToolTip
									arrow={false}
									placement="bottom-start"
									title={item.tooltip}
								>
									<Typography
										className={classes.content}
										variant={"h6"}
										component={"h6"}
									>
										{item.content}
									</Typography>
								</CustomToolTip>
							) : (
								<Typography
									className={classes.content}
									variant={"h6"}
									component={"h6"}
								>
									{item.content}
								</Typography>
							)}
						</Grid>
					))}
			</Grid>
			{isLineBreak && lineBreakItem && (
				<Grid item container direction={"row"} wrap={"wrap"}>
					<Grid className={classes.item} item xs={12}>
						<Typography
							className={classes.label}
							variant={"h6"}
							component={"h6"}
						>
							{lineBreakItem.label}
						</Typography>
						{lineBreakItem.tooltip ? (
							<CustomToolTip
								arrow={false}
								placement="bottom-start"
								title={lineBreakItem.tooltip}
							>
								<Typography
									className={classes.content}
									variant={"h6"}
									component={"h6"}
								>
									{lineBreakItem.content}
								</Typography>
							</CustomToolTip>
						) : (
							<Typography
								className={classes.content}
								variant={"h6"}
								component={"h6"}
							>
								{lineBreakItem.content}
							</Typography>
						)}
					</Grid>
				</Grid>
			)}
			{!hideBottomBorder && (
				<Divider
					style={{ marginLeft: "0", marginRight: "0" }}
					variant="middle"
				/>
			)}
		</Grid>
	);
};

export default CommonSection;
