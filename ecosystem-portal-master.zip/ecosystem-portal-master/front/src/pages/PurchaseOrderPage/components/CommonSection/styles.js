import fonts from "../../../../utils/fonts";
import colors from "../../../../utils/colors";

const styles = {
	container: {
		padding: 24,
		paddingBottom: 0
	},
	hideBottomBorder:{
		"& :after": {
			content: "''",
			width: 0,
			height: 0,
		}
	},
	title:{
		color: colors.limeade,
		fontFamily: fonts.robotoMedium,
		fontSize: "18px",
		fontWeight: "500",
		lineHeight: "50px",
		textTransform: "capitalize"
	},
	titleContainer:{
		flexBasis: "auto !important"
	},
	content:{
		color: colors.waikawaGray,
		fontFamily: fonts.robotoBold,
		fontSize: "14px",
		fontWeight: "bold",
		lineHeight: "10px",
	},
	label:{
		color: colors.lynch,
		fontFamily: fonts.robotoRegular,
		fontSize: "12px",
		lineHeight: "30px",
		textTransform: "uppercase"
	},
	item: {
		width: "240px",
		marginBottom: "10px",
	}
};

export default styles;
