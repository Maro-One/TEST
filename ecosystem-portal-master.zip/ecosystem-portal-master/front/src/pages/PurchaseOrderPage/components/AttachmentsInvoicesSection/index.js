import AttachmentsInvoicesSection from "./AttachmentsInvoicesSection";

export default AttachmentsInvoicesSection;
