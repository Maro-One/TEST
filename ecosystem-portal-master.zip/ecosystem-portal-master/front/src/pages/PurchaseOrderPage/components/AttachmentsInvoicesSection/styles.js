import fonts from "../../../../utils/fonts";
import colors from "../../../../utils/colors";

const styles = {
	container: {
		borderTop: `1px solid ${colors.catskillWhite}`,
		marginTop: "14px"
	},
	pagination: {
		width: "100%"
	},
	toolbar: {
		margin: "15px 0"
	},
	count: {
		flex: "1 1 100%",
		color: "#727CA2",
		fontFamily: fonts.robotoRegular,
		fontSize: "16px",
		fontStyle: "italic",
		"line-height": "19px"
	},
	buttons: {
		backgroundColor: colors.whisperWhite,
		border: "1px solid " + colors.blueHaze,
		borderRadius: "6px",
		height: "36.5px",
		lineHeight: "36px",
		padding: "2px",
		boxSizing: "border-box",
		width: "fit-content",
		display: "flex"
	},
	tableContainer: {
		padding: "0 24px"
	},
	buttonLink: {
		width: "194px",
		textAlign: "center",
		height: "31px",
		lineHeight: "31px",
		color: colors.waikawaGray2,
		fontFamily: fonts.robotoBold,
		fontSize: "14px",
		textTransform: "uppercase",
		textDecoration: "none",
		borderRadius: "3px",
		"&:hover": {
			textDecoration: "none",
			cursor: "pointer"
		}
	},
	buttonLinkActive: {
		color: colors.white,
		backgroundColor: colors.pistachioGreen,
		textShadow: "0 1px 2px rgba(0,0,0,0.15)",
		"&:hover": {
			cursor: "pointer"
		}
	},
	gridContainer: {
		display: "flex",
		alignItems: "center"
	},
	gridItem: {
		display: "flex",
		alignItems: "center"
	}
};

export default styles;
