// @flow
import React from "react";
import type { Node } from "react";
import Toolbar from "@material-ui/core/Toolbar";
import { Link, Grid } from "@material-ui/core";
import * as classnames from "classnames";
import Typography from "@material-ui/core/Typography";
import makeStyles from "@material-ui/core/styles/makeStyles";
import styles from "./styles";
import { FormattedMessage } from "react-intl";

const useStyles = makeStyles(styles);

type Props = {
	activeTab: string,
	children: any,
	pagination: any,
	attachmentsCount: number,
	invoicesCount: number,
	Appel_Commandes_Count: number,
	changeActiveTab: Function,
	filterComponent?: Node,
	filterComponent2?: Node,
	refCmdAppelFilterComponent?:Node,
	isContract?:boolean,
	isOracleData?:boolean

};
const AttachmentsInvoicesSection = ({
	activeTab,
	changeActiveTab,
	children,
	pagination,
	invoicesCount,
	attachmentsCount,
	Appel_Commandes_Count,
	filterComponent,
	filterComponent2,
	refCmdAppelFilterComponent,
	isContract=true,
	isOracleData=true
}: Props) => {
	const classes = useStyles();
	const count = activeTab === "attachments" ? attachmentsCount : activeTab === "invoices" ? invoicesCount : Appel_Commandes_Count;
	return (
		<div className={classes.container}>
			<Toolbar className={classes.toolbar}>
				<Grid container className={classes.gridContainer}>
					<Grid item xs={12} md={6}>
						<div className={classes.buttons}>
							{(isContract || isOracleData) ? <Link
								onClick={() => changeActiveTab("appelDeCommandes")}
								className={classnames(classes.buttonLink, {
									[classes.buttonLinkActive]: activeTab === "appelDeCommandes"
								})}
							>

								<FormattedMessage
									id="appelDeCommande.count"
									defaultMessage="APPEL DE COMMANDES ( {Appel_Commandes_Count} )"
									values={{Appel_Commandes_Count}}
									
								/>

							</Link> : null}
							<Link
								onClick={() => changeActiveTab("attachments")}
								className={classnames(classes.buttonLink, {
									[classes.buttonLinkActive]: activeTab === "attachments"
								})}
							>
								
								<FormattedMessage
									id="attachment.count"
									defaultMessage="Attachements ( {attachmentsCount} )"
									values={{ attachmentsCount }}
								/>

							</Link>
							<Link
								onClick={() => changeActiveTab("invoices")}
								className={classnames(classes.buttonLink, {
									[classes.buttonLinkActive]: activeTab === "invoices"
								})}
							>
								<FormattedMessage
									id="attachment.invoice.count"
									defaultMessage="Factures ( {invoicesCount} )"
									values={{ invoicesCount }}
								/>
								{ }
							</Link>
						</div>
					</Grid>
					<Grid
						item
						container
						xs={12}
						md={6}
						className={classes.gridItem}
						justify="flex-end"
					>
						{filterComponent}
						{filterComponent2}
						{refCmdAppelFilterComponent}
						{pagination}
					</Grid>
				</Grid>
			</Toolbar>
			<div className={classes.tableContainer}>{children}</div>
			<Toolbar className={classes.toolbar}>
				<Typography className={classes.count} variant="caption">
					{count}&nbsp;<FormattedMessage id={activeTab === "attachments" ? "attachment.title" : activeTab === "invoices" ? 
						"invoice.title" : "appelDeCommande.title"} defaultMessage="attachments" />{(count > 1 ? "s" : "")}
				</Typography>
				{pagination}
			</Toolbar>
		</div>
	);
};

export default AttachmentsInvoicesSection;