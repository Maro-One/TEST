import AppelDeCommandes from "./AppelDeCommandes";

export default AppelDeCommandes;
