// @flow
//Appel de commande

import React, { useState,useEffect } from "react";
import CustomChip from "../../../../common/CustomChip";
import CustomTable from "../../../../common/CustomTable";
import Pagination from "../../../../common/Pagination";
import isEqual from "lodash/isEqual";
import { formatCurrency, formatDate } from "../../../../utils/formatters";
import AttachmentsInvoicesSection from "../AttachmentsInvoicesSection";
//import { getCurrentOrderFor, sortAppelDeCommandes } from "../../actions";
//import {useDispatch} from "react-redux";
import {FormattedMessage} from "react-intl";

type Props = {
    changeActiveTab: Function,
	appelDeCommandes: AppelDeCommandeType[],
    changePage: Function,
	count: number,
	page: number,
	perPage: number,
    attachmentsCount: number,
    invoicesCount: number,
	status?: string,
	sort: any,
	setRefCmdAppelList: Function , // NEW PROP
	purchaseOrderId?: string, // Ajout de cette prop optionnelle
	isContract?: boolean,
	isOracleData?: boolean
}

const AppelDeCommandes = ({
	changeActiveTab,
	attachmentsCount,
	invoicesCount,
	appelDeCommandes = [],
	changePage,
	count = 0,
	page = 0,
	perPage = 10,
	status,
	setRefCmdAppelList, // NEW PROP
	purchaseOrderId = null, // Ajout de cette prop
	isContract,
	isOracleData
}: Props) => {	
	//const dispatch = useDispatch();

	useEffect(() => {
		const refCmdAppelList = appelDeCommandes.map(appelDeCommande => appelDeCommande.refCmdAppel);
		// Vérifier si les valeurs ont changé avant de déclencher une mise à jour
		setRefCmdAppelList(prevRefCmdAppelList => {
			if (!isEqual(prevRefCmdAppelList, refCmdAppelList)) {
				return refCmdAppelList; // Met à jour seulement si c'est différent
			}
			return prevRefCmdAppelList; // Sinon, ne change rien
		});
		
	}, [appelDeCommandes, setRefCmdAppelList]);


	// State to hold the current page number
	const [currentPage, setCurrentPage] = useState(0);

	// Function to handle page change
	const handlePageChange = (newPage: number) => {
		setCurrentPage(newPage);
	};

	// Get the attachments for the current page
	const indexOfLastItem = (currentPage + 1) * perPage;
	const indexOfFirstItem = indexOfLastItem - perPage;
	const currentAppelDeCommandes = appelDeCommandes.slice(
		indexOfFirstItem,
		indexOfLastItem
	);
	const pagination = (
		<Pagination
			perPage={perPage}
			count={appelDeCommandes.length}
			page={currentPage}
			onChangePage={handlePageChange}
		/>
	);
	const thead = [
		{ 
			id: "RefAppelDeCommande",label:
				<FormattedMessage
					id="appelDeCommande.ref"
					defaultMessage="REF Appel De Commande"
				/>
		},
		{ 
			id: "status",label:
				<FormattedMessage
					id="appelDeCommande.statut"
					defaultMessage="STATUT"
				/>
		},
		{ 
			id: "date",label:
				<FormattedMessage
					id="appelDeCommande.date"
					defaultMessage="DATE D'APPROBATION"
				/>
		},
		{ 
			id: "montant",label:
				<FormattedMessage
					id="appelDeCommande.amount"
					defaultMessage="MONTANT COMMANDE"
				/>
		},
		{ 
			id: "realisation",label:
				<FormattedMessage
					id="appelDeCommande.realisation"
					defaultMessage="% DE RÉALISATION"
				/>
		}
	];	
	const trows = purchaseOrderId ?
		currentAppelDeCommandes.map((appelDeCommande: AppelDeCommandeType) => ({
			RefAppelDeCommande: <strong>{appelDeCommande.refCmdAppel}</strong>,
			status: <CustomChip value={appelDeCommande.status} />,
			date: formatDate(new Date(appelDeCommande.approvalDate)),
			montant: formatCurrency(appelDeCommande.montantAppelDeCommande),
			realisation: <p>{appelDeCommande.appelDeCommandePRCNT}%</p>
		}))
		: []; // Empty rows if purchaseOrderId is null;

	return (
		<AttachmentsInvoicesSection
			pagination={pagination}
			isContract={isContract}
			isOracleData={isOracleData}
			changeActiveTab={changeActiveTab}
			activeTab={"appelDeCommandes"}
			Appel_Commandes_Count={purchaseOrderId ? count : 0}
			attachmentsCount={attachmentsCount}
			invoicesCount={invoicesCount}
		>
			<CustomTable dataStatus={status} thead={thead} trows={trows} />
		</AttachmentsInvoicesSection>
	);
};

export default AppelDeCommandes;