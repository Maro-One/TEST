import React, { useState, useEffect,useCallback } from "react";
import BreadCrumbs from "../../../common/BreadCrumbs";
import OrderIdenification from "../components/OrderIdenification";
import OrderDetails from "../components/OrderDetails";
import Attachments from "../components/Attachments";
import Invoices from "../components/Invoices";
import usePurchaseOrder from "../hooks/usePurchaseOrder";
import useAttachments from "../hooks/useAttachments";
import useInvoices from "../hooks/useInvoices";
import useAppelDeCommandes from "../hooks/useAppelDeCommandes";
import StatusControllerSpinner from "../../../common/SpinnerNew/StatusControllerSpinner";
import AppelDeCommandes from "../components/AppelDeCommandes/AppelDeCommandes";

const PurchaseOrderPage = () => {
	const { purchaseOrder, companyName } = usePurchaseOrder();
	const [refCmdAppelList, setRefCmdAppelList] = useState([]); // NEW STATE
	const purchaseOrderId = purchaseOrder.details ? purchaseOrder.details.purchaseOrderId : null;
	const purchaseOrderRef = purchaseOrder.details ? purchaseOrder.details.purchaseOrderRef : null;
	const isContract=purchaseOrderId!==purchaseOrderRef;
	const supplierOracleCode = purchaseOrder.details ? purchaseOrder.details.supplierOracleCode : null;
	const isOracleData=supplierOracleCode != null ? true : false;
	// Ne pas appeler ces hooks si purchaseOrderId est null
	const attachmentDetails = useAttachments(refCmdAppelList, purchaseOrderId);
	const invoicesDetails = useInvoices(purchaseOrderId);
	const appelDeCommandesDetails = useAppelDeCommandes(purchaseOrderId) ;

	// const [show, setShow] = useState();
	// const hide = show ? activeTab === "appelDeCommandes" : null;
	// function DisplayCMD(count_AppelDeCMD){
	// 	if({count_AppelDeCMD} != 0){
	// 		setShow(!show) 
	// 	}
	// }

	// Mémoriser la fonction pour éviter la dépendance dynamique
	const getInitialActiveTab = useCallback(() => {
		if(!purchaseOrderId) {
			console.log("Initial tab: appelDeCommandes");
			return "appelDeCommandes";
		}
		else if (purchaseOrderId === purchaseOrderRef) {
			console.log("Initial tab: Attachments");
			return "attachments";
		}else {
			console.log("Initial tab: Appel de Commandes");
			return "appelDeCommandes";
	     }
	}, [purchaseOrderId, purchaseOrderRef]);


	const AppelCommandesData = purchaseOrderId ? appelDeCommandesDetails : [];
	  

	const [activeTab, setActiveTab] = useState(""); // Initialize with an empty string
	const breadcrumbItems = [{ label: "Fournisseurs", to: "/" }];
	if (purchaseOrder.details) {
		breadcrumbItems.push(
			{ label: companyName, to: "/supplier/" + purchaseOrder.details.bravoId },
			{
				label: "Commande #" + purchaseOrder.details.purchaseOrderRef,
				fontWeight: "bold"
			}
		);
	}
	
	// Appeler cette logique seulement après avoir obtenu purchaseOrderId et purchaseOrderRef
	useEffect(() => {
		if (!purchaseOrderId || !purchaseOrderRef) return;

		setActiveTab(getInitialActiveTab());
	}, [purchaseOrderId, purchaseOrderRef,getInitialActiveTab]);  // Déclenche l'effet uniquement après changement de ces variables


	// Logique pour changer l'onglet actif si appel de commandes est disponible
	useEffect(() => {
		if(activeTab ) {
			console.log("ici dans if activeTab "+activeTab);
			return;
		}
		if(!purchaseOrderId) { 
			console.log("ici dans if !purchaseOrderId si c est null le pruchaseOrderId ");
			setActiveTab("appelDeCommandes")
			return;
		}
		if ( AppelCommandesData.status === "LOADING") {
			// Ne pas changer d'onglet si purchaseOrderId est null ou si les détails sont en chargement
			console.log("ici dans if purchaseOrderId || AppelCommandesData.status === looading ");
			setActiveTab("");
			return;
		}
		
		if (AppelCommandesData.count > 0) {
			console.log("ici dans if AppelCommandesData.count > 0 ");
			setActiveTab("appelDeCommandes");
			return;
		} else {
			console.log("ici dans else du if AppelCommandesData.count > 0 ");
			setActiveTab("attachments");
			return;
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [AppelCommandesData]);


	return (
		<>
			<BreadCrumbs items={breadcrumbItems} />
			<StatusControllerSpinner status={purchaseOrder.status}>
				<OrderIdenification purchaseOrder={purchaseOrder.details} />
				<OrderDetails purchaseOrder={purchaseOrder.details} />
			</StatusControllerSpinner>
			{ activeTab === "attachments" && (
				<Attachments
					{...attachmentDetails}
					isContract={isContract}
					isOracleData={isOracleData}
					purchaseOrderId={purchaseOrderId}
					invoicesCount={invoicesDetails.count}
					Appel_Commandes_Count={AppelCommandesData.count}
					changeActiveTab={(newTab) => setActiveTab(newTab)}
					refCmdAppelList={refCmdAppelList} // Pass refCmdAppelList to Attachments
				/>
			)}
			{  activeTab === "invoices" && (
				<Invoices
					{...invoicesDetails}
					isContract={isContract}
					isOracleData={isOracleData}
					purchaseOrderId={purchaseOrderId}
					attachmentsCount={attachmentDetails.count}
					Appel_Commandes_Count={AppelCommandesData.count}
					changeActiveTab={(newTab) => setActiveTab(newTab)}
				/>
			)}
			{ activeTab === "appelDeCommandes" && (
				console.log("here jhhffff"+refCmdAppelList),
				console.log(refCmdAppelList),
				<AppelDeCommandes
					{...AppelCommandesData}
					isContract={isContract}
					isOracleData={isOracleData}
					purchaseOrderId={purchaseOrderId}
					attachmentsCount={attachmentDetails.count}
					invoicesCount={invoicesDetails.count}
					changeActiveTab={(newTab) => setActiveTab(newTab)}
					setRefCmdAppelList={setRefCmdAppelList} // Pass setter function to AppelDeCommandes
				/>
			)}
		</>
	);
};
export default PurchaseOrderPage;