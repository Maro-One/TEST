// @flow

import React from "react";
import { connect } from "react-redux";
import { getInvoicesTimeline } from "../actions";
import EventTimeline from "../components/timeline/EventTimeline";
import { FormattedMessage } from "react-intl";

type Props = {
	requestTimeline: typeof getInvoicesTimeline,
	invoicesTimeline: any,
	sapId: number,
	einvoiceId: number | null,
	invoiceNumber: string,
	approvalStatus: string,
	purchaseOrderId: string,
	filingDate: string,
	dueDate: string,
	amount: string,
	status: string,
	requestSourceI: string
};

const InvoicesTimeline = ({
	invoicesTimeline,
	approvalStatus,
	invoiceNumber,
	requestTimeline,
	einvoiceId,
	sapId,
	purchaseOrderId,
	filingDate,
	dueDate,
	amount,
	status,
	requestSourceI
}: Props) => {
	React.useEffect(() => {
		requestTimeline(invoiceNumber || null, sapId, purchaseOrderId, filingDate, status, requestSourceI);
	}, [invoiceNumber, sapId, requestTimeline, purchaseOrderId, filingDate, status, requestSourceI]);

	return (
		<div>
			{invoicesTimeline && (
				<div className="body">
					<EventTimeline
						title={
							<FormattedMessage
								id="invoiceTimeline.section.title"
								values={{ invoiceNumber: invoiceNumber }}
							/>
						}
						lastStatus={`invoices.approvalStatus.${approvalStatus}`}
						status={invoicesTimeline.status}
						creationDate={filingDate}
						baseEcheance={dueDate}
						amountHT={amount}
						timeEvents={invoicesTimeline.timeline}
					/>
				</div>
			)}
		</div>
	);
};

const mapStateToProps = store => ({
	invoicesTimeline: store.purchaseOrder.invoicesTimeline
});
const mapDispatchToProps = { requestTimeline: getInvoicesTimeline };

export default connect(mapStateToProps, mapDispatchToProps)(InvoicesTimeline);
