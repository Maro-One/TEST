// @flow
import type { Saga } from "redux-saga";
import { takeLatest } from "redux-saga/effects";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";
import { fetchInvoicesFailure, fetchInvoicesSuccess } from "../actions";
import type { FetchInvoicesAction } from "../actions/actionTypes";
import { FETCH_INVOICES } from "../actions/constants";

const fetchInvoicesSaga = function*({
	purchaseOrderId,
	page,
	sort,
	status,
	requestSource
}: FetchInvoicesAction) {
	yield* callEndpoint(
		{
			url: `/api/invoices/all/${purchaseOrderId}/${requestSource}`,
			params: { page, sortBy: sort.by, order: sort.order, status },
			method: "get"
		},
		{
			dataTransform: resp => ({
				invoices: resp.content,
				count: resp.count,
				filter: resp.statusList
			}),
			successActionCreator: fetchInvoicesSuccess,
			errorActionCreator: fetchInvoicesFailure
		}
	);
};

// eslint-disable-next-line require-jsdoc
export default function*(): Saga<void> {
	yield takeLatest(FETCH_INVOICES, fetchInvoicesSaga);
}
