// @flow

import { takeLatest } from "redux-saga/effects";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";
import {
	getInvoicesTimelineError,
	getInvoicesTimelineSuccess
} from "../actions";
import type { GetInvoicesTimelineAction } from "../actions/actionTypes";
import { GET_INVOICES_TIMELINE } from "../actions/constants";

const generateUrl = (invoiceNumber, sapId, orderId, filingDate, status, requestSourceI) => {
	let url = "/api/invoices/invoice-timeline?";
	if (!isNaN(sapId) && sapId !== null) {
		url += `sapInvoiceId=${sapId}&`;
	}

	if (!isNaN(invoiceNumber) && invoiceNumber !== null) {
		url += `invoiceNumber=${invoiceNumber}&`;
	}
	if (orderId !== null) {
		url += `orderId=${orderId}&`;
	}
	if (filingDate !== null) {
		url += `creationDate=${filingDate}&`;
	}
	if (status !== null) {
		url += `invoiceStatus=${status}&`;
	}
	if (requestSourceI !== null) {
		url += `requestSource=${requestSourceI}&`;
	}
	return url.slice(0, -1);
};

export const getInvoicesTimelineRequest = function* ({
	einvoiceId,
	sapId,
	orderId,
	filingDate,
	status,
	requestSourceI
}: GetInvoicesTimelineAction): Generator<any, void, any> {
	yield* callEndpoint(
		{
			url: generateUrl(einvoiceId, sapId, orderId, filingDate, status, requestSourceI),
			method: "get"
		},
		{
			successActionCreator: getInvoicesTimelineSuccess,
			errorActionCreator: getInvoicesTimelineError
		}
	);
};

export default function* (): Generator<any, void, any> {
	yield takeLatest(GET_INVOICES_TIMELINE, getInvoicesTimelineRequest);
}
