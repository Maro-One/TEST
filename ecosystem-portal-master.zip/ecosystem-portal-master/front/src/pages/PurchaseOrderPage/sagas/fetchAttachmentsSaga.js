// @flow
import type { Saga } from "redux-saga";
import { takeLatest } from "redux-saga/effects";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";
import { fetchAttachmentsFailure, fetchAttachmentsSuccess } from "../actions";
import type { FetchAttachmentsAction } from "../actions/actionTypes";
import { FETCH_ATTACHMENTS } from "../actions/constants";

const fetchAttachmentsSaga = function*({
	purchaseOrderId,
	page,
	sort,
	refCmdAppelList,
	requestSource
}: FetchAttachmentsAction) {
	yield* callEndpoint(
		{
			/*
			url: `/api/attachments/approved-attachments/${purchaseOrderId}`,
			params: { page, sortBy: sort.by, order: sort.order },
			method: "get"
			*/
			url: `/api/attachments/approved-attachments/${purchaseOrderId}/${requestSource}`,
			method: "post", // Use POST instead of GET
			data: { // Send refCmdAppelList in the request body
				page,
				sortBy: sort.by,
				order: sort.order,
				refCmdAppelList
			}

		},
		{
			dataTransform: resp => ({
				attachments: resp.content,
				count: resp.count
			}),
			successActionCreator: fetchAttachmentsSuccess,
			errorActionCreator: fetchAttachmentsFailure
		}
	);
};

// eslint-disable-next-line require-jsdoc
export default function*(): Saga<void> {
	yield takeLatest(FETCH_ATTACHMENTS, fetchAttachmentsSaga);
}
