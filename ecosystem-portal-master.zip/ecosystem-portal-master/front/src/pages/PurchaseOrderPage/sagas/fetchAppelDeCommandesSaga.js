// @flow
import type { Saga } from "redux-saga";
import { takeLatest } from "redux-saga/effects";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";
import { fetchAppelDeCommandesFailure, fetchAppelDeCommandesSuccess } from "../actions";
import type { FetchAppelDeCommandesAction } from "../actions/actionTypes";
import { FETCH_AppelDeCommandes } from "../actions/constants";

const fetchAppelDeCommandesSaga = function*({
	purchaseOrderId,
	page,
	sort,
	requestSource
}: FetchAppelDeCommandesAction) {
	
	yield* callEndpoint(
		{
			url: `/api/appel-de-commandes/approved-appel-de-commandes/${purchaseOrderId}/${requestSource}`,
			params: { page, sortBy: sort.by, order: sort.order },
			method: "get"
		},
		{
			dataTransform: resp => ({
				appelDeCommandes: resp.content,
				count: resp.count
				//filter: resp.statusList
			}),
			 successActionCreator: fetchAppelDeCommandesSuccess,
			 errorActionCreator: fetchAppelDeCommandesFailure
		}
	);
};

// eslint-disable-next-line require-jsdoc
export default function*(): Saga<void> {
	yield takeLatest(FETCH_AppelDeCommandes, fetchAppelDeCommandesSaga);
}
