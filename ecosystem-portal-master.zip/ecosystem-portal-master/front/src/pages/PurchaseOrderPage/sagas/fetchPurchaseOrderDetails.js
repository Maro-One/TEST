// @flow
import type { Saga } from "redux-saga";
import { takeLatest } from "redux-saga/effects";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";
import {
	fetchPurchaseOrderDetailsFailure,
	fetchPurchaseOrderDetailsSuccess
} from "../actions";
import type { FetchPurchaseOrderDetailsAction } from "../actions/actionTypes";
import { FETCH_PURCHASE_ORDER_DETAILS } from "../actions/constants";

const fetchPurchaseOrderDetailsSaga = function*({
	purchaseOrderId,
	requestId,
	requestSource
}: FetchPurchaseOrderDetailsAction): Saga<void> {
	yield* callEndpoint(
		{
			url: `/api/funding-request/approved-funding-request-detail/${purchaseOrderId}/${requestId}/${requestSource}`,
			method: "get"
		},
		{
			successActionCreator: fetchPurchaseOrderDetailsSuccess,
			errorActionCreator: fetchPurchaseOrderDetailsFailure
		}
	);
};

export default function*(): Saga<void> {
	yield takeLatest(FETCH_PURCHASE_ORDER_DETAILS, fetchPurchaseOrderDetailsSaga);
}
