// @flow

import type { AttachmentType, SortType } from "../store/types";
import {
	CHANGE_ATTACHMENTS_PAGE,
	FETCH_ATTACHMENTS,
	FETCH_ATTACHMENTS_FAILURE,
	FETCH_ATTACHMENTS_SUCCESS,
	SORT_ATTACHMENTS_BY
} from "./constants";
import type {
	FetchAttachmentsAction,
	FetchAttachmentsFailureAction,
	FetchAttachmentsSuccessAction,
	ChangeAttachmentsPageAction,
	AttachmentsSortAction
} from "./actionTypes";

export const fetchAttachments = (
	purchaseOrderId: number,
	page: number,
	sort: SortType,
	refCmdAppelList: string[],
	requestSource: string
): FetchAttachmentsAction => ({
	type: FETCH_ATTACHMENTS,
	purchaseOrderId,
	page,
	sort,
	refCmdAppelList,
	requestSource
});

type FetchAttachmentsSuccessParamType = {
	attachments: AttachmentType[],
	count: number
};
export const fetchAttachmentsSuccess = (
	data: FetchAttachmentsSuccessParamType
): FetchAttachmentsSuccessAction => ({
	type: FETCH_ATTACHMENTS_SUCCESS,
	attachments: data.attachments,
	count: data.attachments.length
});

export const fetchAttachmentsFailure = (): FetchAttachmentsFailureAction => ({
	type: FETCH_ATTACHMENTS_FAILURE
});

// Attachments Pageable Action

export const changeAttachmentsPage = (
	page: number
): ChangeAttachmentsPageAction => ({
	type: CHANGE_ATTACHMENTS_PAGE,
	page
});

// Attachments Sort action

export const sortAttachments = (sortBy: string): AttachmentsSortAction => ({
	type: SORT_ATTACHMENTS_BY,
	sortBy
});
