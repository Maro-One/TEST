import {
	GET_INVOICES_TIMELINE,
	GET_INVOICES_TIMELINE_SUCCESS,
	GET_INVOICES_TIMELINE_ERROR
} from "./constants";
import type {
	GetInvoicesTimelineAction,
	GetInvoicesTimelineActionSuccess,
	GetInvoicesTimelineActionError
} from "./actionTypes";

export const getInvoicesTimeline = (
	invoiceNumber: number | null,
	sapId: number,
	orderId: string,
	filingDate: string,
	status: string,
	requestSourceI: string
): GetInvoicesTimelineAction => ({
	invoiceNumber,
	sapId,
	orderId,
	filingDate,
	status,
	type: GET_INVOICES_TIMELINE,
	requestSourceI
});

export const getInvoicesTimelineSuccess = (
	timeline: []
): GetInvoicesTimelineActionSuccess => ({
	timeline,
	type: GET_INVOICES_TIMELINE_SUCCESS
});

export const getInvoicesTimelineError = (
	errorMessage: string
): GetInvoicesTimelineActionError => ({
	errorMessage,
	type: GET_INVOICES_TIMELINE_ERROR
});
