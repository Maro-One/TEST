// @flow

import type { AppelDeCommandeType } from "../store/types";
import {
	CHANGE_AppelDeCommandes_PAGE,
	FETCH_AppelDeCommandes,
	FETCH_AppelDeCommandes_FAILURE,
	FETCH_AppelDeCommandes_SUCCESS,
	SORT_APPELDECOMMANDES_BY
} from "./constants";
import type {
	FetchAppelDeCommandesAction,
	FetchAppelDeCommandesFailureAction,
	FetchAppelDeCommandesSuccessAction,
	ChangeAppelDeCommandesPageAction,
	AppelDeCommandesSortAction
} from "./actionTypes";

export const fetchAppelDeCommandes = (
	purchaseOrderId: number,
	page: number,
	sort: SortType,
	requestSource: string
): FetchAppelDeCommandesAction => ({
	type: FETCH_AppelDeCommandes,
	purchaseOrderId,
	page,
	sort,
	requestSource
});

type FetchAppelDeCommandesSuccessParamType = {
	appelDeCommandes: AppelDeCommandeType[],
	count: number
};
export const fetchAppelDeCommandesSuccess = (
	data: FetchAppelDeCommandesSuccessParamType
): FetchAppelDeCommandesSuccessAction => ({
	type: FETCH_AppelDeCommandes_SUCCESS,
	 appelDeCommandes: data.appelDeCommandes,
	 count: data.appelDeCommandes.length
});

export const fetchAppelDeCommandesFailure = (): FetchAppelDeCommandesFailureAction => ({
	type: FETCH_AppelDeCommandes_FAILURE
});

// AppelDeCommandes Pageable Action

export const changeAppelDeCommandesPage = (
 	page: number
): ChangeAppelDeCommandesPageAction => ({
	type: CHANGE_AppelDeCommandes_PAGE,
 	page
});

// AppelDeCommandes Sort action

export const sortAppelDeCommandes = (sortBy: string): AppelDeCommandesSortAction => ({
 	type: SORT_APPELDECOMMANDES_BY,
 	sortBy
});

