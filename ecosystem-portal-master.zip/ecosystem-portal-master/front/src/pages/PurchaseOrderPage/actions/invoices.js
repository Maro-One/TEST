// @flow

// Invoices actions
import type { InvoiceType, SortType } from "../store/types";
import type {
	ChangeInvoicesPageAction,
	FetchInvoicesAction,
	FetchInvoicesFailureAction,
	FetchInvoicesSuccessAction,
	InvoicesSortAction,
	SetFilterValue
} from "./actionTypes";
import {
	CHANGE_INVOICES_PAGE,
	FETCH_INVOICES,
	FETCH_INVOICES_FAILURE,
	FETCH_INVOICES_SUCCESS,
	SORT_INVOICES_BY,
	SET_FILTER_VALUE
} from "./constants";

export const fetchInvoices = (
	purchaseOrderId: number,
	page: number,
	sort: SortType,
	status: string,
	requestSource: string
): FetchInvoicesAction => ({
	type: FETCH_INVOICES,
	purchaseOrderId,
	page,
	sort,
	status,
	requestSource
});

type FetchInvoicesSuccessParamType = {
	invoices: InvoiceType[],
	count: number,
	filter: Array<string>
};
export const fetchInvoicesSuccess = (
	data: FetchInvoicesSuccessParamType
): FetchInvoicesSuccessAction => ({
	type: FETCH_INVOICES_SUCCESS,
	invoices: data.invoices,
	count: data.count,
	filter: data.filter
});

export const fetchInvoicesFailure = (): FetchInvoicesFailureAction => ({
	type: FETCH_INVOICES_FAILURE
});

// Invoices pageable action

export const changeInvoicesPage = (page: number): ChangeInvoicesPageAction => ({
	type: CHANGE_INVOICES_PAGE,
	page
});

// Invoices Sort action

export const sortInvoices = (sortBy: string): InvoicesSortAction => ({
	type: SORT_INVOICES_BY,
	sortBy
});

// Invoices Filter
export const setFilterValue = (value: string): SetFilterValue => ({
	type: SET_FILTER_VALUE,
	name:"INVOICES",
	value
});
