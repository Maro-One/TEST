// @flow

import type {
	AttachmentType,
	InvoiceType,
	AppelDeCommandeType,
	PurchaseOrderDetailsType,
	SortType
} from "../store/types";

// PURCHASE ORDER
export type FetchPurchaseOrderDetailsAction = {
	type: "FETCH_PURCHASE_ORDER_DETAILS",
	purchaseOrderId: number,
	requestId: number,
	requestSource: string
};

export type FetchPurchaseOrderDetailsSuccessAction = {
	type: "FETCH_PURCHASE_ORDER_DETAILS_SUCCESS",
	purchaseOrderDetails: PurchaseOrderDetailsType
};

export type FetchPurchaseOrderDetailsFailureAction = {
	type: "FETCH_PURCHASE_ORDER_DETAILS_FAILURE"
};

export type ClearDataAction = {
	type: "CLEAR_DATA"
};

// ATTACHMENTS
export type FetchAttachmentsAction = {
	type: "FETCH_ATTACHMENTS",
	purchaseOrderId: number,
	page: number,
	sort: SortType,
	refCmdAppelList: string[],
	requestSource: string
};

export type FetchAttachmentsSuccessAction = {
	type: "FETCH_ATTACHMENTS_SUCCESS",
	attachments: AttachmentType[],
	count: number
};

export type FetchAttachmentsFailureAction = {
	type: "FETCH_ATTACHMENTS_FAILURE"
};

export type ChangeAttachmentsPageAction = {
	type: "CHANGE_ATTACHMENTS_PAGE",
	page: number
};

export type AttachmentsSortAction = {
	type: "SORT_ATTACHMENTS_BY",
	sortBy: string
};

//Appel De Commandes
export type FetchAppelDeCommandesAction = {
	type: "FETCH_AppelDeCommandes",
	purchaseOrderId: number,
	page: number,
	sort: SortType
};
export type FetchAppelDeCommandesSuccessAction = {
	type: "FETCH_AppelDeCommandes_SUCCESS",
	appelDeCommandes: AppelDeCommandeType[],
	count: number
};

export type FetchAppelDeCommandesFailureAction = {
	type: "FETCH_AppelDeCommandes_FAILURE"
};

export type ChangeAppelDeCommandesPageAction = {
	type: "CHANGE_AppelDeCommandes_PAGE",
	page: number
};

export type AppelDeCommandesSortAction = {
	type: "SORT_APPELDECOMMANDES_BY",
	sortBy: string
};

// Invoices

export type FetchInvoicesAction = {
	type: "FETCH_INVOICES",
	purchaseOrderId: number,
	page: number,
	sort: SortType,
	status: string,
	requestSource: string
};

export type FetchInvoicesSuccessAction = {
	type: "FETCH_INVOICES_SUCCESS",
	invoices: InvoiceType[],
	count: number,
	filter: Array<string>
};

export type FetchInvoicesFailureAction = {
	type: "FETCH_INVOICES_FAILURE"
};

export type ChangeInvoicesPageAction = {
	type: "CHANGE_INVOICES_PAGE",
	page: number
};

export type InvoicesSortAction = {
	type: "SORT_INVOICES_BY",
	sortBy: string
};

export type GetInvoicesTimelineAction = {
	type: "GET_INVOICES_TIMELINE",
	invoiceNumber: number | null,
	sapId: number,
	orderId: string,
	creationDate: string,
	status: string,
};

export type GetInvoicesTimelineActionSuccess = {
	timeline: [],
	type: "GET_INVOICES_TIMELINE_SUCCESS"
};

export type GetInvoicesTimelineActionError = {
	errorMessage: string,
	type: "GET_INVOICES_TIMELINE_ERROR"
};

export type SetFilterValue = {
	type: "SET_FILTER_VALUE",
	value: string
};

export type PurchaseOrderActionsType =
	| FetchPurchaseOrderDetailsAction
	| FetchPurchaseOrderDetailsSuccessAction
	| FetchPurchaseOrderDetailsFailureAction
	| FetchAttachmentsAction
	| FetchAttachmentsSuccessAction
	| FetchAttachmentsFailureAction
	| ChangeAttachmentsPageAction
	| FetchAppelDeCommandesAction
	| FetchAppelDeCommandesSuccessAction
	| FetchAppelDeCommandesFailureAction
	|  ChangeAppelDeCommandesPageAction
	| AppelDeCommandesSortAction
	| FetchInvoicesAction
	| FetchInvoicesSuccessAction
	| FetchInvoicesFailureAction
	| ChangeInvoicesPageAction
	| ClearDataAction
	| AttachmentsSortAction
	| InvoicesSortAction
	| GetInvoicesTimelineAction
	| GetInvoicesTimelineActionSuccess
	| GetInvoicesTimelineActionError
	| SetFilterValue;
