// @flow

import type { PurchaseOrderDetailsType } from "../store/types";
import {
	FETCH_PURCHASE_ORDER_DETAILS,
	FETCH_PURCHASE_ORDER_DETAILS_FAILURE,
	FETCH_PURCHASE_ORDER_DETAILS_SUCCESS,
	CLEAR_DATA
} from "./constants";
import type {
	FetchPurchaseOrderDetailsAction,
	FetchPurchaseOrderDetailsSuccessAction,
	FetchPurchaseOrderDetailsFailureAction,
	ClearDataAction
} from "./actionTypes";

export const fetchPurchaseOrderDetails = (
	purchaseOrderId: number,
	requestId: number,
	requestSource: string
): FetchPurchaseOrderDetailsAction => ({
	type: FETCH_PURCHASE_ORDER_DETAILS,
	purchaseOrderId,
	requestId,
	requestSource
});

export const fetchPurchaseOrderDetailsSuccess = (
	purchaseOrderDetails: PurchaseOrderDetailsType
): FetchPurchaseOrderDetailsSuccessAction => ({
	type: FETCH_PURCHASE_ORDER_DETAILS_SUCCESS,
	purchaseOrderDetails
});

export const fetchPurchaseOrderDetailsFailure = (): FetchPurchaseOrderDetailsFailureAction => ({
	type: FETCH_PURCHASE_ORDER_DETAILS_FAILURE
});

// Clearing action

export const clearData = (): ClearDataAction => ({
	type: CLEAR_DATA
});
