// @flow

import type { SortType, OrderType } from "../store/types";
import {
	changeAttachmentsPage,
	fetchAttachments,
	fetchAttachmentsFailure,
	fetchAttachmentsSuccess,
	sortAttachments
} from "./attachments";
import {
	changeAppelDeCommandesPage,
	fetchAppelDeCommandes,
	fetchAppelDeCommandesFailure,
	fetchAppelDeCommandesSuccess,
	sortAppelDeCommandes
} from "./appelDeCommandes";
import {
	changeInvoicesPage,
	fetchInvoices,
	fetchInvoicesFailure,
	fetchInvoicesSuccess,
	sortInvoices
} from "./invoices";
import {
	fetchPurchaseOrderDetails,
	fetchPurchaseOrderDetailsFailure,
	fetchPurchaseOrderDetailsSuccess,
	clearData
} from "./purchaseOrder";
import {
	getInvoicesTimeline,
	getInvoicesTimelineError,
	getInvoicesTimelineSuccess
} from "./invoicesTimeline";

export {
	fetchPurchaseOrderDetails,
	fetchPurchaseOrderDetailsFailure,
	fetchPurchaseOrderDetailsSuccess,
	clearData,
	changeAttachmentsPage,
	fetchAttachments,
	fetchAttachmentsFailure,
	fetchAttachmentsSuccess,
	sortAttachments,
	changeAppelDeCommandesPage,
	fetchAppelDeCommandes,
	fetchAppelDeCommandesFailure,
	fetchAppelDeCommandesSuccess,
	sortAppelDeCommandes,
	changeInvoicesPage,
	fetchInvoices,
	fetchInvoicesFailure,
	fetchInvoicesSuccess,
	sortInvoices,
	getInvoicesTimeline,
	getInvoicesTimelineError,
	getInvoicesTimelineSuccess
};

export const getCurrentOrderFor = (
	sort: SortType | typeof undefined,
	columnID: string
): OrderType | typeof undefined =>
	sort && sort.by === columnID ? sort.order : undefined;
