import PurchaseOrderPage from "./container/PurchaseOrderPage";

export default PurchaseOrderPage;
