// @flow
import type {StatusType} from "../../../store/commonTypes";

export type PurchaseOrderDetailsType = {
	approvalAttachmentAmount: number,
	billedAmount: number,
	paidAmount: number,
	id: number,
	bravoId: number,
	supplierOracleCode: string,
	purchaseOrderId: string,
	purchaseOrderRef: string,
	businessUnitName: string,
	status: string,
	purchaseOrderApprovalDate: Date,
	purchaseOrderAmount: number,
	achievementPercentage: number,
	achievementPercentageCallOf: number,
	purchaseOrderDescription: string,
	purchaseOrderCategory: string,
	fundingAgencyName: string,
  purchaseOrderPaymentTermsName: string,
  purchaseOrderPaymentTermsDescription: string
};

export type AttachmentType = {
	refAttachment: string,
    refCmdAppel: string,
    status: string,
    dateValidation: Date,
    montantAttachement: number,
    deviseAttachement: string,
    typeLookupCode: string,
    poHeaderIp: string
};

export type AppelDeCommandeType = {
	refCmdAppel: number,
	status: string,
	approvalDate: Date,
	montantAppelDeCommande: number,
	appelDeCommandePRCNT: number
};

export type InvoiceType = {
	sapInvoiceId: number,
	einvoiceId: number,
	invoiceNumber: string,
	purchaseOrderId: string,
	purchaseOrderCode: string,
	creationDate: Date,
	baseEcheance: Date,
	amountHT: number,
	approvalStatus: string,
	paymentStatus: string,
	status: string,
	dueDate: Date
};

export type OrderType = "asc" | "desc";
export type SortType = { by: string, order: OrderType };
export type FilterType = { list: Array<string>, selectedValue: string | null };

export type PurchaseOrderDetailsStoreType = {
	details: $Shape<PurchaseOrderDetailsType>,
	status: StatusType
};

export type AttachmentsStoreType = {
	attachments: { [page: number]: AttachmentType[] },
	status: StatusType,
	page: number,
	perPage: number,
	count: number,
	sort: SortType
};
export type AppelDeCommandesStoreType = {
	appelDeCommandes: { [page: number]: AppelDeCommandeType[] },
	status: StatusType,
	page: number,
	perPage: number,
	count: number
};
export type InvoicesStoreType = {
	invoices: { [page: number]: InvoiceType[] },
	status: StatusType,
	page: number,
	perPage: number,
	count: number,
	sort: SortType,
	filter: FilterType
};

export type PurchaseOrderStoreType = {
	purchaseOrder: PurchaseOrderDetailsStoreType,
	invoices: InvoicesStoreType,
	attachments: AttachmentsStoreType,
	appelDeCommandes: AppelDeCommandesStoreType
};
