// @flow

import {DESC, ERROR, LOADING, SUCCESS} from "../../../utils/constants";
import type {PurchaseOrderActionsType} from "../actions/actionTypes";
import {
	CHANGE_INVOICES_PAGE,
	CLEAR_DATA,
	FETCH_INVOICES,
	FETCH_INVOICES_FAILURE,
	FETCH_INVOICES_SUCCESS,
	SET_FILTER_VALUE,
	SORT_INVOICES_BY
} from "../actions/constants";
import type {InvoicesStoreType} from "../store/types";
import {toggleSort} from "./helperMethods";
import filterReducerFactory from "../../../utils/filterReducerFactory";

const DEFAULT_STATE: InvoicesStoreType = {
	page: 0,
	invoices: {},
	count: 0,
	perPage: 10,
	status: LOADING,
	sort: {
		by: "dueDate",
		order: DESC
	},
	filter: {
		list: [],
		selectedValue: null
	}
};
const filterReducer = filterReducerFactory("INVOICES")


export default function (
	state: InvoicesStoreType = DEFAULT_STATE,
	action: PurchaseOrderActionsType
) {
	switch (action.type) {
		case FETCH_INVOICES:
			return {...state, status: LOADING};
		case FETCH_INVOICES_SUCCESS:
			return {
				...state,
				invoices: {
					...state.invoices,
					[state.page]: action.invoices
				},
				status: SUCCESS,
				count: action.count,
				filter: {
					...state.filter,
					list: action.filter.length > 0 ? action.filter : state.filter.list
				}
			};
		case FETCH_INVOICES_FAILURE:
			return {...state, status: ERROR};
		case CHANGE_INVOICES_PAGE:
			return {...state, page: action.page};
		case SORT_INVOICES_BY:
			return {
				...state,
				invoices: {},
				page: 0,
				count: 0,
				sort: {
					by: action.sortBy,
					order:
                        state.sort.by === action.sortBy
                        	? toggleSort(state.sort.order)
                        	: DESC
				}
			};
		case SET_FILTER_VALUE:
			return filterReducer(state, action);
		case CLEAR_DATA:
			return {...DEFAULT_STATE};
		default:
			return state;
	}
}
