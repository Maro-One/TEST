// @flow

import { ERROR, LOADING, SUCCESS, DESC } from "../../../utils/constants";
import type { PurchaseOrderActionsType } from "../actions/actionTypes";
import {
	CHANGE_ATTACHMENTS_PAGE,
	FETCH_ATTACHMENTS,
	FETCH_ATTACHMENTS_FAILURE,
	FETCH_ATTACHMENTS_SUCCESS,
	CLEAR_DATA,
	SORT_ATTACHMENTS_BY
} from "../actions/constants";
import type { AttachmentsStoreType } from "../store/types";
import { toggleSort } from "./helperMethods";

const DEFAULT_STATE: AttachmentsStoreType = {
	page: 0,
	attachments: {},
	count: 0,
	perPage: 10,
	status: LOADING,
	sort: {
		by: "updatedDate",
		order: DESC
	}
};

export default function(
	state: AttachmentsStoreType = DEFAULT_STATE,
	action: PurchaseOrderActionsType
) {
	switch (action.type) {
		case FETCH_ATTACHMENTS:
			return { ...state, status: LOADING };
		case FETCH_ATTACHMENTS_SUCCESS:
			return {
				...state,
				attachments: {
					...state.attachments,
					[state.page]: action.attachments
				},
				status: SUCCESS,
				count: action.count
			};
		case FETCH_ATTACHMENTS_FAILURE:
			return { ...state, status: ERROR };
		case CHANGE_ATTACHMENTS_PAGE:
			return { ...state, page: action.page };
		case SORT_ATTACHMENTS_BY:
			return {
				...state,
				attachments: {},
				page: 0,
				count: 0,
				sort: {
					by: action.sortBy,
					order:
						state.sort.by === action.sortBy
							? toggleSort(state.sort.order)
							: DESC
				}
			};
		case CLEAR_DATA:
			return { ...DEFAULT_STATE };
		default:
			return state;
	}
}
