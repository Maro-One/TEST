// @flow

import { ERROR, LOADING, SUCCESS, DESC } from "../../../utils/constants";
import type { PurchaseOrderActionsType } from "../actions/actionTypes";
import {
	CHANGE_AppelDeCommandes_PAGE,
	FETCH_AppelDeCommandes,
	FETCH_AppelDeCommandes_FAILURE,
	FETCH_AppelDeCommandes_SUCCESS,
	CLEAR_DATA,
	SORT_APPELDECOMMANDES_BY
} from "../actions/constants";
import type { AppelDeCommandesStoreTypeStoreType } from "../store/types";
import { toggleSort } from "./helperMethods";

const DEFAULT_STATE: AppelDeCommandesStoreTypeStoreType = {
	page: 0,
	appelDeCommandes: {},
	count: 0,
	perPage: 10,
	status: LOADING,
	sort: {
		by: "updatedDate",
		order: DESC
	}
};

export default function(
	state: AppelDeCommandesStoreTypeStoreType = DEFAULT_STATE,
	action: PurchaseOrderActionsType
) {
	switch (action.type) {
		case FETCH_AppelDeCommandes:
			return { ...state, status: LOADING };
		case FETCH_AppelDeCommandes_SUCCESS:
			return {
				...state,
				appelDeCommandes: {
					...state.appelDeCommandes,
					[state.page]: action.appelDeCommandes
				},
				status: SUCCESS,
				count: action.count
			};
		case FETCH_AppelDeCommandes_FAILURE:
		 	return { ...state, status: ERROR };
		 case CHANGE_AppelDeCommandes_PAGE:
		 	return { ...state, page: action.page };
		 case SORT_APPELDECOMMANDES_BY:
		 	return {
		 		...state,
		 		appelDeCommandes: {},
		 		page: 0,
		 		count: 0,
		 		sort: {
		 			by: action.sortBy,
		 			order:
		 				state.sort.by === action.sortBy
		 					? toggleSort(state.sort.order)
		 					: DESC
				}
			};
		case CLEAR_DATA:
			return { ...DEFAULT_STATE };
		default:
			return state;
	}
}
