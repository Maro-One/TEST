// @flow

import type { OrderType } from "../store/types";
import { ASC, DESC } from "../../../utils/constants";

export const toggleSort = (currentType: OrderType) => {
	if (currentType === ASC) {
		return DESC;
	}
	return ASC;
};
