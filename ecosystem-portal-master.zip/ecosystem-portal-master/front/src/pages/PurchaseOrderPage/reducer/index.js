import { combineReducers } from "redux";
import purchaseOrder from "./PurchaseOrderReducer";
import invoices from "./invoicesReducer";
import attachments from "./attachmentsReducer";
import invoicesTimeline from "./invoicesTimelineReducer";
import appelDeCommandes from "./appelDeCommandesReducer"

export default combineReducers({
	purchaseOrder,
	appelDeCommandes,
	invoices,
	attachments,
	invoicesTimeline,
});
