// @flow

import {ERROR, LOADING, SUCCESS} from "../../../utils/constants";
import type {PurchaseOrderActionsType} from "../actions/actionTypes";
import {
	CLEAR_DATA,
	FETCH_PURCHASE_ORDER_DETAILS,
	FETCH_PURCHASE_ORDER_DETAILS_FAILURE,
	FETCH_PURCHASE_ORDER_DETAILS_SUCCESS,
	SET_FILTER_VALUE
} from "../actions/constants";
import type {PurchaseOrderDetailsStoreType} from "../store/types";
import filterReducerFactory from "../../../utils/filterReducerFactory";

const DEFAULT_STATE: PurchaseOrderDetailsStoreType = {
	details: {},
	status: LOADING
};
const filterReducer = filterReducerFactory("PURCHASE_ORDER")
export default function (
	state: PurchaseOrderDetailsStoreType = DEFAULT_STATE,
	action: PurchaseOrderActionsType
) {
	switch (action.type) {
		case FETCH_PURCHASE_ORDER_DETAILS:
			return {...state, status: LOADING};
		case FETCH_PURCHASE_ORDER_DETAILS_SUCCESS:
			return {
				...state,
				status: SUCCESS,
				details: action.purchaseOrderDetails
			};
		case FETCH_PURCHASE_ORDER_DETAILS_FAILURE:
			return {...state, status: ERROR};
		case SET_FILTER_VALUE:
			return filterReducer(state, action);
		case CLEAR_DATA:
			return {...DEFAULT_STATE};
		default:
			return state;
	}
}
