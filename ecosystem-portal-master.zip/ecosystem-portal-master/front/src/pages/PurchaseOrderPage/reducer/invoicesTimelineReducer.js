// @flow

import {
	GET_INVOICES_TIMELINE,
	GET_INVOICES_TIMELINE_SUCCESS,
	GET_INVOICES_TIMELINE_ERROR
} from "../actions/constants";

const DEFAULT_STATE = {
	status: undefined,
	timeline: []
};
type stateType = {
	status: "SUCCESS" | "ERROR" | "LOADING" | typeof undefined,
	timeline: []
};
/**
 * Stores the invoices timeline  information
 * @param {object} state The current state
 * @param {object} action The action to handle
 * @returns {object} The new state
 */
export default function(state: stateType = DEFAULT_STATE, action: any) {
	switch (action.type) {
		case GET_INVOICES_TIMELINE:
			return Object.assign({}, state, { status: "LOADING" });
		case GET_INVOICES_TIMELINE_SUCCESS:
			return Object.assign({}, state, {
				status: "SUCCESS",
				timeline: action.timeline
			});
		case GET_INVOICES_TIMELINE_ERROR:
			return Object.assign({}, state, { status: "ERROR" });
		default:
			return state;
	}
}
