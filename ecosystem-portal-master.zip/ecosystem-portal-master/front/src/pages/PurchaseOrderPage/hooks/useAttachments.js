// @flow

import {useParams} from "react-router";
import {useDispatch, useSelector} from "react-redux";
import {useCallback, useEffect, useRef} from "react";
import {changeAttachmentsPage, fetchAttachments} from "../actions";

/**
 * a hook for loading attachments and handle page changes
 */
export default function useAttachments(refCmdAppelList, purchaseOrderId) {// Accept refCmdAppelList as a parameter
	//const {purchaseOrderId} = useParams();
	const dispatch = useDispatch();
	const {requestSource} = useParams();
	
	const {attachments, status, page, count, perPage, sort} = useSelector(({purchaseOrder: {attachments}}) => ({
		attachments: attachments.attachments === undefined ? [] : attachments.attachments[attachments.page],
		page: attachments.page,
		status: attachments.status,
		count: attachments.count ? attachments.count : 0,
		perPage: attachments.perPage,
		sort: attachments.sort
	}));
	const changePage = useCallback((page: number) => {
		dispatch(changeAttachmentsPage(page))
	}, [dispatch]);
	const currentNumAttachments = attachments ? attachments.length : 0;

	// Track previous length to detect changes if refCmdAppelList is provided
	const prevRefCmdAppelListLength = useRef(refCmdAppelList ? refCmdAppelList.length : 0);
	
	useEffect(() => {
		// Ne pas faire d'appel si purchaseOrderId est null
		if (!purchaseOrderId) {
			return; // Sortir si purchaseOrderId est null
		}
	
		// Only call fetchAttachments if refCmdAppelList.length has changed
		if (currentNumAttachments === 0 || (refCmdAppelList && refCmdAppelList.length !== prevRefCmdAppelListLength.current)) {	
			dispatch(fetchAttachments(purchaseOrderId, page, sort, refCmdAppelList, requestSource));
			// Update previous length after fetch
			prevRefCmdAppelListLength.current = refCmdAppelList.length;	

		}

	}, [dispatch, purchaseOrderId, page, currentNumAttachments,sort,refCmdAppelList, requestSource]);
	// Renvoie des valeurs par défaut si purchaseOrderId est null
	if (!purchaseOrderId) {
		return {attachments: [], count: 0};
	}
	
	return {attachments, changePage, status, page, count, perPage, sort};
}
