// @flow

import {useParams} from "react-router";
import {useDispatch, useSelector} from "react-redux";
import {useCallback, useEffect} from "react";
import {changeAppelDeCommandesPage, fetchAppelDeCommandes} from "../actions";

/**
 * a hook for loading attachments and handle page changes
 */
export default function useAppelDeCommandes(purchaseOrderId) {
	//console.log("hhhhh123"+this.state)
	//const {purchaseOrderId} = useParams();
	const dispatch = useDispatch();
	const {requestSource} = useParams();
	
	/*const {appelDeCommandes, status, page, count, perPage, sort} = useSelector(({purchaseOrder: {appelDeCommandes,...otherOrthers}}) => {
		
		console.log({"selectorcomment":appelDeCommandes,otherOrthers})
		return ({
		appelDeCommandes: appelDeCommandes?.appelDeCommandes === undefined ? [] : appelDeCommandes?.appelDeCommandes[appelDeCommandes?.page],
		page: appelDeCommandes?.page,
		status: appelDeCommandes?.status,
		count: appelDeCommandes?.count ? appelDeCommandes?.count : 0,
		perPage: appelDeCommandes?.perPage,
		sort: appelDeCommandes?.sort
	})
});*/
	const {appelDeCommandes, status, page, count, perPage, sort} = useSelector(({purchaseOrder: {appelDeCommandes}}) => ({
		appelDeCommandes: appelDeCommandes.appelDeCommandes === undefined ? [] : appelDeCommandes.appelDeCommandes[appelDeCommandes.page],
		page: appelDeCommandes.page,
		status: appelDeCommandes.status,
	    count: appelDeCommandes.count ? appelDeCommandes.count : 0,
		perPage: appelDeCommandes.perPage,
		sort: appelDeCommandes.sort
   	}));
   	/*const {appelDeCommandes, status, page, count, perPage, sort} = useSelector(({purchaseOrder: {appelDeCommandes}}) => ({
	appelDeCommandes: appelDeCommandes && appelDeCommandes.appelDeCommandes ? appelDeCommandes.appelDeCommandes[appelDeCommandes.page] : [],
	page: appelDeCommandes && appelDeCommandes.page,
	status: appelDeCommandes && appelDeCommandes.status,
	count: appelDeCommandes && appelDeCommandes.count ? appelDeCommandes.count : 0,
	perPage: appelDeCommandes && appelDeCommandes.perPage,
	sort: appelDeCommandes && appelDeCommandes.sort
  }));*/
	const changePage = useCallback((page: number) => {
		dispatch(changeAppelDeCommandesPage(page))
	}, [dispatch]);
	const currentNumAppelDeCommandes = appelDeCommandes ? appelDeCommandes.length : 0;
	
	useEffect(() => {
		if (!purchaseOrderId) {
			return; // Sortir si purchaseOrderId est null
		}
		if (purchaseOrderId && currentNumAppelDeCommandes === 0) {
			dispatch(fetchAppelDeCommandes(purchaseOrderId, page, sort, requestSource));
		}
	}, [dispatch, purchaseOrderId, page, currentNumAppelDeCommandes,sort, requestSource]);

	// Renvoie des valeurs par défaut si purchaseOrderId est null
	if (!purchaseOrderId) {
		return {appelDeCommandes: [], count: 0};
	}

	return {appelDeCommandes, changePage, status, page, count, perPage, sort};
}
