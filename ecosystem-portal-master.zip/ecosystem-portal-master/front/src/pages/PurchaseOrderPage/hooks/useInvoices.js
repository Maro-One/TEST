// @flow

import { useParams } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { useCallback, useEffect } from "react";
import { changeInvoicesPage, fetchInvoices } from "../actions";
import { setFilterValue } from "../actions/invoices";

/**
 * A hook for loading invoices and handle page changes.
 */
export default function useInvoices(purchaseOrderId) {
	//const { purchaseOrderId } = useParams();
	const dispatch = useDispatch();
	const {requestSource} = useParams();

	const { invoices, status, page, count, perPage, sort, filter } = useSelector(
		 ({ purchaseOrder: { invoices } }) => ({
			invoices:
				invoices.invoices === undefined ? [] : invoices.invoices[invoices.page],
			page: invoices.page,
			status: invoices.status,
			count: invoices.count ? invoices.count : 0,
			perPage: invoices.perPage,
			sort: invoices.sort,
			filter: invoices.filter
		})
	);

	const changePage = useCallback(
		(page: number) => {
			dispatch(changeInvoicesPage(page));
		},
		[dispatch]
	);

	const onFilterChange = value => dispatch(setFilterValue(value));

	const currentNumInvoices = invoices ? invoices.length : 0;

	useEffect(() => {
		// Ne pas faire d'appel si purchaseOrderId est null
		if (!purchaseOrderId) {
			return; // Sortir si purchaseOrderId est null
		}
		if (purchaseOrderId) {
			dispatch(fetchInvoices(purchaseOrderId, page, sort, filter.selectedValue, requestSource));
		}
	}, [
		dispatch,
		purchaseOrderId,
		page,
		currentNumInvoices,
		sort,
		filter.selectedValue,
		requestSource
	]);

	// Renvoie des valeurs par défaut si purchaseOrderId est null
	if (!purchaseOrderId) {
		return {invoices: [], count: 0, filter:filter || {list:[]}};
	}


	return {
		invoices,
		changePage,
		status,
		page,
		count,
		perPage,
		sort,
		filter,
		onFilterChange
	};
}
