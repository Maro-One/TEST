// @flow
import { useParams } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { fetchPurchaseOrderDetails, clearData } from "../actions";
import { getSupplierInfo } from "../../SupplierDetailPage/actions";

const getCompanyNameFromSupplierInfo = (supplierInfo, defaultValue): string => {
	if (supplierInfo && supplierInfo.data) {
		return supplierInfo.data.companyName;
	}
	return defaultValue;
};
/**
 * a hook for loading purchase order details
 */
export default function() {
	const { purchaseOrderId, bravoId, requestId, requestSource } = useParams();
	const dispatch = useDispatch();
	const { purchaseOrder, companyName } = useSelector(
		({ purchaseOrder, supplierDetail: { supplierInfo } }) => ({
			purchaseOrder: purchaseOrder.purchaseOrder,
			companyName: getCompanyNameFromSupplierInfo(supplierInfo, `#${bravoId}`)
		})
	);
	useEffect(() => {
		dispatch(getSupplierInfo(bravoId));
	}, [bravoId, dispatch]);
	useEffect(() => {
		dispatch(fetchPurchaseOrderDetails(purchaseOrderId, requestId, requestSource));
	}, [purchaseOrderId, dispatch, requestId, requestSource]);

	useEffect(() => {
		// on unmout just clear the current data and be ready for the next
		return () => dispatch(clearData());
	}, [dispatch]);

	return { purchaseOrder, companyName };
}
