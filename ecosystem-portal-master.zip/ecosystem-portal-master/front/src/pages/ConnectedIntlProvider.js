// @flow
import React from "react";
import { IntlProvider } from "react-intl";
import localeFr from "../locales/intl.fr.json";
type Props = {
	locale: "fr" | "en",
	messages: Object,
	rest: any
};
const ConnectedIntlProvider = ({
	locale = "fr",
	messages = localeFr,
	...rest
}: Props) => <IntlProvider messages={messages} locale={locale} {...rest} />;
export default ConnectedIntlProvider;
