export const IMPORT_FILE_FORM_SUBMIT = "IMPORT_FILE_FORM_SUBMIT_SAP";
export const IMPORT_FILE_FORM_SUBMIT_ERROR = "IMPORT_FILE_FORM_SUBMIT_ERROR_SAP";
export const IMPORT_FILE_FORM_SUBMIT_SUCCESS = "IMPORT_FILE_FORM_SUBMIT_SUCCESS_SAP";
export const IMPORT_FILE_FORM_DELETE = "IMPORT_FILE_FORM_DELETE_SAP";

export type AttachmentFormSubmit = {
    type: "IMPORT_FILE_FORM_SUBMIT_SAP",
    attachment: any,
    file: File | null
};

export const importFileFormSubmit =
    (file: File | null): AttachmentFormSubmit => ({
    	"type": "IMPORT_FILE_FORM_SUBMIT_SAP",
    	file
    });
export type ImportFileError = {
    type: "IMPORT_FILE_FORM_SUBMIT_ERROR_SAP",
    message: string
};
export type ImportFileSuccess = {
    type: "IMPORT_FILE_FORM_SUBMIT_SUCCESS_SAP",
    response: any
};
export const INPUT_NAME_SAP = "file_funding_request_SAP";
export const STORE_NAME = "importFile";
export const ToKB = 1024;
export const importFileSuccess = (response: any): ImportFileSuccess => ({
	"type": "IMPORT_FILE_FORM_SUBMIT_SUCCESS_SAP",
	response
});
export const importFileError = (message: string): ImportFileError => ({
	"type": "IMPORT_FILE_FORM_SUBMIT_ERROR_SAP",
	message
});