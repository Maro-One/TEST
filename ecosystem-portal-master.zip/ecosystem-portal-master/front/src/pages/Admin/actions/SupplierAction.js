//import type { SupplierProps } from "../types/TypesSuppliers";

export const FETCH_SUPPLIERS_EXPORT = "FETCH_SUPPLIERS_EXPORT";
export const FETCH_SUPPLIERS_EXPORT_SUCCESS = "FETCH_SUPPLIERS_EXPORT_SUCCESS";
export const FETCH_SUPPLIERS_EXPORT_FAILURE = "FETCH_SUPPLIERS_EXPORT_FAILURE";

export type FetchSuppliersExportAction = {
	type: typeof FETCH_SUPPLIERS_EXPORT,
};

export type FetchSuppliersExportSuccessAction = {
	type: typeof FETCH_SUPPLIERS_EXPORT_SUCCESS,
	file: any
};

export type FetchSuppliersExportFailureAction = {
	type: typeof FETCH_SUPPLIERS_EXPORT_FAILURE
};

export const fetchSuppliersExport = (): FetchSuppliersAction => ({
	type: FETCH_SUPPLIERS_EXPORT,
});

export const fetchSuppliersExportSuccess = ({
	file
}: {
	//suppliers: SupplierProps[],
}): FetchSuppliersExportFailureAction => ({
	type: FETCH_SUPPLIERS_EXPORT_SUCCESS,
	file
});

export const fetchSuppliersExportFailure = (): FetchSuppliersFailureAction => ({
	type: FETCH_SUPPLIERS_EXPORT_FAILURE
});

export type SuppliersAction =
	| FetchSuppliersExportAction
	| FetchSuppliersExportSuccessAction
	| FetchSuppliersExportFailureAction;
