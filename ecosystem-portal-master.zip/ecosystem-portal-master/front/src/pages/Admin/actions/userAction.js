import type { UserProps } from "../types/Types";

export const FETCH_USERS = "FETCH_USERS";
export const FETCH_USERS_SUCCESS = "FETCH_USERS_SUCCESS";
export const FETCH_USERS_FAILURE = "FETCH_USERS_FAILURE";

export type FetchUsersAction = {
	type: typeof FETCH_USERS,
};

export type FetchUsersSuccessAction = {
	type: typeof FETCH_USERS_SUCCESS,
	users: UserProps[],
};

export type FetchUsersFailureAction = {
	type: typeof FETCH_USERS_FAILURE
};

export const fetchUsers = (): FetchUsersAction => ({
	type: FETCH_USERS,
});

export const fetchUsersSuccess = ({
	users,
}: {
	users: UserProps[],
}): FetchUsersSuccessAction => ({
	type: FETCH_USERS_SUCCESS,
	users
});

export const fetchUsersFailure = (): FetchUsersFailureAction => ({
	type: FETCH_USERS_FAILURE
});

export type UsersAction =
	| FetchUsersAction
	| FetchUsersSuccessAction
	| FetchUsersFailureAction;