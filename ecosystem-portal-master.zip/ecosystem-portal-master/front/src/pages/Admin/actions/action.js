export const IMPORT_FILE_FORM_SUBMIT = "IMPORT_FILE_FORM_SUBMIT";
export const IMPORT_FILE_FORM_SUBMIT_ERROR = "IMPORT_FILE_FORM_SUBMIT_ERROR";
export const IMPORT_FILE_FORM_SUBMIT_SUCCESS = "IMPORT_FILE_FORM_SUBMIT_SUCCESS";
export const IMPORT_FILE_FORM_DELETE = "IMPORT_FILE_FORM_DELETE";

export type AttachmentFormSubmit = {
    type: "IMPORT_FILE_FORM_SUBMIT",
    attachment: any,
    file: File | null
};

export const importFileFormSubmit =
    (file: File | null): AttachmentFormSubmit => ({
    	"type": "IMPORT_FILE_FORM_SUBMIT",
    	file
    });
export type ImportFileError = {
    type: "IMPORT_FILE_FORM_SUBMIT_ERROR",
    message: string
};
export type ImportFileSuccess = {
    type: "IMPORT_FILE_FORM_SUBMIT_SUCCESS",
    response: any
};
export const INPUT_NAME = "funding_request_file";
export const STORE_NAME = "importFile";
export const ToKB = 1024;
export const importFileSuccess = (response: any): ImportFileSuccess => ({
	"type": "IMPORT_FILE_FORM_SUBMIT_SUCCESS",
	response
});
export const importFileError = (message: string): ImportFileError => ({
	"type": "IMPORT_FILE_FORM_SUBMIT_ERROR",
	message
});