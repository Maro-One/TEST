import React from "react";
import { useDispatch , useSelector} from "react-redux";
import { fetchSuppliersExport } from "../actions/SupplierAction";
import { StyledSendButton } from "../components/Buttons";



const ExportSuppliers =()=>{
	const dispatch = useDispatch();	
	const { status } = useSelector(
		({ suppliersExportReducer }) => ({
			status: suppliersExportReducer?.status,
		})
	);

	
	const ExportSuppliersToExcel = async ()=>{ 
		dispatch(fetchSuppliersExport());      
	}
	if (status === "LOADING"){
		return(
			<StyledSendButton>
				{"File Exporting..."}
			</StyledSendButton>
		)
	}else {
		return(
			<StyledSendButton onClick={ExportSuppliersToExcel}>
				{"Export suppliers / Requests"}
			</StyledSendButton>
		)
	}
}
export default ExportSuppliers;

