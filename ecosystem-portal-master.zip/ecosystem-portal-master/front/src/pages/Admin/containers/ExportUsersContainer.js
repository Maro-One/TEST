// @flow
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers } from "../actions/userAction";
import { StyledSendButton } from "../components/Buttons";

const ExportUsersContainer =()=>{

	const dispatch = useDispatch();	
	const { status } = useSelector(
		({ users }) => ({
			status: users?.status,
		})
	);

	
	const ExportUsersToExcel = async ()=>{ 
		dispatch(fetchUsers());      
	}
	if (status === "LOADING"){
		return(
			<StyledSendButton>
				{"File Exporting..."}
			</StyledSendButton>
		)
	}else {
		return(
			<StyledSendButton onClick={ExportUsersToExcel}>
				{"Export users"}
			</StyledSendButton>
		)
	}
}
export default ExportUsersContainer;


