// @flow

import React from "react";
import {useHistory} from "react-router";
import {StyledSendButton} from "../components/Buttons";
import Grid from "@material-ui/core/Grid";
import ExportUsersContainer from "./ExportUsersContainer";
//import ExportSuppliers from "./ExportSuppliers";

const AdminPage = () => {
	const history = useHistory();
	const openImportUsers = () => {
		history.push("/users-import");
	};
	const openImportRequestsSAP = () => {
		history.push("/requests-import-sap");
	};
	const openImportRequests = () => {
		history.push("/requests-import");
	};
	return <Grid
		direction={"row"}
		justify={"center"}
		spacing={2}
		style={{padding: "2rem"}}
		container
	>
		{/* <Grid item>
			<ExportSuppliers/>
		</Grid> */}
		<Grid item>
			<StyledSendButton onClick={openImportUsers}>
				{"Import users"}
			</StyledSendButton>
		</Grid>
		<Grid item>
			<StyledSendButton onClick={openImportRequestsSAP}>
				{"Import requests sap"}
			</StyledSendButton>
		</Grid>
		<Grid item>
			<StyledSendButton onClick={openImportRequests}>
				{"Import requests"}
			</StyledSendButton>
		</Grid>
		<Grid item>
			<ExportUsersContainer/>
		</Grid>
	</Grid>;
};

export default AdminPage;
