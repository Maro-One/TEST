// @flow

import React from "react";
import {connect} from "react-redux";

import {change} from "redux-form";
import InputFile from "../../../common/UploadFile";


/*
 * Todo : move in a common file because it's a config attribute
 */

const INPUT_NAME_SAP = "file_funding_request_SAP";
const isEmpty = (attachement) => Boolean(attachement);
type Props = {
    fieldName: string;
    fileAttchment: any;
    inputkey: number
}
/* eslint-disable react/no-set-state */
const UploadFileContainerSAP = ({fieldName, fileAttchment, inputkey}: Props) => (

	<InputFile
		fieldName={fieldName}
		handleFileUpload={change}
		haveFile={isEmpty(fileAttchment) && isEmpty(fileAttchment.values) && isEmpty(fileAttchment.values[INPUT_NAME_SAP])}
		inputkey={inputkey}
	/>
);

const mapStateToProps = (state) => ({"fileAttchment": state.form.newAttachment});
const mapDispatchToProps = {"restFormFile": change};

export default connect(mapStateToProps, mapDispatchToProps)(UploadFileContainerSAP);

