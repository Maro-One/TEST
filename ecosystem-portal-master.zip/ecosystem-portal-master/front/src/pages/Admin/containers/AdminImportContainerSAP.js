/* eslint-disable */
// @flow
import * as React from "react";
import AdminImportSap from "../components/AdminImportSap";
import { change, reduxForm } from "redux-form";
import { connect } from "react-redux";
import { importFileFormSubmit, INPUT_NAME_SAP, STORE_NAME } from "../actions/actionSap"
import FormattedMessage from "react-intl/lib/components/message";
import CustomTable from "../../../common/CustomTable";
import MessageTableCellComponent from "../../../common/MessageTableCell/MessageTableCell"; // Import new message cell component

type Props = {
    restFormFile: Function,
    importFileFormSubmit: Function,
    deleteResponse: Function,
    importFundingRequestFile: any,
    erorr: any,
    status: "SUCCESS" | "ERROR" | "LOADING" | "",
    importResponse: any,
};
const showInStatus = (status) => (status !== "" && status !== "ERROR")
const AdminImportContainerSAP = ({
    restFormFile,
    importFundingRequestFile,
    importFileFormSubmit,
    importResponse,
    deleteResponse,
    erorr, status
}: Props) => {


    const handleOnSubmit = () => {
        importFileFormSubmit(
            ((importFundingRequestFile !== undefined && importFundingRequestFile.values !== undefined && importFundingRequestFile.values[INPUT_NAME_SAP])
                ? importFundingRequestFile.values[INPUT_NAME_SAP][0]
                : null),
        );
    }

     // Adjust column widths dynamically
  const thead = [
    {
      id: "agencyIDString", 
      label: (
        <FormattedMessage
          id="agencyIDString"
          defaultMessage="Agency ID"
        />
      ),
      width: "15%" // Adjusting width
    },
    {
      id: "CommandeID", 
      label: (
        <FormattedMessage
          id="CommandeID"
          defaultMessage="Commande ID"
        />
      ),
      width: "15%" // Adjusting width
    },
    {
      id: "message", 
      label: (
        <FormattedMessage
          id="message"
          defaultMessage="Message"
        />
      ),
      width: "40%" // Increase width for messages
    },
    {
      id: "ContractID", 
      label: (
        <FormattedMessage
          id="ContractID"
          defaultMessage="Contract ID"
        />
      ),
      width: "15%" // Adjusting width
    },
    {
      id: "saved", 
      label: (
        <FormattedMessage
          id="saved"
          defaultMessage="Saved"
        />
      ),
      width: "15%" // Adjusting width
    },
  ];



  const trows = importResponse && importResponse.map((i) => ({
    agencyIDString: <strong>{i.agencyIDString}</strong>,
    CommandeID: <strong>{i.commandeID}</strong>,
    message: i.message, // Pass raw message text, it will be handled by MessageTableCellComponent
    ContractID: <strong>{i.contractID}</strong>,
    saved: <strong>
      {i.saved ? (
        <FormattedMessage
          id="saved"
          defaultMessage="Saved"
        />
      ) : (
        <FormattedMessage
          id="not.saved"
          defaultMessage="Not saved"
        />
      )}
    </strong>,
  }));

    return (
        <React.Fragment>
            <AdminImportSap
                onSubmit={handleOnSubmit}
                importFundingRequestFile={importFundingRequestFile}
                restFormFile={restFormFile}
                deleteResponse={deleteResponse}

            />
            <div>
                {showInStatus(status) && <CustomTable dataStatus={status} thead={thead} trows={trows} />}
                {erorr &&
                    <FormattedMessage defaultMessage="une erreur est survenue. veuillez réessayer plus tard"
                        id="import.file.error"
                    />

                }
            </div>
        </React.Fragment>
    );
};

const mapStateToProps = (store) => ({
    "importFundingRequestFile": store.form.importFile,
    "importResponse": store.uploadFileReducer.response,
    "erorr": store.uploadFileReducer.error,
    "status": store.uploadFileReducer.status

});

const mapDispatchToProps = {
    "restFormFile": change,
    "importFileFormSubmit": importFileFormSubmit,
    "deleteResponse": () => ({ type: "IMPORT_FILE_FORM_DELETE" })
};

const ConnectedAdminImportContainer = connect(mapStateToProps, mapDispatchToProps)(AdminImportContainerSAP);
export default reduxForm({ "form": STORE_NAME })(ConnectedAdminImportContainer);
