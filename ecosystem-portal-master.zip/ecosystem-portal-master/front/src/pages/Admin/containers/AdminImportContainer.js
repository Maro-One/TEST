// @flow
import * as React from "react";
import AdminImport from "../components/AdminImport";
import {change, reduxForm} from "redux-form";
import {connect} from "react-redux";
import {importFileFormSubmit, INPUT_NAME, STORE_NAME} from "../actions/action"
import FormattedMessage from "react-intl/lib/components/message";
import CustomTable from "../../../common/CustomTable";

type Props = {
    restFormFile: Function,
    importFileFormSubmit: Function,
    deleteResponse: Function,
    importFundingRequestFile: any,
    erorr: any,
    status: "SUCCESS" | "ERROR" | "LOADING" | "",
    importResponse: any,
};
const showInStatus = (status) => (status !== "" && status !== "ERROR")
const AdminImportContainer = ({
	restFormFile,
	importFundingRequestFile,
	importFileFormSubmit,
	importResponse,
	deleteResponse,
	erorr, status
}: Props) => {


	const handleOnSubmit = () => {
		importFileFormSubmit(
			((importFundingRequestFile !== undefined && importFundingRequestFile.values !== undefined && importFundingRequestFile.values[INPUT_NAME])
				? importFundingRequestFile.values[INPUT_NAME][0]
				: null),
		);
	}
	const thead = [
		{
			id: "agencyIDString", label:
                <FormattedMessage
                	id="agencyIDString"
                	defaultMessage="Agency Id"
                />
		},
		{
			id: "message", label:
                <FormattedMessage
                	id="message"
                	defaultMessage="Message"
                />
		},
		{
			id: "operationUnit", label:
                <FormattedMessage
                	id="operationUnit"
                	defaultMessage="Operation Unit"
                />

		},
		{
			id: "orderReference", label:
                <FormattedMessage
                	id="orderReference"
                	defaultMessage="Order Reference"
                />

		},
		{
			id: "saved", label:
                <FormattedMessage
                	id="saved"
                	defaultMessage="Saved"
                />

		},
	];
	const trows = importResponse && importResponse.map((i) => ({
		agencyIDString: <strong>{i.agencyIDString}</strong>,
		message: <strong>{i.message}</strong>,
		operationUnit: <strong>{i.operationUnit}</strong>,
		orderReference: <strong>{i.orderReference}</strong>,
		saved: <strong>{i.saved ? <FormattedMessage
			id="saved"
			defaultMessage="saved"
		/> :
			<FormattedMessage
				id="not.saved"
				defaultMessage="not saved"
			/>}</strong>,
	}));
	return (
		<React.Fragment>
			<AdminImport
				onSubmit={handleOnSubmit}
				importFundingRequestFile={importFundingRequestFile}
				restFormFile={restFormFile}
				deleteResponse={deleteResponse}

			/>
			<div>
				{showInStatus(status) && <CustomTable dataStatus={status} thead={thead} trows={trows}/>}
				{erorr &&
                <FormattedMessage defaultMessage="une erreur est survenue. veuillez réessayer plus tard"
                	id="import.file.error"
                />

				}
			</div>
		</React.Fragment>
	);
};

const mapStateToProps = (store) => ({
	"importFundingRequestFile": store.form.importFile,
	"importResponse": store.uploadFileReducer.response,
	"erorr": store.uploadFileReducer.error,
	"status": store.uploadFileReducer.status

});

const mapDispatchToProps = {
	"restFormFile": change,
	"importFileFormSubmit": importFileFormSubmit,
	"deleteResponse": () => ({type: "IMPORT_FILE_FORM_DELETE"})
};

const ConnectedAdminImportContainer = connect(mapStateToProps, mapDispatchToProps)(AdminImportContainer);
export default reduxForm({"form": STORE_NAME})(ConnectedAdminImportContainer);
