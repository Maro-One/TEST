import AdminImportSap from "./containers/AdminImportContainerSAP";

export default AdminImportSap;