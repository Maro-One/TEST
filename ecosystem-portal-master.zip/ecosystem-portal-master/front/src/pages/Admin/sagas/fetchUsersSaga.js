// @flow
import { takeLatest } from "redux-saga/effects";
import type { Saga } from "redux-saga";
import { fetchUsersFailure, fetchUsersSuccess, FETCH_USERS } from "../actions/userAction";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";

// eslint-disable-next-line require-jsdoc
const fetchUsersSaga = function* () {
	let url = "/api/export-users";
	yield* callEndpoint(
		{
			url,
			method: "get",
			responseType: "blob",
		},
		{
			dataTransform: (resp) => ({
				users: resp
			}),
			successActionCreator: fetchUsersSuccess,
			errorActionCreator: fetchUsersFailure,
		}
	);
};

// eslint-disable-next-line require-jsdoc
export default function* (): Saga<void> {
	yield takeLatest(FETCH_USERS, fetchUsersSaga);
}
