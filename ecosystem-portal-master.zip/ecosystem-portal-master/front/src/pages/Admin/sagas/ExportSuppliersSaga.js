/* eslint-disable */
import { takeLatest } from "redux-saga/effects";
import type { Saga } from "redux-saga";
import { fetchSuppliersExportFailure, fetchSuppliersExportSuccess, FETCH_SUPPLIERS_EXPORT } from "../actions/SupplierAction";
import { callEndpoint } from "../../../store/sagas/callEndpointSaga";

// eslint-disable-next-line require-jsdoc
const ExportSuppliersSaga = function* () {
	let url = "/api/supplier/export-suppliers";
	yield* callEndpoint(
		{
			url,
			method: "get",
            responseType: "blob",
		},
		{
			dataTransform: (resp) => ({
				file: resp
			}),
			successActionCreator: fetchSuppliersExportSuccess,
			errorActionCreator: fetchSuppliersExportFailure,
		}
	);
};

// eslint-disable-next-line require-jsdoc
export default function* (): Saga<void> {
	yield takeLatest(FETCH_SUPPLIERS_EXPORT, ExportSuppliersSaga);
}
