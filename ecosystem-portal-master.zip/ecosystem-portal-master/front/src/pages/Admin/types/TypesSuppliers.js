export type SuppliersStoreType = {
    status: "SUCCESS" | "ERROR" | "LOADING",
  };
