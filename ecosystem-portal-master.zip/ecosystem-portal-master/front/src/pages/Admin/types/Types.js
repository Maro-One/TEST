export type UserProps = {
    firstName: string,
    lastName: string,
    roleLabel: string,
    email: string,
    lastAttempt: string,
  };
  
export type UsersStoreType = {
    users: UserProps[],
    status: "SUCCESS" | "ERROR" | "LOADING",
  };