import AdminImport from "../AdminImport";
import * as React from "react";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { reduxForm } from "redux-form";
import { screen, render } from "@testing-library/react";
import {INPUT_NAME} from "../../actions/action";

import "@testing-library/jest-dom"

const mockStore = configureStore([]);

// dans votre test :
describe("AdminImport component", () => {
	let store;

	beforeEach(() => {
	  store = mockStore({
		
			form: {
			  importFile: {
					registeredFields: {
				  users_file: {
							name: "users_file",
							type: "Field",
							count: 1
				  }
					},
					values: {
				  users_file: {
							"0": {}
				  }
					}
			  }
			},
			suppliers: {
			  status: "LOADING",
			  page: 0,
			  perPage: 10,
			  suppliers: {},
			  count: 0
			},
			search: {
			  options: [],
			  loading: false,
			  success: null,
			  error: null
			},
			purchaseOrder: {
			  purchaseOrder: {
					details: {},
					status: "LOADING"
			  },
			  invoices: {
					page: 0,
					invoices: {},
					count: 0,
					perPage: 10,
					status: "LOADING",
					sort: {
				  by: "dueDate",
				  order: "desc"
					},
					filter: {
				  list: [],
				  selectedValue: null
					}
			  },
			  attachments: {
					page: 0,
					attachments: {},
					count: 0,
					perPage: 10,
					status: "LOADING",
					sort: {
				  by: "updatedDate",
				  order: "desc"
					}
			  },
			  invoicesTimeline: {
					timeline: []
			  }
			},
			supplierDetail: {
			  supplierInfo: {
					data: null,
					loading: false,
					success: false,
					error: null
			  },
			  supplierScorings: {
					data: [],
					loading: false,
					success: false,
					error: null
			  },
			  purchaseOrders: {
					data: {
				  list: [],
				  count: 0,
				  page: 0
					},
					loading: false,
					success: false,
					error: null
			  }
			},
			resetPassword: {
			  response: null
			},
			user: {
			  user: null,
			  token: "Bearer eyJhbGciOiJIUzUxMiJ9.eyJleHAiOjE2NTMzODcxNzEsInVzZXIiOnsibG9naW4iOiJvdW1haW1hLnNiYWkifSwiaWF0IjoxNjUzMzAwNzcxfQ."+
			  +"eqRP8Iyw-b-X9cd9JoyqSLLh1wU_OPd7YxqIbIVdjc1FkhB1TLNcplIN2GqyWKzAPdwtLFhrZHwT0kdFxUBM7g",
			  isLoading: false,
			  exp: 1653387171,
			  roleLabel: "ROLE_ADMIN",
			  error: "error",
			  httpStatus: 500,
			  agency: "Finéa",
			  firstName: "Oumaima",
			  lastName: "Sbai"
			},
			changePassword: {
			  status: "SUCCESS"
			},
			captcha: {
			  data: {
					image: "",
					entryCode: ""
			  },
			  status: ""
			},
			uploadFileReducer: {
			  status: ""
			},
			usersImport: {
			  status: ""
			},
			_persist: {
			  version: -1,
			  rehydrated: true
			}
		  
	  });
	});
	it("should be handling checkboxChecked", () => {
		const key =INPUT_NAME;   

		const props =  {
			"importFundingRequestFile" : {
				values: {
					[key]: 
					[
						{
							name: "users.xls",
							size: 59,
							type: "Unknown",
							webkitRelativePath: "",
						}
					]
				}
			}
		}
		

		// eslint-disable-next-line react/prop-types
		const Wrapper = ({ children }) => (
			<Provider store={store}>{children}</Provider>
		);
		const Cpt = reduxForm({
			form: "form"
		  })(AdminImport);

		render(<Cpt {...props}/>, { wrapper: Wrapper });


		expect(screen.getByTestId("paper")).toBeInTheDocument();
		expect(screen.getByText("error")).toBeInTheDocument();

	});
});