import {withStyles} from "@material-ui/core";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import CloseIcon from "@material-ui/icons/Close";

export const StyledSendButton = withStyles({
	"root": {
		"color": "#fff",
		"background-color": "#7bcb09",
		"borderRadius": "4px",
		"border": "1px solid #7bcb09",
		"&:disabled": {
			"color": "#8092a5",
			"borderRadius": "4px",
			"border": "solid 1px #dae0e6",
			"background-color": "unset"
		},
		"&:hover": {"background-color": "#7bcb09"}
	}
})(Button);
export const StyledIconButton = withStyles({
	"root": {
		"backgroundColor": "#f3f3f3",
		"border": "none",
		"color": "#c5cbdb",
		"fontSize": "10px",
		"minWidth": "18px",
		"width": "22px",
		"height": "22px"
	}
})(IconButton);
export const StyledDeletIcon = withStyles({
	"root": {
		"width": "15px!important",
		"height": "15px!important"
	}
})(CloseIcon);
