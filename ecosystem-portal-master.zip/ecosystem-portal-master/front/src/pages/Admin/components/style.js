import {createStyles} from "@material-ui/core";
const spacing1 = 3;
const spacing2 = 4;
const style =(theme) => createStyles({
	"root": {
		"padding": theme.spacing(spacing1, spacing2),
		"width": "560px"
	},
	"textFieldLabel": {
		"fontSize": "12px",
		"color": "#8092a5",
		"verticalAlign": "super"
	},
	"textField": {
		"height": "38px",
		"width": "90%"
	},
	"searchIcon": {
		"color": "#8092a5",
		"width": "20px"
	},
	"resize": {"fontSize": 12},
	"centerContainer": {"textAlign": "center"},
	"subtitle1": {"fontSize": 12},
	"container": {
		"width": "496px",
		"margin": "5px auto 0",
		"minHeight": "50px",
		"padding": "13px"
	}
});
export default style;
