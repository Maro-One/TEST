// @flow

import {
	IMPORT_FILE_FORM_DELETE,
	IMPORT_FILE_FORM_SUBMIT,
	IMPORT_FILE_FORM_SUBMIT_ERROR,
	IMPORT_FILE_FORM_SUBMIT_SUCCESS
} from "../actions/actionSap";

type StateType = {
    status: "SUCCESS" | "ERROR" | "LOADING" | ""
};

const InitialState: StateType = {
	status: ""
};

export default function (state: StateType = InitialState, action: any): Object {
	switch (action.type) {
		case IMPORT_FILE_FORM_SUBMIT:
			return {...state, status: "LOADING"};
		case IMPORT_FILE_FORM_SUBMIT_ERROR:
			return {
				...state,
				status: "ERROR",
				error: action.response
			};
		case IMPORT_FILE_FORM_SUBMIT_SUCCESS:
			return {
				...state,
				status: "SUCCESS",
				response: action.response
			};
		case IMPORT_FILE_FORM_DELETE:
			return InitialState;
		default:
			return state;
	}
};

