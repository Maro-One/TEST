// @flow
import type { UsersStoreType } from "../types/Types";
import { FETCH_USERS, FETCH_USERS_FAILURE, FETCH_USERS_SUCCESS } from "../actions/userAction";

const DEFAULT_STATE: UsersStoreType = {
	status: "SUCCESS",
};

// eslint-disable-next-line require-jsdoc
export default function (
	state: UsersStoreType = DEFAULT_STATE,
	action
) {
	switch (action.type) {
		case FETCH_USERS:
			return Object.assign({}, state, {
				status: "LOADING"
			});
		case FETCH_USERS_SUCCESS:
			const href = URL.createObjectURL(action.users);

			// create "a" HTML element with href to file & click
			const link = document.createElement("a");
			link.href = href;
			link.setAttribute("download", "Users_Export.xlsx"); //or any other extension
			document.body.appendChild(link);
			link.click();

			// clean up "a" element & remove ObjectURL
			document.body.removeChild(link);
			URL.revokeObjectURL(href);
			return { ...state, status: "SUCCESS" };
		case FETCH_USERS_FAILURE:
			return Object.assign({}, state, {
				status: "ERROR"
			});
		default:
			return state;
	}
}
