import type { SuppliersStoreType } from "../types/TypesSuppliers";
import { FETCH_SUPPLIERS_EXPORT,  FETCH_SUPPLIERS_EXPORT_FAILURE, FETCH_SUPPLIERS_EXPORT_SUCCESS } from "../actions/SupplierAction";

const DEFAULT_STATE: SuppliersStoreType = {
	status: "SUCCESS"
};

// eslint-disable-next-line require-jsdoc
export default function (
	state: SuppliersStoreType = DEFAULT_STATE,
	action
) {
	switch (action.type) {
		case FETCH_SUPPLIERS_EXPORT:
			return Object.assign({}, state, {
				status: "LOADING"
			});
		case FETCH_SUPPLIERS_EXPORT_SUCCESS:
			const href = URL.createObjectURL(action.file);

			// create "a" HTML element with href to file & click
			const link = document.createElement("a");
			link.href = href;
			link.setAttribute("download", "Supplier_Request_Export.xlsx"); //or any other extension
			document.body.appendChild(link);
			link.click();

			// clean up "a" element & remove ObjectURL
			document.body.removeChild(link);
			URL.revokeObjectURL(href);
			return { ...state, status: "SUCCESS" };
		case FETCH_SUPPLIERS_EXPORT_FAILURE:
			return Object.assign({}, state, {
				status: "ERROR"
			});
		default:
			return state;
	}
}
