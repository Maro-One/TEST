import AdminImport from "./containers/AdminImportContainer";

export default AdminImport;
