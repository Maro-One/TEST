// @flow

export type StatusType = "SUCCESS" | "ERROR" | "LOADING";

export type HttpResponseType = {
	httpStatus?: ?number,
	error?: ?string,
	type: ?("ERROR" | "INFO")
};
