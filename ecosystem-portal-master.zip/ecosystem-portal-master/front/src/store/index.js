import createSagaMiddleware from "redux-saga";
import rootReducer from "./reducers";
import rootSaga from "./sagas";
import { applyMiddleware, createStore } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import { persistStore } from "redux-persist";

const sagaMiddleware = createSagaMiddleware();

function configureStore(preloadedState) {
	const middlewares = [sagaMiddleware];
	const middlewareEnhancer = applyMiddleware(...middlewares);
	const enhancers = [middlewareEnhancer];
	const composedEnhancers = composeWithDevTools(...enhancers);

	const store = createStore(rootReducer, preloadedState, composedEnhancers);
	if (process.env.NODE_ENV !== "production" && module.hot) {
		module.hot.accept("./reducers", () => store.replaceReducer(rootReducer));
	}
	sagaMiddleware.run(rootSaga);
	return store;
}
const store = configureStore(undefined);

export const persistor = persistStore(store);
export default store;
