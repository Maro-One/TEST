// @flow

export type ActionWithoutPayloadType<T> = {|
  type: T
|};

export type ActionWithPayloadType<T, P> = {|
  type: T,
  payload: P
|};


export type ERROR_TYPE = { error: string };
