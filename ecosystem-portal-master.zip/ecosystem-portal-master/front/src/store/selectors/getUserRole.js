// @flow

/*
 * Selector to retrieve the user role
 */
import type {UserRole} from "../../utils/UserRole";

const getUserRole = (state: {user: {roleLabel: UserRole}}): UserRole => state.user.roleLabel;

export default getUserRole;
