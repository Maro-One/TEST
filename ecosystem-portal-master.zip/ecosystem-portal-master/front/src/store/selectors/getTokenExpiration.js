// @flow

/*
 * Selector to retrieve the user token expiration
 */
const getTokenExpiration = (state: {user: {exp: number}}): number => state.user.exp;

export default getTokenExpiration;
