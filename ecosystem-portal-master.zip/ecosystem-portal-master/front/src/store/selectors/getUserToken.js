// @flow

/*
 * Selector to retrieve the user token
 */
const getUserToken = (state: {user: {token: string}}): string => (state.user.token);
export default getUserToken;
