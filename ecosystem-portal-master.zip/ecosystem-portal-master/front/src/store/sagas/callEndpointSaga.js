// @flow
import { call, put, select } from "redux-saga/effects";
import type { RequestConfig } from "../../utils/helper";
import { request } from "../../utils/helper";
import getUserToken from "../selectors/getUserToken";
import { toast } from "react-toastify";
import type { Saga } from "redux-saga";
import { logUserOut } from "../../pages/LoginPage/actions";
import getTokenExpiration from "../selectors/getTokenExpiration";
import history from "../../utils/history";

type ActionConfig = {
	dataTransform?: Function,
	successActionCreator: Function,
	errorActionCreator: Function
};

/*
 *  Check token expiration and logout
 * */
function* checkTokenExpiration() {
	const exp = yield select(getTokenExpiration);
	if (!exp) {
		return;
	}
	const currentTimestampInSec = Date.now() / 1000;
	if (exp <= currentTimestampInSec) {
		yield call(toast, "Votre session a expiré", { type: toast.TYPE.WARNING });
		yield put(logUserOut);
	}
}

const BAD_REQUEST = 400;
const UNAUTHORIZED = 401;
const FORBIDDEN = 403;

export function* callEndpoint(
	endpointConfig: RequestConfig,
	{
		dataTransform = data => data,
		successActionCreator,
		errorActionCreator
	}: ActionConfig
): Saga<void> {
	const token = yield select(getUserToken);
	const headers = {};
	if (token) {
		headers.Authorization = `${token}`;
	}
	try {
		const options = {
			...endpointConfig,
			headers
		};
		const requestCall = call(request, options);
		const response = yield requestCall;
		yield put(successActionCreator(dataTransform(response.data)));
	} catch (error) {
		if (
			token &&
			error.response &&
			(error.response.status === UNAUTHORIZED ||
				error.response.status === FORBIDDEN)
		) {
			yield* checkTokenExpiration();
		}
		if (
			error.response.status === UNAUTHORIZED ||
			error.response.status === FORBIDDEN ||
			error.response.status === BAD_REQUEST
		) {
			yield call(history.push, "/404");
		} else {
			yield call(toast, "Internal Server Error", {
				type: toast.TYPE.INFO
			});
		}
		yield put(errorActionCreator("error"));
	}
}
