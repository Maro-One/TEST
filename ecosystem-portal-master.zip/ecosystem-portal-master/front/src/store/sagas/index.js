import { all } from "redux-saga/effects";
import loginSaga from "../../pages/LoginPage/sagas";
import fetchSupplierSaga from "../../pages/SuppliersPage/store/sagas/fetchSupplierSaga";
import resetPasswordRequest from "../../pages/ResetPasswordPage/store/sagas";
import {
	watchGetPurchaseOrders,
	watchGetSupplierInfo,
	watchGetSupplierScoring,
	watchValidatePurchaseOrder, watchRefusePurchaseOrder
} from "../../pages/SupplierDetailPage/sagas";
import fetchPurchaseOrderDetailsSaga from "../../pages/PurchaseOrderPage/sagas/fetchPurchaseOrderDetails";
import fetchAttachmentsSaga from "../../pages/PurchaseOrderPage/sagas/fetchAttachmentsSaga";
import fetchAppelDeCommandesSaga from "../../pages/PurchaseOrderPage/sagas/fetchAppelDeCommandesSaga";
import fetchInvoicesSaga from "../../pages/PurchaseOrderPage/sagas/fetchInvoicesSaga";
import getInvoicesTimelineSaga from "../../pages/PurchaseOrderPage/sagas/getInvoicesTimelineSaga";
import {watchSearchSupplier} from "../../pages/Search/saga";
import usersImport from "../../pages/UsersImport/sagas/usersImportSaga";
import UploadFileSaga from "../../pages/Admin/sagas/UploadFileSaga";
import UploadFileSAPSaga from "../../pages/Admin/sagas/UploadFileSAPSaga";
import {loginFailedSaga, loginSuccessSaga} from "../../config/piwikSaga";
import fetchUsersSaga from "../../pages/Admin/sagas/fetchUsersSaga";
import ExportSuppliersSaga from "../../pages/Admin/sagas/ExportSuppliersSaga";

/**
 * Grouping all saga to one saga in order to add it to the middleware
 */
export default function* () {
	yield all([
		loginSaga(),
		fetchSupplierSaga(),
		watchGetSupplierInfo(),
		watchGetSupplierScoring(),
		watchGetPurchaseOrders(),
		fetchPurchaseOrderDetailsSaga(),
		fetchAttachmentsSaga(),
		fetchAppelDeCommandesSaga(),
		fetchInvoicesSaga(),
		resetPasswordRequest(),
		watchSearchSupplier(),
		watchValidatePurchaseOrder(),
		getInvoicesTimelineSaga(),
		usersImport(),
		UploadFileSaga(),
		watchRefusePurchaseOrder(),
		loginFailedSaga(),
		loginSuccessSaga(),
		fetchUsersSaga(),
		ExportSuppliersSaga(),
		UploadFileSAPSaga()
	]);
}
