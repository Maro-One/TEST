import { combineReducers } from "redux";
import { reducer as formReducer } from "redux-form";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import loginReducer from "../../pages/LoginPage/reducer/loginReducer";
import purchaseOrderReducer from "../../pages/PurchaseOrderPage/reducer";
import resetPasswordReducer from "../../pages/ResetPasswordPage/store/reducer";
import captcha from "../../pages/ResetPasswordPage/store/reducer/captcha";
import searchReducer from "../../pages/Search/reducer";
import supplierDetailReducer from "../../pages/SupplierDetailPage/reducer";
import suppliersReducer from "../../pages/SuppliersPage/store/suppliersReducer";
import changePasswordReducer from "../../pages/ResetPasswordPage/store/reducer/changePassword";
import uploadFileReducer from "../../pages/Admin/reducer";
import usersImport from "../../pages/UsersImport/reducer";
import usersReducer  from "../../pages/Admin/reducer/usersReducer";
import suppliersExportReducer from "../../pages/Admin/reducer/suppliersExportReducer";

const persisterConfig = {
	key: "ecosystem",
	storage,
	whitelist: ["user"]
};

const combinedReducers = persistReducer(
	persisterConfig,
	combineReducers({
		form: formReducer,
		suppliers: suppliersReducer,
		search: searchReducer,
		purchaseOrder: purchaseOrderReducer,
		supplierDetail: supplierDetailReducer,
		resetPassword: resetPasswordReducer,
		user: loginReducer,
		changePassword: changePasswordReducer,
		captcha,
		uploadFileReducer,
		usersImport,
		users: usersReducer,
		suppliersExportReducer
	})
);

export default combinedReducers;
