// @flow

import {call, takeLatest} from "redux-saga/effects";
import piwik from "./piwik";
import {ERROR_FETCHING_USER_INFORMATION, SET_USER_INFORMATION} from "../pages/LoginPage/actions";


const piwikSagaGeneratorSucess = function* piwikSaga(action): Generator<any, void, any> {
	try {

		const payload = [
			"setCustomVariable",
			1,
			"name",
			`${action?.payload?.firstName} ${action?.payload?.lastName}`
			,
			"visit"
		];

		yield call(piwik.push, payload);
	} catch (error) {
		console.log(error);
	}
};
const piwikSagaGeneratorFailed = function* piwikSaga(): Generator<any, void, any> {
	try {

		const payload = [
			"trackEvent",
			"Login page",
			"Login",
			"failed"
		];
		yield call(piwik.push, payload);
	} catch (error) {
		console.log(error);
	}
};


// Piwik sagas
const loginFailedSaga = function* loginFailedSaga(): Generator<any, void, any> {
	yield takeLatest(ERROR_FETCHING_USER_INFORMATION, piwikSagaGeneratorFailed);
};

const loginSuccessSaga = function* loginSuccessSaga(): Generator<any, void, any> {
	yield takeLatest(SET_USER_INFORMATION, piwikSagaGeneratorSucess);
};

export {
	loginFailedSaga,
	loginSuccessSaga
}
