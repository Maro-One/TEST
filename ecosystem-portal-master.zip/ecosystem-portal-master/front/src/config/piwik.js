import PiwikReactRouter from "piwik-react-router";

// const PIWIK_STAGING_URL = "https://pi-analytics-stg.digilab.ocpgroup.ma/";
const PIWIK_STAGING_URL = "";

// TO-DO: add piwik production host
// const PIWIK_PROD_URL = "https://pi-analytics.ocpgroup.ma";
const PIWIK_PROD_URL = "";

const hostname = window && window.location && window.location.hostname;

let PIWIK_HOST = PIWIK_STAGING_URL;
// let PIWIK_SITE_ID=2
let PIWIK_SITE_ID=""
if (hostname && typeof hostname === "string") {
	if (hostname.indexOf("tamwil.ocpgroup.ma") >= 0) {
		PIWIK_HOST = PIWIK_PROD_URL;
		// PIWIK_SITE_ID = 16;
		PIWIK_SITE_ID = "";
	}
}

const piwik = PiwikReactRouter({
	"url": PIWIK_HOST,
	"siteId": PIWIK_SITE_ID
});

export default piwik;
