// @flow

const months = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
export const formatDate = (value: Date) => {
	if (value) {
		let date = value.getDate();
		if (date < 10) {
			date = "0"+date;
		}
		return (
			date +
			" " +
			months[value.getMonth()] +
			" " +
			value.getFullYear()
		);
	}
	return "";
};

const currency = "DH";
export const formatCurrency = (value: number) => {
	if (!value) {
		value = 0;
	}
	const parts = value.toFixed(2).toString().split(".");
	parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	return parts.join(".") + " " + currency;
};

export const formatCurrencyForContractOrCmd = (value: number,isCommande:boolean) => {
	if (!value) {
		value = 0;
	}
	if(isCommande){
		const parts = value.toFixed(2).toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
		return parts.join(".") + " " + currency;
	}
	else {
		const parts = value.toFixed(2).toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
		return value === 0 ? "_" : parts.join(".") + " " + currency;
	}
};


export const formatPercentForContractOrCmd = (value: number,isCommande:boolean) => {
	if (!value) {
		value = 0;
	}
	if(isCommande){
		return parseFloat(value * 100).toFixed(0) + " %";
	}
	else {
		return value === 0 ? "_" : parseFloat(value * 100).toFixed(0) + " %";
	}
};


export const formatPercent = (value: number) => {
	if (!value) {
		value = 0;
	}
	return parseFloat(value * 100).toFixed(0) + " %";
};

export const formatAndRoundNumber = (value: number, round: number = 2) => {
	if(!value){
		return null;
	}
	return value.toFixed(round)
};
