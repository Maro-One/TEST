// @flow

import { CANCEL } from "redux-saga";
import axios from "axios";
import colors from "./colors";
export type RequestConfig = {
	url: string,
	params?: { [string]: string | number | boolean },
	data?: any,
	method?: "get" | "post" | "put" | "delete"
};

export const request = (config: RequestConfig): Promise<any> => {
	const source = axios.CancelToken.source();

	const responsePromise = axios({
		...config,
		cancelToken: source.token
	});

	responsePromise[CANCEL] = () => source.cancel();

	return responsePromise;
};

export const truncString = (string: string, maxLength: number) => {
	if (!string) return "";
	let suffix = "";
	if (string.length > maxLength) suffix = "...";
	return string.substr(0, maxLength) + suffix;
};

export const formatStatus = (value: string): [string, string] => {
	switch (value) {
		case "REFUSED":
			return ["Refusée", colors.peachSchnapps];
		case "PENDING":
			return ["En attente",colors.pattensBlue, colors.dodgerBlue];
		case "APPROVED":
			return ["Approuvée",colors.snowyMintGreen, colors.goblinGreen];
		case "SENT_TO_AGENCY":
			return ["Envoyé à l'agence", colors.snowyMintGreen];
		default:
			return [value, colors.snowyMintGreen];
	}
};
export const formatInvoiceStatus=(value : string): [string, string, string]=> {
	switch (value) {
		case "IN_SEIZURE":
			return ["Saisie Arrêt", colors.bgColor, colors.bgColorText];
		case "IN_DEPOSIT":
			return ["Déposée", colors.pattensBlue, colors.dodgerBlue];
		case "IN_PROCESS_OF_ACCOUNTING":
			return ["En Rapprochement comptable", colors.pattensBlue, colors.dodgerBlue];
		case "IN_PROCESS_OF_APPROVAL":
			return ["En approbation", colors.pattensBlue, colors.dodgerBlue];
		case "IN_REJECTED_AFTER_SCAN":
			return ["Rejetée après SCAN", colors.peachSchnapps];
		case "IN_REJECTED":
			return ["Rejetée", colors.peachSchnapps];
		case "INVOICE_PAID":
		case "IN_PAID":
			return ["Réglée", colors.sulu, colors.christi];
		case "IN_PROGRESS":
			return ["En cours de traitement", colors.snowyMintGreen];
		case "INVOICE_CREATED":
			return ["Facture créée sur système (SAP)", colors.snowyMintGreen];
		case "IN_LITIGATION":
			return ["En litige", colors.sandyBeach];
		case "APPROVED":
			return ["Validée", colors.snowyMintGreen, colors.goblinGreen];
		case "INVOICE_PARTIALLY_PAID":
			return ["Paiement partiel", colors.snowyMintGreen, colors.goblinGreen];
		default:
			return [value, colors.snowyMintGreen];
	}
};
export const formatAttachmentStatus=(value : string): [string, string, string]=> {
	switch (value) {
		case "Accepter":
			return ["Accepter", colors.TeaGreen];
		case "Annuler":
			return ["Annuler", colors.Gainsboro];
		case "Corriger":
			return ["Corriger", colors.Cornsilk];
		case "Mettre à disposition":
			return ["Mettre à disposition", colors.pistachioGreen, colors.white];
		case "Rapprocher":
			return ["Rapprocher", colors.Almond];
		case "Réceptionner":
			return ["Réceptionner", colors.lightGreen];
		case "Rejeter":
			return ["Rejeter", colors.Flesh];
		case "Retourner au client":
			return ["Retourner au client", colors.WhiteSmoke];
		case "Retourner à la réception":
			return ["Retourner à la réception", colors.Gainsboro2];
		case "Retourner au fournisseur":
			return ["Retourner au fournisseur", colors.LightApricot];
		case "Livrer":
			return ["Livrer", colors.DarkGray];
		case "Transférer":
			return ["Transférer", colors.Salomie];
		case "Réception d'articles non commandés":
			return ["Réception d'articles non commandés", colors.GrayishYellow];	
		default:
			return [value, colors.snowyMintGreen];
	}
};
export const formatPurchaseOrderStatus = (status: string = ""): [string, string] => {
	switch (status) {
		case "APPROVED":
			return ["Approuvée", colors.snowyMintGreen];
		case "CANCELLED":
			return ["Annulée", colors.peachSchnapps];
		case "IN_PROCESS":
			return ["En cours", colors.snowyMintGreen];
		case "INCOMPLETE":
			return ["Incomplète", colors.snowyMintGreen];
		case "PRE_APPROVED":
			return ["Pré-approuvée", colors.snowyMintGreen];
		case "REJECTED":
			return ["Rejetée", colors.peachSchnapps];
		case "REQUIRES_REAPPROVAL":
			return ["Nouvelle approbation requise", colors.peachSchnapps];
		case "RETURNED":
			return ["Retournée", colors.peachSchnapps];
		case "PENDING":
			return ["En attente", colors.snowyMintGreen];
		default:
			return [status, colors.snowyMintGreen];
	}
};

const MAX_SIZE_KB = 5120000;
const AUTORISATION_TYPE: any = [
	"application/vnd.ms-excel",
	"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	"text/csv"
];
export const CheckFileValidity = (file: any) => file.size > MAX_SIZE_KB || AUTORISATION_TYPE.indexOf(file.type) < 0;

export const isNotEmpty = (attachement: any) => Boolean(attachement);

export const getDiffInDays = (startDate: Date, endDate: Date) => {
	return (endDate.getTime() - startDate.getTime()) / 86400000;
};

