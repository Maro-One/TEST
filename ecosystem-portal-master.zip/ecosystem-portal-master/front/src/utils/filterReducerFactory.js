import {SET_FILTER_VALUE} from "../pages/PurchaseOrderPage/actions/constants";

export default function filterReducerFactory(filterName: string) {

	return function filterReducer(state , action) {
		const {name} = action;
		if (name !== filterName) return state;
		return action.type === SET_FILTER_VALUE ? {
			...state,
			filter: {
				...state.filter,
				selectedValue: action.value
			}
		} : state;
	}
}


