// @flow

export const ERROR = "ERROR";
export const LOADING = "LOADING";
export const SUCCESS = "SUCCESS";
export const DESC = "desc";
export const ASC = "asc";

export const eventStatusMap = {
	IN_DESPOSIT: "eventCode.InDeposit",
	IN_REJECTED_AFTER_SCAN: "eventCode.InRejectedScan",
	IN_PROCESS_OF_ACCOUNTING: "eventCode.InProcessAccounting",
	IN_PROCESS_OF_PAYEMENT: "eventCode.InProcessPayment",
	IN_REJECTED: "eventCode.InRejected",
	INVOICE_SCANNED: "eventCode.InvScanned",
	INVOICE_CREATED: "eventCode.InvCreated",
	INVOICE_PAID: "eventCode.InvPaid",
	INVOICE_PARTIALLY_PAID: "eventCode.InvPartPaid",
	INVOICE_VALIDATED: "eventCode.InvValidated",
	IN_SEIZURE: "eventCode.InSeizure"
};
