const fonts = {
	robotoMedium: "Roboto-Medium",
	robotoRegular: "Roboto-Regular",
	robotoBold: "Roboto-Bold",
	robotoLight: "Roboto-Light",
};

export default fonts;
