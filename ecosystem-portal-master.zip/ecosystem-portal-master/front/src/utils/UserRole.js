// @flow

export const ROLE_ADMIN = "ROLE_ADMIN";
export const ROLE_BUYER = "ROLE_BUYER";
export const ROLE_AGENCY = "ROLE_AGENCY";

export type UserRole = "ROLE_ADMIN" | "ROLE_BUYER" | "ROLE_AGENCY";
