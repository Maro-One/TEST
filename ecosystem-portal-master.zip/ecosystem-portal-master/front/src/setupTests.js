// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import "@testing-library/jest-dom/extend-expect";
import ReactDOM from "react-dom";

// this is a mock for some internal libs that uses it
ReactDOM.createPortal = jest.fn((element) => {
	return element;
});
