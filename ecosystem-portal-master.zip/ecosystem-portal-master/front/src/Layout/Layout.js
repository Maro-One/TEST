import React from "react";
import { Route, Switch } from "react-router-dom";
import Footer from "../common/Footer";
import NavBar from "../common/NavBar";
import SupplierDetailPage from "../pages/SupplierDetailPage";
import SupplierDetailBuyerPage from "../pages/Buyer";
import SuppliersPage from "../pages/SuppliersPage";
import useStyles, { containerStyles } from "./styles";
import Container from "@material-ui/core/Container";
import RedirectLogin from "../pages/LoginPage/container/RedirectLogin";
import PurchaseOrderPage from "../pages/PurchaseOrderPage";
import withStyles from "@material-ui/core/styles/withStyles";
import NoMatch from "../pages/NoMatch";
import { useSelector } from "react-redux";
import getUserRole from "../store/selectors/getUserRole";
import { ROLE_ADMIN, ROLE_AGENCY, ROLE_BUYER } from "../utils/UserRole";
import AdminImport from "../pages/Admin";
import AdminImportSap from "../pages/Admin/indexSAP";
import ImportUsers from "../pages/UsersImport";
import AdminPage from "../pages/Admin/containers/AdminPage";

const StyledContainer = withStyles(containerStyles)(Container);

const Layout = () => {
	const userRole = useSelector(getUserRole);
	const classes = useStyles();
	return (
		<RedirectLogin >
			<div className={classes.container}>
				<NavBar />
				<StyledContainer>
					<Switch>
						{userRole === ROLE_BUYER && <Route
							exact
							path="/"
							component={SupplierDetailBuyerPage}
						/>}
						{userRole === ROLE_ADMIN &&
							<>
								<Route
									exact
									path="/"
									component={AdminPage}
								/>
								<Route
									exact
									path="/requests-import-sap"
									component={AdminImportSap}
								/>
								<Route
									exact
									path="/requests-import"
									component={AdminImport}
								/>
								<Route
									exact
									path="/users-import"
									component={ImportUsers}
								/>
							</>}
						{userRole === ROLE_AGENCY &&
							<>
								<Route
									exact
									path="/"
									component={SuppliersPage}
								/>
								<Route
									exact
									path="/supplier/:bravoId"
									component={SupplierDetailPage}
								/>
								<Route
									exact
									path="/order/:purchaseOrderId/:bravoId/:requestId/:requestSource"
									component={PurchaseOrderPage}
								/>
							</>
						}
						<Route path="*">
							<NoMatch />
						</Route>
					</Switch>
				</StyledContainer>
				<Footer />
			</div>
		</RedirectLogin>
	);
};

export default Layout;
