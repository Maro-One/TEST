import {makeStyles} from "@material-ui/core/styles";
import colors from "../utils/colors";

const useStyles = makeStyles({
	container: {
		minHeight: "100%",
		display: "flex",
		flexDirection: "column",
		padding: "0 !important",
	}
});
export const containerStyles = {
	root: {
		backgroundColor: colors.white,
		margin: "32px auto",
		padding: "0",
		boxShadow: "0 6px 8px 0 rgba(0,0,0,0.05)",
		flexGrow: 100
	}
};
export default useStyles;
